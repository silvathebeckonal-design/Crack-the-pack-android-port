# Crack the Pack Arcade

A retro pixel-art launcher for **Crack the Pack**, the card pack opening game.
The web build plays full-screen in the browser behind a curved CRT screen, and
the same game ships as an Android app.

## Features

- CRT screen with an adjustable bulge (Settings → Bulge), smooth scanlines and
  clicks that follow the curve
- Scrolling board background, 9-slice frames and a pixel-art cursor taken from
  the original game
- One background track at a time; sound effects play independently
- Android saves stored in a folder you choose (`Documents/Crack-The-Pack/Saves`),
  so progress survives reinstalling

## Run the web version

You need Node.js 20+ (or Bun).

```sh
npm install
npm run dev
```

Then open http://localhost:8080. The game itself lives in `public/ctp/`
(`public/ctp/assets/game.js`); the page at `/` shows it full-screen.

```sh
npm test        # game and save tests
npm run build   # production build
```

## Android app

Download the latest signed APK from the
[Releases page](../../releases). On first launch the app asks for a save
folder: pick or create `Documents/Crack-The-Pack/Saves`. Existing saves are
migrated automatically.

To build the APK yourself you need JDK 17 and the Android SDK with
`build-tools;34.0.0` and `platforms;android-34`:

```sh
ANDROID_SDK=/path/to/sdk ./android/build-apk.sh
```

The script packs `public/ctp` into a WebView wrapper (no Gradle needed) and
signs it with `android/ctp-release.keystore` (the private release key is not
included in this download; the script creates a new key if it is missing).
Builds signed with a different key can't update an installed copy; uninstall
first (your save folder stays).

When `android/apk-parts` is present, `./android/assemble-apk.sh` rebuilds the
exact released APK from those parts and checks its SHA-256. The
**Package Android APK** workflow does the same and publishes it to the
`latest-apk` release.

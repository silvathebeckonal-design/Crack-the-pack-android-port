#!/usr/bin/env bash
# Builds an installable Crack the Pack APK from public/ctp (no Gradle).
# Needs: JDK 17 on PATH (javac, keytool) and ANDROID_SDK with build-tools;34.0.0 + platforms;android-34.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SDK="${ANDROID_SDK:-/tmp/sdk}"
BT="$SDK/build-tools/34.0.0"
JAR="$SDK/platforms/android-34/android.jar"
OUT="${OUT_DIR:-/tmp/apk-build}"
KEYSTORE="${KEYSTORE:-$ROOT/android/ctp-release.keystore}"
KS_PASS="${KS_PASS:-crackthepack}"

rm -rf "$OUT"; mkdir -p "$OUT"/{assets/www,gen,classes,dex,res}
cp -r "$ROOT/android/www/." "$OUT/assets/www/"
cp -r "$ROOT/public/ctp" "$OUT/assets/www/ctp"
cp "$ROOT/public/favicon.png" "$OUT/assets/www/favicon.png"

"$BT/aapt2" compile --dir "$ROOT/android/res" -o "$OUT/res/res.zip"
"$BT/aapt2" link -I "$JAR" --manifest "$ROOT/android/AndroidManifest.xml" \
  --java "$OUT/gen" -A "$OUT/assets" -o "$OUT/unsigned.apk" "$OUT/res/res.zip" \
  -0 mp3 -0 png -0 ttf

javac -source 8 -target 8 -nowarn -Xlint:-options -bootclasspath "$JAR" -d "$OUT/classes" \
  $(find "$ROOT/android/src" "$OUT/gen" -name '*.java')
"$BT/d8" --release --lib "$JAR" --min-api 24 --output "$OUT/dex" $(find "$OUT/classes" -name '*.class')
(cd "$OUT/dex" && zip -q -j "$OUT/unsigned.apk" classes.dex)

"$BT/zipalign" -f -p 4 "$OUT/unsigned.apk" "$OUT/aligned.apk"
if [ ! -f "$KEYSTORE" ]; then
  keytool -genkeypair -keystore "$KEYSTORE" -storepass "$KS_PASS" -keypass "$KS_PASS" \
    -alias ctp -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Crack the Pack"
fi
"$BT/apksigner" sign --ks "$KEYSTORE" --ks-pass "pass:$KS_PASS" --ks-key-alias ctp \
  --out "$OUT/CrackThePack.apk" "$OUT/aligned.apk"
"$BT/apksigner" verify "$OUT/CrackThePack.apk"
echo "APK: $OUT/CrackThePack.apk"

package com.crackthepack.game;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import android.os.Environment;
import android.webkit.JavascriptInterface;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private static final String TAG = "CrackThePack";
    private static final String ASSET_HOST = "appassets.androidplatform.net";
    private static final String BASE_URL = "https://" + ASSET_HOST + "/index.html";
    private static final int FILE_CHOOSER_REQUEST_CODE = 1001;
    private static final int SAVE_FOLDER_REQUEST_CODE = 1002;

    private WebView webView;
    private ValueCallback<Uri[]> uploadMessageCallback;
    private ExternalSaveStore saveStore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Set crash handler to prevent immediate silent termination
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread t, final Throwable e) {
                Log.e(TAG, "FATAL CRASH on thread " + t.getName(), e);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        showErrorScreen("Crash on launch: " + e.getClass().getSimpleName() + "\n" + e.getMessage() + "\n\n" + Log.getStackTraceString(e));
                    }
                });
            }
        });

        super.onCreate(savedInstanceState);
        saveStore = new ExternalSaveStore(this);

        try {
            requestWindowFeature(Window.FEATURE_NO_TITLE);
        } catch (Throwable ignored) {}

        try {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            setVolumeControlStream(AudioManager.STREAM_MUSIC);
        } catch (Throwable ignored) {}

        // Cutout mode on API 28+
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                WindowManager.LayoutParams lp = getWindow().getAttributes();
                if (lp != null) {
                    lp.layoutInDisplayCutoutMode =
                            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
                    getWindow().setAttributes(lp);
                }
            }
        } catch (Throwable ignored) {}

        try {
            webView = new WebView(this);
            setContentView(webView);
            configureWebView();
            setImmersiveMode();
            if (saveStore.hasFolder()) webView.loadUrl(BASE_URL);
            else chooseSaveFolder();
        } catch (Throwable t) {
            Log.e(TAG, "Failed to initialize WebView", t);
            showErrorScreen("Could not initialize WebView: " + t.getMessage() + "\n\n" + Log.getStackTraceString(t));
        }
    }

    private void chooseSaveFolder() {
        new AlertDialog.Builder(this)
                .setTitle("External save folder")
                .setMessage("Choose or create a folder in Documents for your game save (user.dat). Keep this folder to preserve your save after uninstalling.")
                .setCancelable(false)
                .setPositiveButton("Choose folder", new android.content.DialogInterface.OnClickListener() {
                  @Override public void onClick(android.content.DialogInterface dialog, int which) {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                            | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                            | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                            | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
                    startActivityForResult(intent, SAVE_FOLDER_REQUEST_CODE);
                  }
                }).setNegativeButton("Exit", new android.content.DialogInterface.OnClickListener() {
                  @Override public void onClick(android.content.DialogInterface dialog, int which) { finish(); }
                }).show();
    }

    private void showErrorScreen(String errorText) {
        try {
            ScrollView scrollView = new ScrollView(this);
            scrollView.setBackgroundColor(Color.parseColor("#0a1622"));
            scrollView.setPadding(40, 40, 40, 40);

            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);

            TextView title = new TextView(this);
            title.setText("CRACK THE PACK MOBILE");
            title.setTextColor(Color.parseColor("#ffea00"));
            title.setTextSize(22);
            title.setPadding(0, 0, 0, 20);
            layout.addView(title);

            TextView msg = new TextView(this);
            msg.setText(errorText);
            msg.setTextColor(Color.parseColor("#ff6666"));
            msg.setTextSize(14);
            msg.setTextIsSelectable(true);
            layout.addView(msg);

            scrollView.addView(layout);
            setContentView(scrollView);
        } catch (Throwable t) {
            Log.e(TAG, "Failed to display error screen", t);
        }
    }

    private void setImmersiveMode() {
        try {
            Window window = getWindow();
            if (window == null) return;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                window.setDecorFitsSystemWindows(false);
                WindowInsetsController controller = window.getInsetsController();
                if (controller != null) {
                    controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                    controller.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                }
            } else {
                View decorView = window.getDecorView();
                if (decorView != null) {
                    int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
                    decorView.setSystemUiVisibility(flags);
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "Failed to apply immersive mode", t);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            setImmersiveMode();
        }
    }

    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        webView.setBackgroundColor(0xFF0A1622);
        webView.addJavascriptInterface(new SaveBridge(), "AndroidSave");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                Log.d(TAG, "[Console " + consoleMessage.messageLevel() + "] "
                        + consoleMessage.message() + " (" + consoleMessage.sourceId()
                        + ":" + consoleMessage.lineNumber() + ")");
                return true;
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (uploadMessageCallback != null) {
                    uploadMessageCallback.onReceiveValue(null);
                }
                uploadMessageCallback = filePathCallback;

                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");

                try {
                    startActivityForResult(Intent.createChooser(intent, "Select data.win"), FILE_CHOOSER_REQUEST_CODE);
                } catch (Exception e) {
                    uploadMessageCallback = null;
                    return false;
                }
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (request != null && request.getUrl() != null) {
                    WebResourceResponse resp = handleIntercept(request.getUrl());
                    if (resp != null) return resp;
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                if (url != null) {
                    WebResourceResponse resp = handleIntercept(Uri.parse(url));
                    if (resp != null) return resp;
                }
                return super.shouldInterceptRequest(view, url);
            }
        });
    }

    private WebResourceResponse handleIntercept(Uri uri) {
        if (uri == null) return null;
        String host = uri.getHost();
        if (ASSET_HOST.equals(host) || "localhost".equals(host)) {
            String path = uri.getPath();
            if (path == null || path.isEmpty() || "/".equals(path)) {
                path = "/index.html";
            }
            if (path.startsWith("/")) {
                path = path.substring(1);
            }

            // Strip query or hash if present
            int qIdx = path.indexOf('?');
            if (qIdx != -1) path = path.substring(0, qIdx);
            int hIdx = path.indexOf('#');
            if (hIdx != -1) path = path.substring(0, hIdx);

            String assetPath = "www/" + path;
            try {
                AssetManager am = getAssets();
                InputStream is = am.open(assetPath);
                String mime = getMimeType(assetPath);
                // Binary files MUST have null encoding in WebResourceResponse
                String encoding = isBinary(assetPath) ? null : "UTF-8";

                Map<String, String> headers = new HashMap<>();
                headers.put("Access-Control-Allow-Origin", "*");
                headers.put("Access-Control-Allow-Methods", "GET, OPTIONS");
                headers.put("Cache-Control", "no-cache");

                return new WebResourceResponse(mime, encoding, 200, "OK", headers, is);
            } catch (Exception e) {
                Log.w(TAG, "Asset not found: " + assetPath + " (" + e.getMessage() + ")");
            }
        }
        return null;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SAVE_FOLDER_REQUEST_CODE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                try {
                    Uri folder = data.getData();
                    int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION
                            | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    getContentResolver().takePersistableUriPermission(folder, flags);
                    saveStore.selectFolder(folder);
                    webView.loadUrl(BASE_URL);
                    return;
                } catch (Exception e) {
                    Toast.makeText(this, "Cannot save in that folder. Choose another folder.", Toast.LENGTH_LONG).show();
                }
            }
            chooseSaveFolder();
            return;
        }
        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (uploadMessageCallback != null) {
                Uri[] results = null;
                if (resultCode == RESULT_OK && data != null) {
                    String dataString = data.getDataString();
                    if (dataString != null) {
                        results = new Uri[]{Uri.parse(dataString)};
                    } else if (data.getClipData() != null) {
                        int count = data.getClipData().getItemCount();
                        results = new Uri[count];
                        for (int i = 0; i < count; i++) {
                            results[i] = data.getClipData().getItemAt(i).getUri();
                        }
                    }
                }
                uploadMessageCallback.onReceiveValue(results);
                uploadMessageCallback = null;
            }
        }
    }

    private boolean isBinary(String path) {
        String lower = path.toLowerCase();
        return lower.endsWith(".png") || lower.endsWith(".jpg") || lower.endsWith(".jpeg")
                || lower.endsWith(".webp") || lower.endsWith(".mp3") || lower.endsWith(".ogg")
                || lower.endsWith(".wav") || lower.endsWith(".ttf") || lower.endsWith(".woff")
                || lower.endsWith(".woff2");
    }

    private String getMimeType(String path) {
        String lower = path.toLowerCase();
        if (lower.endsWith(".html")) return "text/html";
        if (lower.endsWith(".js") || lower.endsWith(".mjs")) return "application/javascript";
        if (lower.endsWith(".css")) return "text/css";
        if (lower.endsWith(".png")) return "image/png";
        if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
        if (lower.endsWith(".webp")) return "image/webp";
        if (lower.endsWith(".svg")) return "image/svg+xml";
        if (lower.endsWith(".mp3")) return "audio/mpeg";
        if (lower.endsWith(".ogg")) return "audio/ogg";
        if (lower.endsWith(".wav")) return "audio/wav";
        if (lower.endsWith(".json")) return "application/json";
        if (lower.endsWith(".webmanifest")) return "application/manifest+json";
        if (lower.endsWith(".woff2")) return "font/woff2";
        if (lower.endsWith(".woff")) return "font/woff";
        if (lower.endsWith(".ttf")) return "font/ttf";
        return "application/octet-stream";
    }

    @Override
    protected void onPause() {
        super.onPause();
        try {
            if (webView != null) {
                webView.onPause();
                webView.pauseTimers();
            }
        } catch (Throwable ignored) {}
    }

    @Override
    protected void onResume() {
        super.onResume();
        setImmersiveMode();
        try {
            if (webView != null) {
                webView.onResume();
                webView.resumeTimers();
            }
        } catch (Throwable ignored) {}
    }

    @Override
    protected void onDestroy() {
        try {
            if (webView != null) {
                webView.destroy();
                webView = null;
            }
        } catch (Throwable ignored) {}
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    public class SaveBridge {
        @JavascriptInterface
        public void saveGame(final String json) {
            try { saveStore.save(json); }
            catch (Exception e) {
                Log.e(TAG, "External save failed", e);
                runOnUiThread(new Runnable() {
                  @Override public void run() { Toast.makeText(MainActivity.this,
                        "External save failed. Your backup is retained; reopen the app to choose a writable folder.",
                        Toast.LENGTH_LONG).show(); }
                });
            }
        }

        @JavascriptInterface
        public String loadGame() {
            return saveStore.load();
        }
    }

}

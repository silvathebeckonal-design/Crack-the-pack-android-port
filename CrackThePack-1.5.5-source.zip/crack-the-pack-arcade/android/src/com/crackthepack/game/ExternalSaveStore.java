package com.crackthepack.game;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.util.AtomicFile;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** SAF grants access to a shared folder without all-files/storage permissions. */
public final class ExternalSaveStore {
    private final Context context;
    private static final String PREFS = "external_save";

    public ExternalSaveStore(Context context) { this.context = context; }

    private Uri tree() {
        String value = context.getSharedPreferences(PREFS, 0).getString("tree", null);
        return value == null ? null : Uri.parse(value);
    }

    public synchronized boolean hasFolder() {
        try {
            Uri uri = tree();
            if (uri == null) return false;
            Uri root = DocumentsContract.buildDocumentUriUsingTree(uri, DocumentsContract.getTreeDocumentId(uri));
            try (Cursor cursor = context.getContentResolver().query(root,
                    new String[]{DocumentsContract.Document.COLUMN_FLAGS}, null, null, null)) {
                return cursor != null && cursor.moveToFirst()
                        && (cursor.getInt(0) & DocumentsContract.Document.FLAG_DIR_SUPPORTS_CREATE) != 0;
            }
        } catch (Exception e) { return false; }
    }

    public synchronized void selectFolder(Uri uri) throws Exception {
        context.getSharedPreferences(PREFS, 0).edit().putString("tree", uri.toString()).commit();
        if (!hasFolder()) throw new IOException("Choose a writable folder");
        // Prefer the selected folder's existing save; never overwrite it with an older copy.
        String saved = load();
        if (saved != null) save(saved);
        // Do not create an empty reset marker before WebView save migration.
    }

    private Uri document(boolean create) throws Exception {
        Uri uri = tree();
        if (uri == null) throw new IOException("No external save folder selected");
        String id = DocumentsContract.getTreeDocumentId(uri);
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(uri, id);
        try (Cursor cursor = context.getContentResolver().query(children,
                new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                        DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null)) {
            while (cursor != null && cursor.moveToNext()) {
                if ("user.dat".equals(cursor.getString(1)))
                    return DocumentsContract.buildDocumentUriUsingTree(uri, cursor.getString(0));
            }
        }
        if (!create) return null;
        Uri root = DocumentsContract.buildDocumentUriUsingTree(uri, id);
        Uri result = DocumentsContract.createDocument(context.getContentResolver(), root,
                "application/octet-stream", "user.dat");
        if (result == null) throw new IOException("Cannot create user.dat");
        return result;
    }

    private AtomicFile backup() throws IOException {
        File external = context.getExternalFilesDir(null);
        if (external == null) throw new IOException("External storage unavailable");
        File file = new File(external, "Crack-The-Pack/Saves/user.dat");
        File parent = file.getParentFile();
        if (parent == null || (!parent.isDirectory() && !parent.mkdirs()))
            throw new IOException("Cannot create external backup directory");
        return new AtomicFile(file);
    }

    public synchronized void save(String json) throws Exception {
        if (!valid(json)) throw new IOException("Invalid save data");
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        // Serial, synchronous atomic backup survives interrupted shared-folder writes.
        AtomicFile backup = backup();
        FileOutputStream stream = backup.startWrite();
        try {
            stream.write(bytes);
            backup.finishWrite(stream);
        } catch (Exception e) { backup.failWrite(stream); throw e; }
        Uri file = document(true);
        try (OutputStream output = context.getContentResolver().openOutputStream(file, "wt")) {
            if (output == null) throw new IOException("Cannot open external save");
            output.write(bytes);
            output.flush();
        }
    }

    private static boolean valid(String json) {
        if (json == null) return false;
        if (json.isEmpty()) return true; // Explicit reset, not a missing save.
        try { return new JSONObject(json).getJSONObject("stats").getInt("ver") == 6; }
        catch (Exception e) { return false; }
    }

    private static String read(InputStream input) throws IOException {
        if (input == null) throw new IOException("Cannot open save");
        try (InputStream source = input; ByteArrayOutputStream bytes = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int count;
            while ((count = source.read(buffer)) != -1) bytes.write(buffer, 0, count);
            return new String(bytes.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    public synchronized String load() {
        // A more recent atomic backup wins after a failed/interrupted primary write.
        try {
            AtomicFile copy = backup();
            Uri file = document(false);
            if (file != null) {
                long modified = 0;
                try (Cursor cursor = context.getContentResolver().query(file,
                        new String[]{DocumentsContract.Document.COLUMN_LAST_MODIFIED}, null, null, null)) {
                    if (cursor != null && cursor.moveToFirst()) modified = cursor.getLong(0);
                }
                if (modified > 0 && copy.getBaseFile().lastModified() > modified) {
                    String json = read(copy.openRead());
                    if (valid(json)) return json;
                }
                String json = read(context.getContentResolver().openInputStream(file));
                if (valid(json)) return json;
            }
        } catch (Exception ignored) {}
        File legacy = new File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOCUMENTS), "Crack-The-Pack/Saves/user.dat");
        try {
            AtomicFile copy = backup();
            if (legacy.lastModified() > copy.getBaseFile().lastModified()) {
                String json = read(new FileInputStream(legacy));
                if (valid(json)) return json;
            }
        } catch (Exception ignored) {}
        try {
            AtomicFile copy = backup();
            String json = read(copy.openRead());
            if (valid(json)) return json;
        } catch (Exception ignored) {}
        try {
            String json = read(new FileInputStream(legacy));
            if (valid(json)) return json;
        } catch (Exception ignored) {}
        return null;
    }
}
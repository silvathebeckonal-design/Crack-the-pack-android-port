#!/usr/bin/env bash
# Reassembles the exact signed APK from repository-safe parts.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PARTS="$ROOT/android/apk-parts"
OUT="${1:-$ROOT/CrackThePack.apk}"
EXPECTED_SHA256="655d228d6c76387a7e2f36744b2df521fb759a49c6fbe26becb7db9b50ec4ff3"
TMP="${OUT}.tmp"

mkdir -p "$(dirname "$OUT")"
trap 'rm -f "$TMP"' EXIT
cat "$PARTS"/CrackThePack.apk.part-* > "$TMP"
printf '%s  %s\n' "$EXPECTED_SHA256" "$TMP" | sha256sum -c -
mv "$TMP" "$OUT"
trap - EXIT
printf 'APK: %s\n' "$OUT"

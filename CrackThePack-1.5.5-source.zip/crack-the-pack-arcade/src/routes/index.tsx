import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Crack the Pack — Retro Pixel Launcher" },
      {
        name: "description",
        content:
          "Launch Crack the Pack in your browser: crack booster packs, collect every card variant, all behind a pixel-perfect CRT screen.",
      },
      { property: "og:title", content: "Crack the Pack — Retro Pixel Launcher" },
      {
        property: "og:description",
        content: "Crack booster packs and collect every card variant in a retro CRT pixel-art launcher.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <main className="fixed inset-0 overflow-hidden bg-background">
      <h1 className="sr-only">Crack the Pack</h1>
      <iframe
        src="/ctp/index.html"
        title="Crack the Pack"
        allow="autoplay; fullscreen; gamepad"
        allowFullScreen
        className="block h-full w-full border-0"
      />
    </main>
  );
}

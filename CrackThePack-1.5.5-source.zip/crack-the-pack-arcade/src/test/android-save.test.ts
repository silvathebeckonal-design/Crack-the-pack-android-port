import { readFileSync } from "node:fs";
import { runInNewContext } from "node:vm";
import { describe, expect, it } from "vitest";

const game = readFileSync("public/ctp/assets/game.js", "utf8");
const start = game.indexOf("    load() {", game.indexOf("    saveOptions() {"));
const end = game.indexOf("    resetSave() {", start);
const method = game.slice(start, end).trim();

function load(native: string | null, local: string | null) {
  const writes: string[] = [];
  const defaults = () => ({ stats: {}, money_max: 100 });
  const state = runInNewContext(`({ options: {lang: 'en'}, stats: w(), audio: {}, ${method} })`, {
    localStorage: { getItem: (key: string) => key === "save" ? local : null },
    window: { AndroidSave: { loadGame: () => native, saveGame: (json: string) => writes.push(json) } },
    At: "save", jt: "options", T: () => ({}), w: defaults, It: (value: unknown) => value, oe: { en: {} },
  });
  state.load();
  return { state, writes };
}

const saved = JSON.stringify({ cards: [], upgrades: [], boosters: [], stats: { ver: 6, money: 42 } });

describe("Android external saves", () => {
  it("migrates an existing WebView save to the external folder", () => {
    const result = load(null, saved);
    expect(result.writes).toEqual([saved]);
    expect(result.state.stats.money).toBe(42);
  });
  it("restores progress from the external save without local data", () => {
    expect(load(saved, null).state.stats.money).toBe(42);
  });
  it("does not resurrect a local save after an external reset", () => {
    const result = load("", saved);
    expect(result.state.stats.money).toBeUndefined();
    expect(result.writes).toEqual([]);
  });
});
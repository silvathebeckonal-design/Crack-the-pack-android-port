import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";

const game = readFileSync("public/ctp/assets/game.js", "utf8");

describe("Upgrade panel", () => {
  it("places the starting root at y=70 when the panel opens at y=30", () => {
    const construction = game.match(/new ti\(e, n, r \+ (\d+), t, i\)/);
    expect(construction).not.toBeNull();
    expect(570 + Number(construction?.[1]) + 30 - 540).toBe(70);
  });
  it("only clips the tree at the panel's top border, not below the title", () => {
    expect(game).toContain("n.setScissor({ x: t.x, y: t.y + 3, w: 300, h: t.h() - 3 });");
  });
  it("uses the original free drag limits", () => {
    expect(game).toContain("u = lt(r, 560 - c, 690 - s);");
  });
});

(function () {
  let e = (() => {
    let e = new Uint32Array(256);
    for (let t = 0; t < 256; t++) {
      let n = t << 24;
      for (let e = 0; e < 8; e++)
        n = n & 2147483648 ? (n << 1) ^ 79764919 : n << 1;
      e[t] = n >>> 0;
    }
    return e;
  })();
  var t = class {
      data;
      pos = 0;
      constructor(e) {
        this.data = e;
      }
      bits(e) {
        let t = 0;
        for (let n = 0; n < e; n++) {
          let e = this.pos >>> 3;
          if (e >= this.data.length)
            throw Error(`bzip2: unexpected end of data`);
          ((t = (t << 1) | ((this.data[e] >>> (7 - (this.pos & 7))) & 1)),
            this.pos++);
        }
        return t >>> 0;
      }
      bit() {
        return this.bits(1);
      }
    },
    n = class {
      buf;
      len = 0;
      constructor(e) {
        this.buf = new Uint8Array(Math.max(1024, e));
      }
      push(e) {
        if (this.len >= this.buf.length) {
          let e = new Uint8Array(this.buf.length * 2);
          (e.set(this.buf), (this.buf = e));
        }
        this.buf[this.len++] = e;
      }
      result() {
        return this.buf.subarray(0, this.len);
      }
    };
  function r(r, i = 0) {
    if (r[0] !== 66 || r[1] !== 90 || r[2] !== 104)
      throw Error(`bzip2: bad signature`);
    let a = r[3] - 48;
    if (a < 1 || a > 9) throw Error(`bzip2: bad block size`);
    let o = a * 1e5,
      s = new t(r);
    s.pos = 32;
    let c = new n(i || o),
      l = new Uint32Array(o);
    for (;;) {
      let t = s.bits(24),
        n = s.bits(24);
      if (t === 1536581 && n === 3690640) {
        s.bits(32);
        break;
      }
      if (t !== 3227993 || n !== 2511705)
        throw Error(`bzip2: bad block header`);
      let r = s.bits(32);
      if (s.bit()) throw Error(`bzip2: randomised blocks are not supported`);
      let i = s.bits(24),
        a = s.bits(16),
        u = [];
      for (let e = 0; e < 16; e++)
        if (a & (32768 >>> e)) {
          let t = s.bits(16);
          for (let n = 0; n < 16; n++) t & (32768 >>> n) && u.push(e * 16 + n);
        }
      if (!u.length) throw Error(`bzip2: empty symbol map`);
      let d = u.length + 2,
        f = s.bits(3);
      if (f < 2 || f > 6) throw Error(`bzip2: bad group count`);
      let p = s.bits(15);
      if (p < 1) throw Error(`bzip2: bad selector count`);
      let m = Array.from({ length: f }, (e, t) => t),
        h = new Uint8Array(p);
      for (let e = 0; e < p; e++) {
        let t = 0;
        for (; s.bit();) if ((t++, t >= f)) throw Error(`bzip2: bad selector`);
        let n = m[t];
        (m.splice(t, 1), m.unshift(n), (h[e] = n));
      }
      let g = [];
      for (let e = 0; e < f; e++) {
        let e = new Uint8Array(d),
          t = s.bits(5);
        for (let n = 0; n < d; n++) {
          for (;;) {
            if (t < 1 || t > 20) throw Error(`bzip2: bad code length`);
            if (!s.bit()) break;
            t += s.bit() ? -1 : 1;
          }
          e[n] = t;
        }
        let n = 32,
          r = 0;
        for (let t of e) (t > r && (r = t), t < n && (n = t));
        let i = new Int32Array(d),
          a = 0;
        for (let t = n; t <= r; t++)
          for (let n = 0; n < d; n++) e[n] === t && (i[a++] = n);
        let o = new Int32Array(r + 2);
        for (let t of e) o[t]++;
        let c = new Int32Array(r + 2),
          l = new Int32Array(r + 2),
          u = 0,
          f = 0;
        for (let e = n; e <= r; e++)
          ((l[e] = f - u), (u += o[e]), (f += o[e]), (c[e] = u - 1), (u <<= 1));
        g.push({ limit: c, base: l, perm: i, minLen: n, maxLen: r });
      }
      let _ = new Uint8Array(256);
      for (let e = 0; e < 256; e++) _[e] = e;
      let v = new Int32Array(256),
        y = 0,
        b = 0,
        x = 0,
        S = 0,
        C = 0,
        w = g[0],
        T = d - 1;
      for (;;) {
        if (C === 0) {
          if (S >= p) throw Error(`bzip2: selectors exhausted`);
          ((w = g[h[S++]]), (C = 50));
        }
        C--;
        let e = w.minLen,
          t = s.bits(e);
        for (; e <= w.maxLen && t > w.limit[e];)
          ((t = (t << 1) | s.bit()), e++);
        if (e > w.maxLen) throw Error(`bzip2: bad Huffman code`);
        let n = w.perm[t + w.base[e]];
        if (n === 0 || n === 1) {
          (b === 0 && ((b = 1), (x = 0)), (x += (n + 1) * b), (b <<= 1));
          continue;
        }
        if (b) {
          b = 0;
          let e = u[_[0]];
          if (y + x > o) throw Error(`bzip2: block overflow`);
          for (v[e] += x; x-- > 0;) l[y++] = e;
        }
        if (n === T) break;
        let r = n - 1,
          i = _[r];
        (_.copyWithin(1, 0, r), (_[0] = i));
        let a = u[i];
        if (y >= o) throw Error(`bzip2: block overflow`);
        (v[a]++, (l[y++] = a));
      }
      if (i >= y) throw Error(`bzip2: bad origin pointer`);
      let E = new Int32Array(256);
      for (let e = 0, t = 0; e < 256; e++) ((E[e] = t), (t += v[e]));
      for (let e = 0; e < y; e++) {
        let t = l[e] & 255;
        l[E[t]++] |= e << 8;
      }
      let D = 4294967295,
        O = l[i] >>> 8,
        k = -1,
        A = 0;
      for (let t = 0; t < y; t++) {
        let t = l[O],
          n = t & 255;
        if (((O = t >>> 8), A === 4)) {
          for (let t = 0; t < n; t++)
            (c.push(k), (D = ((D << 8) ^ e[((D >>> 24) ^ k) & 255]) >>> 0));
          ((A = 0), (k = -1));
          continue;
        }
        (n === k ? A++ : ((A = 1), (k = n)),
          c.push(n),
          (D = ((D << 8) ^ e[((D >>> 24) ^ n) & 255]) >>> 0));
      }
      if (~D >>> 0 !== r)
        throw Error(`bzip2: block CRC mismatch (file is corrupted)`);
    }
    return c.result();
  }
  async function i(e, t) {
    let n = new Response(new Blob([e]).stream().pipeThrough(t));
    return new Uint8Array(await n.arrayBuffer());
  }
  let a = (() => {
    let e = new Uint32Array(256);
    for (let t = 0; t < 256; t++) {
      let n = t;
      for (let e = 0; e < 8; e++) n = n & 1 ? 3988292384 ^ (n >>> 1) : n >>> 1;
      e[t] = n >>> 0;
    }
    return e;
  })();
  function o(e) {
    let t = 4294967295;
    for (let n of e)
      for (let e = 0; e < n.length; e++) t = a[(t ^ n[e]) & 255] ^ (t >>> 8);
    return (t ^ 4294967295) >>> 0;
  }
  function s(e, t) {
    let n = new Uint8Array(12 + t.length),
      r = new DataView(n.buffer);
    r.setUint32(0, t.length);
    let i = new Uint8Array([...e].map((e) => e.charCodeAt(0)));
    return (n.set(i, 4), n.set(t, 8), r.setUint32(8 + t.length, o([i, t])), n);
  }
  async function c(e) {
    let { width: t, height: n, data: r } = e,
      a = t * 4,
      o = new Uint8Array((a + 1) * n);
    for (let e = 0; e < n; e++) {
      let t = e * (a + 1);
      o[t] = 1;
      let n = e * a;
      for (let e = 0; e < a; e++)
        o[t + 1 + e] = (r[n + e] - (e >= 4 ? r[n + e - 4] : 0)) & 255;
    }
    let c = await i(o, new CompressionStream(`deflate`)),
      l = new Uint8Array(13),
      u = new DataView(l.buffer);
    (u.setUint32(0, t), u.setUint32(4, n), (l[8] = 8), (l[9] = 6));
    let d = [
        new Uint8Array([137, 80, 78, 71, 13, 10, 26, 10]),
        s(`IHDR`, l),
        s(`IDAT`, c),
        s(`IEND`, new Uint8Array()),
      ],
      f = new Uint8Array(d.reduce((e, t) => e + t.length, 0)),
      p = 0;
    for (let e of d) (f.set(e, p), (p += e.length));
    return f;
  }
  async function l(e) {
    let t = [137, 80, 78, 71, 13, 10, 26, 10];
    for (let n = 0; n < 8; n++)
      if (e[n] !== t[n]) throw Error(`texture: not a PNG image`);
    let n = new DataView(e.buffer, e.byteOffset, e.byteLength),
      r = 8,
      a = 0,
      o = 0,
      s = 0,
      c = 0,
      l = 0,
      u = null,
      d = null,
      f = [];
    for (; r + 8 <= e.length;) {
      let t = n.getUint32(r),
        i = String.fromCharCode(...e.subarray(r + 4, r + 8)),
        p = e.subarray(r + 8, r + 8 + t);
      if (p.length !== t) throw Error(`texture: truncated PNG`);
      if (i === `IHDR`)
        ((a = n.getUint32(r + 8)),
          (o = n.getUint32(r + 12)),
          (s = e[r + 16]),
          (c = e[r + 17]),
          (l = e[r + 20]));
      else if (i === `PLTE`) u = p;
      else if (i === `tRNS`) d = p;
      else if (i === `IDAT`) f.push(p);
      else if (i === `IEND`) break;
      r += 12 + t;
    }
    if (s !== 8 || l) throw Error(`texture: unsupported PNG format`);
    let p = { 0: 1, 2: 3, 3: 1, 4: 2, 6: 4 }[c];
    if (!p) throw Error(`texture: unsupported PNG colour type`);
    let m = f.reduce((e, t) => e + t.length, 0),
      h = new Uint8Array(m),
      g = 0;
    for (let e of f) (h.set(e, g), (g += e.length));
    let _ = await i(h, new DecompressionStream(`deflate`)),
      v = a * p;
    if (_.length < (v + 1) * o) throw Error(`texture: truncated PNG data`);
    let y = new Uint8Array(v * o);
    for (let e = 0; e < o; e++) {
      let t = _[e * (v + 1)],
        n = e * (v + 1) + 1,
        r = e * v;
      for (let i = 0; i < v; i++) {
        let a = i >= p ? y[r + i - p] : 0,
          o = e ? y[r - v + i] : 0,
          s = i >= p && e ? y[r - v + i - p] : 0,
          c = _[n + i];
        if (t === 1) c += a;
        else if (t === 2) c += o;
        else if (t === 3) c += (a + o) >> 1;
        else if (t === 4) {
          let e = a + o - s,
            t = Math.abs(e - a),
            n = Math.abs(e - o),
            r = Math.abs(e - s);
          c += t <= n && t <= r ? a : n <= r ? o : s;
        }
        y[r + i] = c & 255;
      }
    }
    let b = new Uint8Array(a * o * 4);
    for (let e = 0, t = 0; e < a * o; e++, t += p) {
      let n = e * 4;
      if (c === 6) b.set(y.subarray(t, t + 4), n);
      else if (c === 2)
        ((b[n] = y[t]),
          (b[n + 1] = y[t + 1]),
          (b[n + 2] = y[t + 2]),
          (b[n + 3] = 255));
      else if (c === 0 || c === 4)
        ((b[n] = b[n + 1] = b[n + 2] = y[t]),
          (b[n + 3] = c === 4 ? y[t + 1] : 255));
      else {
        let e = y[t];
        ((b[n] = u[e * 3]),
          (b[n + 1] = u[e * 3 + 1]),
          (b[n + 2] = u[e * 3 + 2]),
          (b[n + 3] = d && e < d.length ? d[e] : 255));
      }
    }
    return { width: a, height: o, data: b };
  }
  function u(e) {
    if (
      e.length < 12 ||
      e[0] !== 102 ||
      e[1] !== 105 ||
      e[2] !== 111 ||
      e[3] !== 113
    )
      throw Error(`texture: not a GameMaker QOI image`);
    let t = e[4] | (e[5] << 8),
      n = e[6] | (e[7] << 8),
      r = (e[8] | (e[9] << 8) | (e[10] << 16) | (e[11] << 24)) >>> 0;
    if (!t || !n) throw Error(`texture: empty QOI image`);
    if (12 + r > e.length) throw Error(`texture: truncated QOI image`);
    let i = e.subarray(12, 12 + r),
      a = new Uint8Array(t * n * 4),
      o = new Uint8Array(256),
      s = 0,
      c = 0,
      l = 0,
      u = 255,
      d = 0,
      f = 0,
      p = (e, t) => (e << (32 - t)) >> (32 - t);
    for (let e = 0; e < a.length; e += 4) {
      if (f > 0) f--;
      else if (d < i.length) {
        let e = i[d++];
        if (!(e & 192)) {
          let t = (e & 63) << 2;
          ((s = o[t]), (c = o[t + 1]), (l = o[t + 2]), (u = o[t + 3]));
        } else if ((e & 224) == 64) f = e & 31;
        else if ((e & 224) == 96) f = (((e & 31) << 8) | i[d++]) + 32;
        else if ((e & 192) == 128)
          ((s = (s + p((e >> 4) & 3, 2)) & 255),
            (c = (c + p((e >> 2) & 3, 2)) & 255),
            (l = (l + p(e & 3, 2)) & 255));
        else if ((e & 224) == 192) {
          let t = (e << 8) | i[d++];
          ((s = (s + p((t >> 8) & 31, 5)) & 255),
            (c = (c + p((t >> 4) & 15, 4)) & 255),
            (l = (l + p(t & 15, 4)) & 255));
        } else if ((e & 240) == 224) {
          let t = (e << 16) | (i[d++] << 8) | i[d++];
          ((s = (s + p((t >> 15) & 31, 5)) & 255),
            (c = (c + p((t >> 10) & 31, 5)) & 255),
            (l = (l + p((t >> 5) & 31, 5)) & 255),
            (u = (u + p(t & 31, 5)) & 255));
        } else
          (e & 8 && (s = i[d++]),
            e & 4 && (c = i[d++]),
            e & 2 && (l = i[d++]),
            e & 1 && (u = i[d++]));
        let t = ((s ^ c ^ l ^ u) & 63) << 2;
        ((o[t] = s), (o[t + 1] = c), (o[t + 2] = l), (o[t + 3] = u));
      }
      ((a[e] = s), (a[e + 1] = c), (a[e + 2] = l), (a[e + 3] = u));
    }
    return { width: t, height: n, data: a };
  }
  var d = class extends Error {
      code;
      constructor(e, t) {
        (super(e), (this.code = t));
      }
    },
    f = class {
      bytes;
      dv;
      chunks = new Map();
      pageCache = new Map();
      tpagCache = new Map();
      constructor(e) {
        if (
          ((this.bytes = e instanceof Uint8Array ? e : new Uint8Array(e)),
          (this.dv = new DataView(
            this.bytes.buffer,
            this.bytes.byteOffset,
            this.bytes.byteLength,
          )),
          this.bytes.length < 16 || this.str4(0) !== `FORM`)
        )
          throw new d(
            `This is not a GameMaker data file (no FORM header).`,
            `not-gamemaker`,
          );
        let t = this.u32(4);
        if (t + 8 > this.bytes.length)
          throw new d(
            `The file is incomplete: it should be ${t + 8} bytes but only ${this.bytes.length} bytes were read.`,
            `corrupted`,
          );
        let n = 8,
          r = 8 + t;
        for (; n < r;) {
          if (n + 8 > r)
            throw new d(`The chunk table is damaged.`, `corrupted`);
          let e = this.str4(n);
          if (!/^[A-Z0-9]{4}$/.test(e))
            throw new d(`Unexpected chunk "${e}" at ${n}.`, `corrupted`);
          let t = this.u32(n + 4);
          if (n + 8 + t > r)
            throw new d(
              `Chunk ${e} runs past the end of the file.`,
              `corrupted`,
            );
          (this.chunks.set(e, { name: e, start: n + 8, size: t }),
            (n += 8 + t));
        }
        if (!this.chunks.has(`GEN8`))
          throw new d(
            `The GEN8 (game information) chunk is missing.`,
            `not-gamemaker`,
          );
      }
      check(e, t) {
        if (e < 0 || e + t > this.bytes.length)
          throw new d(`Read outside the file at ${e}.`, `corrupted`);
      }
      u8(e) {
        return (this.check(e, 1), this.bytes[e]);
      }
      u16(e) {
        return (this.check(e, 2), this.dv.getUint16(e, !0));
      }
      i32(e) {
        return (this.check(e, 4), this.dv.getInt32(e, !0));
      }
      u32(e) {
        return (this.check(e, 4), this.dv.getUint32(e, !0));
      }
      f32(e) {
        return (this.check(e, 4), this.dv.getFloat32(e, !0));
      }
      str4(e) {
        return (
          this.check(e, 4),
          String.fromCharCode(
            this.bytes[e],
            this.bytes[e + 1],
            this.bytes[e + 2],
            this.bytes[e + 3],
          )
        );
      }
      str(e) {
        if (!e) return ``;
        let t = this.u32(e - 4);
        if (t > 1 << 20)
          throw new d(`A string record is damaged.`, `corrupted`);
        return (
          this.check(e, t),
          new TextDecoder().decode(this.bytes.subarray(e, e + t))
        );
      }
      chunk(e) {
        let t = this.chunks.get(e);
        if (!t) throw new d(`The ${e} chunk is missing.`, `unsupported`);
        return t;
      }
      list(e) {
        let t = this.chunk(e);
        if (t.size < 4) return [];
        let n = this.u32(t.start);
        if (4 + n * 4 > t.size)
          throw new d(`The ${e} list is damaged.`, `corrupted`);
        let r = [];
        for (let i = 0; i < n; i++) {
          let n = this.u32(t.start + 4 + i * 4);
          if (n && (n < t.start || n >= t.start + t.size))
            throw new d(`A ${e} entry points outside its chunk.`, `corrupted`);
          r.push(n);
        }
        return r;
      }
      gen8() {
        let e = this.chunk(`GEN8`).start,
          t = Array.from(this.bytes.subarray(e + 24, e + 40), (e) =>
            e.toString(16).padStart(2, `0`),
          ).join(``);
        return {
          debug: this.u8(e) !== 0,
          bytecodeVersion: this.u8(e + 1),
          fileName: this.str(this.u32(e + 4)),
          config: this.str(this.u32(e + 8)),
          gameId: this.u32(e + 20),
          guid: t,
          name: this.str(this.u32(e + 40)),
          major: this.u32(e + 44),
          minor: this.u32(e + 48),
          release: this.u32(e + 52),
          build: this.u32(e + 56),
          defaultWidth: this.u32(e + 60),
          defaultHeight: this.u32(e + 64),
          timestamp: Number(this.dv.getBigUint64(e + 92, !0)),
          displayName: this.str(this.u32(e + 100)),
        };
      }
      tpag(e) {
        let t = this.tpagCache.get(e);
        if (t) return t;
        let n = this.chunk(`TPAG`);
        if (e < n.start || e + 22 > n.start + n.size)
          throw new d(`A texture page item is outside TPAG.`, `corrupted`);
        let r = (t) => this.u16(e + t * 2),
          i = {
            srcX: r(0),
            srcY: r(1),
            srcW: r(2),
            srcH: r(3),
            tgtX: r(4),
            tgtY: r(5),
            tgtW: r(6),
            tgtH: r(7),
            boundW: r(8),
            boundH: r(9),
            page: r(10),
          };
        return (this.tpagCache.set(e, i), i);
      }
      sprites() {
        let e = new Map();
        for (let t of this.list(`SPRT`)) {
          if (!t) continue;
          let n = this.str(this.u32(t)),
            r = this.u32(t + 4),
            i = this.u32(t + 8),
            a = this.i32(t + 48),
            o = this.i32(t + 52),
            s = t + 56,
            c = [];
          if (this.i32(s) === -1) {
            let t = this.u32(s + 4),
              l = this.u32(s + 8);
            if (((s += 20), t >= 2 && (s += 4), t >= 3 && (s += 4), l !== 0)) {
              e.set(n, {
                name: n,
                width: r,
                height: i,
                originX: a,
                originY: o,
                frames: c,
              });
              continue;
            }
          }
          let l = this.u32(s);
          if (l > 4096)
            throw new d(`Sprite ${n} has a damaged frame list.`, `corrupted`);
          for (let e = 0; e < l; e++)
            c.push(this.tpag(this.u32(s + 4 + e * 4)));
          e.set(n, {
            name: n,
            width: r,
            height: i,
            originX: a,
            originY: o,
            frames: c,
          });
        }
        return e;
      }
      texturePointers() {
        let e = this.list(`TXTR`),
          t = this.chunk(`TXTR`),
          n = 28;
        if ((e.length > 1 && (n = e[1] - e[0]), ![8, 12, 16, 28].includes(n)))
          throw new d(`Unknown texture page format.`, `unsupported`);
        let r = e.map((e) => this.u32(e + n - 4)),
          i = [...r].sort((e, t) => e - t),
          a = r.map((e) => i.find((t) => t > e) ?? t.start + t.size);
        for (let e of r)
          if (e < t.start || e >= t.start + t.size)
            throw new d(`Texture data lies outside TXTR.`, `corrupted`);
        return { ptrs: r, ends: a };
      }
      pageCount() {
        return this.list(`TXTR`).length;
      }
      async page(e) {
        let t = this.pageCache.get(e);
        if (t) return t;
        let { ptrs: n, ends: i } = this.texturePointers();
        if (e < 0 || e >= n.length)
          throw new d(`Texture page ${e} does not exist.`, `corrupted`);
        let a = this.bytes.subarray(n[e], i[e]),
          o;
        try {
          let t = String.fromCharCode(a[0], a[1], a[2], a[3]);
          if (t === `2zoq`) {
            let t = a[8] !== 66 || a[9] !== 90,
              i = t ? this.dv.getUint32(n[e] + 8, !0) : 0;
            o = u(r(a.subarray(t ? 12 : 8), i));
          } else if (t === `fioq`) o = u(a);
          else if (a[0] === 137 && t.slice(1) === `PNG`) o = await l(a);
          else throw Error(`unknown texture encoding "${t}"`);
        } catch (t) {
          throw t instanceof d
            ? t
            : new d(
                `Texture page ${e} could not be decoded: ${t.message}`,
                `corrupted`,
              );
        }
        return (this.pageCache.set(e, o), o);
      }
      dropPage(e) {
        this.pageCache.delete(e);
      }
      async frame(e) {
        let t = await this.page(e.page),
          n = e.boundW,
          r = e.boundH,
          i = new Uint8Array(n * r * 4);
        if (e.srcX + e.srcW > t.width || e.srcY + e.srcH > t.height)
          throw new d(
            `A sprite frame lies outside its texture page.`,
            `corrupted`,
          );
        for (let a = 0; a < e.tgtH; a++) {
          let o = e.tgtY + a;
          if (o < 0 || o >= r) continue;
          let s =
            e.srcY + Math.min(e.srcH - 1, Math.floor((a * e.srcH) / e.tgtH));
          for (let r = 0; r < e.tgtW; r++) {
            let a = e.tgtX + r;
            if (a < 0 || a >= n) continue;
            let c =
                e.srcX +
                Math.min(e.srcW - 1, Math.floor((r * e.srcW) / e.tgtW)),
              l = (s * t.width + c) * 4,
              u = (o * n + a) * 4;
            ((i[u] = t.data[l]),
              (i[u + 1] = t.data[l + 1]),
              (i[u + 2] = t.data[l + 2]),
              (i[u + 3] = t.data[l + 3]));
          }
        }
        return { width: n, height: r, data: i };
      }
      async region(e) {
        let t = await this.page(e.page),
          n = new Uint8Array(e.srcW * e.srcH * 4);
        for (let r = 0; r < e.srcH; r++) {
          let i = ((e.srcY + r) * t.width + e.srcX) * 4;
          n.set(t.data.subarray(i, i + e.srcW * 4), r * e.srcW * 4);
        }
        return { width: e.srcW, height: e.srcH, data: n };
      }
      fonts() {
        let e = new Map();
        for (let t of this.list(`FONT`)) {
          if (!t) continue;
          let n = this.str(this.u32(t)),
            r = this.u32(t + 28);
          e.set(n, {
            name: n,
            displayName: this.str(this.u32(t + 4)),
            item: r ? this.tpag(r) : null,
          });
        }
        return e;
      }
      sounds() {
        let e = new Map();
        for (let t of this.list(`SOND`)) {
          if (!t) continue;
          let n = this.str(this.u32(t));
          e.set(n, {
            name: n,
            flags: this.u32(t + 4),
            file: this.str(this.u32(t + 12)),
            volume: this.f32(t + 20),
            audioIndex: this.i32(t + 32),
          });
        }
        return e;
      }
      audio(e) {
        let t = this.list(`AUDO`);
        if (e < 0 || e >= t.length)
          throw new d(`Embedded sound ${e} does not exist.`, `corrupted`);
        let n = t[e],
          r = this.u32(n),
          i = this.chunk(`AUDO`);
        if (n + 4 + r > i.start + i.size)
          throw new d(`Embedded sound ${e} is truncated.`, `corrupted`);
        return this.bytes.subarray(n + 4, n + 4 + r);
      }
    };
  function p(e) {
    let t = String.fromCharCode(e[0], e[1], e[2], e[3]);
    return t === `RIFF` &&
      String.fromCharCode(e[8], e[9], e[10], e[11]) === `WAVE`
      ? { ext: `wav`, mime: `audio/wav` }
      : t === `OggS`
        ? { ext: `ogg`, mime: `audio/ogg` }
        : t.startsWith(`ID3`) || (e[0] === 255 && (e[1] & 224) == 224)
          ? { ext: `mp3`, mime: `audio/mpeg` }
          : null;
  }
  var m = {
      w: 2048,
      h: 2048,
      sprites: JSON.parse(
        `{"sAlarm":{"w":40,"h":40,"ox":20,"oy":12,"sp":0.0,"st":0,"bb":[5,10,34,32],"f":[[1602,1287],[1644,1287]]},"sBGBoard":{"w":50,"h":50,"ox":0,"oy":0,"sp":30.0,"st":0,"bb":[0,0,49,49],"f":[[1996,1215],[926,1287],[978,1287],[1030,1287],[1082,1287],[1134,1287],[1186,1287],[1238,1287],[1290,1287],[1342,1287],[1394,1287],[1446,1287]]},"sBGEnding_1":{"w":320,"h":180,"ox":0,"oy":0,"sp":0.0,"st":0,"bb":[10,4,308,43],"f":[[2,215]]},"sBGEnding_2":{"w":320,"h":180,"ox":0,"oy":0,"sp":0.0,"st":0,"bb":[8,107,306,179],"f":[[324,215]]},"sBGEnding_3":{"w":320,"h":180,"ox":0,"oy":0,"sp":0.0,"st":0,"bb":[17,42,319,179],"f":[[646,215]]},"sBGEnding_4":{"w":320,"h":180,"ox":0,"oy":0,"sp":0.0,"st":0,"bb":[11,59,224,157],"f":[[968,215]]},"sBGEnding_5":{"w":320,"h":180,"ox":0,"oy":0,"sp":0.0,"st":0,"bb":[0,142,319,179],"f":[[1290,215]]},"sBGEnding":{"w":320,"h":180,"ox":0,"oy":0,"sp":0.0,"st":0,"bb":[0,0,319,179],"f":[[1612,215]]},"sBGMenuIntro_1":{"w":320,"h":180,"ox":0,"oy":0,"sp":0.0,"st":0,"bb":[27,14,281,163],"f":[[2,397]]},"sBooster0":{"w":100,"h":100,"ox":50,"oy":50,"sp":0.0,"st":0,"bb":[22,6,77,94],"f":[[1934,215],[1605,397]]},"sBooster0Plastic":{"w":100,"h":100,"ox":76,"oy":13,"sp":0.0,"st":0,"bb":[22,6,77,94],"f":[[1707,397],[1809,397]]},"sBooster1":{"w":100,"h":100,"ox":50,"oy":50,"sp":0.0,"st":0,"bb":[22,6,77,94],"f":[[1911,397],[2,579]]},"sBooster1Plastic":{"w":100,"h":100,"ox":76,"oy":13,"sp":30.0,"st":0,"bb":[22,6,77,13],"f":[[104,579]]},"sBooster2":{"w":100,"h":100,"ox":50,"oy":50,"sp":0.0,"st":0,"bb":[22,6,77,94],"f":[[206,579],[308,579]]},"sBooster2Plastic":{"w":100,"h":100,"ox":76,"oy":13,"sp":30.0,"st":0,"bb":[22,6,77,13],"f":[[410,579]]},"sBooster3":{"w":100,"h":100,"ox":50,"oy":50,"sp":0.0,"st":0,"bb":[9,6,91,94],"f":[[512,579],[614,579]]},"sBooster3Plastic":{"w":100,"h":100,"ox":76,"oy":13,"sp":30.0,"st":0,"bb":[22,6,77,13],"f":[[716,579]]},"sBooster4":{"w":100,"h":100,"ox":50,"oy":62,"sp":0.0,"st":0,"bb":[22,18,77,77],"f":[[818,579],[920,579]]},"sBooster4Plastic":{"w":100,"h":100,"ox":76,"oy":13,"sp":30.0,"st":0,"bb":[22,6,77,13],"f":[[1022,579]]},"sBooster5":{"w":100,"h":100,"ox":50,"oy":50,"sp":0.0,"st":0,"bb":[22,6,77,94],"f":[[1124,579],[1226,579]]},"sBooster5Plastic":{"w":100,"h":100,"ox":76,"oy":13,"sp":30.0,"st":0,"bb":[22,6,77,13],"f":[[1328,579]]},"sBooster6":{"w":100,"h":100,"ox":50,"oy":50,"sp":0.0,"st":0,"bb":[22,6,77,94],"f":[[1430,579],[1532,579]]},"sBooster6Plastic":{"w":100,"h":100,"ox":76,"oy":13,"sp":30.0,"st":0,"bb":[22,6,77,13],"f":[[1634,579]]},"sBooster7":{"w":150,"h":150,"ox":75,"oy":75,"sp":0.0,"st":0,"bb":[44,7,105,123],"f":[[324,397],[476,397]]},"sBooster7Plastic":{"w":100,"h":100,"ox":76,"oy":39,"sp":30.0,"st":0,"bb":[22,8,77,39],"f":[[1736,579]]},"sBooster8":{"w":100,"h":100,"ox":50,"oy":50,"sp":0.0,"st":0,"bb":[22,6,77,94],"f":[[1838,579],[1940,579]]},"sBooster8Plastic":{"w":100,"h":100,"ox":76,"oy":39,"sp":30.0,"st":0,"bb":[22,32,77,39],"f":[[2,681]]},"sBoosterBlister":{"w":400,"h":400,"ox":200,"oy":200,"sp":0.0,"st":0,"bb":[156,137,242,263],"k":0.5,"f":[[1595,2]],"tw":200,"th":200},"sBoosterBlister2":{"w":400,"h":400,"ox":200,"oy":200,"sp":0.0,"st":0,"bb":[156,137,242,263],"k":0.5,"f":[[1797,2]],"tw":200,"th":200},"sBoosterFissuration":{"w":100,"h":100,"ox":50,"oy":50,"sp":0.0,"st":0,"bb":[24,16,76,86],"f":[[104,681],[206,681],[308,681],[410,681]]},"sCardArt0":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[938,681],[990,681]]},"sCardArt1":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[5,5,46,57],"f":[[1042,681],[1094,681]]},"sCardArt10":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1146,681],[1198,681]]},"sCardArt100":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1250,681],[1302,681]]},"sCardArt101":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1354,681],[1406,681]]},"sCardArt102":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1458,681],[1510,681]]},"sCardArt103":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1562,681],[1614,681]]},"sCardArt104":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1666,681],[1718,681]]},"sCardArt105":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1770,681],[1822,681]]},"sCardArt106":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1874,681],[1926,681]]},"sCardArt107":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1978,681],[2,783]]},"sCardArt108":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[54,783],[106,783]]},"sCardArt109":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[158,783],[210,783]]},"sCardArt11":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[262,783],[314,783]]},"sCardArt110":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[366,783],[418,783]]},"sCardArt111":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[470,783],[522,783]]},"sCardArt112":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[574,783],[626,783]]},"sCardArt113":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[678,783],[730,783]]},"sCardArt114":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[782,783],[834,783]]},"sCardArt115":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[886,783],[938,783]]},"sCardArt116":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[990,783],[1042,783]]},"sCardArt117":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1094,783],[1146,783]]},"sCardArt118":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1198,783],[1250,783]]},"sCardArt119":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1302,783],[1354,783]]},"sCardArt12":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1406,783],[1458,783]]},"sCardArt120":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1510,783],[1562,783]]},"sCardArt121":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1614,783],[1666,783]]},"sCardArt122":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1718,783],[1770,783]]},"sCardArt123":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1822,783],[1874,783]]},"sCardArt124":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1926,783],[1978,783]]},"sCardArt125":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[2,855],[54,855]]},"sCardArt126":{"w":150,"h":210,"ox":75,"oy":105,"sp":30.0,"st":0,"bb":[10,28,146,160],"f":[[379,2],[531,2]]},"sCardArt127":{"w":150,"h":210,"ox":75,"oy":105,"sp":30.0,"st":0,"bb":[54,74,96,127],"f":[[683,2],[835,2]]},"sCardArt128":{"w":150,"h":210,"ox":75,"oy":105,"sp":30.0,"st":0,"bb":[54,74,96,127],"f":[[987,2],[1139,2]]},"sCardArt129":{"w":150,"h":210,"ox":75,"oy":105,"sp":30.0,"st":0,"bb":[54,74,96,127],"f":[[1291,2],[1443,2]]},"sCardArt13":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[106,855],[158,855]]},"sCardArt130":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[210,855],[262,855]]},"sCardArt131":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[314,855],[366,855]]},"sCardArt132":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[418,855],[470,855]]},"sCardArt133":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[522,855],[574,855]]},"sCardArt134":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[626,855],[678,855]]},"sCardArt135":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[730,855],[782,855]]},"sCardArt136":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[834,855],[886,855]]},"sCardArt137":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[938,855],[990,855]]},"sCardArt138":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1042,855],[1094,855]]},"sCardArt139":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1146,855],[1198,855]]},"sCardArt14":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1250,855],[1302,855]]},"sCardArt140":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1354,855],[1406,855]]},"sCardArt141":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1458,855],[1510,855]]},"sCardArt142":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1562,855],[1614,855]]},"sCardArt15":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1666,855],[1718,855]]},"sCardArt16":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1770,855],[1822,855]]},"sCardArt17":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1874,855],[1926,855]]},"sCardArt18":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1978,855],[2,927]]},"sCardArt19":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[54,927],[106,927]]},"sCardArt2":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[158,927],[210,927]]},"sCardArt20":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[262,927],[314,927]]},"sCardArt21":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[366,927],[418,927]]},"sCardArt22":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[470,927],[522,927]]},"sCardArt23":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[574,927],[626,927]]},"sCardArt24":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[678,927],[730,927]]},"sCardArt25":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[782,927],[834,927]]},"sCardArt26":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[886,927],[938,927]]},"sCardArt27":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[990,927],[1042,927]]},"sCardArt28":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1094,927],[1146,927]]},"sCardArt29":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1198,927],[1250,927]]},"sCardArt3":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1302,927],[1354,927]]},"sCardArt30":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1406,927],[1458,927]]},"sCardArt31":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1510,927],[1562,927]]},"sCardArt32":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1614,927]]},"sCardArt33":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1666,927]]},"sCardArt34":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1718,927]]},"sCardArt35":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1770,927]]},"sCardArt36":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1822,927],[1874,927]]},"sCardArt37":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1926,927],[1978,927]]},"sCardArt38":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[2,999],[54,999]]},"sCardArt39":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[106,999],[158,999]]},"sCardArt4":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[210,999],[262,999]]},"sCardArt40":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[314,999],[366,999]]},"sCardArt41":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[0,0,0,0],"f":[[418,999]]},"sCardArt42":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[470,999],[522,999]]},"sCardArt43":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[574,999],[626,999]]},"sCardArt44":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[678,999],[730,999]]},"sCardArt45":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[782,999],[834,999]]},"sCardArt46":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[886,999],[938,999]]},"sCardArt47":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[990,999],[1042,999]]},"sCardArt48":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1094,999],[1146,999]]},"sCardArt49":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1198,999],[1250,999]]},"sCardArt5":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1302,999],[1354,999]]},"sCardArt50":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1406,999]]},"sCardArt51":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1458,999]]},"sCardArt52":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1510,999]]},"sCardArt53":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1562,999],[1614,999]]},"sCardArt54":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1666,999],[1718,999]]},"sCardArt55":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1770,999],[1822,999]]},"sCardArt56":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1874,999],[1926,999]]},"sCardArt57":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1978,999],[2,1071]]},"sCardArt58":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[54,1071],[106,1071]]},"sCardArt59":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[1,1,49,57],"f":[[158,1071],[210,1071]]},"sCardArt6":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[262,1071],[314,1071]]},"sCardArt60":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[366,1071],[418,1071]]},"sCardArt61":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[470,1071],[522,1071]]},"sCardArt62":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[574,1071],[626,1071]]},"sCardArt63":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[678,1071],[730,1071]]},"sCardArt64":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[782,1071],[834,1071]]},"sCardArt65":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[886,1071],[938,1071]]},"sCardArt66":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[990,1071],[1042,1071]]},"sCardArt67":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1094,1071],[1146,1071]]},"sCardArt68":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1198,1071],[1250,1071]]},"sCardArt69":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1302,1071],[1354,1071]]},"sCardArt7":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1406,1071],[1458,1071]]},"sCardArt70":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1510,1071],[1562,1071]]},"sCardArt71":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1614,1071],[1666,1071]]},"sCardArt72":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1718,1071],[1770,1071]]},"sCardArt73":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1822,1071],[1874,1071]]},"sCardArt74":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1926,1071],[1978,1071]]},"sCardArt75":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[2,1143],[54,1143]]},"sCardArt76":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[106,1143],[158,1143]]},"sCardArt77":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[210,1143],[262,1143]]},"sCardArt78":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[314,1143],[366,1143]]},"sCardArt79":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[418,1143],[470,1143]]},"sCardArt8":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[522,1143],[574,1143]]},"sCardArt80":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[626,1143],[678,1143]]},"sCardArt81":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[730,1143],[782,1143]]},"sCardArt82":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[834,1143],[886,1143]]},"sCardArt83":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,2,46,57],"f":[[938,1143],[990,1143]]},"sCardArt84":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1042,1143],[1094,1143]]},"sCardArt85":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1146,1143],[1198,1143]]},"sCardArt86":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,3,46,58],"f":[[1250,1143],[1302,1143]]},"sCardArt87":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1354,1143],[1406,1143]]},"sCardArt88":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1458,1143],[1510,1143]]},"sCardArt89":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1562,1143],[1614,1143]]},"sCardArt9":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1666,1143],[1718,1143]]},"sCardArt90":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1770,1143],[1822,1143]]},"sCardArt91":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1874,1143],[1926,1143]]},"sCardArt92":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1978,1143],[2,1215]]},"sCardArt93":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,1,46,57],"f":[[54,1215],[106,1215]]},"sCardArt94":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[158,1215],[210,1215]]},"sCardArt95":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[262,1215],[314,1215]]},"sCardArt96":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[366,1215],[418,1215]]},"sCardArt97":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[470,1215],[522,1215]]},"sCardArt98":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[574,1215],[626,1215]]},"sCardArt99":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[2,4,48,57],"f":[[678,1215],[730,1215]]},"sCardBack":{"w":50,"h":70,"ox":25,"oy":35,"sp":0.0,"st":0,"bb":[0,0,49,69],"f":[[782,1215],[834,1215],[886,1215],[938,1215]]},"sCardBackground":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,45,67],"f":[[990,1215],[1042,1215]]},"sCardBase":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[0,0,49,69],"f":[[1094,1215]]},"sCardBorder":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[0,0,49,69],"f":[[1146,1215]]},"sCardLock":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[0,0,49,69],"f":[[1198,1215],[1250,1215]]},"sCardSeal":{"w":50,"h":70,"ox":25,"oy":35,"sp":0.0,"st":0,"bb":[6,13,44,52],"f":[[1302,1215]]},"sCardStars":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[8,59,41,65],"f":[[1354,1215],[1406,1215],[1458,1215],[1510,1215]]},"sCardTop":{"w":50,"h":70,"ox":25,"oy":35,"sp":0.0,"st":0,"bb":[2,2,47,67],"f":[[1562,1215],[1614,1215]]},"sCoin":{"w":15,"h":15,"ox":7,"oy":7,"sp":0.0,"st":0,"bb":[1,1,12,12],"f":[[846,1427],[863,1427],[880,1427],[897,1427]]},"sCursor":{"w":20,"h":20,"ox":9,"oy":9,"sp":0.0,"st":0,"bb":[1,2,18,16],"f":[[477,1390],[499,1390]]},"sDancer1":{"w":20,"h":20,"ox":10,"oy":10,"sp":5.0,"st":0,"bb":[3,2,16,18],"f":[[521,1390],[543,1390],[565,1390],[587,1390]]},"sDancer2":{"w":20,"h":20,"ox":10,"oy":10,"sp":10.0,"st":0,"bb":[5,2,15,18],"f":[[609,1390],[631,1390],[653,1390],[675,1390],[697,1390],[719,1390]]},"sDancer3":{"w":50,"h":50,"ox":25,"oy":25,"sp":3.0,"st":0,"bb":[21,10,39,33],"f":[[1498,1287],[1550,1287]]},"sFinalImage":{"w":160,"h":90,"ox":0,"oy":0,"sp":2.0,"st":0,"bb":[0,0,159,89],"f":[[614,681],[776,681]]},"sFXImpact":{"w":8,"h":8,"ox":4,"oy":4,"sp":30.0,"st":0,"bb":[0,0,7,7],"f":[[926,1427]]},"sGUIArrows":{"w":20,"h":20,"ox":10,"oy":10,"sp":0.0,"st":0,"bb":[4,2,17,16],"f":[[741,1390]]},"sGUIButton":{"w":40,"h":25,"ox":20,"oy":12,"sp":0.0,"st":0,"bb":[0,0,39,24],"f":[[394,1390]],"ns":[2,2,2,2]},"sGUICheckbox":{"w":20,"h":20,"ox":0,"oy":0,"sp":30.0,"st":0,"bb":[2,2,17,17],"f":[[763,1390],[785,1390]]},"sGUIMenu":{"w":25,"h":25,"ox":12,"oy":12,"sp":30.0,"st":0,"bb":[2,2,22,22],"f":[[436,1390]]},"sGUIOutline":{"w":8,"h":8,"ox":4,"oy":4,"sp":30.0,"st":0,"bb":[0,0,7,7],"f":[[936,1427],[946,1427]],"ns":[1,1,1,1]},"sGUISlidebar":{"w":40,"h":15,"ox":0,"oy":7,"sp":0.0,"st":0,"bb":[0,0,39,14],"f":[[506,1427],[548,1427]]},"sHand":{"w":64,"h":64,"ox":21,"oy":56,"sp":0.0,"st":0,"bb":[17,13,44,40],"f":[[1666,1215],[1732,1215]]},"sLogo":{"w":1500,"h":844,"ox":750,"oy":422,"sp":30.0,"st":0,"bb":[356,123,1086,718],"k":0.25,"f":[[2,2]],"tw":375,"th":211},"sMagnet":{"w":40,"h":40,"ox":21,"oy":20,"sp":0.0,"st":0,"bb":[12,12,25,27],"f":[[1686,1287],[1728,1287]]},"sMenuStudioDev":{"w":1000,"h":1000,"ox":500,"oy":500,"sp":30.0,"st":0,"bb":[217,226,781,981],"k":0.125,"f":[[1478,397]],"tw":125,"th":125},"sMenuStudioLogo":{"w":1920,"h":1080,"ox":936,"oy":619,"sp":30.0,"st":0,"bb":[256,227,1673,1042],"k":0.125,"f":[[1236,397]],"tw":240,"th":135},"sModule":{"w":20,"h":20,"ox":10,"oy":10,"sp":0.0,"st":0,"bb":[2,1,17,18],"f":[[807,1390],[829,1390],[851,1390],[873,1390]]},"sModuleArenaCrown":{"w":100,"h":100,"ox":50,"oy":40,"sp":30.0,"st":0,"bb":[37,28,62,46],"f":[[512,681]]},"sModuleMuseum":{"w":20,"h":20,"ox":10,"oy":10,"sp":0.0,"st":0,"bb":[4,2,15,18],"f":[[895,1390],[917,1390]]},"sScientist":{"w":150,"h":150,"ox":75,"oy":82,"sp":0.0,"st":0,"bb":[43,52,104,136],"f":[[628,397],[780,397],[932,397],[1084,397]]},"sUIBar":{"w":10,"h":10,"ox":0,"oy":5,"sp":0.0,"st":0,"bb":[0,0,9,9],"f":[[2033,1390],[914,1427]],"ns":[2,2,3,2]},"sUIButton":{"w":20,"h":20,"ox":10,"oy":10,"sp":0.0,"st":0,"bb":[1,1,18,18],"f":[[939,1390],[961,1390],[983,1390],[1005,1390],[1027,1390],[1049,1390],[1071,1390],[1093,1390]]},"sUICadre":{"w":20,"h":20,"ox":0,"oy":0,"sp":0.0,"st":0,"bb":[0,4,19,19],"f":[[1115,1390],[1137,1390]],"ns":[3,3,3,3]},"sUIClick":{"w":30,"h":48,"ox":15,"oy":32,"sp":0.0,"st":0,"bb":[2,19,27,44],"f":[[1999,2],[2013,397]]},"sUIDealer":{"w":32,"h":32,"ox":16,"oy":16,"sp":0.0,"st":0,"bb":[4,2,27,29],"f":[[360,1390]]},"sUIHeart":{"w":16,"h":16,"ox":2,"oy":3,"sp":30.0,"st":0,"bb":[1,2,13,13],"f":[[1313,1390]]},"sUIOngletsIcon":{"w":20,"h":20,"ox":10,"oy":10,"sp":0.0,"st":0,"bb":[1,1,18,18],"f":[[1159,1390],[1181,1390],[1203,1390],[1225,1390]]},"sUIRollGift":{"w":64,"h":64,"ox":31,"oy":28,"sp":30.0,"st":0,"bb":[22,13,39,35],"f":[[1798,1215]]},"sUIShopClick":{"w":64,"h":64,"ox":34,"oy":30,"sp":30.0,"st":0,"bb":[29,25,40,41],"f":[[1864,1215],[1930,1215]]},"sUIStar_1":{"w":21,"h":35,"ox":9,"oy":3,"sp":30.0,"st":0,"bb":[0,14,20,34],"f":[[1770,1287]]},"suistar":{"w":21,"h":35,"ox":9,"oy":3,"sp":30.0,"st":0,"bb":[0,14,20,34],"f":[[1793,1287]]},"sUITutorialInput":{"w":30,"h":15,"ox":15,"oy":7,"sp":30.0,"st":0,"bb":[1,1,25,12],"f":[[590,1427],[622,1427],[654,1427],[686,1427]]},"sUITutorialInput2":{"w":30,"h":15,"ox":15,"oy":7,"sp":30.0,"st":0,"bb":[1,1,25,12],"f":[[718,1427],[750,1427],[782,1427],[814,1427]]},"sUIUnlock":{"w":12,"h":23,"ox":6,"oy":11,"sp":30.0,"st":0,"bb":[2,1,9,21],"f":[[463,1390]]},"sUIUpgrade":{"w":20,"h":20,"ox":10,"oy":10,"sp":0.0,"st":0,"bb":[0,0,19,19],"f":[[1247,1390],[1269,1390],[1291,1390]]},"sUIUpgradeIcons":{"w":16,"h":16,"ox":8,"oy":8,"sp":0.0,"st":0,"bb":[0,0,15,15],"f":[[1331,1390],[1349,1390],[1367,1390],[1385,1390],[1403,1390],[1421,1390],[1439,1390],[1457,1390],[1475,1390],[1493,1390],[1511,1390],[1529,1390],[1547,1390],[1565,1390],[1583,1390],[1601,1390],[1619,1390],[1637,1390],[1655,1390],[1673,1390],[1691,1390],[1709,1390],[1727,1390],[1745,1390],[1763,1390],[1781,1390],[1799,1390],[1817,1390],[1835,1390],[1853,1390],[1871,1390],[1889,1390],[1907,1390],[1925,1390],[1943,1390],[1961,1390],[1979,1390],[1997,1390],[2015,1390],[2,1427],[20,1427],[38,1427],[56,1427],[74,1427],[92,1427],[110,1427],[128,1427],[146,1427],[164,1427],[182,1427],[200,1427],[218,1427],[236,1427],[254,1427],[272,1427],[290,1427],[308,1427],[326,1427],[344,1427],[362,1427],[380,1427],[398,1427],[416,1427],[434,1427],[452,1427],[470,1427],[488,1427]]},"pt_shape_pixel":{"w":64,"h":64,"ox":32,"oy":32,"sp":0,"st":0,"bb":[0,0,63,63],"f":[[2,1287]]},"pt_shape_disk":{"w":64,"h":64,"ox":32,"oy":32,"sp":0,"st":0,"bb":[0,0,63,63],"f":[[68,1287]]},"pt_shape_square":{"w":64,"h":64,"ox":32,"oy":32,"sp":0,"st":0,"bb":[0,0,63,63],"f":[[134,1287]]},"pt_shape_star":{"w":64,"h":64,"ox":32,"oy":32,"sp":0,"st":0,"bb":[0,0,63,63],"f":[[200,1287]]},"pt_shape_circle":{"w":64,"h":64,"ox":32,"oy":32,"sp":0,"st":0,"bb":[0,0,63,63],"f":[[266,1287]]},"pt_shape_ring":{"w":64,"h":64,"ox":32,"oy":32,"sp":0,"st":0,"bb":[0,0,63,63],"f":[[332,1287]]},"pt_shape_sphere":{"w":64,"h":64,"ox":32,"oy":32,"sp":0,"st":0,"bb":[0,0,63,63],"f":[[398,1287]]},"pt_shape_flare":{"w":64,"h":64,"ox":32,"oy":32,"sp":0,"st":0,"bb":[0,0,63,63],"f":[[464,1287]]},"pt_shape_spark":{"w":64,"h":64,"ox":32,"oy":32,"sp":0,"st":0,"bb":[0,0,63,63],"f":[[530,1287]]},"pt_shape_explosion":{"w":64,"h":64,"ox":32,"oy":32,"sp":0,"st":0,"bb":[0,0,63,63],"f":[[596,1287]]},"pt_shape_cloud":{"w":64,"h":64,"ox":32,"oy":32,"sp":0,"st":0,"bb":[0,0,63,63],"f":[[662,1287]]},"pt_shape_smoke":{"w":64,"h":64,"ox":32,"oy":32,"sp":0,"st":0,"bb":[0,0,63,63],"f":[[728,1287]]},"pt_shape_snow":{"w":64,"h":64,"ox":32,"oy":32,"sp":0,"st":0,"bb":[0,0,63,63],"f":[[794,1287]]},"pt_shape_line":{"w":64,"h":64,"ox":32,"oy":32,"sp":0,"st":0,"bb":[0,0,63,63],"f":[[860,1287]]}}`,
      ),
      white: [956, 1427],
      font: {
        size: 24,
        lineHeight: 35,
        glyphs: {
          32: [2036, 215, 10, 35, 10, 0],
          33: [2042, 579, 4, 35, 6, 0],
          34: [16, 1390, 10, 35, 12, 0],
          35: [2030, 681, 16, 35, 18, 0],
          36: [2, 1353, 12, 35, 14, 0],
          37: [16, 1353, 12, 35, 14, 0],
          38: [30, 1353, 12, 35, 14, 0],
          39: [288, 1390, 4, 35, 6, 0],
          40: [176, 1390, 6, 35, 8, 0],
          41: [184, 1390, 6, 35, 8, 0],
          42: [192, 1390, 6, 35, 10, 2],
          43: [44, 1353, 12, 35, 14, 0],
          44: [294, 1390, 4, 35, 6, 0],
          45: [58, 1353, 12, 35, 14, 0],
          46: [300, 1390, 4, 35, 6, 0],
          47: [72, 1353, 12, 35, 14, 0],
          48: [86, 1353, 12, 35, 14, 0],
          49: [200, 1390, 6, 35, 8, 0],
          50: [100, 1353, 12, 35, 14, 0],
          51: [114, 1353, 12, 35, 14, 0],
          52: [128, 1353, 12, 35, 14, 0],
          53: [142, 1353, 12, 35, 14, 0],
          54: [156, 1353, 12, 35, 14, 0],
          55: [170, 1353, 12, 35, 14, 0],
          56: [184, 1353, 12, 35, 14, 0],
          57: [198, 1353, 12, 35, 14, 0],
          58: [306, 1390, 4, 35, 6, 0],
          59: [312, 1390, 4, 35, 6, 0],
          60: [28, 1390, 10, 35, 12, 0],
          61: [212, 1353, 12, 35, 14, 0],
          62: [40, 1390, 10, 35, 12, 0],
          63: [226, 1353, 12, 35, 14, 0],
          64: [240, 1353, 12, 35, 14, 0],
          65: [254, 1353, 12, 35, 14, 0],
          66: [268, 1353, 12, 35, 14, 0],
          67: [282, 1353, 12, 35, 14, 0],
          68: [296, 1353, 12, 35, 14, 0],
          69: [310, 1353, 12, 35, 14, 0],
          70: [324, 1353, 12, 35, 14, 0],
          71: [338, 1353, 12, 35, 14, 0],
          72: [352, 1353, 12, 35, 14, 0],
          73: [366, 1353, 12, 35, 14, 0],
          74: [380, 1353, 12, 35, 14, 0],
          75: [394, 1353, 12, 35, 14, 0],
          76: [408, 1353, 12, 35, 14, 0],
          77: [422, 1353, 12, 35, 14, 0],
          78: [436, 1353, 12, 35, 14, 0],
          79: [450, 1353, 12, 35, 14, 0],
          80: [464, 1353, 12, 35, 14, 0],
          81: [478, 1353, 12, 35, 14, 0],
          82: [492, 1353, 12, 35, 14, 0],
          83: [506, 1353, 12, 35, 14, 0],
          84: [520, 1353, 12, 35, 14, 0],
          85: [534, 1353, 12, 35, 14, 0],
          86: [548, 1353, 12, 35, 14, 0],
          87: [2030, 783, 16, 35, 18, 0],
          88: [562, 1353, 12, 35, 14, 0],
          89: [576, 1353, 12, 35, 14, 0],
          90: [590, 1353, 12, 35, 14, 0],
          91: [208, 1390, 6, 35, 8, 0],
          92: [604, 1353, 12, 35, 14, 0],
          93: [216, 1390, 6, 35, 8, 0],
          94: [618, 1353, 12, 35, 14, 0],
          95: [632, 1353, 12, 35, 14, 0],
          96: [318, 1390, 4, 35, 6, 0],
          97: [646, 1353, 12, 35, 14, 0],
          98: [660, 1353, 12, 35, 14, 0],
          99: [674, 1353, 12, 35, 14, 0],
          100: [688, 1353, 12, 35, 14, 0],
          101: [702, 1353, 12, 35, 14, 0],
          102: [52, 1390, 10, 35, 12, 0],
          103: [716, 1353, 12, 35, 14, 0],
          104: [730, 1353, 12, 35, 14, 0],
          105: [324, 1390, 4, 35, 6, 0],
          106: [224, 1390, 6, 35, 6, -2],
          107: [744, 1353, 12, 35, 14, 0],
          108: [330, 1390, 4, 35, 6, 0],
          109: [2030, 855, 16, 35, 18, 0],
          110: [758, 1353, 12, 35, 14, 0],
          111: [772, 1353, 12, 35, 14, 0],
          112: [786, 1353, 12, 35, 14, 0],
          113: [800, 1353, 12, 35, 14, 0],
          114: [814, 1353, 12, 35, 14, 0],
          115: [828, 1353, 12, 35, 14, 0],
          116: [136, 1390, 8, 35, 10, 0],
          117: [842, 1353, 12, 35, 14, 0],
          118: [856, 1353, 12, 35, 14, 0],
          119: [2030, 927, 16, 35, 18, 0],
          120: [870, 1353, 12, 35, 14, 0],
          121: [884, 1353, 12, 35, 14, 0],
          122: [898, 1353, 12, 35, 14, 0],
          123: [232, 1390, 6, 35, 8, 0],
          124: [2044, 1287, 2, 35, 4, 0],
          125: [240, 1390, 6, 35, 8, 0],
          126: [912, 1353, 12, 35, 14, 0],
          160: [2045, 397, 1, 35, 10, 0],
          161: [336, 1390, 4, 35, 6, 0],
          162: [926, 1353, 12, 35, 14, 0],
          163: [2031, 2, 14, 35, 16, 0],
          164: [940, 1353, 12, 35, 14, 0],
          165: [954, 1353, 12, 35, 14, 0],
          166: [342, 1390, 4, 35, 6, 0],
          167: [968, 1353, 12, 35, 14, 0],
          168: [64, 1390, 10, 35, 12, 0],
          169: [1816, 1287, 20, 35, 22, 0],
          170: [76, 1390, 10, 35, 12, 0],
          171: [2030, 999, 16, 35, 18, 0],
          172: [982, 1353, 12, 35, 14, 0],
          174: [1838, 1287, 20, 35, 22, 0],
          175: [996, 1353, 12, 35, 14, 0],
          176: [146, 1390, 8, 35, 10, 0],
          177: [1010, 1353, 12, 35, 14, 0],
          178: [88, 1390, 10, 35, 12, 0],
          179: [100, 1390, 10, 35, 12, 0],
          180: [248, 1390, 6, 35, 8, 0],
          181: [1024, 1353, 12, 35, 14, 0],
          182: [1980, 1287, 14, 35, 16, 0],
          183: [348, 1390, 4, 35, 6, 0],
          184: [256, 1390, 6, 35, 8, 0],
          185: [264, 1390, 6, 35, 8, 0],
          186: [112, 1390, 10, 35, 12, 0],
          187: [2030, 1071, 16, 35, 18, 0],
          188: [1882, 1287, 18, 35, 20, 0],
          189: [1902, 1287, 18, 35, 20, 0],
          190: [1922, 1287, 18, 35, 20, 0],
          191: [1038, 1353, 12, 35, 14, 0],
          192: [1052, 1353, 12, 35, 14, 0],
          193: [1066, 1353, 12, 35, 14, 0],
          194: [1080, 1353, 12, 35, 14, 0],
          195: [1094, 1353, 12, 35, 14, 0],
          196: [1108, 1353, 12, 35, 14, 0],
          197: [1122, 1353, 12, 35, 14, 0],
          198: [1942, 1287, 18, 35, 20, 0],
          199: [1136, 1353, 12, 35, 14, 0],
          200: [1150, 1353, 12, 35, 14, 0],
          201: [1164, 1353, 12, 35, 14, 0],
          202: [1178, 1353, 12, 35, 14, 0],
          203: [1192, 1353, 12, 35, 14, 0],
          204: [1206, 1353, 12, 35, 14, 0],
          205: [1220, 1353, 12, 35, 14, 0],
          206: [1234, 1353, 12, 35, 14, 0],
          207: [1248, 1353, 12, 35, 14, 0],
          208: [1996, 1287, 14, 35, 16, 0],
          209: [1262, 1353, 12, 35, 14, 0],
          210: [1276, 1353, 12, 35, 14, 0],
          211: [1290, 1353, 12, 35, 14, 0],
          212: [1304, 1353, 12, 35, 14, 0],
          213: [1318, 1353, 12, 35, 14, 0],
          214: [1332, 1353, 12, 35, 14, 0],
          215: [1346, 1353, 12, 35, 14, 0],
          216: [2030, 1143, 16, 35, 16, -2],
          217: [1360, 1353, 12, 35, 14, 0],
          218: [1374, 1353, 12, 35, 14, 0],
          219: [1388, 1353, 12, 35, 14, 0],
          220: [1402, 1353, 12, 35, 14, 0],
          221: [1416, 1353, 12, 35, 14, 0],
          222: [1430, 1353, 12, 35, 14, 0],
          223: [1444, 1353, 12, 35, 14, 0],
          224: [1458, 1353, 12, 35, 14, 0],
          225: [1472, 1353, 12, 35, 14, 0],
          226: [1486, 1353, 12, 35, 14, 0],
          227: [1500, 1353, 12, 35, 14, 0],
          228: [1514, 1353, 12, 35, 14, 0],
          229: [1528, 1353, 12, 35, 14, 0],
          230: [1860, 1287, 20, 35, 22, 0],
          231: [1542, 1353, 12, 35, 14, 0],
          232: [1556, 1353, 12, 35, 14, 0],
          233: [1570, 1353, 12, 35, 14, 0],
          234: [1584, 1353, 12, 35, 14, 0],
          235: [1598, 1353, 12, 35, 14, 0],
          236: [272, 1390, 6, 35, 6, -2],
          237: [280, 1390, 6, 35, 8, 0],
          238: [156, 1390, 8, 35, 8, -2],
          239: [166, 1390, 8, 35, 8, -2],
          240: [2012, 1287, 14, 35, 16, 0],
          241: [1612, 1353, 12, 35, 14, 0],
          242: [1626, 1353, 12, 35, 14, 0],
          243: [1640, 1353, 12, 35, 14, 0],
          244: [1654, 1353, 12, 35, 14, 0],
          245: [1668, 1353, 12, 35, 14, 0],
          246: [1682, 1353, 12, 35, 14, 0],
          247: [1696, 1353, 12, 35, 14, 0],
          248: [1962, 1287, 16, 35, 16, -2],
          249: [1710, 1353, 12, 35, 14, 0],
          250: [1724, 1353, 12, 35, 14, 0],
          251: [1738, 1353, 12, 35, 14, 0],
          252: [1752, 1353, 12, 35, 14, 0],
          253: [1766, 1353, 12, 35, 14, 0],
          254: [1780, 1353, 12, 35, 14, 0],
          255: [1794, 1353, 12, 35, 14, 0],
          260: [1808, 1353, 12, 35, 14, 0],
          261: [1822, 1353, 12, 35, 14, 0],
          262: [1836, 1353, 12, 35, 14, 0],
          263: [1850, 1353, 12, 35, 14, 0],
          280: [1864, 1353, 12, 35, 14, 0],
          281: [1878, 1353, 12, 35, 14, 0],
          287: [1892, 1353, 12, 35, 14, 0],
          304: [1906, 1353, 12, 35, 14, 0],
          305: [354, 1390, 4, 35, 6, 0],
          321: [2028, 1287, 14, 35, 14, -2],
          322: [124, 1390, 10, 35, 10, -2],
          323: [1920, 1353, 12, 35, 14, 0],
          324: [1934, 1353, 12, 35, 14, 0],
          346: [1948, 1353, 12, 35, 14, 0],
          347: [1962, 1353, 12, 35, 14, 0],
          350: [1976, 1353, 12, 35, 14, 0],
          351: [1990, 1353, 12, 35, 14, 0],
          377: [2004, 1353, 12, 35, 14, 0],
          378: [2018, 1353, 12, 35, 14, 0],
          379: [2032, 1353, 12, 35, 14, 0],
          380: [2, 1390, 12, 35, 14, 0],
        },
      },
    },
    h = {
      mscBoard1: 1,
      mscBoard2: 0.78,
      mscBoard3: 0.86,
      mscBoard4: 0.88,
      mscBoard5: 0.64,
      mscBoardRush: 1,
      mscCollectionFull: 0.95,
      mscEnding: 1,
      mscModuleArena: 0.89,
      mscModuleLab: 0.8,
      mscModuleMemory: 0.84,
      mscModuleMuseum: 1,
      mscTitle: 0.86,
      mscTuto: 1,
      sndApplause: 0.78,
      sndBarTick: 0.77,
      sndBoosterHurt: 0.77,
      sndBoosterHurt2: 0.86,
      sndCardDraw1: 0.65,
      sndCardDraw2: 0.75,
      sndCardDraw3: 0.84,
      sndCardFlip1: 1,
      sndCardFull: 0.91,
      sndCardNew0: 0.66,
      sndCardNew1: 0.62,
      sndCardNew2: 0.62,
      sndCardNew3: 0.64,
      sndCardNew4: 0.64,
      sndCardNew5: 0.65,
      sndCardNew6: 1,
      sndCardNotnew: 0.6,
      sndCardRecord: 0.63,
      sndCardStamp: 0.92,
      sndClick1: 0.45,
      sndCoin: 0.94,
      sndExplosion1: 0.59,
      sndExplosion2: 0.47,
      sndHover: 0.29,
      sndHurt1: 1,
      sndModuleLabLaunched: 1,
      sndModuleMuseum1: 0.65,
      sndModuleMuseum2: 0.45,
      sndModuleMuseum3: 1,
      sndMoney1: 0.8,
      sndUpgrade1: 0.5,
      sndVoiceEN123: 1,
      sndVoiceEN124: 1,
      sndVoiceEN125: 1,
      sndVoiceEN126: 1,
      sndVoiceEN142: 1,
      sndVoiceEN28: 1,
      sndVoiceEN29: 1,
      sndVoiceEN58: 1,
      sndVoiceEN59: 1,
      sndVoiceFR123: 1,
      sndVoiceFR124: 1,
      sndVoiceFR125: 1,
      sndVoiceFR126: 1,
      sndVoiceFR142: 1,
      sndVoiceFR28: 1,
      sndVoiceFR29: 1,
      sndVoiceFR58: 1,
      sndVoiceFR59: 1,
      sndWoosh1: 1,
      sndWooshEnter: 1,
      sndWooshExit: 1,
      sndWrong1: 1,
    };
  let g = {
      ebe5883f2d5006b14d3f63f1a9e90589752cb3b01c4ff39b0637f9806c4f82c1: `Crack the Pack (reference build, GEN8 timestamp 1791067143)`,
    },
    _ = {
      projectName: `Idle_Cards`,
      displayName: `Crack the Pack`,
      minBytecode: 17,
    },
    v = Object.entries(m.sprites).filter(([e]) => !e.startsWith(`pt_shape_`)),
    y = Object.keys(h),
    b = `fontBase`,
    x = [
      [`mask`, `spr_mask_rgbx`, 0],
      [`slot`, `spr_slot`, 0],
      [`underwater`, `_filter_underwater_noise_sprite`, 0],
      [`heathaze`, `_filter_heathaze_noise_sprite`, 0],
    ];
  async function S(e) {
    let t = await crypto.subtle.digest(`SHA-256`, e);
    return Array.from(new Uint8Array(t), (e) =>
      e.toString(16).padStart(2, `0`),
    ).join(``);
  }
  function C(e, t = ``) {
    let n = (e, n = [], r = null) => ({
        result: {
          ok: !1,
          gen8: r,
          reason: e,
          problems: n,
          knownBuild: g[t] ?? null,
          sha256: t,
        },
        dw: null,
      }),
      r,
      i;
    try {
      ((r = new f(e)), (i = r.gen8()));
    } catch (e) {
      return e instanceof d
        ? e.code === `not-gamemaker`
          ? n(`This file isn't a GameMaker data.win.`, [e.message])
          : n(
              `This data.win is damaged or incomplete. Copy it again from your game folder.`,
              [e.message],
            )
        : n(`This file couldn't be read.`, [String(e)]);
    }
    if (i.name !== _.projectName || i.displayName !== _.displayName)
      return n(
        `This data.win belongs to "${(i.displayName || i.name || ``).trim() || `another game`}", not Crack the Pack.`,
        [`GEN8 name "${i.name}", display name "${i.displayName}"`],
        i,
      );
    if (i.bytecodeVersion < _.minBytecode)
      return n(
        `This is an old Crack the Pack build that this port doesn't support.`,
        [`bytecode ${i.bytecodeVersion}`],
        i,
      );
    let a = [];
    try {
      for (let e of [`SPRT`, `TPAG`, `TXTR`, `FONT`, `SOND`, `AUDO`])
        r.chunks.has(e) || a.push(`missing ${e} chunk`);
      if (!a.length) {
        let e = r.sprites();
        for (let [t, n] of v) {
          let r = e.get(t);
          r
            ? (r.width !== n.w ||
                r.height !== n.h ||
                r.frames.length !== n.f.length ||
                r.originX !== n.ox ||
                r.originY !== n.oy) &&
              a.push(
                `sprite ${t} is ${r.width}×${r.height}/${r.frames.length}f, expected ${n.w}×${n.h}/${n.f.length}f`,
              )
            : a.push(`sprite ${t} missing`);
        }
        for (let [, t, n] of x)
          e.get(t)?.frames[n] || a.push(`texture ${t} missing`);
        let t = r.pageCount();
        for (let n of e.values())
          for (let e of n.frames)
            e.page >= t &&
              a.push(`sprite ${n.name} uses missing page ${e.page}`);
        r.fonts().get(`fontBase`)?.item || a.push(`font ${b} missing`);
        let n = r.sounds(),
          i = r.list(`AUDO`).length;
        for (let e of y) {
          let t = n.get(e);
          t
            ? t.audioIndex >= i &&
              a.push(`sound ${e} points at missing audio ${t.audioIndex}`)
            : a.push(`sound ${e} missing`);
        }
      }
    } catch (e) {
      return n(
        `This data.win is damaged or incomplete. Copy it again from your game folder.`,
        [String(e.message ?? e)],
        i,
      );
    }
    return a.length
      ? n(
          `This Crack the Pack data.win is a different version: some resources the port needs don't match.`,
          a.slice(0, 20),
          i,
        )
      : {
          result: {
            ok: !0,
            gen8: i,
            reason: ``,
            problems: [],
            knownBuild: g[t] ?? null,
            sha256: t,
          },
          dw: r,
        };
  }
  let w = `crack-a-pack`,
    T = `GameVault/installations/${w}`;
  (`${T}`, `${T}`);
  let E = {
    sprite: (e, t) => `assets/sprites/${e}_${t}.png`,
    font: (e) => `assets/textures/fonts/${e}.png`,
    fx: (e) => `assets/textures/fx/${e}.png`,
    atlas: `assets/textures/sprite_atlas.png`,
    audio: (e, t) => `assets/audio/${e}.${t}`,
    gen8: `metadata/gen8.json`,
  };
  function D(e) {
    let t = new Uint8Array(16384);
    for (let n = 0; n < 64; n++)
      for (let r = 0; r < 64; r++) {
        let i = (n * 64 + r) * 4,
          a = Math.max(0, Math.min(1, e(r, n)));
        ((t[i] = t[i + 1] = t[i + 2] = 255), (t[i + 3] = Math.round(a * 255)));
      }
    return { width: 64, height: 64, data: t };
  }
  function O(e) {
    return (t, n) => {
      let r = 0;
      for (let i = 0; i < 4; i++)
        for (let a = 0; a < 4; a++)
          e(t + (a + 0.5) / 4, n + (i + 0.5) / 4) && r++;
      return r / 16;
    };
  }
  let k = (e, t) => Math.hypot(e - 32, t - 32),
    A = (e, t) => {
      let n = Math.sin(e * 12.9898 + t * 78.233) * 43758.5453;
      return n - Math.floor(n);
    };
  function j(e, t, n) {
    let r = e / n,
      i = t / n,
      a = Math.floor(r),
      o = Math.floor(i),
      s = r - a,
      c = i - o,
      l = (e, t, n) => e + (t - e) * (n * n * (3 - 2 * n));
    return l(l(A(a, o), A(a + 1, o), s), l(A(a, o + 1), A(a + 1, o + 1), s), c);
  }
  function M(e, t) {
    let n = [];
    for (let e = 0; e < 10; e++) {
      let t = e % 2 ? 12.5 : 31,
        r = -Math.PI / 2 + (e * Math.PI) / 5;
      n.push([32 + t * Math.cos(r), 34 + t * Math.sin(r)]);
    }
    let r = !1;
    for (let i = 0, a = n.length - 1; i < n.length; a = i++) {
      let [o, s] = n[i],
        [c, l] = n[a];
      s > t != l > t && e < ((c - o) * (t - s)) / (l - s) + o && (r = !r);
    }
    return r;
  }
  let N = {
      pt_shape_pixel: () =>
        D((e, t) => +(e >= 31 && e <= 32 && t >= 31 && t <= 32)),
      pt_shape_disk: () => D(O((e, t) => k(e, t) <= 31)),
      pt_shape_square: () =>
        D((e, t) => +(e >= 2 && e < 62 && t >= 2 && t < 62)),
      pt_shape_line: () =>
        D((e, t) =>
          t >= 31 && t <= 32 && e >= 2 && e < 62
            ? 1 - Math.abs(e - 31.5) / 32
            : 0,
        ),
      pt_shape_star: () => D((e, t) => +!!M(e + 0.5, t + 0.5)),
      pt_shape_circle: () => D(O((e, t) => Math.abs(k(e, t) - 29.5) <= 1)),
      pt_shape_ring: () =>
        D((e, t) => Math.exp(-(((k(e + 0.5, t + 0.5) - 20) / 4) ** 2))),
      pt_shape_sphere: () =>
        D((e, t) => Math.max(0, 1 - k(e + 0.5, t + 0.5) / 30) ** 1.5),
      pt_shape_flare: () =>
        D((e, t) => {
          let n = Math.abs(e + 0.5 - 32),
            r = Math.abs(t + 0.5 - 32);
          return (
            Math.max(0, 1 - k(e + 0.5, t + 0.5) / 31) *
            (Math.exp(-n / 1.2) + Math.exp(-r / 1.2) + Math.exp(-(n + r) / 4))
          );
        }),
      pt_shape_spark: () =>
        D((e, t) => {
          let n = e + 0.5 - 32,
            r = t + 0.5 - 32,
            i = Math.hypot(n, r),
            a = Math.atan2(r, n);
          return (
            Math.max(0, 1 - i / 28) *
            (Math.abs(Math.cos(4 * a)) ** 24 + Math.exp(-i / 3))
          );
        }),
      pt_shape_snow: () =>
        D(
          O((e, t) => {
            let n = e - 32,
              r = t - 32;
            if (Math.hypot(n, r) > 30) return !1;
            for (let e = 0; e < 3; e++) {
              let t = (e * Math.PI) / 3;
              if (Math.abs(n * Math.sin(t) - r * Math.cos(t)) <= 1.5) return !0;
            }
            return !1;
          }),
        ),
      pt_shape_explosion: () =>
        D((e, t) => Math.max(0, 1 - k(e, t) / 30) * (0.4 + 0.8 * j(e, t, 6))),
      pt_shape_cloud: () =>
        D(
          (e, t) =>
            0.83 *
            Math.max(0, 1 - k(e, t) / 30) *
            (0.3 + 0.7 * j(e + 9, t + 3, 8)),
        ),
      pt_shape_smoke: () =>
        D(
          (e, t) =>
            0.52 *
            Math.max(0, 1 - k(e, t) / 30) *
            (0.3 + 0.7 * j(e + 4, t + 17, 7)),
        ),
    },
    P = Object.keys(N);
  function F(e) {
    let t = N[e];
    if (!t) throw Error(`unknown particle shape ${e}`);
    return t();
  }
  async function I(e, t, n = [], r = () => {}) {
    try {
      return await L(e, t, n, r);
    } catch (t) {
      let n = await S(e).catch(() => ``);
      return {
        ok: !1,
        identification: {
          ok: !1,
          gen8: null,
          reason: `This data.win is damaged: some of its pictures or sounds can't be read. Copy it again from your game folder.`,
          problems: [t instanceof Error ? t.message : String(t)],
          knownBuild: null,
          sha256: n,
        },
      };
    }
  }
  async function L(e, t, n, r) {
    r({ stage: `checking`, done: 0, total: 1 });
    let i = await S(e),
      { result: a, dw: o } = C(e, i);
    if (!a.ok || !o) return { ok: !1, identification: a };
    let s = [],
      l = (e) => s.push(e),
      u = o.sprites(),
      d = [];
    for (let [e, t] of v) for (let n = 0; n < t.f.length; n++) d.push([e, n]);
    let f = d.length + P.length,
      p = 0;
    d.sort(
      (e, t) => u.get(e[0]).frames[e[1]].page - u.get(t[0]).frames[t[1]].page,
    );
    let m = -1;
    for (let [e, t] of d) {
      let n = u.get(e).frames[t];
      (m !== -1 && n.page !== m && o.dropPage(m),
        (m = n.page),
        l({
          path: E.sprite(e, t),
          data: await c(await o.frame(n)),
          mime: `image/png`,
          kind: `sprite`,
          source: `data.win`,
        }),
        ++p % 16 == 0 && r({ stage: `sprites`, done: p, total: f }));
    }
    for (let e of P)
      (l({
        path: E.sprite(e, 0),
        data: await c(F(e)),
        mime: `image/png`,
        kind: `sprite`,
        source: `port`,
      }),
        p++);
    (r({ stage: `sprites`, done: p, total: f }),
      r({ stage: `textures`, done: 0, total: 1 + x.length }));
    let h = o.fonts().get(b);
    l({
      path: E.font(b),
      data: await c(await o.region(h.item)),
      mime: `image/png`,
      kind: `font`,
      source: `data.win`,
    });
    for (let [e, t, n] of x)
      l({
        path: E.fx(e),
        data: await c(await o.frame(u.get(t).frames[n])),
        mime: `image/png`,
        kind: `texture`,
        source: `data.win`,
      });
    let g = R(o, n, l, (e, t) => r({ stage: `audio`, done: e, total: t })),
      y = {
        schema: 1,
        game: w,
        portVersion: `1.0.0`,
        supported: { ..._ },
        source: {
          fileName: t,
          size: e.length,
          sha256: i,
          knownBuild: a.knownBuild,
          gen8: a.gen8,
        },
        importedAt: new Date().toISOString(),
        files: {},
        music: g,
        atlas: null,
      };
    l({
      path: E.gen8,
      data: new TextEncoder().encode(JSON.stringify(a.gen8, null, 2)),
      mime: `application/json`,
      kind: `metadata`,
      source: `data.win`,
    });
    for (let e of s)
      y.files[e.path] = {
        size: e.data.length,
        sha256: await S(e.data),
        kind: e.kind,
        source: e.source,
      };
    return (
      r({ stage: `done`, done: 1, total: 1 }),
      { ok: !0, identification: a, manifest: y, files: s }
    );
  }
  function R(e, t, n, r) {
    let i = e.sounds(),
      a = new Map(t.map((e) => [e.name.toLowerCase(), e.data])),
      o = [],
      s = [];
    return (
      y.forEach((t, c) => {
        let l = i.get(t),
          u = null,
          d = `data.win`;
        if (l.audioIndex >= 0) u = e.audio(l.audioIndex);
        else {
          let e = a.get((l.file || `${t}.ogg`).toLowerCase());
          e && ((u = e), (d = `game-folder`));
        }
        let f = u ? p(u) : null;
        if (u && f)
          (n({
            path: E.audio(t, f.ext),
            data: u,
            mime: f.mime,
            kind: `audio`,
            source: d,
          }),
            l.audioIndex < 0 && o.push(t));
        else if (l.audioIndex < 0) s.push(t);
        else throw Error(`Embedded sound ${t} has an unknown format.`);
        r(c + 1, y.length);
      }),
      { present: o, missing: s }
    );
  }
  self.onmessage = async (e) => {
    let { dataWin: t, fileName: n, extras: r } = e.data;
    try {
      let e = r.map((e) => ({ name: e.name, data: new Uint8Array(e.data) })),
        i = await I(new Uint8Array(t), n, e, (e) =>
          self.postMessage({ type: `progress`, p: e }),
        );
      if (!i.ok) {
        self.postMessage({ type: `result`, res: i });
        return;
      }
      let a = [],
        o = i.files.map((e) => {
          let t = e.data.slice();
          return (a.push(t.buffer), { ...e, data: t });
        });
      self.postMessage({ type: `result`, res: { ...i, files: o } }, a);
    } catch (e) {
      self.postMessage({
        type: `error`,
        message: e instanceof Error ? e.message : String(e),
      });
    }
  };
})();

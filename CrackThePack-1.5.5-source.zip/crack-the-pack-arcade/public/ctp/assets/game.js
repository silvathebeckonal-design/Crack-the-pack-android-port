var e = Object.create,
  t = Object.defineProperty,
  n = Object.getOwnPropertyDescriptor,
  r = Object.getOwnPropertyNames,
  i = Object.getPrototypeOf,
  a = Object.prototype.hasOwnProperty,
  o = (e, t) => () => (
    t || (e((t = { exports: {} }).exports, t), (e = null)),
    t.exports
  ),
  s = (e, i, o, s) => {
    if ((i && typeof i == `object`) || typeof i == `function`)
      for (var c = r(i), l = 0, u = c.length, d; l < u; l++)
        ((d = c[l]),
          !a.call(e, d) &&
            d !== o &&
            t(e, d, {
              get: ((e) => i[e]).bind(null, d),
              enumerable: !(s = n(i, d)) || s.enumerable,
            }));
    return e;
  },
  c = (n, r, o) => (
    (o = n == null ? {} : e(i(n))),
    s(
      r || !n || !n.__esModule || !a.call(n, `default`)
        ? t(o, `default`, { value: n, enumerable: !0 })
        : o,
      n,
    )
  );
(function () {
  let e = document.createElement(`link`).relList;
  if (e && e.supports && e.supports(`modulepreload`)) return;
  for (let e of document.querySelectorAll(`link[rel="modulepreload"]`)) n(e);
  new MutationObserver((e) => {
    for (let t of e)
      if (t.type === `childList`)
        for (let e of t.addedNodes)
          e.tagName === `LINK` && e.rel === `modulepreload` && n(e);
  }).observe(document, { childList: !0, subtree: !0 });
  function t(e) {
    let t = {};
    return (
      e.integrity && (t.integrity = e.integrity),
      e.referrerPolicy && (t.referrerPolicy = e.referrerPolicy),
      (t.credentials =
        e.crossOrigin === `use-credentials`
          ? `include`
          : e.crossOrigin === `anonymous`
            ? `omit`
            : `same-origin`),
      t
    );
  }
  function n(e) {
    if (e.ep) return;
    e.ep = !0;
    let n = t(e);
    fetch(e.href, n);
  }
})();
var l = o((e) => {
    var t = Symbol.for(`react.transitional.element`),
      n = Symbol.for(`react.portal`),
      r = Symbol.for(`react.fragment`),
      i = Symbol.for(`react.strict_mode`),
      a = Symbol.for(`react.profiler`),
      o = Symbol.for(`react.consumer`),
      s = Symbol.for(`react.context`),
      c = Symbol.for(`react.forward_ref`),
      l = Symbol.for(`react.suspense`),
      u = Symbol.for(`react.memo`),
      d = Symbol.for(`react.lazy`),
      f = Symbol.for(`react.activity`),
      p = Symbol.iterator;
    function m(e) {
      return typeof e != `object` || !e
        ? null
        : ((e = (p && e[p]) || e[`@@iterator`]),
          typeof e == `function` ? e : null);
    }
    var h = {
        isMounted: function () {
          return !1;
        },
        enqueueForceUpdate: function () {},
        enqueueReplaceState: function () {},
        enqueueSetState: function () {},
      },
      g = Object.assign,
      _ = {};
    function v(e, t, n) {
      ((this.props = e),
        (this.context = t),
        (this.refs = _),
        (this.updater = n || h));
    }
    ((v.prototype.isReactComponent = {}),
      (v.prototype.setState = function (e, t) {
        if (typeof e != `object` && typeof e != `function` && e != null)
          throw Error(
            `takes an object of state variables to update or a function which returns an object of state variables.`,
          );
        this.updater.enqueueSetState(this, e, t, `setState`);
      }),
      (v.prototype.forceUpdate = function (e) {
        this.updater.enqueueForceUpdate(this, e, `forceUpdate`);
      }));
    function y() {}
    y.prototype = v.prototype;
    function b(e, t, n) {
      ((this.props = e),
        (this.context = t),
        (this.refs = _),
        (this.updater = n || h));
    }
    var x = (b.prototype = new y());
    ((x.constructor = b), g(x, v.prototype), (x.isPureReactComponent = !0));
    var ee = Array.isArray;
    function S() {}
    var C = { H: null, A: null, T: null, S: null },
      te = Object.prototype.hasOwnProperty;
    function ne(e, n, r) {
      var i = r.ref;
      return {
        $$typeof: t,
        type: e,
        key: n,
        ref: i === void 0 ? null : i,
        props: r,
      };
    }
    function re(e, t) {
      return ne(e.type, t, e.props);
    }
    function ie(e) {
      return typeof e == `object` && !!e && e.$$typeof === t;
    }
    function ae(e) {
      var t = { "=": `=0`, ":": `=2` };
      return (
        `$` +
        e.replace(/[=:]/g, function (e) {
          return t[e];
        })
      );
    }
    var oe = /\/+/g;
    function se(e, t) {
      return typeof e == `object` && e && e.key != null
        ? ae(`` + e.key)
        : t.toString(36);
    }
    function ce(e) {
      switch (e.status) {
        case `fulfilled`:
          return e.value;
        case `rejected`:
          throw e.reason;
        default:
          switch (
            (typeof e.status == `string`
              ? e.then(S, S)
              : ((e.status = `pending`),
                e.then(
                  function (t) {
                    e.status === `pending` &&
                      ((e.status = `fulfilled`), (e.value = t));
                  },
                  function (t) {
                    e.status === `pending` &&
                      ((e.status = `rejected`), (e.reason = t));
                  },
                )),
            e.status)
          ) {
            case `fulfilled`:
              return e.value;
            case `rejected`:
              throw e.reason;
          }
      }
      throw e;
    }
    function le(e, r, i, a, o) {
      var s = typeof e;
      (s === `undefined` || s === `boolean`) && (e = null);
      var c = !1;
      if (e === null) c = !0;
      else
        switch (s) {
          case `bigint`:
          case `string`:
          case `number`:
            c = !0;
            break;
          case `object`:
            switch (e.$$typeof) {
              case t:
              case n:
                c = !0;
                break;
              case d:
                return ((c = e._init), le(c(e._payload), r, i, a, o));
            }
        }
      if (c)
        return (
          (o = o(e)),
          (c = a === `` ? `.` + se(e, 0) : a),
          ee(o)
            ? ((i = ``),
              c != null && (i = c.replace(oe, `$&/`) + `/`),
              le(o, r, i, ``, function (e) {
                return e;
              }))
            : o != null &&
              (ie(o) &&
                (o = re(
                  o,
                  i +
                    (o.key == null || (e && e.key === o.key)
                      ? ``
                      : (`` + o.key).replace(oe, `$&/`) + `/`) +
                    c,
                )),
              r.push(o)),
          1
        );
      c = 0;
      var l = a === `` ? `.` : a + `:`;
      if (ee(e))
        for (var u = 0; u < e.length; u++)
          ((a = e[u]), (s = l + se(a, u)), (c += le(a, r, i, s, o)));
      else if (((u = m(e)), typeof u == `function`))
        for (e = u.call(e), u = 0; !(a = e.next()).done;)
          ((a = a.value), (s = l + se(a, u++)), (c += le(a, r, i, s, o)));
      else if (s === `object`) {
        if (typeof e.then == `function`) return le(ce(e), r, i, a, o);
        throw (
          (r = String(e)),
          Error(
            `Objects are not valid as a React child (found: ` +
              (r === `[object Object]`
                ? `object with keys {` + Object.keys(e).join(`, `) + `}`
                : r) +
              `). If you meant to render a collection of children, use an array instead.`,
          )
        );
      }
      return c;
    }
    function ue(e, t, n) {
      if (e == null) return e;
      var r = [],
        i = 0;
      return (
        le(e, r, ``, ``, function (e) {
          return t.call(n, e, i++);
        }),
        r
      );
    }
    function de(e) {
      if (e._status === -1) {
        var t = e._result;
        ((t = t()),
          t.then(
            function (t) {
              (e._status === 0 || e._status === -1) &&
                ((e._status = 1), (e._result = t));
            },
            function (t) {
              (e._status === 0 || e._status === -1) &&
                ((e._status = 2), (e._result = t));
            },
          ),
          e._status === -1 && ((e._status = 0), (e._result = t)));
      }
      if (e._status === 1) return e._result.default;
      throw e._result;
    }
    var w =
        typeof reportError == `function`
          ? reportError
          : function (e) {
              if (
                typeof window == `object` &&
                typeof window.ErrorEvent == `function`
              ) {
                var t = new window.ErrorEvent(`error`, {
                  bubbles: !0,
                  cancelable: !0,
                  message:
                    typeof e == `object` && e && typeof e.message == `string`
                      ? String(e.message)
                      : String(e),
                  error: e,
                });
                if (!window.dispatchEvent(t)) return;
              } else if (
                typeof process == `object` &&
                typeof process.emit == `function`
              ) {
                process.emit(`uncaughtException`, e);
                return;
              }
              console.error(e);
            },
      T = {
        map: ue,
        forEach: function (e, t, n) {
          ue(
            e,
            function () {
              t.apply(this, arguments);
            },
            n,
          );
        },
        count: function (e) {
          var t = 0;
          return (
            ue(e, function () {
              t++;
            }),
            t
          );
        },
        toArray: function (e) {
          return (
            ue(e, function (e) {
              return e;
            }) || []
          );
        },
        only: function (e) {
          if (!ie(e))
            throw Error(
              `React.Children.only expected to receive a single React element child.`,
            );
          return e;
        },
      };
    ((e.Activity = f),
      (e.Children = T),
      (e.Component = v),
      (e.Fragment = r),
      (e.Profiler = a),
      (e.PureComponent = b),
      (e.StrictMode = i),
      (e.Suspense = l),
      (e.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = C),
      (e.__COMPILER_RUNTIME = {
        __proto__: null,
        c: function (e) {
          return C.H.useMemoCache(e);
        },
      }),
      (e.cache = function (e) {
        return function () {
          return e.apply(null, arguments);
        };
      }),
      (e.cacheSignal = function () {
        return null;
      }),
      (e.cloneElement = function (e, t, n) {
        if (e == null)
          throw Error(
            `The argument must be a React element, but you passed ` + e + `.`,
          );
        var r = g({}, e.props),
          i = e.key;
        if (t != null)
          for (a in (t.key !== void 0 && (i = `` + t.key), t))
            !te.call(t, a) ||
              a === `key` ||
              a === `__self` ||
              a === `__source` ||
              (a === `ref` && t.ref === void 0) ||
              (r[a] = t[a]);
        var a = arguments.length - 2;
        if (a === 1) r.children = n;
        else if (1 < a) {
          for (var o = Array(a), s = 0; s < a; s++) o[s] = arguments[s + 2];
          r.children = o;
        }
        return ne(e.type, i, r);
      }),
      (e.createContext = function (e) {
        return (
          (e = {
            $$typeof: s,
            _currentValue: e,
            _currentValue2: e,
            _threadCount: 0,
            Provider: null,
            Consumer: null,
          }),
          (e.Provider = e),
          (e.Consumer = { $$typeof: o, _context: e }),
          e
        );
      }),
      (e.createElement = function (e, t, n) {
        var r,
          i = {},
          a = null;
        if (t != null)
          for (r in (t.key !== void 0 && (a = `` + t.key), t))
            te.call(t, r) &&
              r !== `key` &&
              r !== `__self` &&
              r !== `__source` &&
              (i[r] = t[r]);
        var o = arguments.length - 2;
        if (o === 1) i.children = n;
        else if (1 < o) {
          for (var s = Array(o), c = 0; c < o; c++) s[c] = arguments[c + 2];
          i.children = s;
        }
        if (e && e.defaultProps)
          for (r in ((o = e.defaultProps), o)) i[r] === void 0 && (i[r] = o[r]);
        return ne(e, a, i);
      }),
      (e.createRef = function () {
        return { current: null };
      }),
      (e.forwardRef = function (e) {
        return { $$typeof: c, render: e };
      }),
      (e.isValidElement = ie),
      (e.lazy = function (e) {
        return {
          $$typeof: d,
          _payload: { _status: -1, _result: e },
          _init: de,
        };
      }),
      (e.memo = function (e, t) {
        return { $$typeof: u, type: e, compare: t === void 0 ? null : t };
      }),
      (e.startTransition = function (e) {
        var t = C.T,
          n = {};
        C.T = n;
        try {
          var r = e(),
            i = C.S;
          (i !== null && i(n, r),
            typeof r == `object` &&
              r &&
              typeof r.then == `function` &&
              r.then(S, w));
        } catch (e) {
          w(e);
        } finally {
          (t !== null && n.types !== null && (t.types = n.types), (C.T = t));
        }
      }),
      (e.unstable_useCacheRefresh = function () {
        return C.H.useCacheRefresh();
      }),
      (e.use = function (e) {
        return C.H.use(e);
      }),
      (e.useActionState = function (e, t, n) {
        return C.H.useActionState(e, t, n);
      }),
      (e.useCallback = function (e, t) {
        return C.H.useCallback(e, t);
      }),
      (e.useContext = function (e) {
        return C.H.useContext(e);
      }),
      (e.useDebugValue = function () {}),
      (e.useDeferredValue = function (e, t) {
        return C.H.useDeferredValue(e, t);
      }),
      (e.useEffect = function (e, t) {
        return C.H.useEffect(e, t);
      }),
      (e.useEffectEvent = function (e) {
        return C.H.useEffectEvent(e);
      }),
      (e.useId = function () {
        return C.H.useId();
      }),
      (e.useImperativeHandle = function (e, t, n) {
        return C.H.useImperativeHandle(e, t, n);
      }),
      (e.useInsertionEffect = function (e, t) {
        return C.H.useInsertionEffect(e, t);
      }),
      (e.useLayoutEffect = function (e, t) {
        return C.H.useLayoutEffect(e, t);
      }),
      (e.useMemo = function (e, t) {
        return C.H.useMemo(e, t);
      }),
      (e.useOptimistic = function (e, t) {
        return C.H.useOptimistic(e, t);
      }),
      (e.useReducer = function (e, t, n) {
        return C.H.useReducer(e, t, n);
      }),
      (e.useRef = function (e) {
        return C.H.useRef(e);
      }),
      (e.useState = function (e) {
        return C.H.useState(e);
      }),
      (e.useSyncExternalStore = function (e, t, n) {
        return C.H.useSyncExternalStore(e, t, n);
      }),
      (e.useTransition = function () {
        return C.H.useTransition();
      }),
      (e.version = `19.2.8`));
  }),
  u = o((e, t) => {
    t.exports = l();
  }),
  d = o((e) => {
    function t(e, t) {
      var n = e.length;
      e.push(t);
      a: for (; 0 < n;) {
        var r = (n - 1) >>> 1,
          a = e[r];
        if (0 < i(a, t)) ((e[r] = t), (e[n] = a), (n = r));
        else break a;
      }
    }
    function n(e) {
      return e.length === 0 ? null : e[0];
    }
    function r(e) {
      if (e.length === 0) return null;
      var t = e[0],
        n = e.pop();
      if (n !== t) {
        e[0] = n;
        a: for (var r = 0, a = e.length, o = a >>> 1; r < o;) {
          var s = 2 * (r + 1) - 1,
            c = e[s],
            l = s + 1,
            u = e[l];
          if (0 > i(c, n))
            l < a && 0 > i(u, c)
              ? ((e[r] = u), (e[l] = n), (r = l))
              : ((e[r] = c), (e[s] = n), (r = s));
          else if (l < a && 0 > i(u, n)) ((e[r] = u), (e[l] = n), (r = l));
          else break a;
        }
      }
      return t;
    }
    function i(e, t) {
      var n = e.sortIndex - t.sortIndex;
      return n === 0 ? e.id - t.id : n;
    }
    if (
      ((e.unstable_now = void 0),
      typeof performance == `object` && typeof performance.now == `function`)
    ) {
      var a = performance;
      e.unstable_now = function () {
        return a.now();
      };
    } else {
      var o = Date,
        s = o.now();
      e.unstable_now = function () {
        return o.now() - s;
      };
    }
    var c = [],
      l = [],
      u = 1,
      d = null,
      f = 3,
      p = !1,
      m = !1,
      h = !1,
      g = !1,
      _ = typeof setTimeout == `function` ? setTimeout : null,
      v = typeof clearTimeout == `function` ? clearTimeout : null,
      y = typeof setImmediate < `u` ? setImmediate : null;
    function b(e) {
      for (var i = n(l); i !== null;) {
        if (i.callback === null) r(l);
        else if (i.startTime <= e)
          (r(l), (i.sortIndex = i.expirationTime), t(c, i));
        else break;
        i = n(l);
      }
    }
    function x(e) {
      if (((h = !1), b(e), !m))
        if (n(c) !== null) ((m = !0), ee || ((ee = !0), ie()));
        else {
          var t = n(l);
          t !== null && se(x, t.startTime - e);
        }
    }
    var ee = !1,
      S = -1,
      C = 5,
      te = -1;
    function ne() {
      return g ? !0 : !(e.unstable_now() - te < C);
    }
    function re() {
      if (((g = !1), ee)) {
        var t = e.unstable_now();
        te = t;
        var i = !0;
        try {
          a: {
            ((m = !1), h && ((h = !1), v(S), (S = -1)), (p = !0));
            var a = f;
            try {
              b: {
                for (
                  b(t), d = n(c);
                  d !== null && !(d.expirationTime > t && ne());
                ) {
                  var o = d.callback;
                  if (typeof o == `function`) {
                    ((d.callback = null), (f = d.priorityLevel));
                    var s = o(d.expirationTime <= t);
                    if (((t = e.unstable_now()), typeof s == `function`)) {
                      ((d.callback = s), b(t), (i = !0));
                      break b;
                    }
                    (d === n(c) && r(c), b(t));
                  } else r(c);
                  d = n(c);
                }
                if (d !== null) i = !0;
                else {
                  var u = n(l);
                  (u !== null && se(x, u.startTime - t), (i = !1));
                }
              }
              break a;
            } finally {
              ((d = null), (f = a), (p = !1));
            }
          }
        } finally {
          i ? ie() : (ee = !1);
        }
      }
    }
    var ie;
    if (typeof y == `function`)
      ie = function () {
        y(re);
      };
    else if (typeof MessageChannel < `u`) {
      var ae = new MessageChannel(),
        oe = ae.port2;
      ((ae.port1.onmessage = re),
        (ie = function () {
          oe.postMessage(null);
        }));
    } else
      ie = function () {
        _(re, 0);
      };
    function se(t, n) {
      S = _(function () {
        t(e.unstable_now());
      }, n);
    }
    ((e.unstable_IdlePriority = 5),
      (e.unstable_ImmediatePriority = 1),
      (e.unstable_LowPriority = 4),
      (e.unstable_NormalPriority = 3),
      (e.unstable_Profiling = null),
      (e.unstable_UserBlockingPriority = 2),
      (e.unstable_cancelCallback = function (e) {
        e.callback = null;
      }),
      (e.unstable_forceFrameRate = function (e) {
        0 > e || 125 < e
          ? console.error(
              `forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported`,
            )
          : (C = 0 < e ? Math.floor(1e3 / e) : 5);
      }),
      (e.unstable_getCurrentPriorityLevel = function () {
        return f;
      }),
      (e.unstable_next = function (e) {
        switch (f) {
          case 1:
          case 2:
          case 3:
            var t = 3;
            break;
          default:
            t = f;
        }
        var n = f;
        f = t;
        try {
          return e();
        } finally {
          f = n;
        }
      }),
      (e.unstable_requestPaint = function () {
        g = !0;
      }),
      (e.unstable_runWithPriority = function (e, t) {
        switch (e) {
          case 1:
          case 2:
          case 3:
          case 4:
          case 5:
            break;
          default:
            e = 3;
        }
        var n = f;
        f = e;
        try {
          return t();
        } finally {
          f = n;
        }
      }),
      (e.unstable_scheduleCallback = function (r, i, a) {
        var o = e.unstable_now();
        switch (
          (typeof a == `object` && a
            ? ((a = a.delay), (a = typeof a == `number` && 0 < a ? o + a : o))
            : (a = o),
          r)
        ) {
          case 1:
            var s = -1;
            break;
          case 2:
            s = 250;
            break;
          case 5:
            s = 1073741823;
            break;
          case 4:
            s = 1e4;
            break;
          default:
            s = 5e3;
        }
        return (
          (s = a + s),
          (r = {
            id: u++,
            callback: i,
            priorityLevel: r,
            startTime: a,
            expirationTime: s,
            sortIndex: -1,
          }),
          a > o
            ? ((r.sortIndex = a),
              t(l, r),
              n(c) === null &&
                r === n(l) &&
                (h ? (v(S), (S = -1)) : (h = !0), se(x, a - o)))
            : ((r.sortIndex = s),
              t(c, r),
              m || p || ((m = !0), ee || ((ee = !0), ie()))),
          r
        );
      }),
      (e.unstable_shouldYield = ne),
      (e.unstable_wrapCallback = function (e) {
        var t = f;
        return function () {
          var n = f;
          f = t;
          try {
            return e.apply(this, arguments);
          } finally {
            f = n;
          }
        };
      }));
  }),
  f = o((e, t) => {
    t.exports = d();
  }),
  p = o((e) => {
    var t = u();
    function n(e) {
      var t = `https://react.dev/errors/` + e;
      if (1 < arguments.length) {
        t += `?args[]=` + encodeURIComponent(arguments[1]);
        for (var n = 2; n < arguments.length; n++)
          t += `&args[]=` + encodeURIComponent(arguments[n]);
      }
      return (
        `Minified React error #` +
        e +
        `; visit ` +
        t +
        ` for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`
      );
    }
    function r() {}
    var i = {
        d: {
          f: r,
          r: function () {
            throw Error(n(522));
          },
          D: r,
          C: r,
          L: r,
          m: r,
          X: r,
          S: r,
          M: r,
        },
        p: 0,
        findDOMNode: null,
      },
      a = Symbol.for(`react.portal`);
    function o(e, t, n) {
      var r =
        3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
      return {
        $$typeof: a,
        key: r == null ? null : `` + r,
        children: e,
        containerInfo: t,
        implementation: n,
      };
    }
    var s = t.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;
    function c(e, t) {
      if (e === `font`) return ``;
      if (typeof t == `string`) return t === `use-credentials` ? t : ``;
    }
    ((e.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = i),
      (e.createPortal = function (e, t) {
        var r =
          2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
        if (!t || (t.nodeType !== 1 && t.nodeType !== 9 && t.nodeType !== 11))
          throw Error(n(299));
        return o(e, t, null, r);
      }),
      (e.flushSync = function (e) {
        var t = s.T,
          n = i.p;
        try {
          if (((s.T = null), (i.p = 2), e)) return e();
        } finally {
          ((s.T = t), (i.p = n), i.d.f());
        }
      }),
      (e.preconnect = function (e, t) {
        typeof e == `string` &&
          (t
            ? ((t = t.crossOrigin),
              (t =
                typeof t == `string`
                  ? t === `use-credentials`
                    ? t
                    : ``
                  : void 0))
            : (t = null),
          i.d.C(e, t));
      }),
      (e.prefetchDNS = function (e) {
        typeof e == `string` && i.d.D(e);
      }),
      (e.preinit = function (e, t) {
        if (typeof e == `string` && t && typeof t.as == `string`) {
          var n = t.as,
            r = c(n, t.crossOrigin),
            a = typeof t.integrity == `string` ? t.integrity : void 0,
            o = typeof t.fetchPriority == `string` ? t.fetchPriority : void 0;
          n === `style`
            ? i.d.S(
                e,
                typeof t.precedence == `string` ? t.precedence : void 0,
                { crossOrigin: r, integrity: a, fetchPriority: o },
              )
            : n === `script` &&
              i.d.X(e, {
                crossOrigin: r,
                integrity: a,
                fetchPriority: o,
                nonce: typeof t.nonce == `string` ? t.nonce : void 0,
              });
        }
      }),
      (e.preinitModule = function (e, t) {
        if (typeof e == `string`)
          if (typeof t == `object` && t) {
            if (t.as == null || t.as === `script`) {
              var n = c(t.as, t.crossOrigin);
              i.d.M(e, {
                crossOrigin: n,
                integrity:
                  typeof t.integrity == `string` ? t.integrity : void 0,
                nonce: typeof t.nonce == `string` ? t.nonce : void 0,
              });
            }
          } else t ?? i.d.M(e);
      }),
      (e.preload = function (e, t) {
        if (
          typeof e == `string` &&
          typeof t == `object` &&
          t &&
          typeof t.as == `string`
        ) {
          var n = t.as,
            r = c(n, t.crossOrigin);
          i.d.L(e, n, {
            crossOrigin: r,
            integrity: typeof t.integrity == `string` ? t.integrity : void 0,
            nonce: typeof t.nonce == `string` ? t.nonce : void 0,
            type: typeof t.type == `string` ? t.type : void 0,
            fetchPriority:
              typeof t.fetchPriority == `string` ? t.fetchPriority : void 0,
            referrerPolicy:
              typeof t.referrerPolicy == `string` ? t.referrerPolicy : void 0,
            imageSrcSet:
              typeof t.imageSrcSet == `string` ? t.imageSrcSet : void 0,
            imageSizes: typeof t.imageSizes == `string` ? t.imageSizes : void 0,
            media: typeof t.media == `string` ? t.media : void 0,
          });
        }
      }),
      (e.preloadModule = function (e, t) {
        if (typeof e == `string`)
          if (t) {
            var n = c(t.as, t.crossOrigin);
            i.d.m(e, {
              as: typeof t.as == `string` && t.as !== `script` ? t.as : void 0,
              crossOrigin: n,
              integrity: typeof t.integrity == `string` ? t.integrity : void 0,
            });
          } else i.d.m(e);
      }),
      (e.requestFormReset = function (e) {
        i.d.r(e);
      }),
      (e.unstable_batchedUpdates = function (e, t) {
        return e(t);
      }),
      (e.useFormState = function (e, t, n) {
        return s.H.useFormState(e, t, n);
      }),
      (e.useFormStatus = function () {
        return s.H.useHostTransitionStatus();
      }),
      (e.version = `19.2.8`));
  }),
  m = o((e, t) => {
    function n() {
      if (!(
        typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > `u` ||
        typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != `function`
      ))
        try {
          __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n);
        } catch (e) {
          console.error(e);
        }
    }
    (n(), (t.exports = p()));
  }),
  h = o((e) => {
    var t = f(),
      n = u(),
      r = m();
    function i(e) {
      var t = `https://react.dev/errors/` + e;
      if (1 < arguments.length) {
        t += `?args[]=` + encodeURIComponent(arguments[1]);
        for (var n = 2; n < arguments.length; n++)
          t += `&args[]=` + encodeURIComponent(arguments[n]);
      }
      return (
        `Minified React error #` +
        e +
        `; visit ` +
        t +
        ` for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`
      );
    }
    function a(e) {
      return !(
        !e ||
        (e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11)
      );
    }
    function o(e) {
      var t = e,
        n = e;
      if (e.alternate) for (; t.return;) t = t.return;
      else {
        e = t;
        do ((t = e), t.flags & 4098 && (n = t.return), (e = t.return));
        while (e);
      }
      return t.tag === 3 ? n : null;
    }
    function s(e) {
      if (e.tag === 13) {
        var t = e.memoizedState;
        if (
          (t === null &&
            ((e = e.alternate), e !== null && (t = e.memoizedState)),
          t !== null)
        )
          return t.dehydrated;
      }
      return null;
    }
    function c(e) {
      if (e.tag === 31) {
        var t = e.memoizedState;
        if (
          (t === null &&
            ((e = e.alternate), e !== null && (t = e.memoizedState)),
          t !== null)
        )
          return t.dehydrated;
      }
      return null;
    }
    function l(e) {
      if (o(e) !== e) throw Error(i(188));
    }
    function d(e) {
      var t = e.alternate;
      if (!t) {
        if (((t = o(e)), t === null)) throw Error(i(188));
        return t === e ? e : null;
      }
      for (var n = e, r = t; ;) {
        var a = n.return;
        if (a === null) break;
        var s = a.alternate;
        if (s === null) {
          if (((r = a.return), r !== null)) {
            n = r;
            continue;
          }
          break;
        }
        if (a.child === s.child) {
          for (s = a.child; s;) {
            if (s === n) return (l(a), e);
            if (s === r) return (l(a), t);
            s = s.sibling;
          }
          throw Error(i(188));
        }
        if (n.return !== r.return) ((n = a), (r = s));
        else {
          for (var c = !1, u = a.child; u;) {
            if (u === n) {
              ((c = !0), (n = a), (r = s));
              break;
            }
            if (u === r) {
              ((c = !0), (r = a), (n = s));
              break;
            }
            u = u.sibling;
          }
          if (!c) {
            for (u = s.child; u;) {
              if (u === n) {
                ((c = !0), (n = s), (r = a));
                break;
              }
              if (u === r) {
                ((c = !0), (r = s), (n = a));
                break;
              }
              u = u.sibling;
            }
            if (!c) throw Error(i(189));
          }
        }
        if (n.alternate !== r) throw Error(i(190));
      }
      if (n.tag !== 3) throw Error(i(188));
      return n.stateNode.current === n ? e : t;
    }
    function p(e) {
      var t = e.tag;
      if (t === 5 || t === 26 || t === 27 || t === 6) return e;
      for (e = e.child; e !== null;) {
        if (((t = p(e)), t !== null)) return t;
        e = e.sibling;
      }
      return null;
    }
    var h = Object.assign,
      g = Symbol.for(`react.element`),
      _ = Symbol.for(`react.transitional.element`),
      v = Symbol.for(`react.portal`),
      y = Symbol.for(`react.fragment`),
      b = Symbol.for(`react.strict_mode`),
      x = Symbol.for(`react.profiler`),
      ee = Symbol.for(`react.consumer`),
      S = Symbol.for(`react.context`),
      C = Symbol.for(`react.forward_ref`),
      te = Symbol.for(`react.suspense`),
      ne = Symbol.for(`react.suspense_list`),
      re = Symbol.for(`react.memo`),
      ie = Symbol.for(`react.lazy`),
      ae = Symbol.for(`react.activity`),
      oe = Symbol.for(`react.memo_cache_sentinel`),
      se = Symbol.iterator;
    function ce(e) {
      return typeof e != `object` || !e
        ? null
        : ((e = (se && e[se]) || e[`@@iterator`]),
          typeof e == `function` ? e : null);
    }
    var le = Symbol.for(`react.client.reference`);
    function ue(e) {
      if (e == null) return null;
      if (typeof e == `function`)
        return e.$$typeof === le ? null : e.displayName || e.name || null;
      if (typeof e == `string`) return e;
      switch (e) {
        case y:
          return `Fragment`;
        case x:
          return `Profiler`;
        case b:
          return `StrictMode`;
        case te:
          return `Suspense`;
        case ne:
          return `SuspenseList`;
        case ae:
          return `Activity`;
      }
      if (typeof e == `object`)
        switch (e.$$typeof) {
          case v:
            return `Portal`;
          case S:
            return e.displayName || `Context`;
          case ee:
            return (e._context.displayName || `Context`) + `.Consumer`;
          case C:
            var t = e.render;
            return (
              (e = e.displayName),
              (e ||=
                ((e = t.displayName || t.name || ``),
                e === `` ? `ForwardRef` : `ForwardRef(` + e + `)`)),
              e
            );
          case re:
            return (
              (t = e.displayName || null),
              t === null ? ue(e.type) || `Memo` : t
            );
          case ie:
            ((t = e._payload), (e = e._init));
            try {
              return ue(e(t));
            } catch {}
        }
      return null;
    }
    var de = Array.isArray,
      w = n.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
      T = r.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
      fe = { pending: !1, data: null, method: null, action: null },
      pe = [],
      me = -1;
    function he(e) {
      return { current: e };
    }
    function ge(e) {
      0 > me || ((e.current = pe[me]), (pe[me] = null), me--);
    }
    function E(e, t) {
      (me++, (pe[me] = e.current), (e.current = t));
    }
    var _e = he(null),
      ve = he(null),
      ye = he(null),
      be = he(null);
    function xe(e, t) {
      switch ((E(ye, t), E(ve, e), E(_e, null), t.nodeType)) {
        case 9:
        case 11:
          e = (e = t.documentElement) && (e = e.namespaceURI) ? Vd(e) : 0;
          break;
        default:
          if (((e = t.tagName), (t = t.namespaceURI)))
            ((t = Vd(t)), (e = Hd(t, e)));
          else
            switch (e) {
              case `svg`:
                e = 1;
                break;
              case `math`:
                e = 2;
                break;
              default:
                e = 0;
            }
      }
      (ge(_e), E(_e, e));
    }
    function Se() {
      (ge(_e), ge(ve), ge(ye));
    }
    function Ce(e) {
      e.memoizedState !== null && E(be, e);
      var t = _e.current,
        n = Hd(t, e.type);
      t !== n && (E(ve, e), E(_e, n));
    }
    function we(e) {
      (ve.current === e && (ge(_e), ge(ve)),
        be.current === e && (ge(be), (Qf._currentValue = fe)));
    }
    var Te, Ee;
    function De(e) {
      if (Te === void 0)
        try {
          throw Error();
        } catch (e) {
          var t = e.stack.trim().match(/\n( *(at )?)/);
          ((Te = (t && t[1]) || ``),
            (Ee =
              -1 <
              e.stack.indexOf(`
    at`)
                ? ` (<anonymous>)`
                : -1 < e.stack.indexOf(`@`)
                  ? `@unknown:0:0`
                  : ``));
        }
      return (
        `
` +
        Te +
        e +
        Ee
      );
    }
    var Oe = !1;
    function ke(e, t) {
      if (!e || Oe) return ``;
      Oe = !0;
      var n = Error.prepareStackTrace;
      Error.prepareStackTrace = void 0;
      try {
        var r = {
          DetermineComponentFrameRoot: function () {
            try {
              if (t) {
                var n = function () {
                  throw Error();
                };
                if (
                  (Object.defineProperty(n.prototype, "props", {
                    set: function () {
                      throw Error();
                    },
                  }),
                  typeof Reflect == `object` && Reflect.construct)
                ) {
                  try {
                    Reflect.construct(n, []);
                  } catch (e) {
                    var r = e;
                  }
                  Reflect.construct(e, [], n);
                } else {
                  try {
                    n.call();
                  } catch (e) {
                    r = e;
                  }
                  e.call(n.prototype);
                }
              } else {
                try {
                  throw Error();
                } catch (e) {
                  r = e;
                }
                (n = e()) &&
                  typeof n.catch == `function` &&
                  n.catch(function () {});
              }
            } catch (e) {
              if (e && r && typeof e.stack == `string`)
                return [e.stack, r.stack];
            }
            return [null, null];
          },
        };
        r.DetermineComponentFrameRoot.displayName = `DetermineComponentFrameRoot`;
        var i = Object.getOwnPropertyDescriptor(
          r.DetermineComponentFrameRoot,
          `name`,
        );
        i &&
          i.configurable &&
          Object.defineProperty(r.DetermineComponentFrameRoot, "name", {
            value: `DetermineComponentFrameRoot`,
          });
        var a = r.DetermineComponentFrameRoot(),
          o = a[0],
          s = a[1];
        if (o && s) {
          var c = o.split(`
`),
            l = s.split(`
`);
          for (
            i = r = 0;
            r < c.length && !c[r].includes(`DetermineComponentFrameRoot`);
          )
            r++;
          for (; i < l.length && !l[i].includes(`DetermineComponentFrameRoot`);)
            i++;
          if (r === c.length || i === l.length)
            for (
              r = c.length - 1, i = l.length - 1;
              1 <= r && 0 <= i && c[r] !== l[i];
            )
              i--;
          for (; 1 <= r && 0 <= i; r--, i--)
            if (c[r] !== l[i]) {
              if (r !== 1 || i !== 1)
                do
                  if ((r--, i--, 0 > i || c[r] !== l[i])) {
                    var u =
                      `
` + c[r].replace(` at new `, ` at `);
                    return (
                      e.displayName &&
                        u.includes(`<anonymous>`) &&
                        (u = u.replace(`<anonymous>`, e.displayName)),
                      u
                    );
                  }
                while (1 <= r && 0 <= i);
              break;
            }
        }
      } finally {
        ((Oe = !1), (Error.prepareStackTrace = n));
      }
      return (n = e ? e.displayName || e.name : ``) ? De(n) : ``;
    }
    function Ae(e, t) {
      switch (e.tag) {
        case 26:
        case 27:
        case 5:
          return De(e.type);
        case 16:
          return De(`Lazy`);
        case 13:
          return e.child !== t && t !== null
            ? De(`Suspense Fallback`)
            : De(`Suspense`);
        case 19:
          return De(`SuspenseList`);
        case 0:
        case 15:
          return ke(e.type, !1);
        case 11:
          return ke(e.type.render, !1);
        case 1:
          return ke(e.type, !0);
        case 31:
          return De(`Activity`);
        default:
          return ``;
      }
    }
    function je(e) {
      try {
        var t = ``,
          n = null;
        do ((t += Ae(e, n)), (n = e), (e = e.return));
        while (e);
        return t;
      } catch (e) {
        return (
          `
Error generating stack: ` +
          e.message +
          `
` +
          e.stack
        );
      }
    }
    var Me = Object.prototype.hasOwnProperty,
      Ne = t.unstable_scheduleCallback,
      Pe = t.unstable_cancelCallback,
      Fe = t.unstable_shouldYield,
      Ie = t.unstable_requestPaint,
      Le = t.unstable_now,
      Re = t.unstable_getCurrentPriorityLevel,
      ze = t.unstable_ImmediatePriority,
      Be = t.unstable_UserBlockingPriority,
      Ve = t.unstable_NormalPriority,
      He = t.unstable_LowPriority,
      D = t.unstable_IdlePriority,
      O = t.log,
      Ue = t.unstable_setDisableYieldValue,
      We = null,
      Ge = null;
    function Ke(e) {
      if (
        (typeof O == `function` && Ue(e),
        Ge && typeof Ge.setStrictMode == `function`)
      )
        try {
          Ge.setStrictMode(We, e);
        } catch {}
    }
    var qe = Math.clz32 ? Math.clz32 : Xe,
      Je = Math.log,
      Ye = Math.LN2;
    function Xe(e) {
      return ((e >>>= 0), e === 0 ? 32 : (31 - ((Je(e) / Ye) | 0)) | 0);
    }
    var Ze = 256,
      Qe = 262144,
      $e = 4194304;
    function et(e) {
      var t = e & 42;
      if (t !== 0) return t;
      switch (e & -e) {
        case 1:
          return 1;
        case 2:
          return 2;
        case 4:
          return 4;
        case 8:
          return 8;
        case 16:
          return 16;
        case 32:
          return 32;
        case 64:
          return 64;
        case 128:
          return 128;
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
          return e & 261888;
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
          return e & 3932160;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
          return e & 62914560;
        case 67108864:
          return 67108864;
        case 134217728:
          return 134217728;
        case 268435456:
          return 268435456;
        case 536870912:
          return 536870912;
        case 1073741824:
          return 0;
        default:
          return e;
      }
    }
    function k(e, t, n) {
      var r = e.pendingLanes;
      if (r === 0) return 0;
      var i = 0,
        a = e.suspendedLanes,
        o = e.pingedLanes;
      e = e.warmLanes;
      var s = r & 134217727;
      return (
        s === 0
          ? ((s = r & ~a),
            s === 0
              ? o === 0
                ? n || ((n = r & ~e), n !== 0 && (i = et(n)))
                : (i = et(o))
              : (i = et(s)))
          : ((r = s & ~a),
            r === 0
              ? ((o &= s),
                o === 0
                  ? n || ((n = s & ~e), n !== 0 && (i = et(n)))
                  : (i = et(o)))
              : (i = et(r))),
        i === 0
          ? 0
          : t !== 0 &&
              t !== i &&
              (t & a) === 0 &&
              ((a = i & -i), (n = t & -t), a >= n || (a === 32 && n & 4194048))
            ? t
            : i
      );
    }
    function tt(e, t) {
      return (e.pendingLanes & ~(e.suspendedLanes & ~e.pingedLanes) & t) === 0;
    }
    function nt(e, t) {
      switch (e) {
        case 1:
        case 2:
        case 4:
        case 8:
        case 64:
          return t + 250;
        case 16:
        case 32:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
          return t + 5e3;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
          return -1;
        case 67108864:
        case 134217728:
        case 268435456:
        case 536870912:
        case 1073741824:
          return -1;
        default:
          return -1;
      }
    }
    function rt() {
      var e = $e;
      return (($e <<= 1), !($e & 62914560) && ($e = 4194304), e);
    }
    function it(e) {
      for (var t = [], n = 0; 31 > n; n++) t.push(e);
      return t;
    }
    function at(e, t) {
      ((e.pendingLanes |= t),
        t !== 268435456 &&
          ((e.suspendedLanes = 0), (e.pingedLanes = 0), (e.warmLanes = 0)));
    }
    function ot(e, t, n, r, i, a) {
      var o = e.pendingLanes;
      ((e.pendingLanes = n),
        (e.suspendedLanes = 0),
        (e.pingedLanes = 0),
        (e.warmLanes = 0),
        (e.expiredLanes &= n),
        (e.entangledLanes &= n),
        (e.errorRecoveryDisabledLanes &= n),
        (e.shellSuspendCounter = 0));
      var s = e.entanglements,
        c = e.expirationTimes,
        l = e.hiddenUpdates;
      for (n = o & ~n; 0 < n;) {
        var u = 31 - qe(n),
          d = 1 << u;
        ((s[u] = 0), (c[u] = -1));
        var f = l[u];
        if (f !== null)
          for (l[u] = null, u = 0; u < f.length; u++) {
            var p = f[u];
            p !== null && (p.lane &= -536870913);
          }
        n &= ~d;
      }
      (r !== 0 && A(e, r, 0),
        a !== 0 &&
          i === 0 &&
          e.tag !== 0 &&
          (e.suspendedLanes |= a & ~(o & ~t)));
    }
    function A(e, t, n) {
      ((e.pendingLanes |= t), (e.suspendedLanes &= ~t));
      var r = 31 - qe(t);
      ((e.entangledLanes |= t),
        (e.entanglements[r] = e.entanglements[r] | 1073741824 | (n & 261930)));
    }
    function j(e, t) {
      var n = (e.entangledLanes |= t);
      for (e = e.entanglements; n;) {
        var r = 31 - qe(n),
          i = 1 << r;
        ((i & t) | (e[r] & t) && (e[r] |= t), (n &= ~i));
      }
    }
    function M(e, t) {
      var n = t & -t;
      return (
        (n = n & 42 ? 1 : st(n)),
        (n & (e.suspendedLanes | t)) === 0 ? n : 0
      );
    }
    function st(e) {
      switch (e) {
        case 2:
          e = 1;
          break;
        case 8:
          e = 4;
          break;
        case 32:
          e = 16;
          break;
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
          e = 128;
          break;
        case 268435456:
          e = 134217728;
          break;
        default:
          e = 0;
      }
      return e;
    }
    function ct(e) {
      return (
        (e &= -e),
        2 < e ? (8 < e ? (e & 134217727 ? 32 : 268435456) : 8) : 2
      );
    }
    function lt() {
      var e = T.p;
      return e === 0 ? ((e = window.event), e === void 0 ? 32 : mp(e.type)) : e;
    }
    function N(e, t) {
      var n = T.p;
      try {
        return ((T.p = e), t());
      } finally {
        T.p = n;
      }
    }
    var P = Math.random().toString(36).slice(2),
      F = `__reactFiber$` + P,
      ut = `__reactProps$` + P,
      dt = `__reactContainer$` + P,
      ft = `__reactEvents$` + P,
      pt = `__reactListeners$` + P,
      mt = `__reactHandles$` + P,
      ht = `__reactResources$` + P,
      gt = `__reactMarker$` + P;
    function _t(e) {
      (delete e[F], delete e[ut], delete e[ft], delete e[pt], delete e[mt]);
    }
    function vt(e) {
      var t = e[F];
      if (t) return t;
      for (var n = e.parentNode; n;) {
        if ((t = n[dt] || n[F])) {
          if (
            ((n = t.alternate),
            t.child !== null || (n !== null && n.child !== null))
          )
            for (e = df(e); e !== null;) {
              if ((n = e[F])) return n;
              e = df(e);
            }
          return t;
        }
        ((e = n), (n = e.parentNode));
      }
      return null;
    }
    function yt(e) {
      if ((e = e[F] || e[dt])) {
        var t = e.tag;
        if (
          t === 5 ||
          t === 6 ||
          t === 13 ||
          t === 31 ||
          t === 26 ||
          t === 27 ||
          t === 3
        )
          return e;
      }
      return null;
    }
    function bt(e) {
      var t = e.tag;
      if (t === 5 || t === 26 || t === 27 || t === 6) return e.stateNode;
      throw Error(i(33));
    }
    function xt(e) {
      var t = e[ht];
      return (
        (t ||= e[ht] =
          { hoistableStyles: new Map(), hoistableScripts: new Map() }),
        t
      );
    }
    function St(e) {
      e[gt] = !0;
    }
    var Ct = new Set(),
      wt = {};
    function Tt(e, t) {
      (Et(e, t), Et(e + `Capture`, t));
    }
    function Et(e, t) {
      for (wt[e] = t, e = 0; e < t.length; e++) Ct.add(t[e]);
    }
    var Dt = RegExp(
        `^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$`,
      ),
      Ot = {},
      kt = {};
    function At(e) {
      return Me.call(kt, e)
        ? !0
        : Me.call(Ot, e)
          ? !1
          : Dt.test(e)
            ? (kt[e] = !0)
            : ((Ot[e] = !0), !1);
    }
    function jt(e, t, n) {
      if (At(t))
        if (n === null) e.removeAttribute(t);
        else {
          switch (typeof n) {
            case `undefined`:
            case `function`:
            case `symbol`:
              e.removeAttribute(t);
              return;
            case `boolean`:
              var r = t.toLowerCase().slice(0, 5);
              if (r !== `data-` && r !== `aria-`) {
                e.removeAttribute(t);
                return;
              }
          }
          e.setAttribute(t, `` + n);
        }
    }
    function I(e, t, n) {
      if (n === null) e.removeAttribute(t);
      else {
        switch (typeof n) {
          case `undefined`:
          case `function`:
          case `symbol`:
          case `boolean`:
            e.removeAttribute(t);
            return;
        }
        e.setAttribute(t, `` + n);
      }
    }
    function L(e, t, n, r) {
      if (r === null) e.removeAttribute(n);
      else {
        switch (typeof r) {
          case `undefined`:
          case `function`:
          case `symbol`:
          case `boolean`:
            e.removeAttribute(n);
            return;
        }
        e.setAttributeNS(t, n, `` + r);
      }
    }
    function Mt(e) {
      switch (typeof e) {
        case `bigint`:
        case `boolean`:
        case `number`:
        case `string`:
        case `undefined`:
          return e;
        case `object`:
          return e;
        default:
          return ``;
      }
    }
    function Nt(e) {
      var t = e.type;
      return (
        (e = e.nodeName) &&
        e.toLowerCase() === `input` &&
        (t === `checkbox` || t === `radio`)
      );
    }
    function R(e, t, n) {
      var r = Object.getOwnPropertyDescriptor(e.constructor.prototype, t);
      if (
        !e.hasOwnProperty(t) &&
        r !== void 0 &&
        typeof r.get == `function` &&
        typeof r.set == `function`
      ) {
        var i = r.get,
          a = r.set;
        return (
          Object.defineProperty(e, t, {
            configurable: !0,
            get: function () {
              return i.call(this);
            },
            set: function (e) {
              ((n = `` + e), a.call(this, e));
            },
          }),
          Object.defineProperty(e, t, { enumerable: r.enumerable }),
          {
            getValue: function () {
              return n;
            },
            setValue: function (e) {
              n = `` + e;
            },
            stopTracking: function () {
              ((e._valueTracker = null), delete e[t]);
            },
          }
        );
      }
    }
    function Pt(e) {
      if (!e._valueTracker) {
        var t = Nt(e) ? `checked` : `value`;
        e._valueTracker = R(e, t, `` + e[t]);
      }
    }
    function z(e) {
      if (!e) return !1;
      var t = e._valueTracker;
      if (!t) return !0;
      var n = t.getValue(),
        r = ``;
      return (
        e && (r = Nt(e) ? (e.checked ? `true` : `false`) : e.value),
        (e = r),
        e !== n && (t.setValue(e), !0)
      );
    }
    function Ft(e) {
      if (((e ||= typeof document < `u` ? document : void 0), e === void 0))
        return null;
      try {
        return e.activeElement || e.body;
      } catch {
        return e.body;
      }
    }
    var It = /[\n"\\]/g;
    function Lt(e) {
      return e.replace(It, function (e) {
        return `\\` + e.charCodeAt(0).toString(16) + ` `;
      });
    }
    function Rt(e, t, n, r, i, a, o, s) {
      ((e.name = ``),
        o != null &&
        typeof o != `function` &&
        typeof o != `symbol` &&
        typeof o != `boolean`
          ? (e.type = o)
          : e.removeAttribute(`type`),
        t == null
          ? (o !== `submit` && o !== `reset`) || e.removeAttribute(`value`)
          : o === `number`
            ? ((t === 0 && e.value === ``) || e.value != t) &&
              (e.value = `` + Mt(t))
            : e.value !== `` + Mt(t) && (e.value = `` + Mt(t)),
        t == null
          ? n == null
            ? r != null && e.removeAttribute(`value`)
            : Bt(e, o, Mt(n))
          : Bt(e, o, Mt(t)),
        i == null && a != null && (e.defaultChecked = !!a),
        i != null &&
          (e.checked = i && typeof i != `function` && typeof i != `symbol`),
        s != null &&
        typeof s != `function` &&
        typeof s != `symbol` &&
        typeof s != `boolean`
          ? (e.name = `` + Mt(s))
          : e.removeAttribute(`name`));
    }
    function zt(e, t, n, r, i, a, o, s) {
      if (
        (a != null &&
          typeof a != `function` &&
          typeof a != `symbol` &&
          typeof a != `boolean` &&
          (e.type = a),
        t != null || n != null)
      ) {
        if (!((a !== `submit` && a !== `reset`) || t != null)) {
          Pt(e);
          return;
        }
        ((n = n == null ? `` : `` + Mt(n)),
          (t = t == null ? n : `` + Mt(t)),
          s || t === e.value || (e.value = t),
          (e.defaultValue = t));
      }
      ((r ??= i),
        (r = typeof r != `function` && typeof r != `symbol` && !!r),
        (e.checked = s ? e.checked : !!r),
        (e.defaultChecked = !!r),
        o != null &&
          typeof o != `function` &&
          typeof o != `symbol` &&
          typeof o != `boolean` &&
          (e.name = o),
        Pt(e));
    }
    function Bt(e, t, n) {
      (t === `number` && Ft(e.ownerDocument) === e) ||
        e.defaultValue === `` + n ||
        (e.defaultValue = `` + n);
    }
    function Vt(e, t, n, r) {
      if (((e = e.options), t)) {
        t = {};
        for (var i = 0; i < n.length; i++) t[`$` + n[i]] = !0;
        for (n = 0; n < e.length; n++)
          ((i = t.hasOwnProperty(`$` + e[n].value)),
            e[n].selected !== i && (e[n].selected = i),
            i && r && (e[n].defaultSelected = !0));
      } else {
        for (n = `` + Mt(n), t = null, i = 0; i < e.length; i++) {
          if (e[i].value === n) {
            ((e[i].selected = !0), r && (e[i].defaultSelected = !0));
            return;
          }
          t !== null || e[i].disabled || (t = e[i]);
        }
        t !== null && (t.selected = !0);
      }
    }
    function Ht(e, t, n) {
      if (
        t != null &&
        ((t = `` + Mt(t)), t !== e.value && (e.value = t), n == null)
      ) {
        e.defaultValue !== t && (e.defaultValue = t);
        return;
      }
      e.defaultValue = n == null ? `` : `` + Mt(n);
    }
    function Ut(e, t, n, r) {
      if (t == null) {
        if (r != null) {
          if (n != null) throw Error(i(92));
          if (de(r)) {
            if (1 < r.length) throw Error(i(93));
            r = r[0];
          }
          n = r;
        }
        ((n ??= ``), (t = n));
      }
      ((n = Mt(t)),
        (e.defaultValue = n),
        (r = e.textContent),
        r === n && r !== `` && r !== null && (e.value = r),
        Pt(e));
    }
    function Wt(e, t) {
      if (t) {
        var n = e.firstChild;
        if (n && n === e.lastChild && n.nodeType === 3) {
          n.nodeValue = t;
          return;
        }
      }
      e.textContent = t;
    }
    var Gt = new Set(
      `animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp`.split(
        ` `,
      ),
    );
    function Kt(e, t, n) {
      var r = t.indexOf(`--`) === 0;
      n == null || typeof n == `boolean` || n === ``
        ? r
          ? e.setProperty(t, ``)
          : t === `float`
            ? (e.cssFloat = ``)
            : (e[t] = ``)
        : r
          ? e.setProperty(t, n)
          : typeof n != `number` || n === 0 || Gt.has(t)
            ? t === `float`
              ? (e.cssFloat = n)
              : (e[t] = (`` + n).trim())
            : (e[t] = n + `px`);
    }
    function qt(e, t, n) {
      if (t != null && typeof t != `object`) throw Error(i(62));
      if (((e = e.style), n != null)) {
        for (var r in n)
          !n.hasOwnProperty(r) ||
            (t != null && t.hasOwnProperty(r)) ||
            (r.indexOf(`--`) === 0
              ? e.setProperty(r, ``)
              : r === `float`
                ? (e.cssFloat = ``)
                : (e[r] = ``));
        for (var a in t)
          ((r = t[a]), t.hasOwnProperty(a) && n[a] !== r && Kt(e, a, r));
      } else for (var o in t) t.hasOwnProperty(o) && Kt(e, o, t[o]);
    }
    function Jt(e) {
      if (e.indexOf(`-`) === -1) return !1;
      switch (e) {
        case `annotation-xml`:
        case `color-profile`:
        case `font-face`:
        case `font-face-src`:
        case `font-face-uri`:
        case `font-face-format`:
        case `font-face-name`:
        case `missing-glyph`:
          return !1;
        default:
          return !0;
      }
    }
    var Yt = new Map([
        [`acceptCharset`, `accept-charset`],
        [`htmlFor`, `for`],
        [`httpEquiv`, `http-equiv`],
        [`crossOrigin`, `crossorigin`],
        [`accentHeight`, `accent-height`],
        [`alignmentBaseline`, `alignment-baseline`],
        [`arabicForm`, `arabic-form`],
        [`baselineShift`, `baseline-shift`],
        [`capHeight`, `cap-height`],
        [`clipPath`, `clip-path`],
        [`clipRule`, `clip-rule`],
        [`colorInterpolation`, `color-interpolation`],
        [`colorInterpolationFilters`, `color-interpolation-filters`],
        [`colorProfile`, `color-profile`],
        [`colorRendering`, `color-rendering`],
        [`dominantBaseline`, `dominant-baseline`],
        [`enableBackground`, `enable-background`],
        [`fillOpacity`, `fill-opacity`],
        [`fillRule`, `fill-rule`],
        [`floodColor`, `flood-color`],
        [`floodOpacity`, `flood-opacity`],
        [`fontFamily`, `font-family`],
        [`fontSize`, `font-size`],
        [`fontSizeAdjust`, `font-size-adjust`],
        [`fontStretch`, `font-stretch`],
        [`fontStyle`, `font-style`],
        [`fontVariant`, `font-variant`],
        [`fontWeight`, `font-weight`],
        [`glyphName`, `glyph-name`],
        [`glyphOrientationHorizontal`, `glyph-orientation-horizontal`],
        [`glyphOrientationVertical`, `glyph-orientation-vertical`],
        [`horizAdvX`, `horiz-adv-x`],
        [`horizOriginX`, `horiz-origin-x`],
        [`imageRendering`, `image-rendering`],
        [`letterSpacing`, `letter-spacing`],
        [`lightingColor`, `lighting-color`],
        [`markerEnd`, `marker-end`],
        [`markerMid`, `marker-mid`],
        [`markerStart`, `marker-start`],
        [`overlinePosition`, `overline-position`],
        [`overlineThickness`, `overline-thickness`],
        [`paintOrder`, `paint-order`],
        [`panose-1`, `panose-1`],
        [`pointerEvents`, `pointer-events`],
        [`renderingIntent`, `rendering-intent`],
        [`shapeRendering`, `shape-rendering`],
        [`stopColor`, `stop-color`],
        [`stopOpacity`, `stop-opacity`],
        [`strikethroughPosition`, `strikethrough-position`],
        [`strikethroughThickness`, `strikethrough-thickness`],
        [`strokeDasharray`, `stroke-dasharray`],
        [`strokeDashoffset`, `stroke-dashoffset`],
        [`strokeLinecap`, `stroke-linecap`],
        [`strokeLinejoin`, `stroke-linejoin`],
        [`strokeMiterlimit`, `stroke-miterlimit`],
        [`strokeOpacity`, `stroke-opacity`],
        [`strokeWidth`, `stroke-width`],
        [`textAnchor`, `text-anchor`],
        [`textDecoration`, `text-decoration`],
        [`textRendering`, `text-rendering`],
        [`transformOrigin`, `transform-origin`],
        [`underlinePosition`, `underline-position`],
        [`underlineThickness`, `underline-thickness`],
        [`unicodeBidi`, `unicode-bidi`],
        [`unicodeRange`, `unicode-range`],
        [`unitsPerEm`, `units-per-em`],
        [`vAlphabetic`, `v-alphabetic`],
        [`vHanging`, `v-hanging`],
        [`vIdeographic`, `v-ideographic`],
        [`vMathematical`, `v-mathematical`],
        [`vectorEffect`, `vector-effect`],
        [`vertAdvY`, `vert-adv-y`],
        [`vertOriginX`, `vert-origin-x`],
        [`vertOriginY`, `vert-origin-y`],
        [`wordSpacing`, `word-spacing`],
        [`writingMode`, `writing-mode`],
        [`xmlnsXlink`, `xmlns:xlink`],
        [`xHeight`, `x-height`],
      ]),
      Xt =
        /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;
    function Zt(e) {
      return Xt.test(`` + e)
        ? `javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')`
        : e;
    }
    function Qt() {}
    var $t = null;
    function en(e) {
      return (
        (e = e.target || e.srcElement || window),
        e.correspondingUseElement && (e = e.correspondingUseElement),
        e.nodeType === 3 ? e.parentNode : e
      );
    }
    var tn = null,
      nn = null;
    function rn(e) {
      var t = yt(e);
      if (t && (e = t.stateNode)) {
        var n = e[ut] || null;
        a: switch (((e = t.stateNode), t.type)) {
          case `input`:
            if (
              (Rt(
                e,
                n.value,
                n.defaultValue,
                n.defaultValue,
                n.checked,
                n.defaultChecked,
                n.type,
                n.name,
              ),
              (t = n.name),
              n.type === `radio` && t != null)
            ) {
              for (n = e; n.parentNode;) n = n.parentNode;
              for (
                n = n.querySelectorAll(
                  `input[name="` + Lt(`` + t) + `"][type="radio"]`,
                ),
                  t = 0;
                t < n.length;
                t++
              ) {
                var r = n[t];
                if (r !== e && r.form === e.form) {
                  var a = r[ut] || null;
                  if (!a) throw Error(i(90));
                  Rt(
                    r,
                    a.value,
                    a.defaultValue,
                    a.defaultValue,
                    a.checked,
                    a.defaultChecked,
                    a.type,
                    a.name,
                  );
                }
              }
              for (t = 0; t < n.length; t++)
                ((r = n[t]), r.form === e.form && z(r));
            }
            break a;
          case `textarea`:
            Ht(e, n.value, n.defaultValue);
            break a;
          case `select`:
            ((t = n.value), t != null && Vt(e, !!n.multiple, t, !1));
        }
      }
    }
    var an = !1;
    function on(e, t, n) {
      if (an) return e(t, n);
      an = !0;
      try {
        return e(t);
      } finally {
        if (
          ((an = !1),
          (tn !== null || nn !== null) &&
            (bu(), tn && ((t = tn), (e = nn), (nn = tn = null), rn(t), e)))
        )
          for (t = 0; t < e.length; t++) rn(e[t]);
      }
    }
    function sn(e, t) {
      var n = e.stateNode;
      if (n === null) return null;
      var r = n[ut] || null;
      if (r === null) return null;
      n = r[t];
      a: switch (t) {
        case `onClick`:
        case `onClickCapture`:
        case `onDoubleClick`:
        case `onDoubleClickCapture`:
        case `onMouseDown`:
        case `onMouseDownCapture`:
        case `onMouseMove`:
        case `onMouseMoveCapture`:
        case `onMouseUp`:
        case `onMouseUpCapture`:
        case `onMouseEnter`:
          ((r = !r.disabled) ||
            ((e = e.type),
            (r =
              e !== `button` &&
              e !== `input` &&
              e !== `select` &&
              e !== `textarea`)),
            (e = !r));
          break a;
        default:
          e = !1;
      }
      if (e) return null;
      if (n && typeof n != `function`) throw Error(i(231, t, typeof n));
      return n;
    }
    var cn = !(
        typeof window > `u` ||
        window.document === void 0 ||
        window.document.createElement === void 0
      ),
      ln = !1;
    if (cn)
      try {
        var B = {};
        (Object.defineProperty(B, "passive", {
          get: function () {
            ln = !0;
          },
        }),
          window.addEventListener(`test`, B, B),
          window.removeEventListener(`test`, B, B));
      } catch {
        ln = !1;
      }
    var un = null,
      dn = null,
      fn = null;
    function pn() {
      if (fn) return fn;
      var e,
        t = dn,
        n = t.length,
        r,
        i = `value` in un ? un.value : un.textContent,
        a = i.length;
      for (e = 0; e < n && t[e] === i[e]; e++);
      var o = n - e;
      for (r = 1; r <= o && t[n - r] === i[a - r]; r++);
      return (fn = i.slice(e, 1 < r ? 1 - r : void 0));
    }
    function mn(e) {
      var t = e.keyCode;
      return (
        `charCode` in e
          ? ((e = e.charCode), e === 0 && t === 13 && (e = 13))
          : (e = t),
        e === 10 && (e = 13),
        32 <= e || e === 13 ? e : 0
      );
    }
    function hn() {
      return !0;
    }
    function gn() {
      return !1;
    }
    function _n(e) {
      function t(t, n, r, i, a) {
        for (var o in ((this._reactName = t),
        (this._targetInst = r),
        (this.type = n),
        (this.nativeEvent = i),
        (this.target = a),
        (this.currentTarget = null),
        e))
          e.hasOwnProperty(o) && ((t = e[o]), (this[o] = t ? t(i) : i[o]));
        return (
          (this.isDefaultPrevented = (
            i.defaultPrevented == null
              ? !1 === i.returnValue
              : i.defaultPrevented
          )
            ? hn
            : gn),
          (this.isPropagationStopped = gn),
          this
        );
      }
      return (
        h(t.prototype, {
          preventDefault: function () {
            this.defaultPrevented = !0;
            var e = this.nativeEvent;
            e &&
              (e.preventDefault
                ? e.preventDefault()
                : typeof e.returnValue != `unknown` && (e.returnValue = !1),
              (this.isDefaultPrevented = hn));
          },
          stopPropagation: function () {
            var e = this.nativeEvent;
            e &&
              (e.stopPropagation
                ? e.stopPropagation()
                : typeof e.cancelBubble != `unknown` && (e.cancelBubble = !0),
              (this.isPropagationStopped = hn));
          },
          persist: function () {},
          isPersistent: hn,
        }),
        t
      );
    }
    var vn = {
        eventPhase: 0,
        bubbles: 0,
        cancelable: 0,
        timeStamp: function (e) {
          return e.timeStamp || Date.now();
        },
        defaultPrevented: 0,
        isTrusted: 0,
      },
      yn = _n(vn),
      bn = h({}, vn, { view: 0, detail: 0 }),
      xn = _n(bn),
      Sn,
      Cn,
      wn,
      Tn = h({}, bn, {
        screenX: 0,
        screenY: 0,
        clientX: 0,
        clientY: 0,
        pageX: 0,
        pageY: 0,
        ctrlKey: 0,
        shiftKey: 0,
        altKey: 0,
        metaKey: 0,
        getModifierState: In,
        button: 0,
        buttons: 0,
        relatedTarget: function (e) {
          return e.relatedTarget === void 0
            ? e.fromElement === e.srcElement
              ? e.toElement
              : e.fromElement
            : e.relatedTarget;
        },
        movementX: function (e) {
          return `movementX` in e
            ? e.movementX
            : (e !== wn &&
                (wn && e.type === `mousemove`
                  ? ((Sn = e.screenX - wn.screenX),
                    (Cn = e.screenY - wn.screenY))
                  : (Cn = Sn = 0),
                (wn = e)),
              Sn);
        },
        movementY: function (e) {
          return `movementY` in e ? e.movementY : Cn;
        },
      }),
      En = _n(Tn),
      Dn = _n(h({}, Tn, { dataTransfer: 0 })),
      On = _n(h({}, bn, { relatedTarget: 0 })),
      kn = _n(
        h({}, vn, { animationName: 0, elapsedTime: 0, pseudoElement: 0 }),
      ),
      An = _n(
        h({}, vn, {
          clipboardData: function (e) {
            return `clipboardData` in e
              ? e.clipboardData
              : window.clipboardData;
          },
        }),
      ),
      jn = _n(h({}, vn, { data: 0 })),
      Mn = {
        Esc: `Escape`,
        Spacebar: ` `,
        Left: `ArrowLeft`,
        Up: `ArrowUp`,
        Right: `ArrowRight`,
        Down: `ArrowDown`,
        Del: `Delete`,
        Win: `OS`,
        Menu: `ContextMenu`,
        Apps: `ContextMenu`,
        Scroll: `ScrollLock`,
        MozPrintableKey: `Unidentified`,
      },
      Nn = {
        8: `Backspace`,
        9: `Tab`,
        12: `Clear`,
        13: `Enter`,
        16: `Shift`,
        17: `Control`,
        18: `Alt`,
        19: `Pause`,
        20: `CapsLock`,
        27: `Escape`,
        32: ` `,
        33: `PageUp`,
        34: `PageDown`,
        35: `End`,
        36: `Home`,
        37: `ArrowLeft`,
        38: `ArrowUp`,
        39: `ArrowRight`,
        40: `ArrowDown`,
        45: `Insert`,
        46: `Delete`,
        112: `F1`,
        113: `F2`,
        114: `F3`,
        115: `F4`,
        116: `F5`,
        117: `F6`,
        118: `F7`,
        119: `F8`,
        120: `F9`,
        121: `F10`,
        122: `F11`,
        123: `F12`,
        144: `NumLock`,
        145: `ScrollLock`,
        224: `Meta`,
      },
      Pn = {
        Alt: `altKey`,
        Control: `ctrlKey`,
        Meta: `metaKey`,
        Shift: `shiftKey`,
      };
    function Fn(e) {
      var t = this.nativeEvent;
      return t.getModifierState
        ? t.getModifierState(e)
        : (e = Pn[e])
          ? !!t[e]
          : !1;
    }
    function In() {
      return Fn;
    }
    var Ln = _n(
        h({}, bn, {
          key: function (e) {
            if (e.key) {
              var t = Mn[e.key] || e.key;
              if (t !== `Unidentified`) return t;
            }
            return e.type === `keypress`
              ? ((e = mn(e)), e === 13 ? `Enter` : String.fromCharCode(e))
              : e.type === `keydown` || e.type === `keyup`
                ? Nn[e.keyCode] || `Unidentified`
                : ``;
          },
          code: 0,
          location: 0,
          ctrlKey: 0,
          shiftKey: 0,
          altKey: 0,
          metaKey: 0,
          repeat: 0,
          locale: 0,
          getModifierState: In,
          charCode: function (e) {
            return e.type === `keypress` ? mn(e) : 0;
          },
          keyCode: function (e) {
            return e.type === `keydown` || e.type === `keyup` ? e.keyCode : 0;
          },
          which: function (e) {
            return e.type === `keypress`
              ? mn(e)
              : e.type === `keydown` || e.type === `keyup`
                ? e.keyCode
                : 0;
          },
        }),
      ),
      Rn = _n(
        h({}, Tn, {
          pointerId: 0,
          width: 0,
          height: 0,
          pressure: 0,
          tangentialPressure: 0,
          tiltX: 0,
          tiltY: 0,
          twist: 0,
          pointerType: 0,
          isPrimary: 0,
        }),
      ),
      zn = _n(
        h({}, bn, {
          touches: 0,
          targetTouches: 0,
          changedTouches: 0,
          altKey: 0,
          metaKey: 0,
          ctrlKey: 0,
          shiftKey: 0,
          getModifierState: In,
        }),
      ),
      Bn = _n(h({}, vn, { propertyName: 0, elapsedTime: 0, pseudoElement: 0 })),
      Vn = _n(
        h({}, Tn, {
          deltaX: function (e) {
            return `deltaX` in e
              ? e.deltaX
              : `wheelDeltaX` in e
                ? -e.wheelDeltaX
                : 0;
          },
          deltaY: function (e) {
            return `deltaY` in e
              ? e.deltaY
              : `wheelDeltaY` in e
                ? -e.wheelDeltaY
                : `wheelDelta` in e
                  ? -e.wheelDelta
                  : 0;
          },
          deltaZ: 0,
          deltaMode: 0,
        }),
      ),
      Hn = _n(h({}, vn, { newState: 0, oldState: 0 })),
      Un = [9, 13, 27, 32],
      Wn = cn && `CompositionEvent` in window,
      Gn = null;
    cn && `documentMode` in document && (Gn = document.documentMode);
    var Kn = cn && `TextEvent` in window && !Gn,
      qn = cn && (!Wn || (Gn && 8 < Gn && 11 >= Gn)),
      Jn = ` `,
      Yn = !1;
    function Xn(e, t) {
      switch (e) {
        case `keyup`:
          return Un.indexOf(t.keyCode) !== -1;
        case `keydown`:
          return t.keyCode !== 229;
        case `keypress`:
        case `mousedown`:
        case `focusout`:
          return !0;
        default:
          return !1;
      }
    }
    function Zn(e) {
      return (
        (e = e.detail),
        typeof e == `object` && `data` in e ? e.data : null
      );
    }
    var Qn = !1;
    function $n(e, t) {
      switch (e) {
        case `compositionend`:
          return Zn(t);
        case `keypress`:
          return t.which === 32 ? ((Yn = !0), Jn) : null;
        case `textInput`:
          return ((e = t.data), e === Jn && Yn ? null : e);
        default:
          return null;
      }
    }
    function er(e, t) {
      if (Qn)
        return e === `compositionend` || (!Wn && Xn(e, t))
          ? ((e = pn()), (fn = dn = un = null), (Qn = !1), e)
          : null;
      switch (e) {
        case `paste`:
          return null;
        case `keypress`:
          if (
            !(t.ctrlKey || t.altKey || t.metaKey) ||
            (t.ctrlKey && t.altKey)
          ) {
            if (t.char && 1 < t.char.length) return t.char;
            if (t.which) return String.fromCharCode(t.which);
          }
          return null;
        case `compositionend`:
          return qn && t.locale !== `ko` ? null : t.data;
        default:
          return null;
      }
    }
    var tr = {
      color: !0,
      date: !0,
      datetime: !0,
      "datetime-local": !0,
      email: !0,
      month: !0,
      number: !0,
      password: !0,
      range: !0,
      search: !0,
      tel: !0,
      text: !0,
      time: !0,
      url: !0,
      week: !0,
    };
    function nr(e) {
      var t = e && e.nodeName && e.nodeName.toLowerCase();
      return t === `input` ? !!tr[e.type] : t === `textarea`;
    }
    function rr(e, t, n, r) {
      (tn ? (nn ? nn.push(r) : (nn = [r])) : (tn = r),
        (t = Ed(t, `onChange`)),
        0 < t.length &&
          ((n = new yn(`onChange`, `change`, null, n, r)),
          e.push({ event: n, listeners: t })));
    }
    var ir = null,
      ar = null;
    function or(e) {
      yd(e, 0);
    }
    function sr(e) {
      if (z(bt(e))) return e;
    }
    function cr(e, t) {
      if (e === `change`) return t;
    }
    var lr = !1;
    if (cn) {
      var ur;
      if (cn) {
        var dr = `oninput` in document;
        if (!dr) {
          var fr = document.createElement(`div`);
          (fr.setAttribute(`oninput`, `return;`),
            (dr = typeof fr.oninput == `function`));
        }
        ur = dr;
      } else ur = !1;
      lr = ur && (!document.documentMode || 9 < document.documentMode);
    }
    function pr() {
      ir && (ir.detachEvent(`onpropertychange`, mr), (ar = ir = null));
    }
    function mr(e) {
      if (e.propertyName === `value` && sr(ar)) {
        var t = [];
        (rr(t, ar, e, en(e)), on(or, t));
      }
    }
    function hr(e, t, n) {
      e === `focusin`
        ? (pr(), (ir = t), (ar = n), ir.attachEvent(`onpropertychange`, mr))
        : e === `focusout` && pr();
    }
    function gr(e) {
      if (e === `selectionchange` || e === `keyup` || e === `keydown`)
        return sr(ar);
    }
    function _r(e, t) {
      if (e === `click`) return sr(t);
    }
    function vr(e, t) {
      if (e === `input` || e === `change`) return sr(t);
    }
    function yr(e, t) {
      return (e === t && (e !== 0 || 1 / e == 1 / t)) || (e !== e && t !== t);
    }
    var br = typeof Object.is == `function` ? Object.is : yr;
    function xr(e, t) {
      if (br(e, t)) return !0;
      if (typeof e != `object` || !e || typeof t != `object` || !t) return !1;
      var n = Object.keys(e),
        r = Object.keys(t);
      if (n.length !== r.length) return !1;
      for (r = 0; r < n.length; r++) {
        var i = n[r];
        if (!Me.call(t, i) || !br(e[i], t[i])) return !1;
      }
      return !0;
    }
    function Sr(e) {
      for (; e && e.firstChild;) e = e.firstChild;
      return e;
    }
    function Cr(e, t) {
      var n = Sr(e);
      e = 0;
      for (var r; n;) {
        if (n.nodeType === 3) {
          if (((r = e + n.textContent.length), e <= t && r >= t))
            return { node: n, offset: t - e };
          e = r;
        }
        a: {
          for (; n;) {
            if (n.nextSibling) {
              n = n.nextSibling;
              break a;
            }
            n = n.parentNode;
          }
          n = void 0;
        }
        n = Sr(n);
      }
    }
    function wr(e, t) {
      return e && t
        ? e === t
          ? !0
          : e && e.nodeType === 3
            ? !1
            : t && t.nodeType === 3
              ? wr(e, t.parentNode)
              : `contains` in e
                ? e.contains(t)
                : e.compareDocumentPosition
                  ? !!(e.compareDocumentPosition(t) & 16)
                  : !1
        : !1;
    }
    function Tr(e) {
      e =
        e != null &&
        e.ownerDocument != null &&
        e.ownerDocument.defaultView != null
          ? e.ownerDocument.defaultView
          : window;
      for (var t = Ft(e.document); t instanceof e.HTMLIFrameElement;) {
        try {
          var n = typeof t.contentWindow.location.href == `string`;
        } catch {
          n = !1;
        }
        if (n) e = t.contentWindow;
        else break;
        t = Ft(e.document);
      }
      return t;
    }
    function Er(e) {
      var t = e && e.nodeName && e.nodeName.toLowerCase();
      return (
        t &&
        ((t === `input` &&
          (e.type === `text` ||
            e.type === `search` ||
            e.type === `tel` ||
            e.type === `url` ||
            e.type === `password`)) ||
          t === `textarea` ||
          e.contentEditable === `true`)
      );
    }
    var Dr = cn && `documentMode` in document && 11 >= document.documentMode,
      Or = null,
      kr = null,
      Ar = null,
      jr = !1;
    function Mr(e, t, n) {
      var r =
        n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
      jr ||
        Or == null ||
        Or !== Ft(r) ||
        ((r = Or),
        `selectionStart` in r && Er(r)
          ? (r = { start: r.selectionStart, end: r.selectionEnd })
          : ((r = (
              (r.ownerDocument && r.ownerDocument.defaultView) ||
              window
            ).getSelection()),
            (r = {
              anchorNode: r.anchorNode,
              anchorOffset: r.anchorOffset,
              focusNode: r.focusNode,
              focusOffset: r.focusOffset,
            })),
        (Ar && xr(Ar, r)) ||
          ((Ar = r),
          (r = Ed(kr, `onSelect`)),
          0 < r.length &&
            ((t = new yn(`onSelect`, `select`, null, t, n)),
            e.push({ event: t, listeners: r }),
            (t.target = Or))));
    }
    function Nr(e, t) {
      var n = {};
      return (
        (n[e.toLowerCase()] = t.toLowerCase()),
        (n[`Webkit` + e] = `webkit` + t),
        (n[`Moz` + e] = `moz` + t),
        n
      );
    }
    var Pr = {
        animationend: Nr(`Animation`, `AnimationEnd`),
        animationiteration: Nr(`Animation`, `AnimationIteration`),
        animationstart: Nr(`Animation`, `AnimationStart`),
        transitionrun: Nr(`Transition`, `TransitionRun`),
        transitionstart: Nr(`Transition`, `TransitionStart`),
        transitioncancel: Nr(`Transition`, `TransitionCancel`),
        transitionend: Nr(`Transition`, `TransitionEnd`),
      },
      Fr = {},
      Ir = {};
    cn &&
      ((Ir = document.createElement(`div`).style),
      `AnimationEvent` in window ||
        (delete Pr.animationend.animation,
        delete Pr.animationiteration.animation,
        delete Pr.animationstart.animation),
      `TransitionEvent` in window || delete Pr.transitionend.transition);
    function Lr(e) {
      if (Fr[e]) return Fr[e];
      if (!Pr[e]) return e;
      var t = Pr[e],
        n;
      for (n in t) if (t.hasOwnProperty(n) && n in Ir) return (Fr[e] = t[n]);
      return e;
    }
    var Rr = Lr(`animationend`),
      zr = Lr(`animationiteration`),
      Br = Lr(`animationstart`),
      Vr = Lr(`transitionrun`),
      Hr = Lr(`transitionstart`),
      Ur = Lr(`transitioncancel`),
      Wr = Lr(`transitionend`),
      Gr = new Map(),
      Kr =
        `abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel`.split(
          ` `,
        );
    Kr.push(`scrollEnd`);
    function qr(e, t) {
      (Gr.set(e, t), Tt(t, [e]));
    }
    var Jr =
        typeof reportError == `function`
          ? reportError
          : function (e) {
              if (
                typeof window == `object` &&
                typeof window.ErrorEvent == `function`
              ) {
                var t = new window.ErrorEvent(`error`, {
                  bubbles: !0,
                  cancelable: !0,
                  message:
                    typeof e == `object` && e && typeof e.message == `string`
                      ? String(e.message)
                      : String(e),
                  error: e,
                });
                if (!window.dispatchEvent(t)) return;
              } else if (
                typeof process == `object` &&
                typeof process.emit == `function`
              ) {
                process.emit(`uncaughtException`, e);
                return;
              }
              console.error(e);
            },
      Yr = [],
      Xr = 0,
      Zr = 0;
    function Qr() {
      for (var e = Xr, t = (Zr = Xr = 0); t < e;) {
        var n = Yr[t];
        Yr[t++] = null;
        var r = Yr[t];
        Yr[t++] = null;
        var i = Yr[t];
        Yr[t++] = null;
        var a = Yr[t];
        if (((Yr[t++] = null), r !== null && i !== null)) {
          var o = r.pending;
          (o === null ? (i.next = i) : ((i.next = o.next), (o.next = i)),
            (r.pending = i));
        }
        a !== 0 && ni(n, i, a);
      }
    }
    function $r(e, t, n, r) {
      ((Yr[Xr++] = e),
        (Yr[Xr++] = t),
        (Yr[Xr++] = n),
        (Yr[Xr++] = r),
        (Zr |= r),
        (e.lanes |= r),
        (e = e.alternate),
        e !== null && (e.lanes |= r));
    }
    function ei(e, t, n, r) {
      return ($r(e, t, n, r), ri(e));
    }
    function ti(e, t) {
      return ($r(e, null, null, t), ri(e));
    }
    function ni(e, t, n) {
      e.lanes |= n;
      var r = e.alternate;
      r !== null && (r.lanes |= n);
      for (var i = !1, a = e.return; a !== null;)
        ((a.childLanes |= n),
          (r = a.alternate),
          r !== null && (r.childLanes |= n),
          a.tag === 22 &&
            ((e = a.stateNode), e === null || e._visibility & 1 || (i = !0)),
          (e = a),
          (a = a.return));
      return e.tag === 3
        ? ((a = e.stateNode),
          i &&
            t !== null &&
            ((i = 31 - qe(n)),
            (e = a.hiddenUpdates),
            (r = e[i]),
            r === null ? (e[i] = [t]) : r.push(t),
            (t.lane = n | 536870912)),
          a)
        : null;
    }
    function ri(e) {
      if (50 < du) throw ((du = 0), (fu = null), Error(i(185)));
      for (var t = e.return; t !== null;) ((e = t), (t = e.return));
      return e.tag === 3 ? e.stateNode : null;
    }
    var ii = {};
    function ai(e, t, n, r) {
      ((this.tag = e),
        (this.key = n),
        (this.sibling =
          this.child =
          this.return =
          this.stateNode =
          this.type =
          this.elementType =
            null),
        (this.index = 0),
        (this.refCleanup = this.ref = null),
        (this.pendingProps = t),
        (this.dependencies =
          this.memoizedState =
          this.updateQueue =
          this.memoizedProps =
            null),
        (this.mode = r),
        (this.subtreeFlags = this.flags = 0),
        (this.deletions = null),
        (this.childLanes = this.lanes = 0),
        (this.alternate = null));
    }
    function oi(e, t, n, r) {
      return new ai(e, t, n, r);
    }
    function si(e) {
      return ((e = e.prototype), !(!e || !e.isReactComponent));
    }
    function ci(e, t) {
      var n = e.alternate;
      return (
        n === null
          ? ((n = oi(e.tag, t, e.key, e.mode)),
            (n.elementType = e.elementType),
            (n.type = e.type),
            (n.stateNode = e.stateNode),
            (n.alternate = e),
            (e.alternate = n))
          : ((n.pendingProps = t),
            (n.type = e.type),
            (n.flags = 0),
            (n.subtreeFlags = 0),
            (n.deletions = null)),
        (n.flags = e.flags & 65011712),
        (n.childLanes = e.childLanes),
        (n.lanes = e.lanes),
        (n.child = e.child),
        (n.memoizedProps = e.memoizedProps),
        (n.memoizedState = e.memoizedState),
        (n.updateQueue = e.updateQueue),
        (t = e.dependencies),
        (n.dependencies =
          t === null ? null : { lanes: t.lanes, firstContext: t.firstContext }),
        (n.sibling = e.sibling),
        (n.index = e.index),
        (n.ref = e.ref),
        (n.refCleanup = e.refCleanup),
        n
      );
    }
    function li(e, t) {
      e.flags &= 65011714;
      var n = e.alternate;
      return (
        n === null
          ? ((e.childLanes = 0),
            (e.lanes = t),
            (e.child = null),
            (e.subtreeFlags = 0),
            (e.memoizedProps = null),
            (e.memoizedState = null),
            (e.updateQueue = null),
            (e.dependencies = null),
            (e.stateNode = null))
          : ((e.childLanes = n.childLanes),
            (e.lanes = n.lanes),
            (e.child = n.child),
            (e.subtreeFlags = 0),
            (e.deletions = null),
            (e.memoizedProps = n.memoizedProps),
            (e.memoizedState = n.memoizedState),
            (e.updateQueue = n.updateQueue),
            (e.type = n.type),
            (t = n.dependencies),
            (e.dependencies =
              t === null
                ? null
                : { lanes: t.lanes, firstContext: t.firstContext })),
        e
      );
    }
    function ui(e, t, n, r, a, o) {
      var s = 0;
      if (((r = e), typeof e == `function`)) si(e) && (s = 1);
      else if (typeof e == `string`)
        s = Uf(e, n, _e.current)
          ? 26
          : e === `html` || e === `head` || e === `body`
            ? 27
            : 5;
      else
        a: switch (e) {
          case ae:
            return (
              (e = oi(31, n, t, a)),
              (e.elementType = ae),
              (e.lanes = o),
              e
            );
          case y:
            return di(n.children, a, o, t);
          case b:
            ((s = 8), (a |= 24));
            break;
          case x:
            return (
              (e = oi(12, n, t, a | 2)),
              (e.elementType = x),
              (e.lanes = o),
              e
            );
          case te:
            return (
              (e = oi(13, n, t, a)),
              (e.elementType = te),
              (e.lanes = o),
              e
            );
          case ne:
            return (
              (e = oi(19, n, t, a)),
              (e.elementType = ne),
              (e.lanes = o),
              e
            );
          default:
            if (typeof e == `object` && e)
              switch (e.$$typeof) {
                case S:
                  s = 10;
                  break a;
                case ee:
                  s = 9;
                  break a;
                case C:
                  s = 11;
                  break a;
                case re:
                  s = 14;
                  break a;
                case ie:
                  ((s = 16), (r = null));
                  break a;
              }
            ((s = 29),
              (n = Error(i(130, e === null ? `null` : typeof e, ``))),
              (r = null));
        }
      return (
        (t = oi(s, n, t, a)),
        (t.elementType = e),
        (t.type = r),
        (t.lanes = o),
        t
      );
    }
    function di(e, t, n, r) {
      return ((e = oi(7, e, r, t)), (e.lanes = n), e);
    }
    function fi(e, t, n) {
      return ((e = oi(6, e, null, t)), (e.lanes = n), e);
    }
    function pi(e) {
      var t = oi(18, null, null, 0);
      return ((t.stateNode = e), t);
    }
    function mi(e, t, n) {
      return (
        (t = oi(4, e.children === null ? [] : e.children, e.key, t)),
        (t.lanes = n),
        (t.stateNode = {
          containerInfo: e.containerInfo,
          pendingChildren: null,
          implementation: e.implementation,
        }),
        t
      );
    }
    var hi = new WeakMap();
    function gi(e, t) {
      if (typeof e == `object` && e) {
        var n = hi.get(e);
        return n === void 0
          ? ((t = { value: e, source: t, stack: je(t) }), hi.set(e, t), t)
          : n;
      }
      return { value: e, source: t, stack: je(t) };
    }
    var _i = [],
      vi = 0,
      yi = null,
      bi = 0,
      xi = [],
      Si = 0,
      Ci = null,
      wi = 1,
      Ti = ``;
    function Ei(e, t) {
      ((_i[vi++] = bi), (_i[vi++] = yi), (yi = e), (bi = t));
    }
    function Di(e, t, n) {
      ((xi[Si++] = wi), (xi[Si++] = Ti), (xi[Si++] = Ci), (Ci = e));
      var r = wi;
      e = Ti;
      var i = 32 - qe(r) - 1;
      ((r &= ~(1 << i)), (n += 1));
      var a = 32 - qe(t) + i;
      if (30 < a) {
        var o = i - (i % 5);
        ((a = (r & ((1 << o) - 1)).toString(32)),
          (r >>= o),
          (i -= o),
          (wi = (1 << (32 - qe(t) + i)) | (n << i) | r),
          (Ti = a + e));
      } else ((wi = (1 << a) | (n << i) | r), (Ti = e));
    }
    function Oi(e) {
      e.return !== null && (Ei(e, 1), Di(e, 1, 0));
    }
    function ki(e) {
      for (; e === yi;)
        ((yi = _i[--vi]), (_i[vi] = null), (bi = _i[--vi]), (_i[vi] = null));
      for (; e === Ci;)
        ((Ci = xi[--Si]),
          (xi[Si] = null),
          (Ti = xi[--Si]),
          (xi[Si] = null),
          (wi = xi[--Si]),
          (xi[Si] = null));
    }
    function Ai(e, t) {
      ((xi[Si++] = wi),
        (xi[Si++] = Ti),
        (xi[Si++] = Ci),
        (wi = t.id),
        (Ti = t.overflow),
        (Ci = e));
    }
    var ji = null,
      V = null,
      H = !1,
      Mi = null,
      Ni = !1,
      Pi = Error(i(519));
    function Fi(e) {
      throw (
        Vi(
          gi(
            Error(
              i(
                418,
                1 < arguments.length && arguments[1] !== void 0 && arguments[1]
                  ? `text`
                  : `HTML`,
                ``,
              ),
            ),
            e,
          ),
        ),
        Pi
      );
    }
    function Ii(e) {
      var t = e.stateNode,
        n = e.type,
        r = e.memoizedProps;
      switch (((t[F] = e), (t[ut] = r), n)) {
        case `dialog`:
          (Q(`cancel`, t), Q(`close`, t));
          break;
        case `iframe`:
        case `object`:
        case `embed`:
          Q(`load`, t);
          break;
        case `video`:
        case `audio`:
          for (n = 0; n < _d.length; n++) Q(_d[n], t);
          break;
        case `source`:
          Q(`error`, t);
          break;
        case `img`:
        case `image`:
        case `link`:
          (Q(`error`, t), Q(`load`, t));
          break;
        case `details`:
          Q(`toggle`, t);
          break;
        case `input`:
          (Q(`invalid`, t),
            zt(
              t,
              r.value,
              r.defaultValue,
              r.checked,
              r.defaultChecked,
              r.type,
              r.name,
              !0,
            ));
          break;
        case `select`:
          Q(`invalid`, t);
          break;
        case `textarea`:
          (Q(`invalid`, t), Ut(t, r.value, r.defaultValue, r.children));
      }
      ((n = r.children),
        (typeof n != `string` &&
          typeof n != `number` &&
          typeof n != `bigint`) ||
        t.textContent === `` + n ||
        !0 === r.suppressHydrationWarning ||
        Md(t.textContent, n)
          ? (r.popover != null && (Q(`beforetoggle`, t), Q(`toggle`, t)),
            r.onScroll != null && Q(`scroll`, t),
            r.onScrollEnd != null && Q(`scrollend`, t),
            r.onClick != null && (t.onclick = Qt),
            (t = !0))
          : (t = !1),
        t || Fi(e, !0));
    }
    function Li(e) {
      for (ji = e.return; ji;)
        switch (ji.tag) {
          case 5:
          case 31:
          case 13:
            Ni = !1;
            return;
          case 27:
          case 3:
            Ni = !0;
            return;
          default:
            ji = ji.return;
        }
    }
    function Ri(e) {
      if (e !== ji) return !1;
      if (!H) return (Li(e), (H = !0), !1);
      var t = e.tag,
        n;
      if (
        ((n = t !== 3 && t !== 27) &&
          ((n = t === 5) &&
            ((n = e.type),
            (n =
              n === `form` || n === `button` || Ud(e.type, e.memoizedProps))),
          (n = !n)),
        n && V && Fi(e),
        Li(e),
        t === 13)
      ) {
        if (((e = e.memoizedState), (e = e === null ? null : e.dehydrated), !e))
          throw Error(i(317));
        V = uf(e);
      } else if (t === 31) {
        if (((e = e.memoizedState), (e = e === null ? null : e.dehydrated), !e))
          throw Error(i(317));
        V = uf(e);
      } else
        t === 27
          ? ((t = V), Zd(e.type) ? ((e = lf), (lf = null), (V = e)) : (V = t))
          : (V = ji ? cf(e.stateNode.nextSibling) : null);
      return !0;
    }
    function zi() {
      ((V = ji = null), (H = !1));
    }
    function Bi() {
      var e = Mi;
      return (
        e !== null &&
          (Zl === null ? (Zl = e) : Zl.push.apply(Zl, e), (Mi = null)),
        e
      );
    }
    function Vi(e) {
      Mi === null ? (Mi = [e]) : Mi.push(e);
    }
    var Hi = he(null),
      Ui = null,
      Wi = null;
    function Gi(e, t, n) {
      (E(Hi, t._currentValue), (t._currentValue = n));
    }
    function Ki(e) {
      ((e._currentValue = Hi.current), ge(Hi));
    }
    function qi(e, t, n) {
      for (; e !== null;) {
        var r = e.alternate;
        if (
          ((e.childLanes & t) === t
            ? r !== null && (r.childLanes & t) !== t && (r.childLanes |= t)
            : ((e.childLanes |= t), r !== null && (r.childLanes |= t)),
          e === n)
        )
          break;
        e = e.return;
      }
    }
    function Ji(e, t, n, r) {
      var a = e.child;
      for (a !== null && (a.return = e); a !== null;) {
        var o = a.dependencies;
        if (o !== null) {
          var s = a.child;
          o = o.firstContext;
          a: for (; o !== null;) {
            var c = o;
            o = a;
            for (var l = 0; l < t.length; l++)
              if (c.context === t[l]) {
                ((o.lanes |= n),
                  (c = o.alternate),
                  c !== null && (c.lanes |= n),
                  qi(o.return, n, e),
                  r || (s = null));
                break a;
              }
            o = c.next;
          }
        } else if (a.tag === 18) {
          if (((s = a.return), s === null)) throw Error(i(341));
          ((s.lanes |= n),
            (o = s.alternate),
            o !== null && (o.lanes |= n),
            qi(s, n, e),
            (s = null));
        } else s = a.child;
        if (s !== null) s.return = a;
        else
          for (s = a; s !== null;) {
            if (s === e) {
              s = null;
              break;
            }
            if (((a = s.sibling), a !== null)) {
              ((a.return = s.return), (s = a));
              break;
            }
            s = s.return;
          }
        a = s;
      }
    }
    function Yi(e, t, n, r) {
      e = null;
      for (var a = t, o = !1; a !== null;) {
        if (!o) {
          if (a.flags & 524288) o = !0;
          else if (a.flags & 262144) break;
        }
        if (a.tag === 10) {
          var s = a.alternate;
          if (s === null) throw Error(i(387));
          if (((s = s.memoizedProps), s !== null)) {
            var c = a.type;
            br(a.pendingProps.value, s.value) ||
              (e === null ? (e = [c]) : e.push(c));
          }
        } else if (a === be.current) {
          if (((s = a.alternate), s === null)) throw Error(i(387));
          s.memoizedState.memoizedState !== a.memoizedState.memoizedState &&
            (e === null ? (e = [Qf]) : e.push(Qf));
        }
        a = a.return;
      }
      (e !== null && Ji(t, e, n, r), (t.flags |= 262144));
    }
    function Xi(e) {
      for (e = e.firstContext; e !== null;) {
        if (!br(e.context._currentValue, e.memoizedValue)) return !0;
        e = e.next;
      }
      return !1;
    }
    function Zi(e) {
      ((Ui = e),
        (Wi = null),
        (e = e.dependencies),
        e !== null && (e.firstContext = null));
    }
    function Qi(e) {
      return ea(Ui, e);
    }
    function $i(e, t) {
      return (Ui === null && Zi(e), ea(e, t));
    }
    function ea(e, t) {
      var n = t._currentValue;
      if (((t = { context: t, memoizedValue: n, next: null }), Wi === null)) {
        if (e === null) throw Error(i(308));
        ((Wi = t),
          (e.dependencies = { lanes: 0, firstContext: t }),
          (e.flags |= 524288));
      } else Wi = Wi.next = t;
      return n;
    }
    var ta =
        typeof AbortController < `u`
          ? AbortController
          : function () {
              var e = [],
                t = (this.signal = {
                  aborted: !1,
                  addEventListener: function (t, n) {
                    e.push(n);
                  },
                });
              this.abort = function () {
                ((t.aborted = !0),
                  e.forEach(function (e) {
                    return e();
                  }));
              };
            },
      na = t.unstable_scheduleCallback,
      ra = t.unstable_NormalPriority,
      ia = {
        $$typeof: S,
        Consumer: null,
        Provider: null,
        _currentValue: null,
        _currentValue2: null,
        _threadCount: 0,
      };
    function aa() {
      return { controller: new ta(), data: new Map(), refCount: 0 };
    }
    function oa(e) {
      (e.refCount--,
        e.refCount === 0 &&
          na(ra, function () {
            e.controller.abort();
          }));
    }
    var sa = null,
      ca = 0,
      la = 0,
      ua = null;
    function da(e, t) {
      if (sa === null) {
        var n = (sa = []);
        ((ca = 0),
          (la = dd()),
          (ua = {
            status: `pending`,
            value: void 0,
            then: function (e) {
              n.push(e);
            },
          }));
      }
      return (ca++, t.then(fa, fa), t);
    }
    function fa() {
      if (--ca === 0 && sa !== null) {
        ua !== null && (ua.status = `fulfilled`);
        var e = sa;
        ((sa = null), (la = 0), (ua = null));
        for (var t = 0; t < e.length; t++) (0, e[t])();
      }
    }
    function pa(e, t) {
      var n = [],
        r = {
          status: `pending`,
          value: null,
          reason: null,
          then: function (e) {
            n.push(e);
          },
        };
      return (
        e.then(
          function () {
            ((r.status = `fulfilled`), (r.value = t));
            for (var e = 0; e < n.length; e++) (0, n[e])(t);
          },
          function (e) {
            for (r.status = `rejected`, r.reason = e, e = 0; e < n.length; e++)
              (0, n[e])(void 0);
          },
        ),
        r
      );
    }
    var ma = w.S;
    w.S = function (e, t) {
      ((eu = Le()),
        typeof t == `object` && t && typeof t.then == `function` && da(e, t),
        ma !== null && ma(e, t));
    };
    var ha = he(null);
    function ga() {
      var e = ha.current;
      return e === null ? q.pooledCache : e;
    }
    function _a(e, t) {
      t === null ? E(ha, ha.current) : E(ha, t.pool);
    }
    function va() {
      var e = ga();
      return e === null ? null : { parent: ia._currentValue, pool: e };
    }
    var ya = Error(i(460)),
      ba = Error(i(474)),
      xa = Error(i(542)),
      Sa = { then: function () {} };
    function Ca(e) {
      return ((e = e.status), e === `fulfilled` || e === `rejected`);
    }
    function wa(e, t, n) {
      switch (
        ((n = e[n]),
        n === void 0 ? e.push(t) : n !== t && (t.then(Qt, Qt), (t = n)),
        t.status)
      ) {
        case `fulfilled`:
          return t.value;
        case `rejected`:
          throw ((e = t.reason), Oa(e), e);
        default:
          if (typeof t.status == `string`) t.then(Qt, Qt);
          else {
            if (((e = q), e !== null && 100 < e.shellSuspendCounter))
              throw Error(i(482));
            ((e = t),
              (e.status = `pending`),
              e.then(
                function (e) {
                  if (t.status === `pending`) {
                    var n = t;
                    ((n.status = `fulfilled`), (n.value = e));
                  }
                },
                function (e) {
                  if (t.status === `pending`) {
                    var n = t;
                    ((n.status = `rejected`), (n.reason = e));
                  }
                },
              ));
          }
          switch (t.status) {
            case `fulfilled`:
              return t.value;
            case `rejected`:
              throw ((e = t.reason), Oa(e), e);
          }
          throw ((Ea = t), ya);
      }
    }
    function Ta(e) {
      try {
        var t = e._init;
        return t(e._payload);
      } catch (e) {
        throw typeof e == `object` && e && typeof e.then == `function`
          ? ((Ea = e), ya)
          : e;
      }
    }
    var Ea = null;
    function Da() {
      if (Ea === null) throw Error(i(459));
      var e = Ea;
      return ((Ea = null), e);
    }
    function Oa(e) {
      if (e === ya || e === xa) throw Error(i(483));
    }
    var ka = null,
      Aa = 0;
    function ja(e) {
      var t = Aa;
      return ((Aa += 1), ka === null && (ka = []), wa(ka, e, t));
    }
    function Ma(e, t) {
      ((t = t.props.ref), (e.ref = t === void 0 ? null : t));
    }
    function Na(e, t) {
      throw t.$$typeof === g
        ? Error(i(525))
        : ((e = Object.prototype.toString.call(t)),
          Error(
            i(
              31,
              e === `[object Object]`
                ? `object with keys {` + Object.keys(t).join(`, `) + `}`
                : e,
            ),
          ));
    }
    function Pa(e) {
      function t(t, n) {
        if (e) {
          var r = t.deletions;
          r === null ? ((t.deletions = [n]), (t.flags |= 16)) : r.push(n);
        }
      }
      function n(n, r) {
        if (!e) return null;
        for (; r !== null;) (t(n, r), (r = r.sibling));
        return null;
      }
      function r(e) {
        for (var t = new Map(); e !== null;)
          (e.key === null ? t.set(e.index, e) : t.set(e.key, e),
            (e = e.sibling));
        return t;
      }
      function a(e, t) {
        return ((e = ci(e, t)), (e.index = 0), (e.sibling = null), e);
      }
      function o(t, n, r) {
        return (
          (t.index = r),
          e
            ? ((r = t.alternate),
              r === null
                ? ((t.flags |= 67108866), n)
                : ((r = r.index), r < n ? ((t.flags |= 67108866), n) : r))
            : ((t.flags |= 1048576), n)
        );
      }
      function s(t) {
        return (e && t.alternate === null && (t.flags |= 67108866), t);
      }
      function c(e, t, n, r) {
        return t === null || t.tag !== 6
          ? ((t = fi(n, e.mode, r)), (t.return = e), t)
          : ((t = a(t, n)), (t.return = e), t);
      }
      function l(e, t, n, r) {
        var i = n.type;
        return i === y
          ? d(e, t, n.props.children, r, n.key)
          : t !== null &&
              (t.elementType === i ||
                (typeof i == `object` &&
                  i &&
                  i.$$typeof === ie &&
                  Ta(i) === t.type))
            ? ((t = a(t, n.props)), Ma(t, n), (t.return = e), t)
            : ((t = ui(n.type, n.key, n.props, null, e.mode, r)),
              Ma(t, n),
              (t.return = e),
              t);
      }
      function u(e, t, n, r) {
        return t === null ||
          t.tag !== 4 ||
          t.stateNode.containerInfo !== n.containerInfo ||
          t.stateNode.implementation !== n.implementation
          ? ((t = mi(n, e.mode, r)), (t.return = e), t)
          : ((t = a(t, n.children || [])), (t.return = e), t);
      }
      function d(e, t, n, r, i) {
        return t === null || t.tag !== 7
          ? ((t = di(n, e.mode, r, i)), (t.return = e), t)
          : ((t = a(t, n)), (t.return = e), t);
      }
      function f(e, t, n) {
        if (
          (typeof t == `string` && t !== ``) ||
          typeof t == `number` ||
          typeof t == `bigint`
        )
          return ((t = fi(`` + t, e.mode, n)), (t.return = e), t);
        if (typeof t == `object` && t) {
          switch (t.$$typeof) {
            case _:
              return (
                (n = ui(t.type, t.key, t.props, null, e.mode, n)),
                Ma(n, t),
                (n.return = e),
                n
              );
            case v:
              return ((t = mi(t, e.mode, n)), (t.return = e), t);
            case ie:
              return ((t = Ta(t)), f(e, t, n));
          }
          if (de(t) || ce(t))
            return ((t = di(t, e.mode, n, null)), (t.return = e), t);
          if (typeof t.then == `function`) return f(e, ja(t), n);
          if (t.$$typeof === S) return f(e, $i(e, t), n);
          Na(e, t);
        }
        return null;
      }
      function p(e, t, n, r) {
        var i = t === null ? null : t.key;
        if (
          (typeof n == `string` && n !== ``) ||
          typeof n == `number` ||
          typeof n == `bigint`
        )
          return i === null ? c(e, t, `` + n, r) : null;
        if (typeof n == `object` && n) {
          switch (n.$$typeof) {
            case _:
              return n.key === i ? l(e, t, n, r) : null;
            case v:
              return n.key === i ? u(e, t, n, r) : null;
            case ie:
              return ((n = Ta(n)), p(e, t, n, r));
          }
          if (de(n) || ce(n)) return i === null ? d(e, t, n, r, null) : null;
          if (typeof n.then == `function`) return p(e, t, ja(n), r);
          if (n.$$typeof === S) return p(e, t, $i(e, n), r);
          Na(e, n);
        }
        return null;
      }
      function m(e, t, n, r, i) {
        if (
          (typeof r == `string` && r !== ``) ||
          typeof r == `number` ||
          typeof r == `bigint`
        )
          return ((e = e.get(n) || null), c(t, e, `` + r, i));
        if (typeof r == `object` && r) {
          switch (r.$$typeof) {
            case _:
              return (
                (e = e.get(r.key === null ? n : r.key) || null),
                l(t, e, r, i)
              );
            case v:
              return (
                (e = e.get(r.key === null ? n : r.key) || null),
                u(t, e, r, i)
              );
            case ie:
              return ((r = Ta(r)), m(e, t, n, r, i));
          }
          if (de(r) || ce(r))
            return ((e = e.get(n) || null), d(t, e, r, i, null));
          if (typeof r.then == `function`) return m(e, t, n, ja(r), i);
          if (r.$$typeof === S) return m(e, t, n, $i(t, r), i);
          Na(t, r);
        }
        return null;
      }
      function h(i, a, s, c) {
        for (
          var l = null, u = null, d = a, h = (a = 0), g = null;
          d !== null && h < s.length;
          h++
        ) {
          d.index > h ? ((g = d), (d = null)) : (g = d.sibling);
          var _ = p(i, d, s[h], c);
          if (_ === null) {
            d === null && (d = g);
            break;
          }
          (e && d && _.alternate === null && t(i, d),
            (a = o(_, a, h)),
            u === null ? (l = _) : (u.sibling = _),
            (u = _),
            (d = g));
        }
        if (h === s.length) return (n(i, d), H && Ei(i, h), l);
        if (d === null) {
          for (; h < s.length; h++)
            ((d = f(i, s[h], c)),
              d !== null &&
                ((a = o(d, a, h)),
                u === null ? (l = d) : (u.sibling = d),
                (u = d)));
          return (H && Ei(i, h), l);
        }
        for (d = r(d); h < s.length; h++)
          ((g = m(d, i, h, s[h], c)),
            g !== null &&
              (e &&
                g.alternate !== null &&
                d.delete(g.key === null ? h : g.key),
              (a = o(g, a, h)),
              u === null ? (l = g) : (u.sibling = g),
              (u = g)));
        return (
          e &&
            d.forEach(function (e) {
              return t(i, e);
            }),
          H && Ei(i, h),
          l
        );
      }
      function g(a, s, c, l) {
        if (c == null) throw Error(i(151));
        for (
          var u = null, d = null, h = s, g = (s = 0), _ = null, v = c.next();
          h !== null && !v.done;
          g++, v = c.next()
        ) {
          h.index > g ? ((_ = h), (h = null)) : (_ = h.sibling);
          var y = p(a, h, v.value, l);
          if (y === null) {
            h === null && (h = _);
            break;
          }
          (e && h && y.alternate === null && t(a, h),
            (s = o(y, s, g)),
            d === null ? (u = y) : (d.sibling = y),
            (d = y),
            (h = _));
        }
        if (v.done) return (n(a, h), H && Ei(a, g), u);
        if (h === null) {
          for (; !v.done; g++, v = c.next())
            ((v = f(a, v.value, l)),
              v !== null &&
                ((s = o(v, s, g)),
                d === null ? (u = v) : (d.sibling = v),
                (d = v)));
          return (H && Ei(a, g), u);
        }
        for (h = r(h); !v.done; g++, v = c.next())
          ((v = m(h, a, g, v.value, l)),
            v !== null &&
              (e &&
                v.alternate !== null &&
                h.delete(v.key === null ? g : v.key),
              (s = o(v, s, g)),
              d === null ? (u = v) : (d.sibling = v),
              (d = v)));
        return (
          e &&
            h.forEach(function (e) {
              return t(a, e);
            }),
          H && Ei(a, g),
          u
        );
      }
      function b(e, r, o, c) {
        if (
          (typeof o == `object` &&
            o &&
            o.type === y &&
            o.key === null &&
            (o = o.props.children),
          typeof o == `object` && o)
        ) {
          switch (o.$$typeof) {
            case _:
              a: {
                for (var l = o.key; r !== null;) {
                  if (r.key === l) {
                    if (((l = o.type), l === y)) {
                      if (r.tag === 7) {
                        (n(e, r.sibling),
                          (c = a(r, o.props.children)),
                          (c.return = e),
                          (e = c));
                        break a;
                      }
                    } else if (
                      r.elementType === l ||
                      (typeof l == `object` &&
                        l &&
                        l.$$typeof === ie &&
                        Ta(l) === r.type)
                    ) {
                      (n(e, r.sibling),
                        (c = a(r, o.props)),
                        Ma(c, o),
                        (c.return = e),
                        (e = c));
                      break a;
                    }
                    n(e, r);
                    break;
                  }
                  (t(e, r), (r = r.sibling));
                }
                o.type === y
                  ? ((c = di(o.props.children, e.mode, c, o.key)),
                    (c.return = e),
                    (e = c))
                  : ((c = ui(o.type, o.key, o.props, null, e.mode, c)),
                    Ma(c, o),
                    (c.return = e),
                    (e = c));
              }
              return s(e);
            case v:
              a: {
                for (l = o.key; r !== null;) {
                  if (r.key === l)
                    if (
                      r.tag === 4 &&
                      r.stateNode.containerInfo === o.containerInfo &&
                      r.stateNode.implementation === o.implementation
                    ) {
                      (n(e, r.sibling),
                        (c = a(r, o.children || [])),
                        (c.return = e),
                        (e = c));
                      break a;
                    } else {
                      n(e, r);
                      break;
                    }
                  (t(e, r), (r = r.sibling));
                }
                ((c = mi(o, e.mode, c)), (c.return = e), (e = c));
              }
              return s(e);
            case ie:
              return ((o = Ta(o)), b(e, r, o, c));
          }
          if (de(o)) return h(e, r, o, c);
          if (ce(o)) {
            if (((l = ce(o)), typeof l != `function`)) throw Error(i(150));
            return ((o = l.call(o)), g(e, r, o, c));
          }
          if (typeof o.then == `function`) return b(e, r, ja(o), c);
          if (o.$$typeof === S) return b(e, r, $i(e, o), c);
          Na(e, o);
        }
        return (typeof o == `string` && o !== ``) ||
          typeof o == `number` ||
          typeof o == `bigint`
          ? ((o = `` + o),
            r !== null && r.tag === 6
              ? (n(e, r.sibling), (c = a(r, o)), (c.return = e), (e = c))
              : (n(e, r), (c = fi(o, e.mode, c)), (c.return = e), (e = c)),
            s(e))
          : n(e, r);
      }
      return function (e, t, n, r) {
        try {
          Aa = 0;
          var i = b(e, t, n, r);
          return ((ka = null), i);
        } catch (t) {
          if (t === ya || t === xa) throw t;
          var a = oi(29, t, null, e.mode);
          return ((a.lanes = r), (a.return = e), a);
        }
      };
    }
    var Fa = Pa(!0),
      Ia = Pa(!1),
      La = !1;
    function Ra(e) {
      e.updateQueue = {
        baseState: e.memoizedState,
        firstBaseUpdate: null,
        lastBaseUpdate: null,
        shared: { pending: null, lanes: 0, hiddenCallbacks: null },
        callbacks: null,
      };
    }
    function za(e, t) {
      ((e = e.updateQueue),
        t.updateQueue === e &&
          (t.updateQueue = {
            baseState: e.baseState,
            firstBaseUpdate: e.firstBaseUpdate,
            lastBaseUpdate: e.lastBaseUpdate,
            shared: e.shared,
            callbacks: null,
          }));
    }
    function Ba(e) {
      return { lane: e, tag: 0, payload: null, callback: null, next: null };
    }
    function Va(e, t, n) {
      var r = e.updateQueue;
      if (r === null) return null;
      if (((r = r.shared), K & 2)) {
        var i = r.pending;
        return (
          i === null ? (t.next = t) : ((t.next = i.next), (i.next = t)),
          (r.pending = t),
          (t = ri(e)),
          ni(e, null, n),
          t
        );
      }
      return ($r(e, r, t, n), ri(e));
    }
    function Ha(e, t, n) {
      if (((t = t.updateQueue), t !== null && ((t = t.shared), n & 4194048))) {
        var r = t.lanes;
        ((r &= e.pendingLanes), (n |= r), (t.lanes = n), j(e, n));
      }
    }
    function Ua(e, t) {
      var n = e.updateQueue,
        r = e.alternate;
      if (r !== null && ((r = r.updateQueue), n === r)) {
        var i = null,
          a = null;
        if (((n = n.firstBaseUpdate), n !== null)) {
          do {
            var o = {
              lane: n.lane,
              tag: n.tag,
              payload: n.payload,
              callback: null,
              next: null,
            };
            (a === null ? (i = a = o) : (a = a.next = o), (n = n.next));
          } while (n !== null);
          a === null ? (i = a = t) : (a = a.next = t);
        } else i = a = t;
        ((n = {
          baseState: r.baseState,
          firstBaseUpdate: i,
          lastBaseUpdate: a,
          shared: r.shared,
          callbacks: r.callbacks,
        }),
          (e.updateQueue = n));
        return;
      }
      ((e = n.lastBaseUpdate),
        e === null ? (n.firstBaseUpdate = t) : (e.next = t),
        (n.lastBaseUpdate = t));
    }
    var Wa = !1;
    function Ga() {
      if (Wa) {
        var e = ua;
        if (e !== null) throw e;
      }
    }
    function Ka(e, t, n, r) {
      Wa = !1;
      var i = e.updateQueue;
      La = !1;
      var a = i.firstBaseUpdate,
        o = i.lastBaseUpdate,
        s = i.shared.pending;
      if (s !== null) {
        i.shared.pending = null;
        var c = s,
          l = c.next;
        ((c.next = null), o === null ? (a = l) : (o.next = l), (o = c));
        var u = e.alternate;
        u !== null &&
          ((u = u.updateQueue),
          (s = u.lastBaseUpdate),
          s !== o &&
            (s === null ? (u.firstBaseUpdate = l) : (s.next = l),
            (u.lastBaseUpdate = c)));
      }
      if (a !== null) {
        var d = i.baseState;
        ((o = 0), (u = l = c = null), (s = a));
        do {
          var f = s.lane & -536870913,
            p = f !== s.lane;
          if (p ? (Y & f) === f : (r & f) === f) {
            (f !== 0 && f === la && (Wa = !0),
              u !== null &&
                (u = u.next =
                  {
                    lane: 0,
                    tag: s.tag,
                    payload: s.payload,
                    callback: null,
                    next: null,
                  }));
            a: {
              var m = e,
                g = s;
              f = t;
              var _ = n;
              switch (g.tag) {
                case 1:
                  if (((m = g.payload), typeof m == `function`)) {
                    d = m.call(_, d, f);
                    break a;
                  }
                  d = m;
                  break a;
                case 3:
                  m.flags = (m.flags & -65537) | 128;
                case 0:
                  if (
                    ((m = g.payload),
                    (f = typeof m == `function` ? m.call(_, d, f) : m),
                    f == null)
                  )
                    break a;
                  d = h({}, d, f);
                  break a;
                case 2:
                  La = !0;
              }
            }
            ((f = s.callback),
              f !== null &&
                ((e.flags |= 64),
                p && (e.flags |= 8192),
                (p = i.callbacks),
                p === null ? (i.callbacks = [f]) : p.push(f)));
          } else
            ((p = {
              lane: f,
              tag: s.tag,
              payload: s.payload,
              callback: s.callback,
              next: null,
            }),
              u === null ? ((l = u = p), (c = d)) : (u = u.next = p),
              (o |= f));
          if (((s = s.next), s === null)) {
            if (((s = i.shared.pending), s === null)) break;
            ((p = s),
              (s = p.next),
              (p.next = null),
              (i.lastBaseUpdate = p),
              (i.shared.pending = null));
          }
        } while (1);
        (u === null && (c = d),
          (i.baseState = c),
          (i.firstBaseUpdate = l),
          (i.lastBaseUpdate = u),
          a === null && (i.shared.lanes = 0),
          (Gl |= o),
          (e.lanes = o),
          (e.memoizedState = d));
      }
    }
    function qa(e, t) {
      if (typeof e != `function`) throw Error(i(191, e));
      e.call(t);
    }
    function Ja(e, t) {
      var n = e.callbacks;
      if (n !== null)
        for (e.callbacks = null, e = 0; e < n.length; e++) qa(n[e], t);
    }
    var Ya = he(null),
      Xa = he(0);
    function Za(e, t) {
      ((e = Ul), E(Xa, e), E(Ya, t), (Ul = e | t.baseLanes));
    }
    function Qa() {
      (E(Xa, Ul), E(Ya, Ya.current));
    }
    function $a() {
      ((Ul = Xa.current), ge(Ya), ge(Xa));
    }
    var eo = he(null),
      to = null;
    function no(e) {
      var t = e.alternate;
      (E(so, so.current & 1),
        E(eo, e),
        to === null &&
          (t === null || Ya.current !== null || t.memoizedState !== null) &&
          (to = e));
    }
    function ro(e) {
      (E(so, so.current), E(eo, e), to === null && (to = e));
    }
    function io(e) {
      e.tag === 22
        ? (E(so, so.current), E(eo, e), to === null && (to = e))
        : ao(e);
    }
    function ao() {
      (E(so, so.current), E(eo, eo.current));
    }
    function oo(e) {
      (ge(eo), to === e && (to = null), ge(so));
    }
    var so = he(0);
    function co(e) {
      for (var t = e; t !== null;) {
        if (t.tag === 13) {
          var n = t.memoizedState;
          if (n !== null && ((n = n.dehydrated), n === null || af(n) || of(n)))
            return t;
        } else if (
          t.tag === 19 &&
          (t.memoizedProps.revealOrder === `forwards` ||
            t.memoizedProps.revealOrder === `backwards` ||
            t.memoizedProps.revealOrder === `unstable_legacy-backwards` ||
            t.memoizedProps.revealOrder === `together`)
        ) {
          if (t.flags & 128) return t;
        } else if (t.child !== null) {
          ((t.child.return = t), (t = t.child));
          continue;
        }
        if (t === e) break;
        for (; t.sibling === null;) {
          if (t.return === null || t.return === e) return null;
          t = t.return;
        }
        ((t.sibling.return = t.return), (t = t.sibling));
      }
      return null;
    }
    var lo = 0,
      U = null,
      W = null,
      uo = null,
      fo = !1,
      po = !1,
      mo = !1,
      ho = 0,
      go = 0,
      _o = null,
      vo = 0;
    function yo() {
      throw Error(i(321));
    }
    function bo(e, t) {
      if (t === null) return !1;
      for (var n = 0; n < t.length && n < e.length; n++)
        if (!br(e[n], t[n])) return !1;
      return !0;
    }
    function xo(e, t, n, r, i, a) {
      return (
        (lo = a),
        (U = t),
        (t.memoizedState = null),
        (t.updateQueue = null),
        (t.lanes = 0),
        (w.H = e === null || e.memoizedState === null ? Rs : zs),
        (mo = !1),
        (a = n(r, i)),
        (mo = !1),
        po && (a = Co(t, n, r, i)),
        So(e),
        a
      );
    }
    function So(e) {
      w.H = Ls;
      var t = W !== null && W.next !== null;
      if (((lo = 0), (uo = W = U = null), (fo = !1), (go = 0), (_o = null), t))
        throw Error(i(300));
      e === null ||
        nc ||
        ((e = e.dependencies), e !== null && Xi(e) && (nc = !0));
    }
    function Co(e, t, n, r) {
      U = e;
      var a = 0;
      do {
        if ((po && (_o = null), (go = 0), (po = !1), 25 <= a))
          throw Error(i(301));
        if (((a += 1), (uo = W = null), e.updateQueue != null)) {
          var o = e.updateQueue;
          ((o.lastEffect = null),
            (o.events = null),
            (o.stores = null),
            o.memoCache != null && (o.memoCache.index = 0));
        }
        ((w.H = Bs), (o = t(n, r)));
      } while (po);
      return o;
    }
    function wo() {
      var e = w.H,
        t = e.useState()[0];
      return (
        (t = typeof t.then == `function` ? jo(t) : t),
        (e = e.useState()[0]),
        (W === null ? null : W.memoizedState) !== e && (U.flags |= 1024),
        t
      );
    }
    function To() {
      var e = ho !== 0;
      return ((ho = 0), e);
    }
    function Eo(e, t, n) {
      ((t.updateQueue = e.updateQueue), (t.flags &= -2053), (e.lanes &= ~n));
    }
    function Do(e) {
      if (fo) {
        for (e = e.memoizedState; e !== null;) {
          var t = e.queue;
          (t !== null && (t.pending = null), (e = e.next));
        }
        fo = !1;
      }
      ((lo = 0), (uo = W = U = null), (po = !1), (go = ho = 0), (_o = null));
    }
    function Oo() {
      var e = {
        memoizedState: null,
        baseState: null,
        baseQueue: null,
        queue: null,
        next: null,
      };
      return (
        uo === null ? (U.memoizedState = uo = e) : (uo = uo.next = e),
        uo
      );
    }
    function ko() {
      if (W === null) {
        var e = U.alternate;
        e = e === null ? null : e.memoizedState;
      } else e = W.next;
      var t = uo === null ? U.memoizedState : uo.next;
      if (t !== null) ((uo = t), (W = e));
      else {
        if (e === null)
          throw U.alternate === null ? Error(i(467)) : Error(i(310));
        ((W = e),
          (e = {
            memoizedState: W.memoizedState,
            baseState: W.baseState,
            baseQueue: W.baseQueue,
            queue: W.queue,
            next: null,
          }),
          uo === null ? (U.memoizedState = uo = e) : (uo = uo.next = e));
      }
      return uo;
    }
    function Ao() {
      return { lastEffect: null, events: null, stores: null, memoCache: null };
    }
    function jo(e) {
      var t = go;
      return (
        (go += 1),
        _o === null && (_o = []),
        (e = wa(_o, e, t)),
        (t = U),
        (uo === null ? t.memoizedState : uo.next) === null &&
          ((t = t.alternate),
          (w.H = t === null || t.memoizedState === null ? Rs : zs)),
        e
      );
    }
    function Mo(e) {
      if (typeof e == `object` && e) {
        if (typeof e.then == `function`) return jo(e);
        if (e.$$typeof === S) return Qi(e);
      }
      throw Error(i(438, String(e)));
    }
    function No(e) {
      var t = null,
        n = U.updateQueue;
      if ((n !== null && (t = n.memoCache), t == null)) {
        var r = U.alternate;
        r !== null &&
          ((r = r.updateQueue),
          r !== null &&
            ((r = r.memoCache),
            r != null &&
              (t = {
                data: r.data.map(function (e) {
                  return e.slice();
                }),
                index: 0,
              })));
      }
      if (
        ((t ??= { data: [], index: 0 }),
        n === null && ((n = Ao()), (U.updateQueue = n)),
        (n.memoCache = t),
        (n = t.data[t.index]),
        n === void 0)
      )
        for (n = t.data[t.index] = Array(e), r = 0; r < e; r++) n[r] = oe;
      return (t.index++, n);
    }
    function Po(e, t) {
      return typeof t == `function` ? t(e) : t;
    }
    function Fo(e) {
      return Io(ko(), W, e);
    }
    function Io(e, t, n) {
      var r = e.queue;
      if (r === null) throw Error(i(311));
      r.lastRenderedReducer = n;
      var a = e.baseQueue,
        o = r.pending;
      if (o !== null) {
        if (a !== null) {
          var s = a.next;
          ((a.next = o.next), (o.next = s));
        }
        ((t.baseQueue = a = o), (r.pending = null));
      }
      if (((o = e.baseState), a === null)) e.memoizedState = o;
      else {
        t = a.next;
        var c = (s = null),
          l = null,
          u = t,
          d = !1;
        do {
          var f = u.lane & -536870913;
          if (f === u.lane ? (lo & f) === f : (Y & f) === f) {
            var p = u.revertLane;
            if (p === 0)
              (l !== null &&
                (l = l.next =
                  {
                    lane: 0,
                    revertLane: 0,
                    gesture: null,
                    action: u.action,
                    hasEagerState: u.hasEagerState,
                    eagerState: u.eagerState,
                    next: null,
                  }),
                f === la && (d = !0));
            else if ((lo & p) === p) {
              ((u = u.next), p === la && (d = !0));
              continue;
            } else
              ((f = {
                lane: 0,
                revertLane: u.revertLane,
                gesture: null,
                action: u.action,
                hasEagerState: u.hasEagerState,
                eagerState: u.eagerState,
                next: null,
              }),
                l === null ? ((c = l = f), (s = o)) : (l = l.next = f),
                (U.lanes |= p),
                (Gl |= p));
            ((f = u.action),
              mo && n(o, f),
              (o = u.hasEagerState ? u.eagerState : n(o, f)));
          } else
            ((p = {
              lane: f,
              revertLane: u.revertLane,
              gesture: u.gesture,
              action: u.action,
              hasEagerState: u.hasEagerState,
              eagerState: u.eagerState,
              next: null,
            }),
              l === null ? ((c = l = p), (s = o)) : (l = l.next = p),
              (U.lanes |= f),
              (Gl |= f));
          u = u.next;
        } while (u !== null && u !== t);
        if (
          (l === null ? (s = o) : (l.next = c),
          !br(o, e.memoizedState) && ((nc = !0), d && ((n = ua), n !== null)))
        )
          throw n;
        ((e.memoizedState = o),
          (e.baseState = s),
          (e.baseQueue = l),
          (r.lastRenderedState = o));
      }
      return (a === null && (r.lanes = 0), [e.memoizedState, r.dispatch]);
    }
    function Lo(e) {
      var t = ko(),
        n = t.queue;
      if (n === null) throw Error(i(311));
      n.lastRenderedReducer = e;
      var r = n.dispatch,
        a = n.pending,
        o = t.memoizedState;
      if (a !== null) {
        n.pending = null;
        var s = (a = a.next);
        do ((o = e(o, s.action)), (s = s.next));
        while (s !== a);
        (br(o, t.memoizedState) || (nc = !0),
          (t.memoizedState = o),
          t.baseQueue === null && (t.baseState = o),
          (n.lastRenderedState = o));
      }
      return [o, r];
    }
    function Ro(e, t, n) {
      var r = U,
        a = ko(),
        o = H;
      if (o) {
        if (n === void 0) throw Error(i(407));
        n = n();
      } else n = t();
      var s = !br((W || a).memoizedState, n);
      if (
        (s && ((a.memoizedState = n), (nc = !0)),
        (a = a.queue),
        ls(Vo.bind(null, r, a, e), [e]),
        a.getSnapshot !== t || s || (uo !== null && uo.memoizedState.tag & 1))
      ) {
        if (
          ((r.flags |= 2048),
          is(9, { destroy: void 0 }, Bo.bind(null, r, a, n, t), null),
          q === null)
        )
          throw Error(i(349));
        o || lo & 127 || zo(r, t, n);
      }
      return n;
    }
    function zo(e, t, n) {
      ((e.flags |= 16384),
        (e = { getSnapshot: t, value: n }),
        (t = U.updateQueue),
        t === null
          ? ((t = Ao()), (U.updateQueue = t), (t.stores = [e]))
          : ((n = t.stores), n === null ? (t.stores = [e]) : n.push(e)));
    }
    function Bo(e, t, n, r) {
      ((t.value = n), (t.getSnapshot = r), Ho(t) && Uo(e));
    }
    function Vo(e, t, n) {
      return n(function () {
        Ho(t) && Uo(e);
      });
    }
    function Ho(e) {
      var t = e.getSnapshot;
      e = e.value;
      try {
        var n = t();
        return !br(e, n);
      } catch {
        return !0;
      }
    }
    function Uo(e) {
      var t = ti(e, 2);
      t !== null && hu(t, e, 2);
    }
    function Wo(e) {
      var t = Oo();
      if (typeof e == `function`) {
        var n = e;
        if (((e = n()), mo)) {
          Ke(!0);
          try {
            n();
          } finally {
            Ke(!1);
          }
        }
      }
      return (
        (t.memoizedState = t.baseState = e),
        (t.queue = {
          pending: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: Po,
          lastRenderedState: e,
        }),
        t
      );
    }
    function Go(e, t, n, r) {
      return ((e.baseState = n), Io(e, W, typeof r == `function` ? r : Po));
    }
    function Ko(e, t, n, r, a) {
      if (Ps(e)) throw Error(i(485));
      if (((e = t.action), e !== null)) {
        var o = {
          payload: a,
          action: e,
          next: null,
          isTransition: !0,
          status: `pending`,
          value: null,
          reason: null,
          listeners: [],
          then: function (e) {
            o.listeners.push(e);
          },
        };
        (w.T === null ? (o.isTransition = !1) : n(!0),
          r(o),
          (n = t.pending),
          n === null
            ? ((o.next = t.pending = o), qo(t, o))
            : ((o.next = n.next), (t.pending = n.next = o)));
      }
    }
    function qo(e, t) {
      var n = t.action,
        r = t.payload,
        i = e.state;
      if (t.isTransition) {
        var a = w.T,
          o = {};
        w.T = o;
        try {
          var s = n(i, r),
            c = w.S;
          (c !== null && c(o, s), Jo(e, t, s));
        } catch (n) {
          Xo(e, t, n);
        } finally {
          (a !== null && o.types !== null && (a.types = o.types), (w.T = a));
        }
      } else
        try {
          ((a = n(i, r)), Jo(e, t, a));
        } catch (n) {
          Xo(e, t, n);
        }
    }
    function Jo(e, t, n) {
      typeof n == `object` && n && typeof n.then == `function`
        ? n.then(
            function (n) {
              Yo(e, t, n);
            },
            function (n) {
              return Xo(e, t, n);
            },
          )
        : Yo(e, t, n);
    }
    function Yo(e, t, n) {
      ((t.status = `fulfilled`),
        (t.value = n),
        Zo(t),
        (e.state = n),
        (t = e.pending),
        t !== null &&
          ((n = t.next),
          n === t
            ? (e.pending = null)
            : ((n = n.next), (t.next = n), qo(e, n))));
    }
    function Xo(e, t, n) {
      var r = e.pending;
      if (((e.pending = null), r !== null)) {
        r = r.next;
        do ((t.status = `rejected`), (t.reason = n), Zo(t), (t = t.next));
        while (t !== r);
      }
      e.action = null;
    }
    function Zo(e) {
      e = e.listeners;
      for (var t = 0; t < e.length; t++) (0, e[t])();
    }
    function Qo(e, t) {
      return t;
    }
    function $o(e, t) {
      if (H) {
        var n = q.formState;
        if (n !== null) {
          a: {
            var r = U;
            if (H) {
              if (V) {
                b: {
                  for (var i = V, a = Ni; i.nodeType !== 8;) {
                    if (!a) {
                      i = null;
                      break b;
                    }
                    if (((i = cf(i.nextSibling)), i === null)) {
                      i = null;
                      break b;
                    }
                  }
                  ((a = i.data), (i = a === `F!` || a === `F` ? i : null));
                }
                if (i) {
                  ((V = cf(i.nextSibling)), (r = i.data === `F!`));
                  break a;
                }
              }
              Fi(r);
            }
            r = !1;
          }
          r && (t = n[0]);
        }
      }
      return (
        (n = Oo()),
        (n.memoizedState = n.baseState = t),
        (r = {
          pending: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: Qo,
          lastRenderedState: t,
        }),
        (n.queue = r),
        (n = js.bind(null, U, r)),
        (r.dispatch = n),
        (r = Wo(!1)),
        (a = Ns.bind(null, U, !1, r.queue)),
        (r = Oo()),
        (i = { state: t, dispatch: null, action: e, pending: null }),
        (r.queue = i),
        (n = Ko.bind(null, U, i, a, n)),
        (i.dispatch = n),
        (r.memoizedState = e),
        [t, n, !1]
      );
    }
    function es(e) {
      return ts(ko(), W, e);
    }
    function ts(e, t, n) {
      if (
        ((t = Io(e, t, Qo)[0]),
        (e = Fo(Po)[0]),
        typeof t == `object` && t && typeof t.then == `function`)
      )
        try {
          var r = jo(t);
        } catch (e) {
          throw e === ya ? xa : e;
        }
      else r = t;
      t = ko();
      var i = t.queue,
        a = i.dispatch;
      return (
        n !== t.memoizedState &&
          ((U.flags |= 2048),
          is(9, { destroy: void 0 }, ns.bind(null, i, n), null)),
        [r, a, e]
      );
    }
    function ns(e, t) {
      e.action = t;
    }
    function rs(e) {
      var t = ko(),
        n = W;
      if (n !== null) return ts(t, n, e);
      (ko(), (t = t.memoizedState), (n = ko()));
      var r = n.queue.dispatch;
      return ((n.memoizedState = e), [t, r, !1]);
    }
    function is(e, t, n, r) {
      return (
        (e = { tag: e, create: n, deps: r, inst: t, next: null }),
        (t = U.updateQueue),
        t === null && ((t = Ao()), (U.updateQueue = t)),
        (n = t.lastEffect),
        n === null
          ? (t.lastEffect = e.next = e)
          : ((r = n.next), (n.next = e), (e.next = r), (t.lastEffect = e)),
        e
      );
    }
    function as() {
      return ko().memoizedState;
    }
    function os(e, t, n, r) {
      var i = Oo();
      ((U.flags |= e),
        (i.memoizedState = is(
          1 | t,
          { destroy: void 0 },
          n,
          r === void 0 ? null : r,
        )));
    }
    function ss(e, t, n, r) {
      var i = ko();
      r = r === void 0 ? null : r;
      var a = i.memoizedState.inst;
      W !== null && r !== null && bo(r, W.memoizedState.deps)
        ? (i.memoizedState = is(t, a, n, r))
        : ((U.flags |= e), (i.memoizedState = is(1 | t, a, n, r)));
    }
    function cs(e, t) {
      os(8390656, 8, e, t);
    }
    function ls(e, t) {
      ss(2048, 8, e, t);
    }
    function us(e) {
      U.flags |= 4;
      var t = U.updateQueue;
      if (t === null) ((t = Ao()), (U.updateQueue = t), (t.events = [e]));
      else {
        var n = t.events;
        n === null ? (t.events = [e]) : n.push(e);
      }
    }
    function ds(e) {
      var t = ko().memoizedState;
      return (
        us({ ref: t, nextImpl: e }),
        function () {
          if (K & 2) throw Error(i(440));
          return t.impl.apply(void 0, arguments);
        }
      );
    }
    function fs(e, t) {
      return ss(4, 2, e, t);
    }
    function ps(e, t) {
      return ss(4, 4, e, t);
    }
    function ms(e, t) {
      if (typeof t == `function`) {
        e = e();
        var n = t(e);
        return function () {
          typeof n == `function` ? n() : t(null);
        };
      }
      if (t != null)
        return (
          (e = e()),
          (t.current = e),
          function () {
            t.current = null;
          }
        );
    }
    function hs(e, t, n) {
      ((n = n == null ? null : n.concat([e])),
        ss(4, 4, ms.bind(null, t, e), n));
    }
    function gs() {}
    function _s(e, t) {
      var n = ko();
      t = t === void 0 ? null : t;
      var r = n.memoizedState;
      return t !== null && bo(t, r[1]) ? r[0] : ((n.memoizedState = [e, t]), e);
    }
    function vs(e, t) {
      var n = ko();
      t = t === void 0 ? null : t;
      var r = n.memoizedState;
      if (t !== null && bo(t, r[1])) return r[0];
      if (((r = e()), mo)) {
        Ke(!0);
        try {
          e();
        } finally {
          Ke(!1);
        }
      }
      return ((n.memoizedState = [r, t]), r);
    }
    function ys(e, t, n) {
      return n === void 0 || (lo & 1073741824 && !(Y & 261930))
        ? (e.memoizedState = t)
        : ((e.memoizedState = n), (e = mu()), (U.lanes |= e), (Gl |= e), n);
    }
    function bs(e, t, n, r) {
      return br(n, t)
        ? n
        : Ya.current === null
          ? !(lo & 42) || (lo & 1073741824 && !(Y & 261930))
            ? ((nc = !0), (e.memoizedState = n))
            : ((e = mu()), (U.lanes |= e), (Gl |= e), t)
          : ((e = ys(e, n, r)), br(e, t) || (nc = !0), e);
    }
    function xs(e, t, n, r, i) {
      var a = T.p;
      T.p = a !== 0 && 8 > a ? a : 8;
      var o = w.T,
        s = {};
      ((w.T = s), Ns(e, !1, t, n));
      try {
        var c = i(),
          l = w.S;
        (l !== null && l(s, c),
          typeof c == `object` && c && typeof c.then == `function`
            ? Ms(e, t, pa(c, r), pu(e))
            : Ms(e, t, r, pu(e)));
      } catch (n) {
        Ms(e, t, { then: function () {}, status: `rejected`, reason: n }, pu());
      } finally {
        ((T.p = a),
          o !== null && s.types !== null && (o.types = s.types),
          (w.T = o));
      }
    }
    function Ss() {}
    function Cs(e, t, n, r) {
      if (e.tag !== 5) throw Error(i(476));
      var a = ws(e).queue;
      xs(
        e,
        a,
        t,
        fe,
        n === null
          ? Ss
          : function () {
              return (Ts(e), n(r));
            },
      );
    }
    function ws(e) {
      var t = e.memoizedState;
      if (t !== null) return t;
      t = {
        memoizedState: fe,
        baseState: fe,
        baseQueue: null,
        queue: {
          pending: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: Po,
          lastRenderedState: fe,
        },
        next: null,
      };
      var n = {};
      return (
        (t.next = {
          memoizedState: n,
          baseState: n,
          baseQueue: null,
          queue: {
            pending: null,
            lanes: 0,
            dispatch: null,
            lastRenderedReducer: Po,
            lastRenderedState: n,
          },
          next: null,
        }),
        (e.memoizedState = t),
        (e = e.alternate),
        e !== null && (e.memoizedState = t),
        t
      );
    }
    function Ts(e) {
      var t = ws(e);
      (t.next === null && (t = e.alternate.memoizedState),
        Ms(e, t.next.queue, {}, pu()));
    }
    function Es() {
      return Qi(Qf);
    }
    function Ds() {
      return ko().memoizedState;
    }
    function Os() {
      return ko().memoizedState;
    }
    function ks(e) {
      for (var t = e.return; t !== null;) {
        switch (t.tag) {
          case 24:
          case 3:
            var n = pu();
            e = Ba(n);
            var r = Va(t, e, n);
            (r !== null && (hu(r, t, n), Ha(r, t, n)),
              (t = { cache: aa() }),
              (e.payload = t));
            return;
        }
        t = t.return;
      }
    }
    function As(e, t, n) {
      var r = pu();
      ((n = {
        lane: r,
        revertLane: 0,
        gesture: null,
        action: n,
        hasEagerState: !1,
        eagerState: null,
        next: null,
      }),
        Ps(e)
          ? Fs(t, n)
          : ((n = ei(e, t, n, r)), n !== null && (hu(n, e, r), Is(n, t, r))));
    }
    function js(e, t, n) {
      Ms(e, t, n, pu());
    }
    function Ms(e, t, n, r) {
      var i = {
        lane: r,
        revertLane: 0,
        gesture: null,
        action: n,
        hasEagerState: !1,
        eagerState: null,
        next: null,
      };
      if (Ps(e)) Fs(t, i);
      else {
        var a = e.alternate;
        if (
          e.lanes === 0 &&
          (a === null || a.lanes === 0) &&
          ((a = t.lastRenderedReducer), a !== null)
        )
          try {
            var o = t.lastRenderedState,
              s = a(o, n);
            if (((i.hasEagerState = !0), (i.eagerState = s), br(s, o)))
              return ($r(e, t, i, 0), q === null && Qr(), !1);
          } catch {}
        if (((n = ei(e, t, i, r)), n !== null))
          return (hu(n, e, r), Is(n, t, r), !0);
      }
      return !1;
    }
    function Ns(e, t, n, r) {
      if (
        ((r = {
          lane: 2,
          revertLane: dd(),
          gesture: null,
          action: r,
          hasEagerState: !1,
          eagerState: null,
          next: null,
        }),
        Ps(e))
      ) {
        if (t) throw Error(i(479));
      } else ((t = ei(e, n, r, 2)), t !== null && hu(t, e, 2));
    }
    function Ps(e) {
      var t = e.alternate;
      return e === U || (t !== null && t === U);
    }
    function Fs(e, t) {
      po = fo = !0;
      var n = e.pending;
      (n === null ? (t.next = t) : ((t.next = n.next), (n.next = t)),
        (e.pending = t));
    }
    function Is(e, t, n) {
      if (n & 4194048) {
        var r = t.lanes;
        ((r &= e.pendingLanes), (n |= r), (t.lanes = n), j(e, n));
      }
    }
    var Ls = {
      readContext: Qi,
      use: Mo,
      useCallback: yo,
      useContext: yo,
      useEffect: yo,
      useImperativeHandle: yo,
      useLayoutEffect: yo,
      useInsertionEffect: yo,
      useMemo: yo,
      useReducer: yo,
      useRef: yo,
      useState: yo,
      useDebugValue: yo,
      useDeferredValue: yo,
      useTransition: yo,
      useSyncExternalStore: yo,
      useId: yo,
      useHostTransitionStatus: yo,
      useFormState: yo,
      useActionState: yo,
      useOptimistic: yo,
      useMemoCache: yo,
      useCacheRefresh: yo,
    };
    Ls.useEffectEvent = yo;
    var Rs = {
        readContext: Qi,
        use: Mo,
        useCallback: function (e, t) {
          return ((Oo().memoizedState = [e, t === void 0 ? null : t]), e);
        },
        useContext: Qi,
        useEffect: cs,
        useImperativeHandle: function (e, t, n) {
          ((n = n == null ? null : n.concat([e])),
            os(4194308, 4, ms.bind(null, t, e), n));
        },
        useLayoutEffect: function (e, t) {
          return os(4194308, 4, e, t);
        },
        useInsertionEffect: function (e, t) {
          os(4, 2, e, t);
        },
        useMemo: function (e, t) {
          var n = Oo();
          t = t === void 0 ? null : t;
          var r = e();
          if (mo) {
            Ke(!0);
            try {
              e();
            } finally {
              Ke(!1);
            }
          }
          return ((n.memoizedState = [r, t]), r);
        },
        useReducer: function (e, t, n) {
          var r = Oo();
          if (n !== void 0) {
            var i = n(t);
            if (mo) {
              Ke(!0);
              try {
                n(t);
              } finally {
                Ke(!1);
              }
            }
          } else i = t;
          return (
            (r.memoizedState = r.baseState = i),
            (e = {
              pending: null,
              lanes: 0,
              dispatch: null,
              lastRenderedReducer: e,
              lastRenderedState: i,
            }),
            (r.queue = e),
            (e = e.dispatch = As.bind(null, U, e)),
            [r.memoizedState, e]
          );
        },
        useRef: function (e) {
          var t = Oo();
          return ((e = { current: e }), (t.memoizedState = e));
        },
        useState: function (e) {
          e = Wo(e);
          var t = e.queue,
            n = js.bind(null, U, t);
          return ((t.dispatch = n), [e.memoizedState, n]);
        },
        useDebugValue: gs,
        useDeferredValue: function (e, t) {
          return ys(Oo(), e, t);
        },
        useTransition: function () {
          var e = Wo(!1);
          return (
            (e = xs.bind(null, U, e.queue, !0, !1)),
            (Oo().memoizedState = e),
            [!1, e]
          );
        },
        useSyncExternalStore: function (e, t, n) {
          var r = U,
            a = Oo();
          if (H) {
            if (n === void 0) throw Error(i(407));
            n = n();
          } else {
            if (((n = t()), q === null)) throw Error(i(349));
            Y & 127 || zo(r, t, n);
          }
          a.memoizedState = n;
          var o = { value: n, getSnapshot: t };
          return (
            (a.queue = o),
            cs(Vo.bind(null, r, o, e), [e]),
            (r.flags |= 2048),
            is(9, { destroy: void 0 }, Bo.bind(null, r, o, n, t), null),
            n
          );
        },
        useId: function () {
          var e = Oo(),
            t = q.identifierPrefix;
          if (H) {
            var n = Ti,
              r = wi;
            ((n = (r & ~(1 << (32 - qe(r) - 1))).toString(32) + n),
              (t = `_` + t + `R_` + n),
              (n = ho++),
              0 < n && (t += `H` + n.toString(32)),
              (t += `_`));
          } else ((n = vo++), (t = `_` + t + `r_` + n.toString(32) + `_`));
          return (e.memoizedState = t);
        },
        useHostTransitionStatus: Es,
        useFormState: $o,
        useActionState: $o,
        useOptimistic: function (e) {
          var t = Oo();
          t.memoizedState = t.baseState = e;
          var n = {
            pending: null,
            lanes: 0,
            dispatch: null,
            lastRenderedReducer: null,
            lastRenderedState: null,
          };
          return (
            (t.queue = n),
            (t = Ns.bind(null, U, !0, n)),
            (n.dispatch = t),
            [e, t]
          );
        },
        useMemoCache: No,
        useCacheRefresh: function () {
          return (Oo().memoizedState = ks.bind(null, U));
        },
        useEffectEvent: function (e) {
          var t = Oo(),
            n = { impl: e };
          return (
            (t.memoizedState = n),
            function () {
              if (K & 2) throw Error(i(440));
              return n.impl.apply(void 0, arguments);
            }
          );
        },
      },
      zs = {
        readContext: Qi,
        use: Mo,
        useCallback: _s,
        useContext: Qi,
        useEffect: ls,
        useImperativeHandle: hs,
        useInsertionEffect: fs,
        useLayoutEffect: ps,
        useMemo: vs,
        useReducer: Fo,
        useRef: as,
        useState: function () {
          return Fo(Po);
        },
        useDebugValue: gs,
        useDeferredValue: function (e, t) {
          return bs(ko(), W.memoizedState, e, t);
        },
        useTransition: function () {
          var e = Fo(Po)[0],
            t = ko().memoizedState;
          return [typeof e == `boolean` ? e : jo(e), t];
        },
        useSyncExternalStore: Ro,
        useId: Ds,
        useHostTransitionStatus: Es,
        useFormState: es,
        useActionState: es,
        useOptimistic: function (e, t) {
          return Go(ko(), W, e, t);
        },
        useMemoCache: No,
        useCacheRefresh: Os,
      };
    zs.useEffectEvent = ds;
    var Bs = {
      readContext: Qi,
      use: Mo,
      useCallback: _s,
      useContext: Qi,
      useEffect: ls,
      useImperativeHandle: hs,
      useInsertionEffect: fs,
      useLayoutEffect: ps,
      useMemo: vs,
      useReducer: Lo,
      useRef: as,
      useState: function () {
        return Lo(Po);
      },
      useDebugValue: gs,
      useDeferredValue: function (e, t) {
        var n = ko();
        return W === null ? ys(n, e, t) : bs(n, W.memoizedState, e, t);
      },
      useTransition: function () {
        var e = Lo(Po)[0],
          t = ko().memoizedState;
        return [typeof e == `boolean` ? e : jo(e), t];
      },
      useSyncExternalStore: Ro,
      useId: Ds,
      useHostTransitionStatus: Es,
      useFormState: rs,
      useActionState: rs,
      useOptimistic: function (e, t) {
        var n = ko();
        return W === null
          ? ((n.baseState = e), [e, n.queue.dispatch])
          : Go(n, W, e, t);
      },
      useMemoCache: No,
      useCacheRefresh: Os,
    };
    Bs.useEffectEvent = ds;
    function Vs(e, t, n, r) {
      ((t = e.memoizedState),
        (n = n(r, t)),
        (n = n == null ? t : h({}, t, n)),
        (e.memoizedState = n),
        e.lanes === 0 && (e.updateQueue.baseState = n));
    }
    var Hs = {
      enqueueSetState: function (e, t, n) {
        e = e._reactInternals;
        var r = pu(),
          i = Ba(r);
        ((i.payload = t),
          n != null && (i.callback = n),
          (t = Va(e, i, r)),
          t !== null && (hu(t, e, r), Ha(t, e, r)));
      },
      enqueueReplaceState: function (e, t, n) {
        e = e._reactInternals;
        var r = pu(),
          i = Ba(r);
        ((i.tag = 1),
          (i.payload = t),
          n != null && (i.callback = n),
          (t = Va(e, i, r)),
          t !== null && (hu(t, e, r), Ha(t, e, r)));
      },
      enqueueForceUpdate: function (e, t) {
        e = e._reactInternals;
        var n = pu(),
          r = Ba(n);
        ((r.tag = 2),
          t != null && (r.callback = t),
          (t = Va(e, r, n)),
          t !== null && (hu(t, e, n), Ha(t, e, n)));
      },
    };
    function Us(e, t, n, r, i, a, o) {
      return (
        (e = e.stateNode),
        typeof e.shouldComponentUpdate == `function`
          ? e.shouldComponentUpdate(r, a, o)
          : t.prototype && t.prototype.isPureReactComponent
            ? !xr(n, r) || !xr(i, a)
            : !0
      );
    }
    function Ws(e, t, n, r) {
      ((e = t.state),
        typeof t.componentWillReceiveProps == `function` &&
          t.componentWillReceiveProps(n, r),
        typeof t.UNSAFE_componentWillReceiveProps == `function` &&
          t.UNSAFE_componentWillReceiveProps(n, r),
        t.state !== e && Hs.enqueueReplaceState(t, t.state, null));
    }
    function Gs(e, t) {
      var n = t;
      if (`ref` in t) for (var r in ((n = {}), t)) r !== `ref` && (n[r] = t[r]);
      if ((e = e.defaultProps))
        for (var i in (n === t && (n = h({}, n)), e))
          n[i] === void 0 && (n[i] = e[i]);
      return n;
    }
    function Ks(e) {
      Jr(e);
    }
    function qs(e) {
      console.error(e);
    }
    function Js(e) {
      Jr(e);
    }
    function Ys(e, t) {
      try {
        var n = e.onUncaughtError;
        n(t.value, { componentStack: t.stack });
      } catch (e) {
        setTimeout(function () {
          throw e;
        });
      }
    }
    function Xs(e, t, n) {
      try {
        var r = e.onCaughtError;
        r(n.value, {
          componentStack: n.stack,
          errorBoundary: t.tag === 1 ? t.stateNode : null,
        });
      } catch (e) {
        setTimeout(function () {
          throw e;
        });
      }
    }
    function Zs(e, t, n) {
      return (
        (n = Ba(n)),
        (n.tag = 3),
        (n.payload = { element: null }),
        (n.callback = function () {
          Ys(e, t);
        }),
        n
      );
    }
    function Qs(e) {
      return ((e = Ba(e)), (e.tag = 3), e);
    }
    function $s(e, t, n, r) {
      var i = n.type.getDerivedStateFromError;
      if (typeof i == `function`) {
        var a = r.value;
        ((e.payload = function () {
          return i(a);
        }),
          (e.callback = function () {
            Xs(t, n, r);
          }));
      }
      var o = n.stateNode;
      o !== null &&
        typeof o.componentDidCatch == `function` &&
        (e.callback = function () {
          (Xs(t, n, r),
            typeof i != `function` &&
              (ru === null ? (ru = new Set([this])) : ru.add(this)));
          var e = r.stack;
          this.componentDidCatch(r.value, {
            componentStack: e === null ? `` : e,
          });
        });
    }
    function ec(e, t, n, r, a) {
      if (
        ((n.flags |= 32768),
        typeof r == `object` && r && typeof r.then == `function`)
      ) {
        if (
          ((t = n.alternate),
          t !== null && Yi(t, n, a, !0),
          (n = eo.current),
          n !== null)
        ) {
          switch (n.tag) {
            case 31:
            case 13:
              return (
                to === null
                  ? Du()
                  : n.alternate === null && Wl === 0 && (Wl = 3),
                (n.flags &= -257),
                (n.flags |= 65536),
                (n.lanes = a),
                r === Sa
                  ? (n.flags |= 16384)
                  : ((t = n.updateQueue),
                    t === null ? (n.updateQueue = new Set([r])) : t.add(r),
                    Gu(e, r, a)),
                !1
              );
            case 22:
              return (
                (n.flags |= 65536),
                r === Sa
                  ? (n.flags |= 16384)
                  : ((t = n.updateQueue),
                    t === null
                      ? ((t = {
                          transitions: null,
                          markerInstances: null,
                          retryQueue: new Set([r]),
                        }),
                        (n.updateQueue = t))
                      : ((n = t.retryQueue),
                        n === null ? (t.retryQueue = new Set([r])) : n.add(r)),
                    Gu(e, r, a)),
                !1
              );
          }
          throw Error(i(435, n.tag));
        }
        return (Gu(e, r, a), Du(), !1);
      }
      if (H)
        return (
          (t = eo.current),
          t === null
            ? (r !== Pi && ((t = Error(i(423), { cause: r })), Vi(gi(t, n))),
              (e = e.current.alternate),
              (e.flags |= 65536),
              (a &= -a),
              (e.lanes |= a),
              (r = gi(r, n)),
              (a = Zs(e.stateNode, r, a)),
              Ua(e, a),
              Wl !== 4 && (Wl = 2))
            : (!(t.flags & 65536) && (t.flags |= 256),
              (t.flags |= 65536),
              (t.lanes = a),
              r !== Pi && ((e = Error(i(422), { cause: r })), Vi(gi(e, n)))),
          !1
        );
      var o = Error(i(520), { cause: r });
      if (
        ((o = gi(o, n)),
        Xl === null ? (Xl = [o]) : Xl.push(o),
        Wl !== 4 && (Wl = 2),
        t === null)
      )
        return !0;
      ((r = gi(r, n)), (n = t));
      do {
        switch (n.tag) {
          case 3:
            return (
              (n.flags |= 65536),
              (e = a & -a),
              (n.lanes |= e),
              (e = Zs(n.stateNode, r, e)),
              Ua(n, e),
              !1
            );
          case 1:
            if (
              ((t = n.type),
              (o = n.stateNode),
              !(n.flags & 128) &&
                (typeof t.getDerivedStateFromError == `function` ||
                  (o !== null &&
                    typeof o.componentDidCatch == `function` &&
                    (ru === null || !ru.has(o)))))
            )
              return (
                (n.flags |= 65536),
                (a &= -a),
                (n.lanes |= a),
                (a = Qs(a)),
                $s(a, e, n, r),
                Ua(n, a),
                !1
              );
        }
        n = n.return;
      } while (n !== null);
      return !1;
    }
    var tc = Error(i(461)),
      nc = !1;
    function rc(e, t, n, r) {
      t.child = e === null ? Ia(t, null, n, r) : Fa(t, e.child, n, r);
    }
    function ic(e, t, n, r, i) {
      n = n.render;
      var a = t.ref;
      if (`ref` in r) {
        var o = {};
        for (var s in r) s !== `ref` && (o[s] = r[s]);
      } else o = r;
      return (
        Zi(t),
        (r = xo(e, t, n, o, a, i)),
        (s = To()),
        e !== null && !nc
          ? (Eo(e, t, i), Oc(e, t, i))
          : (H && s && Oi(t), (t.flags |= 1), rc(e, t, r, i), t.child)
      );
    }
    function ac(e, t, n, r, i) {
      if (e === null) {
        var a = n.type;
        return typeof a == `function` &&
          !si(a) &&
          a.defaultProps === void 0 &&
          n.compare === null
          ? ((t.tag = 15), (t.type = a), oc(e, t, a, r, i))
          : ((e = ui(n.type, null, r, t, t.mode, i)),
            (e.ref = t.ref),
            (e.return = t),
            (t.child = e));
      }
      if (((a = e.child), !kc(e, i))) {
        var o = a.memoizedProps;
        if (
          ((n = n.compare),
          (n = n === null ? xr : n),
          n(o, r) && e.ref === t.ref)
        )
          return Oc(e, t, i);
      }
      return (
        (t.flags |= 1),
        (e = ci(a, r)),
        (e.ref = t.ref),
        (e.return = t),
        (t.child = e)
      );
    }
    function oc(e, t, n, r, i) {
      if (e !== null) {
        var a = e.memoizedProps;
        if (xr(a, r) && e.ref === t.ref)
          if (((nc = !1), (t.pendingProps = r = a), kc(e, i)))
            e.flags & 131072 && (nc = !0);
          else return ((t.lanes = e.lanes), Oc(e, t, i));
      }
      return mc(e, t, n, r, i);
    }
    function sc(e, t, n, r) {
      var i = r.children,
        a = e === null ? null : e.memoizedState;
      if (
        (e === null &&
          t.stateNode === null &&
          (t.stateNode = {
            _visibility: 1,
            _pendingMarkers: null,
            _retryCache: null,
            _transitions: null,
          }),
        r.mode === `hidden`)
      ) {
        if (t.flags & 128) {
          if (((a = a === null ? n : a.baseLanes | n), e !== null)) {
            for (r = t.child = e.child, i = 0; r !== null;)
              ((i = i | r.lanes | r.childLanes), (r = r.sibling));
            r = i & ~a;
          } else ((r = 0), (t.child = null));
          return lc(e, t, a, n, r);
        }
        if (n & 536870912)
          ((t.memoizedState = { baseLanes: 0, cachePool: null }),
            e !== null && _a(t, a === null ? null : a.cachePool),
            a === null ? Qa() : Za(t, a),
            io(t));
        else
          return (
            (r = t.lanes = 536870912),
            lc(e, t, a === null ? n : a.baseLanes | n, n, r)
          );
      } else
        a === null
          ? (e !== null && _a(t, null), Qa(), ao(t))
          : (_a(t, a.cachePool), Za(t, a), ao(t), (t.memoizedState = null));
      return (rc(e, t, i, n), t.child);
    }
    function cc(e, t) {
      return (
        (e !== null && e.tag === 22) ||
          t.stateNode !== null ||
          (t.stateNode = {
            _visibility: 1,
            _pendingMarkers: null,
            _retryCache: null,
            _transitions: null,
          }),
        t.sibling
      );
    }
    function lc(e, t, n, r, i) {
      var a = ga();
      return (
        (a = a === null ? null : { parent: ia._currentValue, pool: a }),
        (t.memoizedState = { baseLanes: n, cachePool: a }),
        e !== null && _a(t, null),
        Qa(),
        io(t),
        e !== null && Yi(e, t, r, !0),
        (t.childLanes = i),
        null
      );
    }
    function uc(e, t) {
      return (
        (t = Cc({ mode: t.mode, children: t.children }, e.mode)),
        (t.ref = e.ref),
        (e.child = t),
        (t.return = e),
        t
      );
    }
    function dc(e, t, n) {
      return (
        Fa(t, e.child, null, n),
        (e = uc(t, t.pendingProps)),
        (e.flags |= 2),
        oo(t),
        (t.memoizedState = null),
        e
      );
    }
    function fc(e, t, n) {
      var r = t.pendingProps,
        a = !!(t.flags & 128);
      if (((t.flags &= -129), e === null)) {
        if (H) {
          if (r.mode === `hidden`)
            return ((e = uc(t, r)), (t.lanes = 536870912), cc(null, e));
          if (
            (ro(t),
            (e = V)
              ? ((e = rf(e, Ni)),
                (e = e !== null && e.data === `&` ? e : null),
                e !== null &&
                  ((t.memoizedState = {
                    dehydrated: e,
                    treeContext: Ci === null ? null : { id: wi, overflow: Ti },
                    retryLane: 536870912,
                    hydrationErrors: null,
                  }),
                  (n = pi(e)),
                  (n.return = t),
                  (t.child = n),
                  (ji = t),
                  (V = null)))
              : (e = null),
            e === null)
          )
            throw Fi(t);
          return ((t.lanes = 536870912), null);
        }
        return uc(t, r);
      }
      var o = e.memoizedState;
      if (o !== null) {
        var s = o.dehydrated;
        if ((ro(t), a))
          if (t.flags & 256) ((t.flags &= -257), (t = dc(e, t, n)));
          else if (t.memoizedState !== null)
            ((t.child = e.child), (t.flags |= 128), (t = null));
          else throw Error(i(558));
        else if (
          (nc || Yi(e, t, n, !1), (a = (n & e.childLanes) !== 0), nc || a)
        ) {
          if (
            ((r = q),
            r !== null && ((s = M(r, n)), s !== 0 && s !== o.retryLane))
          )
            throw ((o.retryLane = s), ti(e, s), hu(r, e, s), tc);
          (Du(), (t = dc(e, t, n)));
        } else
          ((e = o.treeContext),
            (V = cf(s.nextSibling)),
            (ji = t),
            (H = !0),
            (Mi = null),
            (Ni = !1),
            e !== null && Ai(t, e),
            (t = uc(t, r)),
            (t.flags |= 4096));
        return t;
      }
      return (
        (e = ci(e.child, { mode: r.mode, children: r.children })),
        (e.ref = t.ref),
        (t.child = e),
        (e.return = t),
        e
      );
    }
    function pc(e, t) {
      var n = t.ref;
      if (n === null) e !== null && e.ref !== null && (t.flags |= 4194816);
      else {
        if (typeof n != `function` && typeof n != `object`) throw Error(i(284));
        (e === null || e.ref !== n) && (t.flags |= 4194816);
      }
    }
    function mc(e, t, n, r, i) {
      return (
        Zi(t),
        (n = xo(e, t, n, r, void 0, i)),
        (r = To()),
        e !== null && !nc
          ? (Eo(e, t, i), Oc(e, t, i))
          : (H && r && Oi(t), (t.flags |= 1), rc(e, t, n, i), t.child)
      );
    }
    function hc(e, t, n, r, i, a) {
      return (
        Zi(t),
        (t.updateQueue = null),
        (n = Co(t, r, n, i)),
        So(e),
        (r = To()),
        e !== null && !nc
          ? (Eo(e, t, a), Oc(e, t, a))
          : (H && r && Oi(t), (t.flags |= 1), rc(e, t, n, a), t.child)
      );
    }
    function gc(e, t, n, r, i) {
      if ((Zi(t), t.stateNode === null)) {
        var a = ii,
          o = n.contextType;
        (typeof o == `object` && o && (a = Qi(o)),
          (a = new n(r, a)),
          (t.memoizedState =
            a.state !== null && a.state !== void 0 ? a.state : null),
          (a.updater = Hs),
          (t.stateNode = a),
          (a._reactInternals = t),
          (a = t.stateNode),
          (a.props = r),
          (a.state = t.memoizedState),
          (a.refs = {}),
          Ra(t),
          (o = n.contextType),
          (a.context = typeof o == `object` && o ? Qi(o) : ii),
          (a.state = t.memoizedState),
          (o = n.getDerivedStateFromProps),
          typeof o == `function` &&
            (Vs(t, n, o, r), (a.state = t.memoizedState)),
          typeof n.getDerivedStateFromProps == `function` ||
            typeof a.getSnapshotBeforeUpdate == `function` ||
            (typeof a.UNSAFE_componentWillMount != `function` &&
              typeof a.componentWillMount != `function`) ||
            ((o = a.state),
            typeof a.componentWillMount == `function` && a.componentWillMount(),
            typeof a.UNSAFE_componentWillMount == `function` &&
              a.UNSAFE_componentWillMount(),
            o !== a.state && Hs.enqueueReplaceState(a, a.state, null),
            Ka(t, r, a, i),
            Ga(),
            (a.state = t.memoizedState)),
          typeof a.componentDidMount == `function` && (t.flags |= 4194308),
          (r = !0));
      } else if (e === null) {
        a = t.stateNode;
        var s = t.memoizedProps,
          c = Gs(n, s);
        a.props = c;
        var l = a.context,
          u = n.contextType;
        ((o = ii), typeof u == `object` && u && (o = Qi(u)));
        var d = n.getDerivedStateFromProps;
        ((u =
          typeof d == `function` ||
          typeof a.getSnapshotBeforeUpdate == `function`),
          (s = t.pendingProps !== s),
          u ||
            (typeof a.UNSAFE_componentWillReceiveProps != `function` &&
              typeof a.componentWillReceiveProps != `function`) ||
            ((s || l !== o) && Ws(t, a, r, o)),
          (La = !1));
        var f = t.memoizedState;
        ((a.state = f),
          Ka(t, r, a, i),
          Ga(),
          (l = t.memoizedState),
          s || f !== l || La
            ? (typeof d == `function` &&
                (Vs(t, n, d, r), (l = t.memoizedState)),
              (c = La || Us(t, n, c, r, f, l, o))
                ? (u ||
                    (typeof a.UNSAFE_componentWillMount != `function` &&
                      typeof a.componentWillMount != `function`) ||
                    (typeof a.componentWillMount == `function` &&
                      a.componentWillMount(),
                    typeof a.UNSAFE_componentWillMount == `function` &&
                      a.UNSAFE_componentWillMount()),
                  typeof a.componentDidMount == `function` &&
                    (t.flags |= 4194308))
                : (typeof a.componentDidMount == `function` &&
                    (t.flags |= 4194308),
                  (t.memoizedProps = r),
                  (t.memoizedState = l)),
              (a.props = r),
              (a.state = l),
              (a.context = o),
              (r = c))
            : (typeof a.componentDidMount == `function` && (t.flags |= 4194308),
              (r = !1)));
      } else {
        ((a = t.stateNode),
          za(e, t),
          (o = t.memoizedProps),
          (u = Gs(n, o)),
          (a.props = u),
          (d = t.pendingProps),
          (f = a.context),
          (l = n.contextType),
          (c = ii),
          typeof l == `object` && l && (c = Qi(l)),
          (s = n.getDerivedStateFromProps),
          (l =
            typeof s == `function` ||
            typeof a.getSnapshotBeforeUpdate == `function`) ||
            (typeof a.UNSAFE_componentWillReceiveProps != `function` &&
              typeof a.componentWillReceiveProps != `function`) ||
            ((o !== d || f !== c) && Ws(t, a, r, c)),
          (La = !1),
          (f = t.memoizedState),
          (a.state = f),
          Ka(t, r, a, i),
          Ga());
        var p = t.memoizedState;
        o !== d ||
        f !== p ||
        La ||
        (e !== null && e.dependencies !== null && Xi(e.dependencies))
          ? (typeof s == `function` && (Vs(t, n, s, r), (p = t.memoizedState)),
            (u =
              La ||
              Us(t, n, u, r, f, p, c) ||
              (e !== null && e.dependencies !== null && Xi(e.dependencies)))
              ? (l ||
                  (typeof a.UNSAFE_componentWillUpdate != `function` &&
                    typeof a.componentWillUpdate != `function`) ||
                  (typeof a.componentWillUpdate == `function` &&
                    a.componentWillUpdate(r, p, c),
                  typeof a.UNSAFE_componentWillUpdate == `function` &&
                    a.UNSAFE_componentWillUpdate(r, p, c)),
                typeof a.componentDidUpdate == `function` && (t.flags |= 4),
                typeof a.getSnapshotBeforeUpdate == `function` &&
                  (t.flags |= 1024))
              : (typeof a.componentDidUpdate != `function` ||
                  (o === e.memoizedProps && f === e.memoizedState) ||
                  (t.flags |= 4),
                typeof a.getSnapshotBeforeUpdate != `function` ||
                  (o === e.memoizedProps && f === e.memoizedState) ||
                  (t.flags |= 1024),
                (t.memoizedProps = r),
                (t.memoizedState = p)),
            (a.props = r),
            (a.state = p),
            (a.context = c),
            (r = u))
          : (typeof a.componentDidUpdate != `function` ||
              (o === e.memoizedProps && f === e.memoizedState) ||
              (t.flags |= 4),
            typeof a.getSnapshotBeforeUpdate != `function` ||
              (o === e.memoizedProps && f === e.memoizedState) ||
              (t.flags |= 1024),
            (r = !1));
      }
      return (
        (a = r),
        pc(e, t),
        (r = !!(t.flags & 128)),
        a || r
          ? ((a = t.stateNode),
            (n =
              r && typeof n.getDerivedStateFromError != `function`
                ? null
                : a.render()),
            (t.flags |= 1),
            e !== null && r
              ? ((t.child = Fa(t, e.child, null, i)),
                (t.child = Fa(t, null, n, i)))
              : rc(e, t, n, i),
            (t.memoizedState = a.state),
            (e = t.child))
          : (e = Oc(e, t, i)),
        e
      );
    }
    function _c(e, t, n, r) {
      return (zi(), (t.flags |= 256), rc(e, t, n, r), t.child);
    }
    var vc = {
      dehydrated: null,
      treeContext: null,
      retryLane: 0,
      hydrationErrors: null,
    };
    function yc(e) {
      return { baseLanes: e, cachePool: va() };
    }
    function bc(e, t, n) {
      return ((e = e === null ? 0 : e.childLanes & ~n), t && (e |= Jl), e);
    }
    function xc(e, t, n) {
      var r = t.pendingProps,
        a = !1,
        o = !!(t.flags & 128),
        s;
      if (
        ((s = o) ||
          (s =
            e !== null && e.memoizedState === null ? !1 : !!(so.current & 2)),
        s && ((a = !0), (t.flags &= -129)),
        (s = !!(t.flags & 32)),
        (t.flags &= -33),
        e === null)
      ) {
        if (H) {
          if (
            (a ? no(t) : ao(t),
            (e = V)
              ? ((e = rf(e, Ni)),
                (e = e !== null && e.data !== `&` ? e : null),
                e !== null &&
                  ((t.memoizedState = {
                    dehydrated: e,
                    treeContext: Ci === null ? null : { id: wi, overflow: Ti },
                    retryLane: 536870912,
                    hydrationErrors: null,
                  }),
                  (n = pi(e)),
                  (n.return = t),
                  (t.child = n),
                  (ji = t),
                  (V = null)))
              : (e = null),
            e === null)
          )
            throw Fi(t);
          return (of(e) ? (t.lanes = 32) : (t.lanes = 536870912), null);
        }
        var c = r.children;
        return (
          (r = r.fallback),
          a
            ? (ao(t),
              (a = t.mode),
              (c = Cc({ mode: `hidden`, children: c }, a)),
              (r = di(r, a, n, null)),
              (c.return = t),
              (r.return = t),
              (c.sibling = r),
              (t.child = c),
              (r = t.child),
              (r.memoizedState = yc(n)),
              (r.childLanes = bc(e, s, n)),
              (t.memoizedState = vc),
              cc(null, r))
            : (no(t), Sc(t, c))
        );
      }
      var l = e.memoizedState;
      if (l !== null && ((c = l.dehydrated), c !== null)) {
        if (o)
          t.flags & 256
            ? (no(t), (t.flags &= -257), (t = wc(e, t, n)))
            : t.memoizedState === null
              ? (ao(t),
                (c = r.fallback),
                (a = t.mode),
                (r = Cc({ mode: `visible`, children: r.children }, a)),
                (c = di(c, a, n, null)),
                (c.flags |= 2),
                (r.return = t),
                (c.return = t),
                (r.sibling = c),
                (t.child = r),
                Fa(t, e.child, null, n),
                (r = t.child),
                (r.memoizedState = yc(n)),
                (r.childLanes = bc(e, s, n)),
                (t.memoizedState = vc),
                (t = cc(null, r)))
              : (ao(t), (t.child = e.child), (t.flags |= 128), (t = null));
        else if ((no(t), of(c))) {
          if (((s = c.nextSibling && c.nextSibling.dataset), s)) var u = s.dgst;
          ((s = u),
            (r = Error(i(419))),
            (r.stack = ``),
            (r.digest = s),
            Vi({ value: r, source: null, stack: null }),
            (t = wc(e, t, n)));
        } else if (
          (nc || Yi(e, t, n, !1), (s = (n & e.childLanes) !== 0), nc || s)
        ) {
          if (
            ((s = q),
            s !== null && ((r = M(s, n)), r !== 0 && r !== l.retryLane))
          )
            throw ((l.retryLane = r), ti(e, r), hu(s, e, r), tc);
          (af(c) || Du(), (t = wc(e, t, n)));
        } else
          af(c)
            ? ((t.flags |= 192), (t.child = e.child), (t = null))
            : ((e = l.treeContext),
              (V = cf(c.nextSibling)),
              (ji = t),
              (H = !0),
              (Mi = null),
              (Ni = !1),
              e !== null && Ai(t, e),
              (t = Sc(t, r.children)),
              (t.flags |= 4096));
        return t;
      }
      return a
        ? (ao(t),
          (c = r.fallback),
          (a = t.mode),
          (l = e.child),
          (u = l.sibling),
          (r = ci(l, { mode: `hidden`, children: r.children })),
          (r.subtreeFlags = l.subtreeFlags & 65011712),
          u === null
            ? ((c = di(c, a, n, null)), (c.flags |= 2))
            : (c = ci(u, c)),
          (c.return = t),
          (r.return = t),
          (r.sibling = c),
          (t.child = r),
          cc(null, r),
          (r = t.child),
          (c = e.child.memoizedState),
          c === null
            ? (c = yc(n))
            : ((a = c.cachePool),
              a === null
                ? (a = va())
                : ((l = ia._currentValue),
                  (a = a.parent === l ? a : { parent: l, pool: l })),
              (c = { baseLanes: c.baseLanes | n, cachePool: a })),
          (r.memoizedState = c),
          (r.childLanes = bc(e, s, n)),
          (t.memoizedState = vc),
          cc(e.child, r))
        : (no(t),
          (n = e.child),
          (e = n.sibling),
          (n = ci(n, { mode: `visible`, children: r.children })),
          (n.return = t),
          (n.sibling = null),
          e !== null &&
            ((s = t.deletions),
            s === null ? ((t.deletions = [e]), (t.flags |= 16)) : s.push(e)),
          (t.child = n),
          (t.memoizedState = null),
          n);
    }
    function Sc(e, t) {
      return (
        (t = Cc({ mode: `visible`, children: t }, e.mode)),
        (t.return = e),
        (e.child = t)
      );
    }
    function Cc(e, t) {
      return ((e = oi(22, e, null, t)), (e.lanes = 0), e);
    }
    function wc(e, t, n) {
      return (
        Fa(t, e.child, null, n),
        (e = Sc(t, t.pendingProps.children)),
        (e.flags |= 2),
        (t.memoizedState = null),
        e
      );
    }
    function Tc(e, t, n) {
      e.lanes |= t;
      var r = e.alternate;
      (r !== null && (r.lanes |= t), qi(e.return, t, n));
    }
    function Ec(e, t, n, r, i, a) {
      var o = e.memoizedState;
      o === null
        ? (e.memoizedState = {
            isBackwards: t,
            rendering: null,
            renderingStartTime: 0,
            last: r,
            tail: n,
            tailMode: i,
            treeForkCount: a,
          })
        : ((o.isBackwards = t),
          (o.rendering = null),
          (o.renderingStartTime = 0),
          (o.last = r),
          (o.tail = n),
          (o.tailMode = i),
          (o.treeForkCount = a));
    }
    function Dc(e, t, n) {
      var r = t.pendingProps,
        i = r.revealOrder,
        a = r.tail;
      r = r.children;
      var o = so.current,
        s = !!(o & 2);
      if (
        (s ? ((o = (o & 1) | 2), (t.flags |= 128)) : (o &= 1),
        E(so, o),
        rc(e, t, r, n),
        (r = H ? bi : 0),
        !s && e !== null && e.flags & 128)
      )
        a: for (e = t.child; e !== null;) {
          if (e.tag === 13) e.memoizedState !== null && Tc(e, n, t);
          else if (e.tag === 19) Tc(e, n, t);
          else if (e.child !== null) {
            ((e.child.return = e), (e = e.child));
            continue;
          }
          if (e === t) break a;
          for (; e.sibling === null;) {
            if (e.return === null || e.return === t) break a;
            e = e.return;
          }
          ((e.sibling.return = e.return), (e = e.sibling));
        }
      switch (i) {
        case `forwards`:
          for (n = t.child, i = null; n !== null;)
            ((e = n.alternate),
              e !== null && co(e) === null && (i = n),
              (n = n.sibling));
          ((n = i),
            n === null
              ? ((i = t.child), (t.child = null))
              : ((i = n.sibling), (n.sibling = null)),
            Ec(t, !1, i, n, a, r));
          break;
        case `backwards`:
        case `unstable_legacy-backwards`:
          for (n = null, i = t.child, t.child = null; i !== null;) {
            if (((e = i.alternate), e !== null && co(e) === null)) {
              t.child = i;
              break;
            }
            ((e = i.sibling), (i.sibling = n), (n = i), (i = e));
          }
          Ec(t, !0, n, null, a, r);
          break;
        case `together`:
          Ec(t, !1, null, null, void 0, r);
          break;
        default:
          t.memoizedState = null;
      }
      return t.child;
    }
    function Oc(e, t, n) {
      if (
        (e !== null && (t.dependencies = e.dependencies),
        (Gl |= t.lanes),
        (n & t.childLanes) === 0)
      )
        if (e !== null) {
          if ((Yi(e, t, n, !1), (n & t.childLanes) === 0)) return null;
        } else return null;
      if (e !== null && t.child !== e.child) throw Error(i(153));
      if (t.child !== null) {
        for (
          e = t.child, n = ci(e, e.pendingProps), t.child = n, n.return = t;
          e.sibling !== null;
        )
          ((e = e.sibling),
            (n = n.sibling = ci(e, e.pendingProps)),
            (n.return = t));
        n.sibling = null;
      }
      return t.child;
    }
    function kc(e, t) {
      return (
        (e.lanes & t) !== 0 || ((e = e.dependencies), !!(e !== null && Xi(e)))
      );
    }
    function Ac(e, t, n) {
      switch (t.tag) {
        case 3:
          (xe(t, t.stateNode.containerInfo),
            Gi(t, ia, e.memoizedState.cache),
            zi());
          break;
        case 27:
        case 5:
          Ce(t);
          break;
        case 4:
          xe(t, t.stateNode.containerInfo);
          break;
        case 10:
          Gi(t, t.type, t.memoizedProps.value);
          break;
        case 31:
          if (t.memoizedState !== null) return ((t.flags |= 128), ro(t), null);
          break;
        case 13:
          var r = t.memoizedState;
          if (r !== null)
            return r.dehydrated === null
              ? (n & t.child.childLanes) === 0
                ? (no(t), (e = Oc(e, t, n)), e === null ? null : e.sibling)
                : xc(e, t, n)
              : (no(t), (t.flags |= 128), null);
          no(t);
          break;
        case 19:
          var i = !!(e.flags & 128);
          if (
            ((r = (n & t.childLanes) !== 0),
            (r ||= (Yi(e, t, n, !1), (n & t.childLanes) !== 0)),
            i)
          ) {
            if (r) return Dc(e, t, n);
            t.flags |= 128;
          }
          if (
            ((i = t.memoizedState),
            i !== null &&
              ((i.rendering = null), (i.tail = null), (i.lastEffect = null)),
            E(so, so.current),
            r)
          )
            break;
          return null;
        case 22:
          return ((t.lanes = 0), sc(e, t, n, t.pendingProps));
        case 24:
          Gi(t, ia, e.memoizedState.cache);
      }
      return Oc(e, t, n);
    }
    function jc(e, t, n) {
      if (e !== null)
        if (e.memoizedProps !== t.pendingProps) nc = !0;
        else {
          if (!kc(e, n) && !(t.flags & 128)) return ((nc = !1), Ac(e, t, n));
          nc = !!(e.flags & 131072);
        }
      else ((nc = !1), H && t.flags & 1048576 && Di(t, bi, t.index));
      switch (((t.lanes = 0), t.tag)) {
        case 16:
          a: {
            var r = t.pendingProps;
            if (((e = Ta(t.elementType)), (t.type = e), typeof e == `function`))
              si(e)
                ? ((r = Gs(e, r)), (t.tag = 1), (t = gc(null, t, e, r, n)))
                : ((t.tag = 0), (t = mc(null, t, e, r, n)));
            else {
              if (e != null) {
                var a = e.$$typeof;
                if (a === C) {
                  ((t.tag = 11), (t = ic(null, t, e, r, n)));
                  break a;
                }
                if (a === re) {
                  ((t.tag = 14), (t = ac(null, t, e, r, n)));
                  break a;
                }
              }
              throw ((t = ue(e) || e), Error(i(306, t, ``)));
            }
          }
          return t;
        case 0:
          return mc(e, t, t.type, t.pendingProps, n);
        case 1:
          return ((r = t.type), (a = Gs(r, t.pendingProps)), gc(e, t, r, a, n));
        case 3:
          a: {
            if ((xe(t, t.stateNode.containerInfo), e === null))
              throw Error(i(387));
            r = t.pendingProps;
            var o = t.memoizedState;
            ((a = o.element), za(e, t), Ka(t, r, null, n));
            var s = t.memoizedState;
            if (
              ((r = s.cache),
              Gi(t, ia, r),
              r !== o.cache && Ji(t, [ia], n, !0),
              Ga(),
              (r = s.element),
              o.isDehydrated)
            )
              if (
                ((o = { element: r, isDehydrated: !1, cache: s.cache }),
                (t.updateQueue.baseState = o),
                (t.memoizedState = o),
                t.flags & 256)
              ) {
                t = _c(e, t, r, n);
                break a;
              } else if (r !== a) {
                ((a = gi(Error(i(424)), t)), Vi(a), (t = _c(e, t, r, n)));
                break a;
              } else {
                switch (((e = t.stateNode.containerInfo), e.nodeType)) {
                  case 9:
                    e = e.body;
                    break;
                  default:
                    e = e.nodeName === `HTML` ? e.ownerDocument.body : e;
                }
                for (
                  V = cf(e.firstChild),
                    ji = t,
                    H = !0,
                    Mi = null,
                    Ni = !0,
                    n = Ia(t, null, r, n),
                    t.child = n;
                  n;
                )
                  ((n.flags = (n.flags & -3) | 4096), (n = n.sibling));
              }
            else {
              if ((zi(), r === a)) {
                t = Oc(e, t, n);
                break a;
              }
              rc(e, t, r, n);
            }
            t = t.child;
          }
          return t;
        case 26:
          return (
            pc(e, t),
            e === null
              ? (n = kf(t.type, null, t.pendingProps, null))
                ? (t.memoizedState = n)
                : H ||
                  ((n = t.type),
                  (e = t.pendingProps),
                  (r = Bd(ye.current).createElement(n)),
                  (r[F] = t),
                  (r[ut] = e),
                  Pd(r, n, e),
                  St(r),
                  (t.stateNode = r))
              : (t.memoizedState = kf(
                  t.type,
                  e.memoizedProps,
                  t.pendingProps,
                  e.memoizedState,
                )),
            null
          );
        case 27:
          return (
            Ce(t),
            e === null &&
              H &&
              ((r = t.stateNode = ff(t.type, t.pendingProps, ye.current)),
              (ji = t),
              (Ni = !0),
              (a = V),
              Zd(t.type) ? ((lf = a), (V = cf(r.firstChild))) : (V = a)),
            rc(e, t, t.pendingProps.children, n),
            pc(e, t),
            e === null && (t.flags |= 4194304),
            t.child
          );
        case 5:
          return (
            e === null &&
              H &&
              ((a = r = V) &&
                ((r = tf(r, t.type, t.pendingProps, Ni)),
                r === null
                  ? (a = !1)
                  : ((t.stateNode = r),
                    (ji = t),
                    (V = cf(r.firstChild)),
                    (Ni = !1),
                    (a = !0))),
              a || Fi(t)),
            Ce(t),
            (a = t.type),
            (o = t.pendingProps),
            (s = e === null ? null : e.memoizedProps),
            (r = o.children),
            Ud(a, o) ? (r = null) : s !== null && Ud(a, s) && (t.flags |= 32),
            t.memoizedState !== null &&
              ((a = xo(e, t, wo, null, null, n)), (Qf._currentValue = a)),
            pc(e, t),
            rc(e, t, r, n),
            t.child
          );
        case 6:
          return (
            e === null &&
              H &&
              ((e = n = V) &&
                ((n = nf(n, t.pendingProps, Ni)),
                n === null
                  ? (e = !1)
                  : ((t.stateNode = n), (ji = t), (V = null), (e = !0))),
              e || Fi(t)),
            null
          );
        case 13:
          return xc(e, t, n);
        case 4:
          return (
            xe(t, t.stateNode.containerInfo),
            (r = t.pendingProps),
            e === null ? (t.child = Fa(t, null, r, n)) : rc(e, t, r, n),
            t.child
          );
        case 11:
          return ic(e, t, t.type, t.pendingProps, n);
        case 7:
          return (rc(e, t, t.pendingProps, n), t.child);
        case 8:
          return (rc(e, t, t.pendingProps.children, n), t.child);
        case 12:
          return (rc(e, t, t.pendingProps.children, n), t.child);
        case 10:
          return (
            (r = t.pendingProps),
            Gi(t, t.type, r.value),
            rc(e, t, r.children, n),
            t.child
          );
        case 9:
          return (
            (a = t.type._context),
            (r = t.pendingProps.children),
            Zi(t),
            (a = Qi(a)),
            (r = r(a)),
            (t.flags |= 1),
            rc(e, t, r, n),
            t.child
          );
        case 14:
          return ac(e, t, t.type, t.pendingProps, n);
        case 15:
          return oc(e, t, t.type, t.pendingProps, n);
        case 19:
          return Dc(e, t, n);
        case 31:
          return fc(e, t, n);
        case 22:
          return sc(e, t, n, t.pendingProps);
        case 24:
          return (
            Zi(t),
            (r = Qi(ia)),
            e === null
              ? ((a = ga()),
                a === null &&
                  ((a = q),
                  (o = aa()),
                  (a.pooledCache = o),
                  o.refCount++,
                  o !== null && (a.pooledCacheLanes |= n),
                  (a = o)),
                (t.memoizedState = { parent: r, cache: a }),
                Ra(t),
                Gi(t, ia, a))
              : ((e.lanes & n) !== 0 && (za(e, t), Ka(t, null, null, n), Ga()),
                (a = e.memoizedState),
                (o = t.memoizedState),
                a.parent === r
                  ? ((r = o.cache),
                    Gi(t, ia, r),
                    r !== a.cache && Ji(t, [ia], n, !0))
                  : ((a = { parent: r, cache: r }),
                    (t.memoizedState = a),
                    t.lanes === 0 &&
                      (t.memoizedState = t.updateQueue.baseState = a),
                    Gi(t, ia, r))),
            rc(e, t, t.pendingProps.children, n),
            t.child
          );
        case 29:
          throw t.pendingProps;
      }
      throw Error(i(156, t.tag));
    }
    function Mc(e) {
      e.flags |= 4;
    }
    function Nc(e, t, n, r, i) {
      if (((t = !!(e.mode & 32)) && (t = !1), t)) {
        if (((e.flags |= 16777216), (i & 335544128) === i))
          if (e.stateNode.complete) e.flags |= 8192;
          else if (wu()) e.flags |= 8192;
          else throw ((Ea = Sa), ba);
      } else e.flags &= -16777217;
    }
    function Pc(e, t) {
      if (t.type !== `stylesheet` || t.state.loading & 4) e.flags &= -16777217;
      else if (((e.flags |= 16777216), !Wf(t)))
        if (wu()) e.flags |= 8192;
        else throw ((Ea = Sa), ba);
    }
    function Fc(e, t) {
      (t !== null && (e.flags |= 4),
        e.flags & 16384 &&
          ((t = e.tag === 22 ? 536870912 : rt()), (e.lanes |= t), (Yl |= t)));
    }
    function Ic(e, t) {
      if (!H)
        switch (e.tailMode) {
          case `hidden`:
            t = e.tail;
            for (var n = null; t !== null;)
              (t.alternate !== null && (n = t), (t = t.sibling));
            n === null ? (e.tail = null) : (n.sibling = null);
            break;
          case `collapsed`:
            n = e.tail;
            for (var r = null; n !== null;)
              (n.alternate !== null && (r = n), (n = n.sibling));
            r === null
              ? t || e.tail === null
                ? (e.tail = null)
                : (e.tail.sibling = null)
              : (r.sibling = null);
        }
    }
    function G(e) {
      var t = e.alternate !== null && e.alternate.child === e.child,
        n = 0,
        r = 0;
      if (t)
        for (var i = e.child; i !== null;)
          ((n |= i.lanes | i.childLanes),
            (r |= i.subtreeFlags & 65011712),
            (r |= i.flags & 65011712),
            (i.return = e),
            (i = i.sibling));
      else
        for (i = e.child; i !== null;)
          ((n |= i.lanes | i.childLanes),
            (r |= i.subtreeFlags),
            (r |= i.flags),
            (i.return = e),
            (i = i.sibling));
      return ((e.subtreeFlags |= r), (e.childLanes = n), t);
    }
    function Lc(e, t, n) {
      var r = t.pendingProps;
      switch ((ki(t), t.tag)) {
        case 16:
        case 15:
        case 0:
        case 11:
        case 7:
        case 8:
        case 12:
        case 9:
        case 14:
          return (G(t), null);
        case 1:
          return (G(t), null);
        case 3:
          return (
            (n = t.stateNode),
            (r = null),
            e !== null && (r = e.memoizedState.cache),
            t.memoizedState.cache !== r && (t.flags |= 2048),
            Ki(ia),
            Se(),
            n.pendingContext &&
              ((n.context = n.pendingContext), (n.pendingContext = null)),
            (e === null || e.child === null) &&
              (Ri(t)
                ? Mc(t)
                : e === null ||
                  (e.memoizedState.isDehydrated && !(t.flags & 256)) ||
                  ((t.flags |= 1024), Bi())),
            G(t),
            null
          );
        case 26:
          var a = t.type,
            o = t.memoizedState;
          return (
            e === null
              ? (Mc(t),
                o === null ? (G(t), Nc(t, a, null, r, n)) : (G(t), Pc(t, o)))
              : o
                ? o === e.memoizedState
                  ? (G(t), (t.flags &= -16777217))
                  : (Mc(t), G(t), Pc(t, o))
                : ((e = e.memoizedProps),
                  e !== r && Mc(t),
                  G(t),
                  Nc(t, a, e, r, n)),
            null
          );
        case 27:
          if (
            (we(t),
            (n = ye.current),
            (a = t.type),
            e !== null && t.stateNode != null)
          )
            e.memoizedProps !== r && Mc(t);
          else {
            if (!r) {
              if (t.stateNode === null) throw Error(i(166));
              return (G(t), null);
            }
            ((e = _e.current),
              Ri(t) ? Ii(t, e) : ((e = ff(a, r, n)), (t.stateNode = e), Mc(t)));
          }
          return (G(t), null);
        case 5:
          if ((we(t), (a = t.type), e !== null && t.stateNode != null))
            e.memoizedProps !== r && Mc(t);
          else {
            if (!r) {
              if (t.stateNode === null) throw Error(i(166));
              return (G(t), null);
            }
            if (((o = _e.current), Ri(t))) Ii(t, o);
            else {
              var s = Bd(ye.current);
              switch (o) {
                case 1:
                  o = s.createElementNS(`http://www.w3.org/2000/svg`, a);
                  break;
                case 2:
                  o = s.createElementNS(
                    `http://www.w3.org/1998/Math/MathML`,
                    a,
                  );
                  break;
                default:
                  switch (a) {
                    case `svg`:
                      o = s.createElementNS(`http://www.w3.org/2000/svg`, a);
                      break;
                    case `math`:
                      o = s.createElementNS(
                        `http://www.w3.org/1998/Math/MathML`,
                        a,
                      );
                      break;
                    case `script`:
                      ((o = s.createElement(`div`)),
                        (o.innerHTML = `<script><\/script>`),
                        (o = o.removeChild(o.firstChild)));
                      break;
                    case `select`:
                      ((o =
                        typeof r.is == `string`
                          ? s.createElement(`select`, { is: r.is })
                          : s.createElement(`select`)),
                        r.multiple
                          ? (o.multiple = !0)
                          : r.size && (o.size = r.size));
                      break;
                    default:
                      o =
                        typeof r.is == `string`
                          ? s.createElement(a, { is: r.is })
                          : s.createElement(a);
                  }
              }
              ((o[F] = t), (o[ut] = r));
              a: for (s = t.child; s !== null;) {
                if (s.tag === 5 || s.tag === 6) o.appendChild(s.stateNode);
                else if (s.tag !== 4 && s.tag !== 27 && s.child !== null) {
                  ((s.child.return = s), (s = s.child));
                  continue;
                }
                if (s === t) break a;
                for (; s.sibling === null;) {
                  if (s.return === null || s.return === t) break a;
                  s = s.return;
                }
                ((s.sibling.return = s.return), (s = s.sibling));
              }
              t.stateNode = o;
              a: switch ((Pd(o, a, r), a)) {
                case `button`:
                case `input`:
                case `select`:
                case `textarea`:
                  r = !!r.autoFocus;
                  break a;
                case `img`:
                  r = !0;
                  break a;
                default:
                  r = !1;
              }
              r && Mc(t);
            }
          }
          return (
            G(t),
            Nc(
              t,
              t.type,
              e === null ? null : e.memoizedProps,
              t.pendingProps,
              n,
            ),
            null
          );
        case 6:
          if (e && t.stateNode != null) e.memoizedProps !== r && Mc(t);
          else {
            if (typeof r != `string` && t.stateNode === null)
              throw Error(i(166));
            if (((e = ye.current), Ri(t))) {
              if (
                ((e = t.stateNode),
                (n = t.memoizedProps),
                (r = null),
                (a = ji),
                a !== null)
              )
                switch (a.tag) {
                  case 27:
                  case 5:
                    r = a.memoizedProps;
                }
              ((e[F] = t),
                (e = !!(
                  e.nodeValue === n ||
                  (r !== null && !0 === r.suppressHydrationWarning) ||
                  Md(e.nodeValue, n)
                )),
                e || Fi(t, !0));
            } else
              ((e = Bd(e).createTextNode(r)), (e[F] = t), (t.stateNode = e));
          }
          return (G(t), null);
        case 31:
          if (((n = t.memoizedState), e === null || e.memoizedState !== null)) {
            if (((r = Ri(t)), n !== null)) {
              if (e === null) {
                if (!r) throw Error(i(318));
                if (
                  ((e = t.memoizedState),
                  (e = e === null ? null : e.dehydrated),
                  !e)
                )
                  throw Error(i(557));
                e[F] = t;
              } else
                (zi(),
                  !(t.flags & 128) && (t.memoizedState = null),
                  (t.flags |= 4));
              (G(t), (e = !1));
            } else
              ((n = Bi()),
                e !== null &&
                  e.memoizedState !== null &&
                  (e.memoizedState.hydrationErrors = n),
                (e = !0));
            if (!e) return t.flags & 256 ? (oo(t), t) : (oo(t), null);
            if (t.flags & 128) throw Error(i(558));
          }
          return (G(t), null);
        case 13:
          if (
            ((r = t.memoizedState),
            e === null ||
              (e.memoizedState !== null && e.memoizedState.dehydrated !== null))
          ) {
            if (((a = Ri(t)), r !== null && r.dehydrated !== null)) {
              if (e === null) {
                if (!a) throw Error(i(318));
                if (
                  ((a = t.memoizedState),
                  (a = a === null ? null : a.dehydrated),
                  !a)
                )
                  throw Error(i(317));
                a[F] = t;
              } else
                (zi(),
                  !(t.flags & 128) && (t.memoizedState = null),
                  (t.flags |= 4));
              (G(t), (a = !1));
            } else
              ((a = Bi()),
                e !== null &&
                  e.memoizedState !== null &&
                  (e.memoizedState.hydrationErrors = a),
                (a = !0));
            if (!a) return t.flags & 256 ? (oo(t), t) : (oo(t), null);
          }
          return (
            oo(t),
            t.flags & 128
              ? ((t.lanes = n), t)
              : ((n = r !== null),
                (e = e !== null && e.memoizedState !== null),
                n &&
                  ((r = t.child),
                  (a = null),
                  r.alternate !== null &&
                    r.alternate.memoizedState !== null &&
                    r.alternate.memoizedState.cachePool !== null &&
                    (a = r.alternate.memoizedState.cachePool.pool),
                  (o = null),
                  r.memoizedState !== null &&
                    r.memoizedState.cachePool !== null &&
                    (o = r.memoizedState.cachePool.pool),
                  o !== a && (r.flags |= 2048)),
                n !== e && n && (t.child.flags |= 8192),
                Fc(t, t.updateQueue),
                G(t),
                null)
          );
        case 4:
          return (
            Se(),
            e === null && Sd(t.stateNode.containerInfo),
            G(t),
            null
          );
        case 10:
          return (Ki(t.type), G(t), null);
        case 19:
          if ((ge(so), (r = t.memoizedState), r === null)) return (G(t), null);
          if (((a = !!(t.flags & 128)), (o = r.rendering), o === null))
            if (a) Ic(r, !1);
            else {
              if (Wl !== 0 || (e !== null && e.flags & 128))
                for (e = t.child; e !== null;) {
                  if (((o = co(e)), o !== null)) {
                    for (
                      t.flags |= 128,
                        Ic(r, !1),
                        e = o.updateQueue,
                        t.updateQueue = e,
                        Fc(t, e),
                        t.subtreeFlags = 0,
                        e = n,
                        n = t.child;
                      n !== null;
                    )
                      (li(n, e), (n = n.sibling));
                    return (
                      E(so, (so.current & 1) | 2),
                      H && Ei(t, r.treeForkCount),
                      t.child
                    );
                  }
                  e = e.sibling;
                }
              r.tail !== null &&
                Le() > tu &&
                ((t.flags |= 128), (a = !0), Ic(r, !1), (t.lanes = 4194304));
            }
          else {
            if (!a)
              if (((e = co(o)), e !== null)) {
                if (
                  ((t.flags |= 128),
                  (a = !0),
                  (e = e.updateQueue),
                  (t.updateQueue = e),
                  Fc(t, e),
                  Ic(r, !0),
                  r.tail === null &&
                    r.tailMode === `hidden` &&
                    !o.alternate &&
                    !H)
                )
                  return (G(t), null);
              } else
                2 * Le() - r.renderingStartTime > tu &&
                  n !== 536870912 &&
                  ((t.flags |= 128), (a = !0), Ic(r, !1), (t.lanes = 4194304));
            r.isBackwards
              ? ((o.sibling = t.child), (t.child = o))
              : ((e = r.last),
                e === null ? (t.child = o) : (e.sibling = o),
                (r.last = o));
          }
          return r.tail === null
            ? (G(t), null)
            : ((e = r.tail),
              (r.rendering = e),
              (r.tail = e.sibling),
              (r.renderingStartTime = Le()),
              (e.sibling = null),
              (n = so.current),
              E(so, a ? (n & 1) | 2 : n & 1),
              H && Ei(t, r.treeForkCount),
              e);
        case 22:
        case 23:
          return (
            oo(t),
            $a(),
            (r = t.memoizedState !== null),
            e === null
              ? r && (t.flags |= 8192)
              : (e.memoizedState !== null) !== r && (t.flags |= 8192),
            r
              ? n & 536870912 &&
                !(t.flags & 128) &&
                (G(t), t.subtreeFlags & 6 && (t.flags |= 8192))
              : G(t),
            (n = t.updateQueue),
            n !== null && Fc(t, n.retryQueue),
            (n = null),
            e !== null &&
              e.memoizedState !== null &&
              e.memoizedState.cachePool !== null &&
              (n = e.memoizedState.cachePool.pool),
            (r = null),
            t.memoizedState !== null &&
              t.memoizedState.cachePool !== null &&
              (r = t.memoizedState.cachePool.pool),
            r !== n && (t.flags |= 2048),
            e !== null && ge(ha),
            null
          );
        case 24:
          return (
            (n = null),
            e !== null && (n = e.memoizedState.cache),
            t.memoizedState.cache !== n && (t.flags |= 2048),
            Ki(ia),
            G(t),
            null
          );
        case 25:
          return null;
        case 30:
          return null;
      }
      throw Error(i(156, t.tag));
    }
    function Rc(e, t) {
      switch ((ki(t), t.tag)) {
        case 1:
          return (
            (e = t.flags),
            e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
          );
        case 3:
          return (
            Ki(ia),
            Se(),
            (e = t.flags),
            e & 65536 && !(e & 128) ? ((t.flags = (e & -65537) | 128), t) : null
          );
        case 26:
        case 27:
        case 5:
          return (we(t), null);
        case 31:
          if (t.memoizedState !== null) {
            if ((oo(t), t.alternate === null)) throw Error(i(340));
            zi();
          }
          return (
            (e = t.flags),
            e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
          );
        case 13:
          if (
            (oo(t), (e = t.memoizedState), e !== null && e.dehydrated !== null)
          ) {
            if (t.alternate === null) throw Error(i(340));
            zi();
          }
          return (
            (e = t.flags),
            e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
          );
        case 19:
          return (ge(so), null);
        case 4:
          return (Se(), null);
        case 10:
          return (Ki(t.type), null);
        case 22:
        case 23:
          return (
            oo(t),
            $a(),
            e !== null && ge(ha),
            (e = t.flags),
            e & 65536 ? ((t.flags = (e & -65537) | 128), t) : null
          );
        case 24:
          return (Ki(ia), null);
        case 25:
          return null;
        default:
          return null;
      }
    }
    function zc(e, t) {
      switch ((ki(t), t.tag)) {
        case 3:
          (Ki(ia), Se());
          break;
        case 26:
        case 27:
        case 5:
          we(t);
          break;
        case 4:
          Se();
          break;
        case 31:
          t.memoizedState !== null && oo(t);
          break;
        case 13:
          oo(t);
          break;
        case 19:
          ge(so);
          break;
        case 10:
          Ki(t.type);
          break;
        case 22:
        case 23:
          (oo(t), $a(), e !== null && ge(ha));
          break;
        case 24:
          Ki(ia);
      }
    }
    function Bc(e, t) {
      try {
        var n = t.updateQueue,
          r = n === null ? null : n.lastEffect;
        if (r !== null) {
          var i = r.next;
          n = i;
          do {
            if ((n.tag & e) === e) {
              r = void 0;
              var a = n.create,
                o = n.inst;
              ((r = a()), (o.destroy = r));
            }
            n = n.next;
          } while (n !== i);
        }
      } catch (e) {
        Z(t, t.return, e);
      }
    }
    function Vc(e, t, n) {
      try {
        var r = t.updateQueue,
          i = r === null ? null : r.lastEffect;
        if (i !== null) {
          var a = i.next;
          r = a;
          do {
            if ((r.tag & e) === e) {
              var o = r.inst,
                s = o.destroy;
              if (s !== void 0) {
                ((o.destroy = void 0), (i = t));
                var c = n,
                  l = s;
                try {
                  l();
                } catch (e) {
                  Z(i, c, e);
                }
              }
            }
            r = r.next;
          } while (r !== a);
        }
      } catch (e) {
        Z(t, t.return, e);
      }
    }
    function Hc(e) {
      var t = e.updateQueue;
      if (t !== null) {
        var n = e.stateNode;
        try {
          Ja(t, n);
        } catch (t) {
          Z(e, e.return, t);
        }
      }
    }
    function Uc(e, t, n) {
      ((n.props = Gs(e.type, e.memoizedProps)), (n.state = e.memoizedState));
      try {
        n.componentWillUnmount();
      } catch (n) {
        Z(e, t, n);
      }
    }
    function Wc(e, t) {
      try {
        var n = e.ref;
        if (n !== null) {
          switch (e.tag) {
            case 26:
            case 27:
            case 5:
              var r = e.stateNode;
              break;
            case 30:
              r = e.stateNode;
              break;
            default:
              r = e.stateNode;
          }
          typeof n == `function` ? (e.refCleanup = n(r)) : (n.current = r);
        }
      } catch (n) {
        Z(e, t, n);
      }
    }
    function Gc(e, t) {
      var n = e.ref,
        r = e.refCleanup;
      if (n !== null)
        if (typeof r == `function`)
          try {
            r();
          } catch (n) {
            Z(e, t, n);
          } finally {
            ((e.refCleanup = null),
              (e = e.alternate),
              e != null && (e.refCleanup = null));
          }
        else if (typeof n == `function`)
          try {
            n(null);
          } catch (n) {
            Z(e, t, n);
          }
        else n.current = null;
    }
    function Kc(e) {
      var t = e.type,
        n = e.memoizedProps,
        r = e.stateNode;
      try {
        a: switch (t) {
          case `button`:
          case `input`:
          case `select`:
          case `textarea`:
            n.autoFocus && r.focus();
            break a;
          case `img`:
            n.src ? (r.src = n.src) : n.srcSet && (r.srcset = n.srcSet);
        }
      } catch (t) {
        Z(e, e.return, t);
      }
    }
    function qc(e, t, n) {
      try {
        var r = e.stateNode;
        (Fd(r, e.type, n, t), (r[ut] = t));
      } catch (t) {
        Z(e, e.return, t);
      }
    }
    function Jc(e) {
      return (
        e.tag === 5 ||
        e.tag === 3 ||
        e.tag === 26 ||
        (e.tag === 27 && Zd(e.type)) ||
        e.tag === 4
      );
    }
    function Yc(e) {
      a: for (;;) {
        for (; e.sibling === null;) {
          if (e.return === null || Jc(e.return)) return null;
          e = e.return;
        }
        for (
          e.sibling.return = e.return, e = e.sibling;
          e.tag !== 5 && e.tag !== 6 && e.tag !== 18;
        ) {
          if (
            (e.tag === 27 && Zd(e.type)) ||
            e.flags & 2 ||
            e.child === null ||
            e.tag === 4
          )
            continue a;
          ((e.child.return = e), (e = e.child));
        }
        if (!(e.flags & 2)) return e.stateNode;
      }
    }
    function Xc(e, t, n) {
      var r = e.tag;
      if (r === 5 || r === 6)
        ((e = e.stateNode),
          t
            ? (n.nodeType === 9
                ? n.body
                : n.nodeName === `HTML`
                  ? n.ownerDocument.body
                  : n
              ).insertBefore(e, t)
            : ((t =
                n.nodeType === 9
                  ? n.body
                  : n.nodeName === `HTML`
                    ? n.ownerDocument.body
                    : n),
              t.appendChild(e),
              (n = n._reactRootContainer),
              n != null || t.onclick !== null || (t.onclick = Qt)));
      else if (
        r !== 4 &&
        (r === 27 && Zd(e.type) && ((n = e.stateNode), (t = null)),
        (e = e.child),
        e !== null)
      )
        for (Xc(e, t, n), e = e.sibling; e !== null;)
          (Xc(e, t, n), (e = e.sibling));
    }
    function Zc(e, t, n) {
      var r = e.tag;
      if (r === 5 || r === 6)
        ((e = e.stateNode), t ? n.insertBefore(e, t) : n.appendChild(e));
      else if (
        r !== 4 &&
        (r === 27 && Zd(e.type) && (n = e.stateNode), (e = e.child), e !== null)
      )
        for (Zc(e, t, n), e = e.sibling; e !== null;)
          (Zc(e, t, n), (e = e.sibling));
    }
    function Qc(e) {
      var t = e.stateNode,
        n = e.memoizedProps;
      try {
        for (var r = e.type, i = t.attributes; i.length;)
          t.removeAttributeNode(i[0]);
        (Pd(t, r, n), (t[F] = e), (t[ut] = n));
      } catch (t) {
        Z(e, e.return, t);
      }
    }
    var $c = !1,
      el = !1,
      tl = !1,
      nl = typeof WeakSet == `function` ? WeakSet : Set,
      rl = null;
    function il(e, t) {
      if (((e = e.containerInfo), (Rd = sp), (e = Tr(e)), Er(e))) {
        if (`selectionStart` in e)
          var n = { start: e.selectionStart, end: e.selectionEnd };
        else
          a: {
            n = ((n = e.ownerDocument) && n.defaultView) || window;
            var r = n.getSelection && n.getSelection();
            if (r && r.rangeCount !== 0) {
              n = r.anchorNode;
              var a = r.anchorOffset,
                o = r.focusNode;
              r = r.focusOffset;
              try {
                (n.nodeType, o.nodeType);
              } catch {
                n = null;
                break a;
              }
              var s = 0,
                c = -1,
                l = -1,
                u = 0,
                d = 0,
                f = e,
                p = null;
              b: for (;;) {
                for (
                  var m;
                  f !== n || (a !== 0 && f.nodeType !== 3) || (c = s + a),
                    f !== o || (r !== 0 && f.nodeType !== 3) || (l = s + r),
                    f.nodeType === 3 && (s += f.nodeValue.length),
                    (m = f.firstChild) !== null;
                )
                  ((p = f), (f = m));
                for (;;) {
                  if (f === e) break b;
                  if (
                    (p === n && ++u === a && (c = s),
                    p === o && ++d === r && (l = s),
                    (m = f.nextSibling) !== null)
                  )
                    break;
                  ((f = p), (p = f.parentNode));
                }
                f = m;
              }
              n = c === -1 || l === -1 ? null : { start: c, end: l };
            } else n = null;
          }
        n ||= { start: 0, end: 0 };
      } else n = null;
      for (
        zd = { focusedElem: e, selectionRange: n }, sp = !1, rl = t;
        rl !== null;
      )
        if (((t = rl), (e = t.child), t.subtreeFlags & 1028 && e !== null))
          ((e.return = t), (rl = e));
        else
          for (; rl !== null;) {
            switch (((t = rl), (o = t.alternate), (e = t.flags), t.tag)) {
              case 0:
                if (
                  e & 4 &&
                  ((e = t.updateQueue),
                  (e = e === null ? null : e.events),
                  e !== null)
                )
                  for (n = 0; n < e.length; n++)
                    ((a = e[n]), (a.ref.impl = a.nextImpl));
                break;
              case 11:
              case 15:
                break;
              case 1:
                if (e & 1024 && o !== null) {
                  ((e = void 0),
                    (n = t),
                    (a = o.memoizedProps),
                    (o = o.memoizedState),
                    (r = n.stateNode));
                  try {
                    var h = Gs(n.type, a);
                    ((e = r.getSnapshotBeforeUpdate(h, o)),
                      (r.__reactInternalSnapshotBeforeUpdate = e));
                  } catch (e) {
                    Z(n, n.return, e);
                  }
                }
                break;
              case 3:
                if (e & 1024) {
                  if (
                    ((e = t.stateNode.containerInfo), (n = e.nodeType), n === 9)
                  )
                    ef(e);
                  else if (n === 1)
                    switch (e.nodeName) {
                      case `HEAD`:
                      case `HTML`:
                      case `BODY`:
                        ef(e);
                        break;
                      default:
                        e.textContent = ``;
                    }
                }
                break;
              case 5:
              case 26:
              case 27:
              case 6:
              case 4:
              case 17:
                break;
              default:
                if (e & 1024) throw Error(i(163));
            }
            if (((e = t.sibling), e !== null)) {
              ((e.return = t.return), (rl = e));
              break;
            }
            rl = t.return;
          }
    }
    function al(e, t, n) {
      var r = n.flags;
      switch (n.tag) {
        case 0:
        case 11:
        case 15:
          (bl(e, n), r & 4 && Bc(5, n));
          break;
        case 1:
          if ((bl(e, n), r & 4))
            if (((e = n.stateNode), t === null))
              try {
                e.componentDidMount();
              } catch (e) {
                Z(n, n.return, e);
              }
            else {
              var i = Gs(n.type, t.memoizedProps);
              t = t.memoizedState;
              try {
                e.componentDidUpdate(
                  i,
                  t,
                  e.__reactInternalSnapshotBeforeUpdate,
                );
              } catch (e) {
                Z(n, n.return, e);
              }
            }
          (r & 64 && Hc(n), r & 512 && Wc(n, n.return));
          break;
        case 3:
          if ((bl(e, n), r & 64 && ((e = n.updateQueue), e !== null))) {
            if (((t = null), n.child !== null))
              switch (n.child.tag) {
                case 27:
                case 5:
                  t = n.child.stateNode;
                  break;
                case 1:
                  t = n.child.stateNode;
              }
            try {
              Ja(e, t);
            } catch (e) {
              Z(n, n.return, e);
            }
          }
          break;
        case 27:
          t === null && r & 4 && Qc(n);
        case 26:
        case 5:
          (bl(e, n), t === null && r & 4 && Kc(n), r & 512 && Wc(n, n.return));
          break;
        case 12:
          bl(e, n);
          break;
        case 31:
          (bl(e, n), r & 4 && dl(e, n));
          break;
        case 13:
          (bl(e, n),
            r & 4 && fl(e, n),
            r & 64 &&
              ((e = n.memoizedState),
              e !== null &&
                ((e = e.dehydrated),
                e !== null && ((n = Ju.bind(null, n)), sf(e, n)))));
          break;
        case 22:
          if (((r = n.memoizedState !== null || $c), !r)) {
            ((t = (t !== null && t.memoizedState !== null) || el), (i = $c));
            var a = el;
            (($c = r),
              (el = t) && !a ? Sl(e, n, !!(n.subtreeFlags & 8772)) : bl(e, n),
              ($c = i),
              (el = a));
          }
          break;
        case 30:
          break;
        default:
          bl(e, n);
      }
    }
    function ol(e) {
      var t = e.alternate;
      (t !== null && ((e.alternate = null), ol(t)),
        (e.child = null),
        (e.deletions = null),
        (e.sibling = null),
        e.tag === 5 && ((t = e.stateNode), t !== null && _t(t)),
        (e.stateNode = null),
        (e.return = null),
        (e.dependencies = null),
        (e.memoizedProps = null),
        (e.memoizedState = null),
        (e.pendingProps = null),
        (e.stateNode = null),
        (e.updateQueue = null));
    }
    var sl = null,
      cl = !1;
    function ll(e, t, n) {
      for (n = n.child; n !== null;) (ul(e, t, n), (n = n.sibling));
    }
    function ul(e, t, n) {
      if (Ge && typeof Ge.onCommitFiberUnmount == `function`)
        try {
          Ge.onCommitFiberUnmount(We, n);
        } catch {}
      switch (n.tag) {
        case 26:
          (el || Gc(n, t),
            ll(e, t, n),
            n.memoizedState
              ? n.memoizedState.count--
              : n.stateNode &&
                ((n = n.stateNode), n.parentNode.removeChild(n)));
          break;
        case 27:
          el || Gc(n, t);
          var r = sl,
            i = cl;
          (Zd(n.type) && ((sl = n.stateNode), (cl = !1)),
            ll(e, t, n),
            pf(n.stateNode),
            (sl = r),
            (cl = i));
          break;
        case 5:
          el || Gc(n, t);
        case 6:
          if (
            ((r = sl),
            (i = cl),
            (sl = null),
            ll(e, t, n),
            (sl = r),
            (cl = i),
            sl !== null)
          )
            if (cl)
              try {
                (sl.nodeType === 9
                  ? sl.body
                  : sl.nodeName === `HTML`
                    ? sl.ownerDocument.body
                    : sl
                ).removeChild(n.stateNode);
              } catch (e) {
                Z(n, t, e);
              }
            else
              try {
                sl.removeChild(n.stateNode);
              } catch (e) {
                Z(n, t, e);
              }
          break;
        case 18:
          sl !== null &&
            (cl
              ? ((e = sl),
                Qd(
                  e.nodeType === 9
                    ? e.body
                    : e.nodeName === `HTML`
                      ? e.ownerDocument.body
                      : e,
                  n.stateNode,
                ),
                Np(e))
              : Qd(sl, n.stateNode));
          break;
        case 4:
          ((r = sl),
            (i = cl),
            (sl = n.stateNode.containerInfo),
            (cl = !0),
            ll(e, t, n),
            (sl = r),
            (cl = i));
          break;
        case 0:
        case 11:
        case 14:
        case 15:
          (Vc(2, n, t), el || Vc(4, n, t), ll(e, t, n));
          break;
        case 1:
          (el ||
            (Gc(n, t),
            (r = n.stateNode),
            typeof r.componentWillUnmount == `function` && Uc(n, t, r)),
            ll(e, t, n));
          break;
        case 21:
          ll(e, t, n);
          break;
        case 22:
          ((el = (r = el) || n.memoizedState !== null), ll(e, t, n), (el = r));
          break;
        default:
          ll(e, t, n);
      }
    }
    function dl(e, t) {
      if (
        t.memoizedState === null &&
        ((e = t.alternate), e !== null && ((e = e.memoizedState), e !== null))
      ) {
        e = e.dehydrated;
        try {
          Np(e);
        } catch (e) {
          Z(t, t.return, e);
        }
      }
    }
    function fl(e, t) {
      if (
        t.memoizedState === null &&
        ((e = t.alternate),
        e !== null &&
          ((e = e.memoizedState),
          e !== null && ((e = e.dehydrated), e !== null)))
      )
        try {
          Np(e);
        } catch (e) {
          Z(t, t.return, e);
        }
    }
    function pl(e) {
      switch (e.tag) {
        case 31:
        case 13:
        case 19:
          var t = e.stateNode;
          return (t === null && (t = e.stateNode = new nl()), t);
        case 22:
          return (
            (e = e.stateNode),
            (t = e._retryCache),
            t === null && (t = e._retryCache = new nl()),
            t
          );
        default:
          throw Error(i(435, e.tag));
      }
    }
    function ml(e, t) {
      var n = pl(e);
      t.forEach(function (t) {
        if (!n.has(t)) {
          n.add(t);
          var r = Yu.bind(null, e, t);
          t.then(r, r);
        }
      });
    }
    function hl(e, t) {
      var n = t.deletions;
      if (n !== null)
        for (var r = 0; r < n.length; r++) {
          var a = n[r],
            o = e,
            s = t,
            c = s;
          a: for (; c !== null;) {
            switch (c.tag) {
              case 27:
                if (Zd(c.type)) {
                  ((sl = c.stateNode), (cl = !1));
                  break a;
                }
                break;
              case 5:
                ((sl = c.stateNode), (cl = !1));
                break a;
              case 3:
              case 4:
                ((sl = c.stateNode.containerInfo), (cl = !0));
                break a;
            }
            c = c.return;
          }
          if (sl === null) throw Error(i(160));
          (ul(o, s, a),
            (sl = null),
            (cl = !1),
            (o = a.alternate),
            o !== null && (o.return = null),
            (a.return = null));
        }
      if (t.subtreeFlags & 13886)
        for (t = t.child; t !== null;) (_l(t, e), (t = t.sibling));
    }
    var gl = null;
    function _l(e, t) {
      var n = e.alternate,
        r = e.flags;
      switch (e.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
          (hl(t, e),
            vl(e),
            r & 4 && (Vc(3, e, e.return), Bc(3, e), Vc(5, e, e.return)));
          break;
        case 1:
          (hl(t, e),
            vl(e),
            r & 512 && (el || n === null || Gc(n, n.return)),
            r & 64 &&
              $c &&
              ((e = e.updateQueue),
              e !== null &&
                ((r = e.callbacks),
                r !== null &&
                  ((n = e.shared.hiddenCallbacks),
                  (e.shared.hiddenCallbacks = n === null ? r : n.concat(r))))));
          break;
        case 26:
          var a = gl;
          if (
            (hl(t, e),
            vl(e),
            r & 512 && (el || n === null || Gc(n, n.return)),
            r & 4)
          ) {
            var o = n === null ? null : n.memoizedState;
            if (((r = e.memoizedState), n === null))
              if (r === null)
                if (e.stateNode === null) {
                  a: {
                    ((r = e.type),
                      (n = e.memoizedProps),
                      (a = a.ownerDocument || a));
                    b: switch (r) {
                      case `title`:
                        ((o = a.getElementsByTagName(`title`)[0]),
                          (!o ||
                            o[gt] ||
                            o[F] ||
                            o.namespaceURI === `http://www.w3.org/2000/svg` ||
                            o.hasAttribute(`itemprop`)) &&
                            ((o = a.createElement(r)),
                            a.head.insertBefore(
                              o,
                              a.querySelector(`head > title`),
                            )),
                          Pd(o, r, n),
                          (o[F] = e),
                          St(o),
                          (r = o));
                        break a;
                      case `link`:
                        var s = Vf(`link`, `href`, a).get(r + (n.href || ``));
                        if (s) {
                          for (var c = 0; c < s.length; c++)
                            if (
                              ((o = s[c]),
                              o.getAttribute(`href`) ===
                                (n.href == null || n.href === ``
                                  ? null
                                  : n.href) &&
                                o.getAttribute(`rel`) ===
                                  (n.rel == null ? null : n.rel) &&
                                o.getAttribute(`title`) ===
                                  (n.title == null ? null : n.title) &&
                                o.getAttribute(`crossorigin`) ===
                                  (n.crossOrigin == null
                                    ? null
                                    : n.crossOrigin))
                            ) {
                              s.splice(c, 1);
                              break b;
                            }
                        }
                        ((o = a.createElement(r)),
                          Pd(o, r, n),
                          a.head.appendChild(o));
                        break;
                      case `meta`:
                        if (
                          (s = Vf(`meta`, `content`, a).get(
                            r + (n.content || ``),
                          ))
                        ) {
                          for (c = 0; c < s.length; c++)
                            if (
                              ((o = s[c]),
                              o.getAttribute(`content`) ===
                                (n.content == null ? null : `` + n.content) &&
                                o.getAttribute(`name`) ===
                                  (n.name == null ? null : n.name) &&
                                o.getAttribute(`property`) ===
                                  (n.property == null ? null : n.property) &&
                                o.getAttribute(`http-equiv`) ===
                                  (n.httpEquiv == null ? null : n.httpEquiv) &&
                                o.getAttribute(`charset`) ===
                                  (n.charSet == null ? null : n.charSet))
                            ) {
                              s.splice(c, 1);
                              break b;
                            }
                        }
                        ((o = a.createElement(r)),
                          Pd(o, r, n),
                          a.head.appendChild(o));
                        break;
                      default:
                        throw Error(i(468, r));
                    }
                    ((o[F] = e), St(o), (r = o));
                  }
                  e.stateNode = r;
                } else Hf(a, e.type, e.stateNode);
              else e.stateNode = If(a, r, e.memoizedProps);
            else
              o === r
                ? r === null &&
                  e.stateNode !== null &&
                  qc(e, e.memoizedProps, n.memoizedProps)
                : (o === null
                    ? n.stateNode !== null &&
                      ((n = n.stateNode), n.parentNode.removeChild(n))
                    : o.count--,
                  r === null
                    ? Hf(a, e.type, e.stateNode)
                    : If(a, r, e.memoizedProps));
          }
          break;
        case 27:
          (hl(t, e),
            vl(e),
            r & 512 && (el || n === null || Gc(n, n.return)),
            n !== null && r & 4 && qc(e, e.memoizedProps, n.memoizedProps));
          break;
        case 5:
          if (
            (hl(t, e),
            vl(e),
            r & 512 && (el || n === null || Gc(n, n.return)),
            e.flags & 32)
          ) {
            a = e.stateNode;
            try {
              Wt(a, ``);
            } catch (t) {
              Z(e, e.return, t);
            }
          }
          (r & 4 &&
            e.stateNode != null &&
            ((a = e.memoizedProps), qc(e, a, n === null ? a : n.memoizedProps)),
            r & 1024 && (tl = !0));
          break;
        case 6:
          if ((hl(t, e), vl(e), r & 4)) {
            if (e.stateNode === null) throw Error(i(162));
            ((r = e.memoizedProps), (n = e.stateNode));
            try {
              n.nodeValue = r;
            } catch (t) {
              Z(e, e.return, t);
            }
          }
          break;
        case 3:
          if (
            ((Bf = null),
            (a = gl),
            (gl = gf(t.containerInfo)),
            hl(t, e),
            (gl = a),
            vl(e),
            r & 4 && n !== null && n.memoizedState.isDehydrated)
          )
            try {
              Np(t.containerInfo);
            } catch (t) {
              Z(e, e.return, t);
            }
          tl && ((tl = !1), yl(e));
          break;
        case 4:
          ((r = gl),
            (gl = gf(e.stateNode.containerInfo)),
            hl(t, e),
            vl(e),
            (gl = r));
          break;
        case 12:
          (hl(t, e), vl(e));
          break;
        case 31:
          (hl(t, e),
            vl(e),
            r & 4 &&
              ((r = e.updateQueue),
              r !== null && ((e.updateQueue = null), ml(e, r))));
          break;
        case 13:
          (hl(t, e),
            vl(e),
            e.child.flags & 8192 &&
              (e.memoizedState !== null) !=
                (n !== null && n.memoizedState !== null) &&
              ($l = Le()),
            r & 4 &&
              ((r = e.updateQueue),
              r !== null && ((e.updateQueue = null), ml(e, r))));
          break;
        case 22:
          a = e.memoizedState !== null;
          var l = n !== null && n.memoizedState !== null,
            u = $c,
            d = el;
          if (
            (($c = u || a),
            (el = d || l),
            hl(t, e),
            (el = d),
            ($c = u),
            vl(e),
            r & 8192)
          )
            a: for (
              t = e.stateNode,
                t._visibility = a ? t._visibility & -2 : t._visibility | 1,
                a && (n === null || l || $c || el || xl(e)),
                n = null,
                t = e;
              ;
            ) {
              if (t.tag === 5 || t.tag === 26) {
                if (n === null) {
                  l = n = t;
                  try {
                    if (((o = l.stateNode), a))
                      ((s = o.style),
                        typeof s.setProperty == `function`
                          ? s.setProperty(`display`, `none`, `important`)
                          : (s.display = `none`));
                    else {
                      c = l.stateNode;
                      var f = l.memoizedProps.style,
                        p =
                          f != null && f.hasOwnProperty(`display`)
                            ? f.display
                            : null;
                      c.style.display =
                        p == null || typeof p == `boolean`
                          ? ``
                          : (`` + p).trim();
                    }
                  } catch (e) {
                    Z(l, l.return, e);
                  }
                }
              } else if (t.tag === 6) {
                if (n === null) {
                  l = t;
                  try {
                    l.stateNode.nodeValue = a ? `` : l.memoizedProps;
                  } catch (e) {
                    Z(l, l.return, e);
                  }
                }
              } else if (t.tag === 18) {
                if (n === null) {
                  l = t;
                  try {
                    var m = l.stateNode;
                    a ? $d(m, !0) : $d(l.stateNode, !1);
                  } catch (e) {
                    Z(l, l.return, e);
                  }
                }
              } else if (
                ((t.tag !== 22 && t.tag !== 23) ||
                  t.memoizedState === null ||
                  t === e) &&
                t.child !== null
              ) {
                ((t.child.return = t), (t = t.child));
                continue;
              }
              if (t === e) break a;
              for (; t.sibling === null;) {
                if (t.return === null || t.return === e) break a;
                (n === t && (n = null), (t = t.return));
              }
              (n === t && (n = null),
                (t.sibling.return = t.return),
                (t = t.sibling));
            }
          r & 4 &&
            ((r = e.updateQueue),
            r !== null &&
              ((n = r.retryQueue),
              n !== null && ((r.retryQueue = null), ml(e, n))));
          break;
        case 19:
          (hl(t, e),
            vl(e),
            r & 4 &&
              ((r = e.updateQueue),
              r !== null && ((e.updateQueue = null), ml(e, r))));
          break;
        case 30:
          break;
        case 21:
          break;
        default:
          (hl(t, e), vl(e));
      }
    }
    function vl(e) {
      var t = e.flags;
      if (t & 2) {
        try {
          for (var n, r = e.return; r !== null;) {
            if (Jc(r)) {
              n = r;
              break;
            }
            r = r.return;
          }
          if (n == null) throw Error(i(160));
          switch (n.tag) {
            case 27:
              var a = n.stateNode;
              Zc(e, Yc(e), a);
              break;
            case 5:
              var o = n.stateNode;
              (n.flags & 32 && (Wt(o, ``), (n.flags &= -33)), Zc(e, Yc(e), o));
              break;
            case 3:
            case 4:
              var s = n.stateNode.containerInfo;
              Xc(e, Yc(e), s);
              break;
            default:
              throw Error(i(161));
          }
        } catch (t) {
          Z(e, e.return, t);
        }
        e.flags &= -3;
      }
      t & 4096 && (e.flags &= -4097);
    }
    function yl(e) {
      if (e.subtreeFlags & 1024)
        for (e = e.child; e !== null;) {
          var t = e;
          (yl(t),
            t.tag === 5 && t.flags & 1024 && t.stateNode.reset(),
            (e = e.sibling));
        }
    }
    function bl(e, t) {
      if (t.subtreeFlags & 8772)
        for (t = t.child; t !== null;) (al(e, t.alternate, t), (t = t.sibling));
    }
    function xl(e) {
      for (e = e.child; e !== null;) {
        var t = e;
        switch (t.tag) {
          case 0:
          case 11:
          case 14:
          case 15:
            (Vc(4, t, t.return), xl(t));
            break;
          case 1:
            Gc(t, t.return);
            var n = t.stateNode;
            (typeof n.componentWillUnmount == `function` && Uc(t, t.return, n),
              xl(t));
            break;
          case 27:
            pf(t.stateNode);
          case 26:
          case 5:
            (Gc(t, t.return), xl(t));
            break;
          case 22:
            t.memoizedState === null && xl(t);
            break;
          case 30:
            xl(t);
            break;
          default:
            xl(t);
        }
        e = e.sibling;
      }
    }
    function Sl(e, t, n) {
      for (n &&= !!(t.subtreeFlags & 8772), t = t.child; t !== null;) {
        var r = t.alternate,
          i = e,
          a = t,
          o = a.flags;
        switch (a.tag) {
          case 0:
          case 11:
          case 15:
            (Sl(i, a, n), Bc(4, a));
            break;
          case 1:
            if (
              (Sl(i, a, n),
              (r = a),
              (i = r.stateNode),
              typeof i.componentDidMount == `function`)
            )
              try {
                i.componentDidMount();
              } catch (e) {
                Z(r, r.return, e);
              }
            if (((r = a), (i = r.updateQueue), i !== null)) {
              var s = r.stateNode;
              try {
                var c = i.shared.hiddenCallbacks;
                if (c !== null)
                  for (
                    i.shared.hiddenCallbacks = null, i = 0;
                    i < c.length;
                    i++
                  )
                    qa(c[i], s);
              } catch (e) {
                Z(r, r.return, e);
              }
            }
            (n && o & 64 && Hc(a), Wc(a, a.return));
            break;
          case 27:
            Qc(a);
          case 26:
          case 5:
            (Sl(i, a, n), n && r === null && o & 4 && Kc(a), Wc(a, a.return));
            break;
          case 12:
            Sl(i, a, n);
            break;
          case 31:
            (Sl(i, a, n), n && o & 4 && dl(i, a));
            break;
          case 13:
            (Sl(i, a, n), n && o & 4 && fl(i, a));
            break;
          case 22:
            (a.memoizedState === null && Sl(i, a, n), Wc(a, a.return));
            break;
          case 30:
            break;
          default:
            Sl(i, a, n);
        }
        t = t.sibling;
      }
    }
    function Cl(e, t) {
      var n = null;
      (e !== null &&
        e.memoizedState !== null &&
        e.memoizedState.cachePool !== null &&
        (n = e.memoizedState.cachePool.pool),
        (e = null),
        t.memoizedState !== null &&
          t.memoizedState.cachePool !== null &&
          (e = t.memoizedState.cachePool.pool),
        e !== n && (e != null && e.refCount++, n != null && oa(n)));
    }
    function wl(e, t) {
      ((e = null),
        t.alternate !== null && (e = t.alternate.memoizedState.cache),
        (t = t.memoizedState.cache),
        t !== e && (t.refCount++, e != null && oa(e)));
    }
    function Tl(e, t, n, r) {
      if (t.subtreeFlags & 10256)
        for (t = t.child; t !== null;) (El(e, t, n, r), (t = t.sibling));
    }
    function El(e, t, n, r) {
      var i = t.flags;
      switch (t.tag) {
        case 0:
        case 11:
        case 15:
          (Tl(e, t, n, r), i & 2048 && Bc(9, t));
          break;
        case 1:
          Tl(e, t, n, r);
          break;
        case 3:
          (Tl(e, t, n, r),
            i & 2048 &&
              ((e = null),
              t.alternate !== null && (e = t.alternate.memoizedState.cache),
              (t = t.memoizedState.cache),
              t !== e && (t.refCount++, e != null && oa(e))));
          break;
        case 12:
          if (i & 2048) {
            (Tl(e, t, n, r), (e = t.stateNode));
            try {
              var a = t.memoizedProps,
                o = a.id,
                s = a.onPostCommit;
              typeof s == `function` &&
                s(
                  o,
                  t.alternate === null ? `mount` : `update`,
                  e.passiveEffectDuration,
                  -0,
                );
            } catch (e) {
              Z(t, t.return, e);
            }
          } else Tl(e, t, n, r);
          break;
        case 31:
          Tl(e, t, n, r);
          break;
        case 13:
          Tl(e, t, n, r);
          break;
        case 23:
          break;
        case 22:
          ((a = t.stateNode),
            (o = t.alternate),
            t.memoizedState === null
              ? a._visibility & 2
                ? Tl(e, t, n, r)
                : ((a._visibility |= 2),
                  Dl(e, t, n, r, !!(t.subtreeFlags & 10256) || !1))
              : a._visibility & 2
                ? Tl(e, t, n, r)
                : Ol(e, t),
            i & 2048 && Cl(o, t));
          break;
        case 24:
          (Tl(e, t, n, r), i & 2048 && wl(t.alternate, t));
          break;
        default:
          Tl(e, t, n, r);
      }
    }
    function Dl(e, t, n, r, i) {
      for (i &&= !!(t.subtreeFlags & 10256) || !1, t = t.child; t !== null;) {
        var a = e,
          o = t,
          s = n,
          c = r,
          l = o.flags;
        switch (o.tag) {
          case 0:
          case 11:
          case 15:
            (Dl(a, o, s, c, i), Bc(8, o));
            break;
          case 23:
            break;
          case 22:
            var u = o.stateNode;
            (o.memoizedState === null
              ? ((u._visibility |= 2), Dl(a, o, s, c, i))
              : u._visibility & 2
                ? Dl(a, o, s, c, i)
                : Ol(a, o),
              i && l & 2048 && Cl(o.alternate, o));
            break;
          case 24:
            (Dl(a, o, s, c, i), i && l & 2048 && wl(o.alternate, o));
            break;
          default:
            Dl(a, o, s, c, i);
        }
        t = t.sibling;
      }
    }
    function Ol(e, t) {
      if (t.subtreeFlags & 10256)
        for (t = t.child; t !== null;) {
          var n = e,
            r = t,
            i = r.flags;
          switch (r.tag) {
            case 22:
              (Ol(n, r), i & 2048 && Cl(r.alternate, r));
              break;
            case 24:
              (Ol(n, r), i & 2048 && wl(r.alternate, r));
              break;
            default:
              Ol(n, r);
          }
          t = t.sibling;
        }
    }
    var kl = 8192;
    function Al(e, t, n) {
      if (e.subtreeFlags & kl)
        for (e = e.child; e !== null;) (jl(e, t, n), (e = e.sibling));
    }
    function jl(e, t, n) {
      switch (e.tag) {
        case 26:
          (Al(e, t, n),
            e.flags & kl &&
              e.memoizedState !== null &&
              Gf(n, gl, e.memoizedState, e.memoizedProps));
          break;
        case 5:
          Al(e, t, n);
          break;
        case 3:
        case 4:
          var r = gl;
          ((gl = gf(e.stateNode.containerInfo)), Al(e, t, n), (gl = r));
          break;
        case 22:
          e.memoizedState === null &&
            ((r = e.alternate),
            r !== null && r.memoizedState !== null
              ? ((r = kl), (kl = 16777216), Al(e, t, n), (kl = r))
              : Al(e, t, n));
          break;
        default:
          Al(e, t, n);
      }
    }
    function Ml(e) {
      var t = e.alternate;
      if (t !== null && ((e = t.child), e !== null)) {
        t.child = null;
        do ((t = e.sibling), (e.sibling = null), (e = t));
        while (e !== null);
      }
    }
    function Nl(e) {
      var t = e.deletions;
      if (e.flags & 16) {
        if (t !== null)
          for (var n = 0; n < t.length; n++) {
            var r = t[n];
            ((rl = r), Il(r, e));
          }
        Ml(e);
      }
      if (e.subtreeFlags & 10256)
        for (e = e.child; e !== null;) (Pl(e), (e = e.sibling));
    }
    function Pl(e) {
      switch (e.tag) {
        case 0:
        case 11:
        case 15:
          (Nl(e), e.flags & 2048 && Vc(9, e, e.return));
          break;
        case 3:
          Nl(e);
          break;
        case 12:
          Nl(e);
          break;
        case 22:
          var t = e.stateNode;
          e.memoizedState !== null &&
          t._visibility & 2 &&
          (e.return === null || e.return.tag !== 13)
            ? ((t._visibility &= -3), Fl(e))
            : Nl(e);
          break;
        default:
          Nl(e);
      }
    }
    function Fl(e) {
      var t = e.deletions;
      if (e.flags & 16) {
        if (t !== null)
          for (var n = 0; n < t.length; n++) {
            var r = t[n];
            ((rl = r), Il(r, e));
          }
        Ml(e);
      }
      for (e = e.child; e !== null;) {
        switch (((t = e), t.tag)) {
          case 0:
          case 11:
          case 15:
            (Vc(8, t, t.return), Fl(t));
            break;
          case 22:
            ((n = t.stateNode),
              n._visibility & 2 && ((n._visibility &= -3), Fl(t)));
            break;
          default:
            Fl(t);
        }
        e = e.sibling;
      }
    }
    function Il(e, t) {
      for (; rl !== null;) {
        var n = rl;
        switch (n.tag) {
          case 0:
          case 11:
          case 15:
            Vc(8, n, t);
            break;
          case 23:
          case 22:
            if (
              n.memoizedState !== null &&
              n.memoizedState.cachePool !== null
            ) {
              var r = n.memoizedState.cachePool.pool;
              r != null && r.refCount++;
            }
            break;
          case 24:
            oa(n.memoizedState.cache);
        }
        if (((r = n.child), r !== null)) ((r.return = n), (rl = r));
        else
          a: for (n = e; rl !== null;) {
            r = rl;
            var i = r.sibling,
              a = r.return;
            if ((ol(r), r === n)) {
              rl = null;
              break a;
            }
            if (i !== null) {
              ((i.return = a), (rl = i));
              break a;
            }
            rl = a;
          }
      }
    }
    var Ll = {
        getCacheForType: function (e) {
          var t = Qi(ia),
            n = t.data.get(e);
          return (n === void 0 && ((n = e()), t.data.set(e, n)), n);
        },
        cacheSignal: function () {
          return Qi(ia).controller.signal;
        },
      },
      Rl = typeof WeakMap == `function` ? WeakMap : Map,
      K = 0,
      q = null,
      J = null,
      Y = 0,
      X = 0,
      zl = null,
      Bl = !1,
      Vl = !1,
      Hl = !1,
      Ul = 0,
      Wl = 0,
      Gl = 0,
      Kl = 0,
      ql = 0,
      Jl = 0,
      Yl = 0,
      Xl = null,
      Zl = null,
      Ql = !1,
      $l = 0,
      eu = 0,
      tu = 1 / 0,
      nu = null,
      ru = null,
      iu = 0,
      au = null,
      ou = null,
      su = 0,
      cu = 0,
      lu = null,
      uu = null,
      du = 0,
      fu = null;
    function pu() {
      return K & 2 && Y !== 0 ? Y & -Y : w.T === null ? lt() : dd();
    }
    function mu() {
      if (Jl === 0)
        if (!(Y & 536870912) || H) {
          var e = Qe;
          ((Qe <<= 1), !(Qe & 3932160) && (Qe = 262144), (Jl = e));
        } else Jl = 536870912;
      return ((e = eo.current), e !== null && (e.flags |= 32), Jl);
    }
    function hu(e, t, n) {
      (((e === q && (X === 2 || X === 9)) || e.cancelPendingCommit !== null) &&
        (Su(e, 0), yu(e, Y, Jl, !1)),
        at(e, n),
        (!(K & 2) || e !== q) &&
          (e === q && (!(K & 2) && (Kl |= n), Wl === 4 && yu(e, Y, Jl, !1)),
          rd(e)));
    }
    function gu(e, t, n) {
      if (K & 6) throw Error(i(327));
      var r = (!n && !(t & 127) && (t & e.expiredLanes) === 0) || tt(e, t),
        a = r ? Au(e, t) : Ou(e, t, !0),
        o = r;
      do {
        if (a === 0) {
          Vl && !r && yu(e, t, 0, !1);
          break;
        }
        if (((n = e.current.alternate), o && !vu(n))) {
          ((a = Ou(e, t, !1)), (o = !1));
          continue;
        }
        if (a === 2) {
          if (((o = t), e.errorRecoveryDisabledLanes & o)) var s = 0;
          else
            ((s = e.pendingLanes & -536870913),
              (s = s === 0 ? (s & 536870912 ? 536870912 : 0) : s));
          if (s !== 0) {
            t = s;
            a: {
              var c = e;
              a = Xl;
              var l = c.current.memoizedState.isDehydrated;
              if ((l && (Su(c, s).flags |= 256), (s = Ou(c, s, !1)), s !== 2)) {
                if (Hl && !l) {
                  ((c.errorRecoveryDisabledLanes |= o), (Kl |= o), (a = 4));
                  break a;
                }
                ((o = Zl),
                  (Zl = a),
                  o !== null &&
                    (Zl === null ? (Zl = o) : Zl.push.apply(Zl, o)));
              }
              a = s;
            }
            if (((o = !1), a !== 2)) continue;
          }
        }
        if (a === 1) {
          (Su(e, 0), yu(e, t, 0, !0));
          break;
        }
        a: {
          switch (((r = e), (o = a), o)) {
            case 0:
            case 1:
              throw Error(i(345));
            case 4:
              if ((t & 4194048) !== t) break;
            case 6:
              yu(r, t, Jl, !Bl);
              break a;
            case 2:
              Zl = null;
              break;
            case 3:
            case 5:
              break;
            default:
              throw Error(i(329));
          }
          if ((t & 62914560) === t && ((a = $l + 300 - Le()), 10 < a)) {
            if ((yu(r, t, Jl, !Bl), k(r, 0, !0) !== 0)) break a;
            ((su = t),
              (r.timeoutHandle = Kd(
                _u.bind(
                  null,
                  r,
                  n,
                  Zl,
                  nu,
                  Ql,
                  t,
                  Jl,
                  Kl,
                  Yl,
                  Bl,
                  o,
                  `Throttled`,
                  -0,
                  0,
                ),
                a,
              )));
            break a;
          }
          _u(r, n, Zl, nu, Ql, t, Jl, Kl, Yl, Bl, o, null, -0, 0);
        }
        break;
      } while (1);
      rd(e);
    }
    function _u(e, t, n, r, i, a, o, s, c, l, u, d, f, p) {
      if (
        ((e.timeoutHandle = -1),
        (d = t.subtreeFlags),
        d & 8192 || (d & 16785408) == 16785408)
      ) {
        ((d = {
          stylesheets: null,
          count: 0,
          imgCount: 0,
          imgBytes: 0,
          suspenseyImages: [],
          waitingForImages: !0,
          waitingForViewTransition: !1,
          unsuspend: Qt,
        }),
          jl(t, a, d));
        var m =
          (a & 62914560) === a
            ? $l - Le()
            : (a & 4194048) === a
              ? eu - Le()
              : 0;
        if (((m = qf(d, m)), m !== null)) {
          ((su = a),
            (e.cancelPendingCommit = m(
              Lu.bind(null, e, t, a, n, r, i, o, s, c, u, d, null, f, p),
            )),
            yu(e, a, o, !l));
          return;
        }
      }
      Lu(e, t, a, n, r, i, o, s, c);
    }
    function vu(e) {
      for (var t = e; ;) {
        var n = t.tag;
        if (
          (n === 0 || n === 11 || n === 15) &&
          t.flags & 16384 &&
          ((n = t.updateQueue), n !== null && ((n = n.stores), n !== null))
        )
          for (var r = 0; r < n.length; r++) {
            var i = n[r],
              a = i.getSnapshot;
            i = i.value;
            try {
              if (!br(a(), i)) return !1;
            } catch {
              return !1;
            }
          }
        if (((n = t.child), t.subtreeFlags & 16384 && n !== null))
          ((n.return = t), (t = n));
        else {
          if (t === e) break;
          for (; t.sibling === null;) {
            if (t.return === null || t.return === e) return !0;
            t = t.return;
          }
          ((t.sibling.return = t.return), (t = t.sibling));
        }
      }
      return !0;
    }
    function yu(e, t, n, r) {
      ((t &= ~ql),
        (t &= ~Kl),
        (e.suspendedLanes |= t),
        (e.pingedLanes &= ~t),
        r && (e.warmLanes |= t),
        (r = e.expirationTimes));
      for (var i = t; 0 < i;) {
        var a = 31 - qe(i),
          o = 1 << a;
        ((r[a] = -1), (i &= ~o));
      }
      n !== 0 && A(e, n, t);
    }
    function bu() {
      return K & 6 ? !0 : (id(0, !1), !1);
    }
    function xu() {
      if (J !== null) {
        if (X === 0) var e = J.return;
        else ((e = J), (Wi = Ui = null), Do(e), (ka = null), (Aa = 0), (e = J));
        for (; e !== null;) (zc(e.alternate, e), (e = e.return));
        J = null;
      }
    }
    function Su(e, t) {
      var n = e.timeoutHandle;
      (n !== -1 && ((e.timeoutHandle = -1), qd(n)),
        (n = e.cancelPendingCommit),
        n !== null && ((e.cancelPendingCommit = null), n()),
        (su = 0),
        xu(),
        (q = e),
        (J = n = ci(e.current, null)),
        (Y = t),
        (X = 0),
        (zl = null),
        (Bl = !1),
        (Vl = tt(e, t)),
        (Hl = !1),
        (Yl = Jl = ql = Kl = Gl = Wl = 0),
        (Zl = Xl = null),
        (Ql = !1),
        t & 8 && (t |= t & 32));
      var r = e.entangledLanes;
      if (r !== 0)
        for (e = e.entanglements, r &= t; 0 < r;) {
          var i = 31 - qe(r),
            a = 1 << i;
          ((t |= e[i]), (r &= ~a));
        }
      return ((Ul = t), Qr(), n);
    }
    function Cu(e, t) {
      ((U = null),
        (w.H = Ls),
        t === ya || t === xa
          ? ((t = Da()), (X = 3))
          : t === ba
            ? ((t = Da()), (X = 4))
            : (X =
                t === tc
                  ? 8
                  : typeof t == `object` && t && typeof t.then == `function`
                    ? 6
                    : 1),
        (zl = t),
        J === null && ((Wl = 1), Ys(e, gi(t, e.current))));
    }
    function wu() {
      var e = eo.current;
      return e === null
        ? !0
        : (Y & 4194048) === Y
          ? to === null
          : (Y & 62914560) === Y || Y & 536870912
            ? e === to
            : !1;
    }
    function Tu() {
      var e = w.H;
      return ((w.H = Ls), e === null ? Ls : e);
    }
    function Eu() {
      var e = w.A;
      return ((w.A = Ll), e);
    }
    function Du() {
      ((Wl = 4),
        Bl || ((Y & 4194048) !== Y && eo.current !== null) || (Vl = !0),
        (!(Gl & 134217727) && !(Kl & 134217727)) ||
          q === null ||
          yu(q, Y, Jl, !1));
    }
    function Ou(e, t, n) {
      var r = K;
      K |= 2;
      var i = Tu(),
        a = Eu();
      ((q !== e || Y !== t) && ((nu = null), Su(e, t)), (t = !1));
      var o = Wl;
      a: do
        try {
          if (X !== 0 && J !== null) {
            var s = J,
              c = zl;
            switch (X) {
              case 8:
                (xu(), (o = 6));
                break a;
              case 3:
              case 2:
              case 9:
              case 6:
                eo.current === null && (t = !0);
                var l = X;
                if (((X = 0), (zl = null), Pu(e, s, c, l), n && Vl)) {
                  o = 0;
                  break a;
                }
                break;
              default:
                ((l = X), (X = 0), (zl = null), Pu(e, s, c, l));
            }
          }
          (ku(), (o = Wl));
          break;
        } catch (t) {
          Cu(e, t);
        }
      while (1);
      return (
        t && e.shellSuspendCounter++,
        (Wi = Ui = null),
        (K = r),
        (w.H = i),
        (w.A = a),
        J === null && ((q = null), (Y = 0), Qr()),
        o
      );
    }
    function ku() {
      for (; J !== null;) Mu(J);
    }
    function Au(e, t) {
      var n = K;
      K |= 2;
      var r = Tu(),
        a = Eu();
      q !== e || Y !== t
        ? ((nu = null), (tu = Le() + 500), Su(e, t))
        : (Vl = tt(e, t));
      a: do
        try {
          if (X !== 0 && J !== null) {
            t = J;
            var o = zl;
            b: switch (X) {
              case 1:
                ((X = 0), (zl = null), Pu(e, t, o, 1));
                break;
              case 2:
              case 9:
                if (Ca(o)) {
                  ((X = 0), (zl = null), Nu(t));
                  break;
                }
                ((t = function () {
                  ((X !== 2 && X !== 9) || q !== e || (X = 7), rd(e));
                }),
                  o.then(t, t));
                break a;
              case 3:
                X = 7;
                break a;
              case 4:
                X = 5;
                break a;
              case 7:
                Ca(o)
                  ? ((X = 0), (zl = null), Nu(t))
                  : ((X = 0), (zl = null), Pu(e, t, o, 7));
                break;
              case 5:
                var s = null;
                switch (J.tag) {
                  case 26:
                    s = J.memoizedState;
                  case 5:
                  case 27:
                    var c = J;
                    if (s ? Wf(s) : c.stateNode.complete) {
                      ((X = 0), (zl = null));
                      var l = c.sibling;
                      if (l !== null) J = l;
                      else {
                        var u = c.return;
                        u === null ? (J = null) : ((J = u), Fu(u));
                      }
                      break b;
                    }
                }
                ((X = 0), (zl = null), Pu(e, t, o, 5));
                break;
              case 6:
                ((X = 0), (zl = null), Pu(e, t, o, 6));
                break;
              case 8:
                (xu(), (Wl = 6));
                break a;
              default:
                throw Error(i(462));
            }
          }
          ju();
          break;
        } catch (t) {
          Cu(e, t);
        }
      while (1);
      return (
        (Wi = Ui = null),
        (w.H = r),
        (w.A = a),
        (K = n),
        J === null ? ((q = null), (Y = 0), Qr(), Wl) : 0
      );
    }
    function ju() {
      for (; J !== null && !Fe();) Mu(J);
    }
    function Mu(e) {
      var t = jc(e.alternate, e, Ul);
      ((e.memoizedProps = e.pendingProps), t === null ? Fu(e) : (J = t));
    }
    function Nu(e) {
      var t = e,
        n = t.alternate;
      switch (t.tag) {
        case 15:
        case 0:
          t = hc(n, t, t.pendingProps, t.type, void 0, Y);
          break;
        case 11:
          t = hc(n, t, t.pendingProps, t.type.render, t.ref, Y);
          break;
        case 5:
          Do(t);
        default:
          (zc(n, t), (t = J = li(t, Ul)), (t = jc(n, t, Ul)));
      }
      ((e.memoizedProps = e.pendingProps), t === null ? Fu(e) : (J = t));
    }
    function Pu(e, t, n, r) {
      ((Wi = Ui = null), Do(t), (ka = null), (Aa = 0));
      var i = t.return;
      try {
        if (ec(e, i, t, n, Y)) {
          ((Wl = 1), Ys(e, gi(n, e.current)), (J = null));
          return;
        }
      } catch (t) {
        if (i !== null) throw ((J = i), t);
        ((Wl = 1), Ys(e, gi(n, e.current)), (J = null));
        return;
      }
      t.flags & 32768
        ? (H || r === 1
            ? (e = !0)
            : Vl || Y & 536870912
              ? (e = !1)
              : ((Bl = e = !0),
                (r === 2 || r === 9 || r === 3 || r === 6) &&
                  ((r = eo.current),
                  r !== null && r.tag === 13 && (r.flags |= 16384))),
          Iu(t, e))
        : Fu(t);
    }
    function Fu(e) {
      var t = e;
      do {
        if (t.flags & 32768) {
          Iu(t, Bl);
          return;
        }
        e = t.return;
        var n = Lc(t.alternate, t, Ul);
        if (n !== null) {
          J = n;
          return;
        }
        if (((t = t.sibling), t !== null)) {
          J = t;
          return;
        }
        J = t = e;
      } while (t !== null);
      Wl === 0 && (Wl = 5);
    }
    function Iu(e, t) {
      do {
        var n = Rc(e.alternate, e);
        if (n !== null) {
          ((n.flags &= 32767), (J = n));
          return;
        }
        if (
          ((n = e.return),
          n !== null &&
            ((n.flags |= 32768), (n.subtreeFlags = 0), (n.deletions = null)),
          !t && ((e = e.sibling), e !== null))
        ) {
          J = e;
          return;
        }
        J = e = n;
      } while (e !== null);
      ((Wl = 6), (J = null));
    }
    function Lu(e, t, n, r, a, o, s, c, l) {
      e.cancelPendingCommit = null;
      do Hu();
      while (iu !== 0);
      if (K & 6) throw Error(i(327));
      if (t !== null) {
        if (t === e.current) throw Error(i(177));
        if (
          ((o = t.lanes | t.childLanes),
          (o |= Zr),
          ot(e, n, o, s, c, l),
          e === q && ((J = q = null), (Y = 0)),
          (ou = t),
          (au = e),
          (su = n),
          (cu = o),
          (lu = a),
          (uu = r),
          t.subtreeFlags & 10256 || t.flags & 10256
            ? ((e.callbackNode = null),
              (e.callbackPriority = 0),
              Xu(Ve, function () {
                return (Uu(), null);
              }))
            : ((e.callbackNode = null), (e.callbackPriority = 0)),
          (r = !!(t.flags & 13878)),
          t.subtreeFlags & 13878 || r)
        ) {
          ((r = w.T), (w.T = null), (a = T.p), (T.p = 2), (s = K), (K |= 4));
          try {
            il(e, t, n);
          } finally {
            ((K = s), (T.p = a), (w.T = r));
          }
        }
        ((iu = 1), Ru(), zu(), Bu());
      }
    }
    function Ru() {
      if (iu === 1) {
        iu = 0;
        var e = au,
          t = ou,
          n = !!(t.flags & 13878);
        if (t.subtreeFlags & 13878 || n) {
          ((n = w.T), (w.T = null));
          var r = T.p;
          T.p = 2;
          var i = K;
          K |= 4;
          try {
            _l(t, e);
            var a = zd,
              o = Tr(e.containerInfo),
              s = a.focusedElem,
              c = a.selectionRange;
            if (
              o !== s &&
              s &&
              s.ownerDocument &&
              wr(s.ownerDocument.documentElement, s)
            ) {
              if (c !== null && Er(s)) {
                var l = c.start,
                  u = c.end;
                if ((u === void 0 && (u = l), `selectionStart` in s))
                  ((s.selectionStart = l),
                    (s.selectionEnd = Math.min(u, s.value.length)));
                else {
                  var d = s.ownerDocument || document,
                    f = (d && d.defaultView) || window;
                  if (f.getSelection) {
                    var p = f.getSelection(),
                      m = s.textContent.length,
                      h = Math.min(c.start, m),
                      g = c.end === void 0 ? h : Math.min(c.end, m);
                    !p.extend && h > g && ((o = g), (g = h), (h = o));
                    var _ = Cr(s, h),
                      v = Cr(s, g);
                    if (
                      _ &&
                      v &&
                      (p.rangeCount !== 1 ||
                        p.anchorNode !== _.node ||
                        p.anchorOffset !== _.offset ||
                        p.focusNode !== v.node ||
                        p.focusOffset !== v.offset)
                    ) {
                      var y = d.createRange();
                      (y.setStart(_.node, _.offset),
                        p.removeAllRanges(),
                        h > g
                          ? (p.addRange(y), p.extend(v.node, v.offset))
                          : (y.setEnd(v.node, v.offset), p.addRange(y)));
                    }
                  }
                }
              }
              for (d = [], p = s; (p = p.parentNode);)
                p.nodeType === 1 &&
                  d.push({ element: p, left: p.scrollLeft, top: p.scrollTop });
              for (
                typeof s.focus == `function` && s.focus(), s = 0;
                s < d.length;
                s++
              ) {
                var b = d[s];
                ((b.element.scrollLeft = b.left),
                  (b.element.scrollTop = b.top));
              }
            }
            ((sp = !!Rd), (zd = Rd = null));
          } finally {
            ((K = i), (T.p = r), (w.T = n));
          }
        }
        ((e.current = t), (iu = 2));
      }
    }
    function zu() {
      if (iu === 2) {
        iu = 0;
        var e = au,
          t = ou,
          n = !!(t.flags & 8772);
        if (t.subtreeFlags & 8772 || n) {
          ((n = w.T), (w.T = null));
          var r = T.p;
          T.p = 2;
          var i = K;
          K |= 4;
          try {
            al(e, t.alternate, t);
          } finally {
            ((K = i), (T.p = r), (w.T = n));
          }
        }
        iu = 3;
      }
    }
    function Bu() {
      if (iu === 4 || iu === 3) {
        ((iu = 0), Ie());
        var e = au,
          t = ou,
          n = su,
          r = uu;
        t.subtreeFlags & 10256 || t.flags & 10256
          ? (iu = 5)
          : ((iu = 0), (ou = au = null), Vu(e, e.pendingLanes));
        var i = e.pendingLanes;
        if (
          (i === 0 && (ru = null),
          ct(n),
          (t = t.stateNode),
          Ge && typeof Ge.onCommitFiberRoot == `function`)
        )
          try {
            Ge.onCommitFiberRoot(We, t, void 0, (t.current.flags & 128) == 128);
          } catch {}
        if (r !== null) {
          ((t = w.T), (i = T.p), (T.p = 2), (w.T = null));
          try {
            for (var a = e.onRecoverableError, o = 0; o < r.length; o++) {
              var s = r[o];
              a(s.value, { componentStack: s.stack });
            }
          } finally {
            ((w.T = t), (T.p = i));
          }
        }
        (su & 3 && Hu(),
          rd(e),
          (i = e.pendingLanes),
          n & 261930 && i & 42
            ? e === fu
              ? du++
              : ((du = 0), (fu = e))
            : (du = 0),
          id(0, !1));
      }
    }
    function Vu(e, t) {
      (e.pooledCacheLanes &= t) === 0 &&
        ((t = e.pooledCache), t != null && ((e.pooledCache = null), oa(t)));
    }
    function Hu() {
      return (Ru(), zu(), Bu(), Uu());
    }
    function Uu() {
      if (iu !== 5) return !1;
      var e = au,
        t = cu;
      cu = 0;
      var n = ct(su),
        r = w.T,
        a = T.p;
      try {
        ((T.p = 32 > n ? 32 : n), (w.T = null), (n = lu), (lu = null));
        var o = au,
          s = su;
        if (((iu = 0), (ou = au = null), (su = 0), K & 6)) throw Error(i(331));
        var c = K;
        if (
          ((K |= 4),
          Pl(o.current),
          El(o, o.current, s, n),
          (K = c),
          id(0, !1),
          Ge && typeof Ge.onPostCommitFiberRoot == `function`)
        )
          try {
            Ge.onPostCommitFiberRoot(We, o);
          } catch {}
        return !0;
      } finally {
        ((T.p = a), (w.T = r), Vu(e, t));
      }
    }
    function Wu(e, t, n) {
      ((t = gi(n, t)),
        (t = Zs(e.stateNode, t, 2)),
        (e = Va(e, t, 2)),
        e !== null && (at(e, 2), rd(e)));
    }
    function Z(e, t, n) {
      if (e.tag === 3) Wu(e, e, n);
      else
        for (; t !== null;) {
          if (t.tag === 3) {
            Wu(t, e, n);
            break;
          }
          if (t.tag === 1) {
            var r = t.stateNode;
            if (
              typeof t.type.getDerivedStateFromError == `function` ||
              (typeof r.componentDidCatch == `function` &&
                (ru === null || !ru.has(r)))
            ) {
              ((e = gi(n, e)),
                (n = Qs(2)),
                (r = Va(t, n, 2)),
                r !== null && ($s(n, r, t, e), at(r, 2), rd(r)));
              break;
            }
          }
          t = t.return;
        }
    }
    function Gu(e, t, n) {
      var r = e.pingCache;
      if (r === null) {
        r = e.pingCache = new Rl();
        var i = new Set();
        r.set(t, i);
      } else ((i = r.get(t)), i === void 0 && ((i = new Set()), r.set(t, i)));
      i.has(n) ||
        ((Hl = !0), i.add(n), (e = Ku.bind(null, e, t, n)), t.then(e, e));
    }
    function Ku(e, t, n) {
      var r = e.pingCache;
      (r !== null && r.delete(t),
        (e.pingedLanes |= e.suspendedLanes & n),
        (e.warmLanes &= ~n),
        q === e &&
          (Y & n) === n &&
          (Wl === 4 || (Wl === 3 && (Y & 62914560) === Y && 300 > Le() - $l)
            ? !(K & 2) && Su(e, 0)
            : (ql |= n),
          Yl === Y && (Yl = 0)),
        rd(e));
    }
    function qu(e, t) {
      (t === 0 && (t = rt()), (e = ti(e, t)), e !== null && (at(e, t), rd(e)));
    }
    function Ju(e) {
      var t = e.memoizedState,
        n = 0;
      (t !== null && (n = t.retryLane), qu(e, n));
    }
    function Yu(e, t) {
      var n = 0;
      switch (e.tag) {
        case 31:
        case 13:
          var r = e.stateNode,
            a = e.memoizedState;
          a !== null && (n = a.retryLane);
          break;
        case 19:
          r = e.stateNode;
          break;
        case 22:
          r = e.stateNode._retryCache;
          break;
        default:
          throw Error(i(314));
      }
      (r !== null && r.delete(t), qu(e, n));
    }
    function Xu(e, t) {
      return Ne(e, t);
    }
    var Zu = null,
      Qu = null,
      $u = !1,
      ed = !1,
      td = !1,
      nd = 0;
    function rd(e) {
      (e !== Qu &&
        e.next === null &&
        (Qu === null ? (Zu = Qu = e) : (Qu = Qu.next = e)),
        (ed = !0),
        $u || (($u = !0), ud()));
    }
    function id(e, t) {
      if (!td && ed) {
        td = !0;
        do
          for (var n = !1, r = Zu; r !== null;) {
            if (!t)
              if (e !== 0) {
                var i = r.pendingLanes;
                if (i === 0) var a = 0;
                else {
                  var o = r.suspendedLanes,
                    s = r.pingedLanes;
                  ((a = (1 << (31 - qe(42 | e) + 1)) - 1),
                    (a &= i & ~(o & ~s)),
                    (a = a & 201326741 ? (a & 201326741) | 1 : a ? a | 2 : 0));
                }
                a !== 0 && ((n = !0), ld(r, a));
              } else
                ((a = Y),
                  (a = k(
                    r,
                    r === q ? a : 0,
                    r.cancelPendingCommit !== null || r.timeoutHandle !== -1,
                  )),
                  !(a & 3) || tt(r, a) || ((n = !0), ld(r, a)));
            r = r.next;
          }
        while (n);
        td = !1;
      }
    }
    function ad() {
      od();
    }
    function od() {
      ed = $u = !1;
      var e = 0;
      nd !== 0 && Gd() && (e = nd);
      for (var t = Le(), n = null, r = Zu; r !== null;) {
        var i = r.next,
          a = sd(r, t);
        (a === 0
          ? ((r.next = null),
            n === null ? (Zu = i) : (n.next = i),
            i === null && (Qu = n))
          : ((n = r), (e !== 0 || a & 3) && (ed = !0)),
          (r = i));
      }
      ((iu !== 0 && iu !== 5) || id(e, !1), nd !== 0 && (nd = 0));
    }
    function sd(e, t) {
      for (
        var n = e.suspendedLanes,
          r = e.pingedLanes,
          i = e.expirationTimes,
          a = e.pendingLanes & -62914561;
        0 < a;
      ) {
        var o = 31 - qe(a),
          s = 1 << o,
          c = i[o];
        (c === -1
          ? ((s & n) === 0 || (s & r) !== 0) && (i[o] = nt(s, t))
          : c <= t && (e.expiredLanes |= s),
          (a &= ~s));
      }
      if (
        ((t = q),
        (n = Y),
        (n = k(
          e,
          e === t ? n : 0,
          e.cancelPendingCommit !== null || e.timeoutHandle !== -1,
        )),
        (r = e.callbackNode),
        n === 0 ||
          (e === t && (X === 2 || X === 9)) ||
          e.cancelPendingCommit !== null)
      )
        return (
          r !== null && r !== null && Pe(r),
          (e.callbackNode = null),
          (e.callbackPriority = 0)
        );
      if (!(n & 3) || tt(e, n)) {
        if (((t = n & -n), t === e.callbackPriority)) return t;
        switch ((r !== null && Pe(r), ct(n))) {
          case 2:
          case 8:
            n = Be;
            break;
          case 32:
            n = Ve;
            break;
          case 268435456:
            n = D;
            break;
          default:
            n = Ve;
        }
        return (
          (r = cd.bind(null, e)),
          (n = Ne(n, r)),
          (e.callbackPriority = t),
          (e.callbackNode = n),
          t
        );
      }
      return (
        r !== null && r !== null && Pe(r),
        (e.callbackPriority = 2),
        (e.callbackNode = null),
        2
      );
    }
    function cd(e, t) {
      if (iu !== 0 && iu !== 5)
        return ((e.callbackNode = null), (e.callbackPriority = 0), null);
      var n = e.callbackNode;
      if (Hu() && e.callbackNode !== n) return null;
      var r = Y;
      return (
        (r = k(
          e,
          e === q ? r : 0,
          e.cancelPendingCommit !== null || e.timeoutHandle !== -1,
        )),
        r === 0
          ? null
          : (gu(e, r, t),
            sd(e, Le()),
            e.callbackNode != null && e.callbackNode === n
              ? cd.bind(null, e)
              : null)
      );
    }
    function ld(e, t) {
      if (Hu()) return null;
      gu(e, t, !0);
    }
    function ud() {
      Yd(function () {
        K & 6 ? Ne(ze, ad) : od();
      });
    }
    function dd() {
      if (nd === 0) {
        var e = la;
        (e === 0 && ((e = Ze), (Ze <<= 1), !(Ze & 261888) && (Ze = 256)),
          (nd = e));
      }
      return nd;
    }
    function fd(e) {
      return e == null || typeof e == `symbol` || typeof e == `boolean`
        ? null
        : typeof e == `function`
          ? e
          : Zt(`` + e);
    }
    function pd(e, t) {
      var n = t.ownerDocument.createElement(`input`);
      return (
        (n.name = t.name),
        (n.value = t.value),
        e.id && n.setAttribute(`form`, e.id),
        t.parentNode.insertBefore(n, t),
        (e = new FormData(e)),
        n.parentNode.removeChild(n),
        e
      );
    }
    function md(e, t, n, r, i) {
      if (t === `submit` && n && n.stateNode === i) {
        var a = fd((i[ut] || null).action),
          o = r.submitter;
        o &&
          ((t = (t = o[ut] || null)
            ? fd(t.formAction)
            : o.getAttribute(`formAction`)),
          t !== null && ((a = t), (o = null)));
        var s = new yn(`action`, `action`, null, r, i);
        e.push({
          event: s,
          listeners: [
            {
              instance: null,
              listener: function () {
                if (r.defaultPrevented) {
                  if (nd !== 0) {
                    var e = o ? pd(i, o) : new FormData(i);
                    Cs(
                      n,
                      { pending: !0, data: e, method: i.method, action: a },
                      null,
                      e,
                    );
                  }
                } else
                  typeof a == `function` &&
                    (s.preventDefault(),
                    (e = o ? pd(i, o) : new FormData(i)),
                    Cs(
                      n,
                      { pending: !0, data: e, method: i.method, action: a },
                      a,
                      e,
                    ));
              },
              currentTarget: i,
            },
          ],
        });
      }
    }
    for (var hd = 0; hd < Kr.length; hd++) {
      var gd = Kr[hd];
      qr(gd.toLowerCase(), `on` + (gd[0].toUpperCase() + gd.slice(1)));
    }
    (qr(Rr, `onAnimationEnd`),
      qr(zr, `onAnimationIteration`),
      qr(Br, `onAnimationStart`),
      qr(`dblclick`, `onDoubleClick`),
      qr(`focusin`, `onFocus`),
      qr(`focusout`, `onBlur`),
      qr(Vr, `onTransitionRun`),
      qr(Hr, `onTransitionStart`),
      qr(Ur, `onTransitionCancel`),
      qr(Wr, `onTransitionEnd`),
      Et(`onMouseEnter`, [`mouseout`, `mouseover`]),
      Et(`onMouseLeave`, [`mouseout`, `mouseover`]),
      Et(`onPointerEnter`, [`pointerout`, `pointerover`]),
      Et(`onPointerLeave`, [`pointerout`, `pointerover`]),
      Tt(
        `onChange`,
        `change click focusin focusout input keydown keyup selectionchange`.split(
          ` `,
        ),
      ),
      Tt(
        `onSelect`,
        `focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange`.split(
          ` `,
        ),
      ),
      Tt(`onBeforeInput`, [`compositionend`, `keypress`, `textInput`, `paste`]),
      Tt(
        `onCompositionEnd`,
        `compositionend focusout keydown keypress keyup mousedown`.split(` `),
      ),
      Tt(
        `onCompositionStart`,
        `compositionstart focusout keydown keypress keyup mousedown`.split(` `),
      ),
      Tt(
        `onCompositionUpdate`,
        `compositionupdate focusout keydown keypress keyup mousedown`.split(
          ` `,
        ),
      ));
    var _d =
        `abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting`.split(
          ` `,
        ),
      vd = new Set(
        `beforetoggle cancel close invalid load scroll scrollend toggle`
          .split(` `)
          .concat(_d),
      );
    function yd(e, t) {
      t = !!(t & 4);
      for (var n = 0; n < e.length; n++) {
        var r = e[n],
          i = r.event;
        r = r.listeners;
        a: {
          var a = void 0;
          if (t)
            for (var o = r.length - 1; 0 <= o; o--) {
              var s = r[o],
                c = s.instance,
                l = s.currentTarget;
              if (((s = s.listener), c !== a && i.isPropagationStopped()))
                break a;
              ((a = s), (i.currentTarget = l));
              try {
                a(i);
              } catch (e) {
                Jr(e);
              }
              ((i.currentTarget = null), (a = c));
            }
          else
            for (o = 0; o < r.length; o++) {
              if (
                ((s = r[o]),
                (c = s.instance),
                (l = s.currentTarget),
                (s = s.listener),
                c !== a && i.isPropagationStopped())
              )
                break a;
              ((a = s), (i.currentTarget = l));
              try {
                a(i);
              } catch (e) {
                Jr(e);
              }
              ((i.currentTarget = null), (a = c));
            }
        }
      }
    }
    function Q(e, t) {
      var n = t[ft];
      n === void 0 && (n = t[ft] = new Set());
      var r = e + `__bubble`;
      n.has(r) || (Cd(t, e, 2, !1), n.add(r));
    }
    function bd(e, t, n) {
      var r = 0;
      (t && (r |= 4), Cd(n, e, r, t));
    }
    var xd = `_reactListening` + Math.random().toString(36).slice(2);
    function Sd(e) {
      if (!e[xd]) {
        ((e[xd] = !0),
          Ct.forEach(function (t) {
            t !== `selectionchange` &&
              (vd.has(t) || bd(t, !1, e), bd(t, !0, e));
          }));
        var t = e.nodeType === 9 ? e : e.ownerDocument;
        t === null || t[xd] || ((t[xd] = !0), bd(`selectionchange`, !1, t));
      }
    }
    function Cd(e, t, n, r) {
      switch (mp(t)) {
        case 2:
          var i = cp;
          break;
        case 8:
          i = lp;
          break;
        default:
          i = up;
      }
      ((n = i.bind(null, t, n, e)),
        (i = void 0),
        !ln ||
          (t !== `touchstart` && t !== `touchmove` && t !== `wheel`) ||
          (i = !0),
        r
          ? i === void 0
            ? e.addEventListener(t, n, !0)
            : e.addEventListener(t, n, { capture: !0, passive: i })
          : i === void 0
            ? e.addEventListener(t, n, !1)
            : e.addEventListener(t, n, { passive: i }));
    }
    function wd(e, t, n, r, i) {
      var a = r;
      if (!(t & 1) && !(t & 2) && r !== null)
        a: for (;;) {
          if (r === null) return;
          var s = r.tag;
          if (s === 3 || s === 4) {
            var c = r.stateNode.containerInfo;
            if (c === i) break;
            if (s === 4)
              for (s = r.return; s !== null;) {
                var l = s.tag;
                if ((l === 3 || l === 4) && s.stateNode.containerInfo === i)
                  return;
                s = s.return;
              }
            for (; c !== null;) {
              if (((s = vt(c)), s === null)) return;
              if (((l = s.tag), l === 5 || l === 6 || l === 26 || l === 27)) {
                r = a = s;
                continue a;
              }
              c = c.parentNode;
            }
          }
          r = r.return;
        }
      on(function () {
        var r = a,
          i = en(n),
          s = [];
        a: {
          var c = Gr.get(e);
          if (c !== void 0) {
            var l = yn,
              u = e;
            switch (e) {
              case `keypress`:
                if (mn(n) === 0) break a;
              case `keydown`:
              case `keyup`:
                l = Ln;
                break;
              case `focusin`:
                ((u = `focus`), (l = On));
                break;
              case `focusout`:
                ((u = `blur`), (l = On));
                break;
              case `beforeblur`:
              case `afterblur`:
                l = On;
                break;
              case `click`:
                if (n.button === 2) break a;
              case `auxclick`:
              case `dblclick`:
              case `mousedown`:
              case `mousemove`:
              case `mouseup`:
              case `mouseout`:
              case `mouseover`:
              case `contextmenu`:
                l = En;
                break;
              case `drag`:
              case `dragend`:
              case `dragenter`:
              case `dragexit`:
              case `dragleave`:
              case `dragover`:
              case `dragstart`:
              case `drop`:
                l = Dn;
                break;
              case `touchcancel`:
              case `touchend`:
              case `touchmove`:
              case `touchstart`:
                l = zn;
                break;
              case Rr:
              case zr:
              case Br:
                l = kn;
                break;
              case Wr:
                l = Bn;
                break;
              case `scroll`:
              case `scrollend`:
                l = xn;
                break;
              case `wheel`:
                l = Vn;
                break;
              case `copy`:
              case `cut`:
              case `paste`:
                l = An;
                break;
              case `gotpointercapture`:
              case `lostpointercapture`:
              case `pointercancel`:
              case `pointerdown`:
              case `pointermove`:
              case `pointerout`:
              case `pointerover`:
              case `pointerup`:
                l = Rn;
                break;
              case `toggle`:
              case `beforetoggle`:
                l = Hn;
            }
            var d = !!(t & 4),
              f = !d && (e === `scroll` || e === `scrollend`),
              p = d ? (c === null ? null : c + `Capture`) : c;
            d = [];
            for (var m = r, h; m !== null;) {
              var g = m;
              if (
                ((h = g.stateNode),
                (g = g.tag),
                (g !== 5 && g !== 26 && g !== 27) ||
                  h === null ||
                  p === null ||
                  ((g = sn(m, p)), g != null && d.push(Td(m, g, h))),
                f)
              )
                break;
              m = m.return;
            }
            0 < d.length &&
              ((c = new l(c, u, null, n, i)),
              s.push({ event: c, listeners: d }));
          }
        }
        if (!(t & 7)) {
          a: {
            if (
              ((c = e === `mouseover` || e === `pointerover`),
              (l = e === `mouseout` || e === `pointerout`),
              c &&
                n !== $t &&
                (u = n.relatedTarget || n.fromElement) &&
                (vt(u) || u[dt]))
            )
              break a;
            if (
              (l || c) &&
              ((c =
                i.window === i
                  ? i
                  : (c = i.ownerDocument)
                    ? c.defaultView || c.parentWindow
                    : window),
              l
                ? ((u = n.relatedTarget || n.toElement),
                  (l = r),
                  (u = u ? vt(u) : null),
                  u !== null &&
                    ((f = o(u)),
                    (d = u.tag),
                    u !== f || (d !== 5 && d !== 27 && d !== 6)) &&
                    (u = null))
                : ((l = null), (u = r)),
              l !== u)
            ) {
              if (
                ((d = En),
                (g = `onMouseLeave`),
                (p = `onMouseEnter`),
                (m = `mouse`),
                (e === `pointerout` || e === `pointerover`) &&
                  ((d = Rn),
                  (g = `onPointerLeave`),
                  (p = `onPointerEnter`),
                  (m = `pointer`)),
                (f = l == null ? c : bt(l)),
                (h = u == null ? c : bt(u)),
                (c = new d(g, m + `leave`, l, n, i)),
                (c.target = f),
                (c.relatedTarget = h),
                (g = null),
                vt(i) === r &&
                  ((d = new d(p, m + `enter`, u, n, i)),
                  (d.target = h),
                  (d.relatedTarget = f),
                  (g = d)),
                (f = g),
                l && u)
              )
                b: {
                  for (d = Dd, p = l, m = u, h = 0, g = p; g; g = d(g)) h++;
                  g = 0;
                  for (var _ = m; _; _ = d(_)) g++;
                  for (; 0 < h - g;) ((p = d(p)), h--);
                  for (; 0 < g - h;) ((m = d(m)), g--);
                  for (; h--;) {
                    if (p === m || (m !== null && p === m.alternate)) {
                      d = p;
                      break b;
                    }
                    ((p = d(p)), (m = d(m)));
                  }
                  d = null;
                }
              else d = null;
              (l !== null && Od(s, c, l, d, !1),
                u !== null && f !== null && Od(s, f, u, d, !0));
            }
          }
          a: {
            if (
              ((c = r ? bt(r) : window),
              (l = c.nodeName && c.nodeName.toLowerCase()),
              l === `select` || (l === `input` && c.type === `file`))
            )
              var v = cr;
            else if (nr(c))
              if (lr) v = vr;
              else {
                v = gr;
                var y = hr;
              }
            else
              ((l = c.nodeName),
                !l ||
                l.toLowerCase() !== `input` ||
                (c.type !== `checkbox` && c.type !== `radio`)
                  ? r && Jt(r.elementType) && (v = cr)
                  : (v = _r));
            if ((v &&= v(e, r))) {
              rr(s, v, n, i);
              break a;
            }
            (y && y(e, c, r),
              e === `focusout` &&
                r &&
                c.type === `number` &&
                r.memoizedProps.value != null &&
                Bt(c, `number`, c.value));
          }
          switch (((y = r ? bt(r) : window), e)) {
            case `focusin`:
              (nr(y) || y.contentEditable === `true`) &&
                ((Or = y), (kr = r), (Ar = null));
              break;
            case `focusout`:
              Ar = kr = Or = null;
              break;
            case `mousedown`:
              jr = !0;
              break;
            case `contextmenu`:
            case `mouseup`:
            case `dragend`:
              ((jr = !1), Mr(s, n, i));
              break;
            case `selectionchange`:
              if (Dr) break;
            case `keydown`:
            case `keyup`:
              Mr(s, n, i);
          }
          var b;
          if (Wn)
            b: {
              switch (e) {
                case `compositionstart`:
                  var x = `onCompositionStart`;
                  break b;
                case `compositionend`:
                  x = `onCompositionEnd`;
                  break b;
                case `compositionupdate`:
                  x = `onCompositionUpdate`;
                  break b;
              }
              x = void 0;
            }
          else
            Qn
              ? Xn(e, n) && (x = `onCompositionEnd`)
              : e === `keydown` &&
                n.keyCode === 229 &&
                (x = `onCompositionStart`);
          (x &&
            (qn &&
              n.locale !== `ko` &&
              (Qn || x !== `onCompositionStart`
                ? x === `onCompositionEnd` && Qn && (b = pn())
                : ((un = i),
                  (dn = `value` in un ? un.value : un.textContent),
                  (Qn = !0))),
            (y = Ed(r, x)),
            0 < y.length &&
              ((x = new jn(x, e, null, n, i)),
              s.push({ event: x, listeners: y }),
              b ? (x.data = b) : ((b = Zn(n)), b !== null && (x.data = b)))),
            (b = Kn ? $n(e, n) : er(e, n)) &&
              ((x = Ed(r, `onBeforeInput`)),
              0 < x.length &&
                ((y = new jn(`onBeforeInput`, `beforeinput`, null, n, i)),
                s.push({ event: y, listeners: x }),
                (y.data = b))),
            md(s, e, r, n, i));
        }
        yd(s, t);
      });
    }
    function Td(e, t, n) {
      return { instance: e, listener: t, currentTarget: n };
    }
    function Ed(e, t) {
      for (var n = t + `Capture`, r = []; e !== null;) {
        var i = e,
          a = i.stateNode;
        if (
          ((i = i.tag),
          (i !== 5 && i !== 26 && i !== 27) ||
            a === null ||
            ((i = sn(e, n)),
            i != null && r.unshift(Td(e, i, a)),
            (i = sn(e, t)),
            i != null && r.push(Td(e, i, a))),
          e.tag === 3)
        )
          return r;
        e = e.return;
      }
      return [];
    }
    function Dd(e) {
      if (e === null) return null;
      do e = e.return;
      while (e && e.tag !== 5 && e.tag !== 27);
      return e || null;
    }
    function Od(e, t, n, r, i) {
      for (var a = t._reactName, o = []; n !== null && n !== r;) {
        var s = n,
          c = s.alternate,
          l = s.stateNode;
        if (((s = s.tag), c !== null && c === r)) break;
        ((s !== 5 && s !== 26 && s !== 27) ||
          l === null ||
          ((c = l),
          i
            ? ((l = sn(n, a)), l != null && o.unshift(Td(n, l, c)))
            : i || ((l = sn(n, a)), l != null && o.push(Td(n, l, c)))),
          (n = n.return));
      }
      o.length !== 0 && e.push({ event: t, listeners: o });
    }
    var kd = /\r\n?/g,
      Ad = /\u0000|\uFFFD/g;
    function jd(e) {
      return (typeof e == `string` ? e : `` + e)
        .replace(
          kd,
          `
`,
        )
        .replace(Ad, ``);
    }
    function Md(e, t) {
      return ((t = jd(t)), jd(e) === t);
    }
    function $(e, t, n, r, a, o) {
      switch (n) {
        case `children`:
          typeof r == `string`
            ? t === `body` || (t === `textarea` && r === ``) || Wt(e, r)
            : (typeof r == `number` || typeof r == `bigint`) &&
              t !== `body` &&
              Wt(e, `` + r);
          break;
        case `className`:
          I(e, `class`, r);
          break;
        case `tabIndex`:
          I(e, `tabindex`, r);
          break;
        case `dir`:
        case `role`:
        case `viewBox`:
        case `width`:
        case `height`:
          I(e, n, r);
          break;
        case `style`:
          qt(e, r, o);
          break;
        case `data`:
          if (t !== `object`) {
            I(e, `data`, r);
            break;
          }
        case `src`:
        case `href`:
          if (r === `` && (t !== `a` || n !== `href`)) {
            e.removeAttribute(n);
            break;
          }
          if (
            r == null ||
            typeof r == `function` ||
            typeof r == `symbol` ||
            typeof r == `boolean`
          ) {
            e.removeAttribute(n);
            break;
          }
          ((r = Zt(`` + r)), e.setAttribute(n, r));
          break;
        case `action`:
        case `formAction`:
          if (typeof r == `function`) {
            e.setAttribute(
              n,
              `javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')`,
            );
            break;
          }
          if (
            (typeof o == `function` &&
              (n === `formAction`
                ? (t !== `input` && $(e, t, `name`, a.name, a, null),
                  $(e, t, `formEncType`, a.formEncType, a, null),
                  $(e, t, `formMethod`, a.formMethod, a, null),
                  $(e, t, `formTarget`, a.formTarget, a, null))
                : ($(e, t, `encType`, a.encType, a, null),
                  $(e, t, `method`, a.method, a, null),
                  $(e, t, `target`, a.target, a, null))),
            r == null || typeof r == `symbol` || typeof r == `boolean`)
          ) {
            e.removeAttribute(n);
            break;
          }
          ((r = Zt(`` + r)), e.setAttribute(n, r));
          break;
        case `onClick`:
          r != null && (e.onclick = Qt);
          break;
        case `onScroll`:
          r != null && Q(`scroll`, e);
          break;
        case `onScrollEnd`:
          r != null && Q(`scrollend`, e);
          break;
        case `dangerouslySetInnerHTML`:
          if (r != null) {
            if (typeof r != `object` || !(`__html` in r)) throw Error(i(61));
            if (((n = r.__html), n != null)) {
              if (a.children != null) throw Error(i(60));
              e.innerHTML = n;
            }
          }
          break;
        case `multiple`:
          e.multiple = r && typeof r != `function` && typeof r != `symbol`;
          break;
        case `muted`:
          e.muted = r && typeof r != `function` && typeof r != `symbol`;
          break;
        case `suppressContentEditableWarning`:
        case `suppressHydrationWarning`:
        case `defaultValue`:
        case `defaultChecked`:
        case `innerHTML`:
        case `ref`:
          break;
        case `autoFocus`:
          break;
        case `xlinkHref`:
          if (
            r == null ||
            typeof r == `function` ||
            typeof r == `boolean` ||
            typeof r == `symbol`
          ) {
            e.removeAttribute(`xlink:href`);
            break;
          }
          ((n = Zt(`` + r)),
            e.setAttributeNS(`http://www.w3.org/1999/xlink`, `xlink:href`, n));
          break;
        case `contentEditable`:
        case `spellCheck`:
        case `draggable`:
        case `value`:
        case `autoReverse`:
        case `externalResourcesRequired`:
        case `focusable`:
        case `preserveAlpha`:
          r != null && typeof r != `function` && typeof r != `symbol`
            ? e.setAttribute(n, `` + r)
            : e.removeAttribute(n);
          break;
        case `inert`:
        case `allowFullScreen`:
        case `async`:
        case `autoPlay`:
        case `controls`:
        case `default`:
        case `defer`:
        case `disabled`:
        case `disablePictureInPicture`:
        case `disableRemotePlayback`:
        case `formNoValidate`:
        case `hidden`:
        case `loop`:
        case `noModule`:
        case `noValidate`:
        case `open`:
        case `playsInline`:
        case `readOnly`:
        case `required`:
        case `reversed`:
        case `scoped`:
        case `seamless`:
        case `itemScope`:
          r && typeof r != `function` && typeof r != `symbol`
            ? e.setAttribute(n, ``)
            : e.removeAttribute(n);
          break;
        case `capture`:
        case `download`:
          !0 === r
            ? e.setAttribute(n, ``)
            : !1 !== r &&
                r != null &&
                typeof r != `function` &&
                typeof r != `symbol`
              ? e.setAttribute(n, r)
              : e.removeAttribute(n);
          break;
        case `cols`:
        case `rows`:
        case `size`:
        case `span`:
          r != null &&
          typeof r != `function` &&
          typeof r != `symbol` &&
          !isNaN(r) &&
          1 <= r
            ? e.setAttribute(n, r)
            : e.removeAttribute(n);
          break;
        case `rowSpan`:
        case `start`:
          r == null ||
          typeof r == `function` ||
          typeof r == `symbol` ||
          isNaN(r)
            ? e.removeAttribute(n)
            : e.setAttribute(n, r);
          break;
        case `popover`:
          (Q(`beforetoggle`, e), Q(`toggle`, e), jt(e, `popover`, r));
          break;
        case `xlinkActuate`:
          L(e, `http://www.w3.org/1999/xlink`, `xlink:actuate`, r);
          break;
        case `xlinkArcrole`:
          L(e, `http://www.w3.org/1999/xlink`, `xlink:arcrole`, r);
          break;
        case `xlinkRole`:
          L(e, `http://www.w3.org/1999/xlink`, `xlink:role`, r);
          break;
        case `xlinkShow`:
          L(e, `http://www.w3.org/1999/xlink`, `xlink:show`, r);
          break;
        case `xlinkTitle`:
          L(e, `http://www.w3.org/1999/xlink`, `xlink:title`, r);
          break;
        case `xlinkType`:
          L(e, `http://www.w3.org/1999/xlink`, `xlink:type`, r);
          break;
        case `xmlBase`:
          L(e, `http://www.w3.org/XML/1998/namespace`, `xml:base`, r);
          break;
        case `xmlLang`:
          L(e, `http://www.w3.org/XML/1998/namespace`, `xml:lang`, r);
          break;
        case `xmlSpace`:
          L(e, `http://www.w3.org/XML/1998/namespace`, `xml:space`, r);
          break;
        case `is`:
          jt(e, `is`, r);
          break;
        case `innerText`:
        case `textContent`:
          break;
        default:
          (!(2 < n.length) ||
            (n[0] !== `o` && n[0] !== `O`) ||
            (n[1] !== `n` && n[1] !== `N`)) &&
            ((n = Yt.get(n) || n), jt(e, n, r));
      }
    }
    function Nd(e, t, n, r, a, o) {
      switch (n) {
        case `style`:
          qt(e, r, o);
          break;
        case `dangerouslySetInnerHTML`:
          if (r != null) {
            if (typeof r != `object` || !(`__html` in r)) throw Error(i(61));
            if (((n = r.__html), n != null)) {
              if (a.children != null) throw Error(i(60));
              e.innerHTML = n;
            }
          }
          break;
        case `children`:
          typeof r == `string`
            ? Wt(e, r)
            : (typeof r == `number` || typeof r == `bigint`) && Wt(e, `` + r);
          break;
        case `onScroll`:
          r != null && Q(`scroll`, e);
          break;
        case `onScrollEnd`:
          r != null && Q(`scrollend`, e);
          break;
        case `onClick`:
          r != null && (e.onclick = Qt);
          break;
        case `suppressContentEditableWarning`:
        case `suppressHydrationWarning`:
        case `innerHTML`:
        case `ref`:
          break;
        case `innerText`:
        case `textContent`:
          break;
        default:
          if (!wt.hasOwnProperty(n))
            a: {
              if (
                n[0] === `o` &&
                n[1] === `n` &&
                ((a = n.endsWith(`Capture`)),
                (t = n.slice(2, a ? n.length - 7 : void 0)),
                (o = e[ut] || null),
                (o = o == null ? null : o[n]),
                typeof o == `function` && e.removeEventListener(t, o, a),
                typeof r == `function`)
              ) {
                (typeof o != `function` &&
                  o !== null &&
                  (n in e
                    ? (e[n] = null)
                    : e.hasAttribute(n) && e.removeAttribute(n)),
                  e.addEventListener(t, r, a));
                break a;
              }
              n in e
                ? (e[n] = r)
                : !0 === r
                  ? e.setAttribute(n, ``)
                  : jt(e, n, r);
            }
      }
    }
    function Pd(e, t, n) {
      switch (t) {
        case `div`:
        case `span`:
        case `svg`:
        case `path`:
        case `a`:
        case `g`:
        case `p`:
        case `li`:
          break;
        case `img`:
          (Q(`error`, e), Q(`load`, e));
          var r = !1,
            a = !1,
            o;
          for (o in n)
            if (n.hasOwnProperty(o)) {
              var s = n[o];
              if (s != null)
                switch (o) {
                  case `src`:
                    r = !0;
                    break;
                  case `srcSet`:
                    a = !0;
                    break;
                  case `children`:
                  case `dangerouslySetInnerHTML`:
                    throw Error(i(137, t));
                  default:
                    $(e, t, o, s, n, null);
                }
            }
          (a && $(e, t, `srcSet`, n.srcSet, n, null),
            r && $(e, t, `src`, n.src, n, null));
          return;
        case `input`:
          Q(`invalid`, e);
          var c = (o = s = a = null),
            l = null,
            u = null;
          for (r in n)
            if (n.hasOwnProperty(r)) {
              var d = n[r];
              if (d != null)
                switch (r) {
                  case `name`:
                    a = d;
                    break;
                  case `type`:
                    s = d;
                    break;
                  case `checked`:
                    l = d;
                    break;
                  case `defaultChecked`:
                    u = d;
                    break;
                  case `value`:
                    o = d;
                    break;
                  case `defaultValue`:
                    c = d;
                    break;
                  case `children`:
                  case `dangerouslySetInnerHTML`:
                    if (d != null) throw Error(i(137, t));
                    break;
                  default:
                    $(e, t, r, d, n, null);
                }
            }
          zt(e, o, c, l, u, s, a, !1);
          return;
        case `select`:
          for (a in (Q(`invalid`, e), (r = s = o = null), n))
            if (n.hasOwnProperty(a) && ((c = n[a]), c != null))
              switch (a) {
                case `value`:
                  o = c;
                  break;
                case `defaultValue`:
                  s = c;
                  break;
                case `multiple`:
                  r = c;
                default:
                  $(e, t, a, c, n, null);
              }
          ((t = o),
            (n = s),
            (e.multiple = !!r),
            t == null ? n != null && Vt(e, !!r, n, !0) : Vt(e, !!r, t, !1));
          return;
        case `textarea`:
          for (s in (Q(`invalid`, e), (o = a = r = null), n))
            if (n.hasOwnProperty(s) && ((c = n[s]), c != null))
              switch (s) {
                case `value`:
                  r = c;
                  break;
                case `defaultValue`:
                  a = c;
                  break;
                case `children`:
                  o = c;
                  break;
                case `dangerouslySetInnerHTML`:
                  if (c != null) throw Error(i(91));
                  break;
                default:
                  $(e, t, s, c, n, null);
              }
          Ut(e, r, a, o);
          return;
        case `option`:
          for (l in n)
            if (n.hasOwnProperty(l) && ((r = n[l]), r != null))
              switch (l) {
                case `selected`:
                  e.selected =
                    r && typeof r != `function` && typeof r != `symbol`;
                  break;
                default:
                  $(e, t, l, r, n, null);
              }
          return;
        case `dialog`:
          (Q(`beforetoggle`, e), Q(`toggle`, e), Q(`cancel`, e), Q(`close`, e));
          break;
        case `iframe`:
        case `object`:
          Q(`load`, e);
          break;
        case `video`:
        case `audio`:
          for (r = 0; r < _d.length; r++) Q(_d[r], e);
          break;
        case `image`:
          (Q(`error`, e), Q(`load`, e));
          break;
        case `details`:
          Q(`toggle`, e);
          break;
        case `embed`:
        case `source`:
        case `link`:
          (Q(`error`, e), Q(`load`, e));
        case `area`:
        case `base`:
        case `br`:
        case `col`:
        case `hr`:
        case `keygen`:
        case `meta`:
        case `param`:
        case `track`:
        case `wbr`:
        case `menuitem`:
          for (u in n)
            if (n.hasOwnProperty(u) && ((r = n[u]), r != null))
              switch (u) {
                case `children`:
                case `dangerouslySetInnerHTML`:
                  throw Error(i(137, t));
                default:
                  $(e, t, u, r, n, null);
              }
          return;
        default:
          if (Jt(t)) {
            for (d in n)
              n.hasOwnProperty(d) &&
                ((r = n[d]), r !== void 0 && Nd(e, t, d, r, n, void 0));
            return;
          }
      }
      for (c in n)
        n.hasOwnProperty(c) &&
          ((r = n[c]), r != null && $(e, t, c, r, n, null));
    }
    function Fd(e, t, n, r) {
      switch (t) {
        case `div`:
        case `span`:
        case `svg`:
        case `path`:
        case `a`:
        case `g`:
        case `p`:
        case `li`:
          break;
        case `input`:
          var a = null,
            o = null,
            s = null,
            c = null,
            l = null,
            u = null,
            d = null;
          for (m in n) {
            var f = n[m];
            if (n.hasOwnProperty(m) && f != null)
              switch (m) {
                case `checked`:
                  break;
                case `value`:
                  break;
                case `defaultValue`:
                  l = f;
                default:
                  r.hasOwnProperty(m) || $(e, t, m, null, r, f);
              }
          }
          for (var p in r) {
            var m = r[p];
            if (((f = n[p]), r.hasOwnProperty(p) && (m != null || f != null)))
              switch (p) {
                case `type`:
                  o = m;
                  break;
                case `name`:
                  a = m;
                  break;
                case `checked`:
                  u = m;
                  break;
                case `defaultChecked`:
                  d = m;
                  break;
                case `value`:
                  s = m;
                  break;
                case `defaultValue`:
                  c = m;
                  break;
                case `children`:
                case `dangerouslySetInnerHTML`:
                  if (m != null) throw Error(i(137, t));
                  break;
                default:
                  m !== f && $(e, t, p, m, r, f);
              }
          }
          Rt(e, s, c, l, u, d, o, a);
          return;
        case `select`:
          for (o in ((m = s = c = p = null), n))
            if (((l = n[o]), n.hasOwnProperty(o) && l != null))
              switch (o) {
                case `value`:
                  break;
                case `multiple`:
                  m = l;
                default:
                  r.hasOwnProperty(o) || $(e, t, o, null, r, l);
              }
          for (a in r)
            if (
              ((o = r[a]),
              (l = n[a]),
              r.hasOwnProperty(a) && (o != null || l != null))
            )
              switch (a) {
                case `value`:
                  p = o;
                  break;
                case `defaultValue`:
                  c = o;
                  break;
                case `multiple`:
                  s = o;
                default:
                  o !== l && $(e, t, a, o, r, l);
              }
          ((t = c),
            (n = s),
            (r = m),
            p == null
              ? !!r != !!n &&
                (t == null ? Vt(e, !!n, n ? [] : ``, !1) : Vt(e, !!n, t, !0))
              : Vt(e, !!n, p, !1));
          return;
        case `textarea`:
          for (c in ((m = p = null), n))
            if (
              ((a = n[c]),
              n.hasOwnProperty(c) && a != null && !r.hasOwnProperty(c))
            )
              switch (c) {
                case `value`:
                  break;
                case `children`:
                  break;
                default:
                  $(e, t, c, null, r, a);
              }
          for (s in r)
            if (
              ((a = r[s]),
              (o = n[s]),
              r.hasOwnProperty(s) && (a != null || o != null))
            )
              switch (s) {
                case `value`:
                  p = a;
                  break;
                case `defaultValue`:
                  m = a;
                  break;
                case `children`:
                  break;
                case `dangerouslySetInnerHTML`:
                  if (a != null) throw Error(i(91));
                  break;
                default:
                  a !== o && $(e, t, s, a, r, o);
              }
          Ht(e, p, m);
          return;
        case `option`:
          for (var h in n)
            if (
              ((p = n[h]),
              n.hasOwnProperty(h) && p != null && !r.hasOwnProperty(h))
            )
              switch (h) {
                case `selected`:
                  e.selected = !1;
                  break;
                default:
                  $(e, t, h, null, r, p);
              }
          for (l in r)
            if (
              ((p = r[l]),
              (m = n[l]),
              r.hasOwnProperty(l) && p !== m && (p != null || m != null))
            )
              switch (l) {
                case `selected`:
                  e.selected =
                    p && typeof p != `function` && typeof p != `symbol`;
                  break;
                default:
                  $(e, t, l, p, r, m);
              }
          return;
        case `img`:
        case `link`:
        case `area`:
        case `base`:
        case `br`:
        case `col`:
        case `embed`:
        case `hr`:
        case `keygen`:
        case `meta`:
        case `param`:
        case `source`:
        case `track`:
        case `wbr`:
        case `menuitem`:
          for (var g in n)
            ((p = n[g]),
              n.hasOwnProperty(g) &&
                p != null &&
                !r.hasOwnProperty(g) &&
                $(e, t, g, null, r, p));
          for (u in r)
            if (
              ((p = r[u]),
              (m = n[u]),
              r.hasOwnProperty(u) && p !== m && (p != null || m != null))
            )
              switch (u) {
                case `children`:
                case `dangerouslySetInnerHTML`:
                  if (p != null) throw Error(i(137, t));
                  break;
                default:
                  $(e, t, u, p, r, m);
              }
          return;
        default:
          if (Jt(t)) {
            for (var _ in n)
              ((p = n[_]),
                n.hasOwnProperty(_) &&
                  p !== void 0 &&
                  !r.hasOwnProperty(_) &&
                  Nd(e, t, _, void 0, r, p));
            for (d in r)
              ((p = r[d]),
                (m = n[d]),
                !r.hasOwnProperty(d) ||
                  p === m ||
                  (p === void 0 && m === void 0) ||
                  Nd(e, t, d, p, r, m));
            return;
          }
      }
      for (var v in n)
        ((p = n[v]),
          n.hasOwnProperty(v) &&
            p != null &&
            !r.hasOwnProperty(v) &&
            $(e, t, v, null, r, p));
      for (f in r)
        ((p = r[f]),
          (m = n[f]),
          !r.hasOwnProperty(f) ||
            p === m ||
            (p == null && m == null) ||
            $(e, t, f, p, r, m));
    }
    function Id(e) {
      switch (e) {
        case `css`:
        case `script`:
        case `font`:
        case `img`:
        case `image`:
        case `input`:
        case `link`:
          return !0;
        default:
          return !1;
      }
    }
    function Ld() {
      if (typeof performance.getEntriesByType == `function`) {
        for (
          var e = 0, t = 0, n = performance.getEntriesByType(`resource`), r = 0;
          r < n.length;
          r++
        ) {
          var i = n[r],
            a = i.transferSize,
            o = i.initiatorType,
            s = i.duration;
          if (a && s && Id(o)) {
            for (o = 0, s = i.responseEnd, r += 1; r < n.length; r++) {
              var c = n[r],
                l = c.startTime;
              if (l > s) break;
              var u = c.transferSize,
                d = c.initiatorType;
              u &&
                Id(d) &&
                ((c = c.responseEnd),
                (o += u * (c < s ? 1 : (s - l) / (c - l))));
            }
            if ((--r, (t += (8 * (a + o)) / (i.duration / 1e3)), e++, 10 < e))
              break;
          }
        }
        if (0 < e) return t / e / 1e6;
      }
      return navigator.connection &&
        ((e = navigator.connection.downlink), typeof e == `number`)
        ? e
        : 5;
    }
    var Rd = null,
      zd = null;
    function Bd(e) {
      return e.nodeType === 9 ? e : e.ownerDocument;
    }
    function Vd(e) {
      switch (e) {
        case `http://www.w3.org/2000/svg`:
          return 1;
        case `http://www.w3.org/1998/Math/MathML`:
          return 2;
        default:
          return 0;
      }
    }
    function Hd(e, t) {
      if (e === 0)
        switch (t) {
          case `svg`:
            return 1;
          case `math`:
            return 2;
          default:
            return 0;
        }
      return e === 1 && t === `foreignObject` ? 0 : e;
    }
    function Ud(e, t) {
      return (
        e === `textarea` ||
        e === `noscript` ||
        typeof t.children == `string` ||
        typeof t.children == `number` ||
        typeof t.children == `bigint` ||
        (typeof t.dangerouslySetInnerHTML == `object` &&
          t.dangerouslySetInnerHTML !== null &&
          t.dangerouslySetInnerHTML.__html != null)
      );
    }
    var Wd = null;
    function Gd() {
      var e = window.event;
      return e && e.type === `popstate`
        ? e !== Wd && ((Wd = e), !0)
        : ((Wd = null), !1);
    }
    var Kd = typeof setTimeout == `function` ? setTimeout : void 0,
      qd = typeof clearTimeout == `function` ? clearTimeout : void 0,
      Jd = typeof Promise == `function` ? Promise : void 0,
      Yd =
        typeof queueMicrotask == `function`
          ? queueMicrotask
          : Jd === void 0
            ? Kd
            : function (e) {
                return Jd.resolve(null).then(e).catch(Xd);
              };
    function Xd(e) {
      setTimeout(function () {
        throw e;
      });
    }
    function Zd(e) {
      return e === `head`;
    }
    function Qd(e, t) {
      var n = t,
        r = 0;
      do {
        var i = n.nextSibling;
        if ((e.removeChild(n), i && i.nodeType === 8))
          if (((n = i.data), n === `/$` || n === `/&`)) {
            if (r === 0) {
              (e.removeChild(i), Np(t));
              return;
            }
            r--;
          } else if (
            n === `$` ||
            n === `$?` ||
            n === `$~` ||
            n === `$!` ||
            n === `&`
          )
            r++;
          else if (n === `html`) pf(e.ownerDocument.documentElement);
          else if (n === `head`) {
            ((n = e.ownerDocument.head), pf(n));
            for (var a = n.firstChild; a;) {
              var o = a.nextSibling,
                s = a.nodeName;
              (a[gt] ||
                s === `SCRIPT` ||
                s === `STYLE` ||
                (s === `LINK` && a.rel.toLowerCase() === `stylesheet`) ||
                n.removeChild(a),
                (a = o));
            }
          } else n === `body` && pf(e.ownerDocument.body);
        n = i;
      } while (n);
      Np(t);
    }
    function $d(e, t) {
      var n = e;
      e = 0;
      do {
        var r = n.nextSibling;
        if (
          (n.nodeType === 1
            ? t
              ? ((n._stashedDisplay = n.style.display),
                (n.style.display = `none`))
              : ((n.style.display = n._stashedDisplay || ``),
                n.getAttribute(`style`) === `` && n.removeAttribute(`style`))
            : n.nodeType === 3 &&
              (t
                ? ((n._stashedText = n.nodeValue), (n.nodeValue = ``))
                : (n.nodeValue = n._stashedText || ``)),
          r && r.nodeType === 8)
        )
          if (((n = r.data), n === `/$`)) {
            if (e === 0) break;
            e--;
          } else (n !== `$` && n !== `$?` && n !== `$~` && n !== `$!`) || e++;
        n = r;
      } while (n);
    }
    function ef(e) {
      var t = e.firstChild;
      for (t && t.nodeType === 10 && (t = t.nextSibling); t;) {
        var n = t;
        switch (((t = t.nextSibling), n.nodeName)) {
          case `HTML`:
          case `HEAD`:
          case `BODY`:
            (ef(n), _t(n));
            continue;
          case `SCRIPT`:
          case `STYLE`:
            continue;
          case `LINK`:
            if (n.rel.toLowerCase() === `stylesheet`) continue;
        }
        e.removeChild(n);
      }
    }
    function tf(e, t, n, r) {
      for (; e.nodeType === 1;) {
        var i = n;
        if (e.nodeName.toLowerCase() !== t.toLowerCase()) {
          if (!r && (e.nodeName !== `INPUT` || e.type !== `hidden`)) break;
        } else if (!r)
          if (t === `input` && e.type === `hidden`) {
            var a = i.name == null ? null : `` + i.name;
            if (i.type === `hidden` && e.getAttribute(`name`) === a) return e;
          } else return e;
        else if (!e[gt])
          switch (t) {
            case `meta`:
              if (!e.hasAttribute(`itemprop`)) break;
              return e;
            case `link`:
              if (
                ((a = e.getAttribute(`rel`)),
                (a === `stylesheet` && e.hasAttribute(`data-precedence`)) ||
                  a !== i.rel ||
                  e.getAttribute(`href`) !==
                    (i.href == null || i.href === `` ? null : i.href) ||
                  e.getAttribute(`crossorigin`) !==
                    (i.crossOrigin == null ? null : i.crossOrigin) ||
                  e.getAttribute(`title`) !==
                    (i.title == null ? null : i.title))
              )
                break;
              return e;
            case `style`:
              if (e.hasAttribute(`data-precedence`)) break;
              return e;
            case `script`:
              if (
                ((a = e.getAttribute(`src`)),
                (a !== (i.src == null ? null : i.src) ||
                  e.getAttribute(`type`) !== (i.type == null ? null : i.type) ||
                  e.getAttribute(`crossorigin`) !==
                    (i.crossOrigin == null ? null : i.crossOrigin)) &&
                  a &&
                  e.hasAttribute(`async`) &&
                  !e.hasAttribute(`itemprop`))
              )
                break;
              return e;
            default:
              return e;
          }
        if (((e = cf(e.nextSibling)), e === null)) break;
      }
      return null;
    }
    function nf(e, t, n) {
      if (t === ``) return null;
      for (; e.nodeType !== 3;)
        if (
          ((e.nodeType !== 1 ||
            e.nodeName !== `INPUT` ||
            e.type !== `hidden`) &&
            !n) ||
          ((e = cf(e.nextSibling)), e === null)
        )
          return null;
      return e;
    }
    function rf(e, t) {
      for (; e.nodeType !== 8;)
        if (
          ((e.nodeType !== 1 ||
            e.nodeName !== `INPUT` ||
            e.type !== `hidden`) &&
            !t) ||
          ((e = cf(e.nextSibling)), e === null)
        )
          return null;
      return e;
    }
    function af(e) {
      return e.data === `$?` || e.data === `$~`;
    }
    function of(e) {
      return (
        e.data === `$!` ||
        (e.data === `$?` && e.ownerDocument.readyState !== `loading`)
      );
    }
    function sf(e, t) {
      var n = e.ownerDocument;
      if (e.data === `$~`) e._reactRetry = t;
      else if (e.data !== `$?` || n.readyState !== `loading`) t();
      else {
        var r = function () {
          (t(), n.removeEventListener(`DOMContentLoaded`, r));
        };
        (n.addEventListener(`DOMContentLoaded`, r), (e._reactRetry = r));
      }
    }
    function cf(e) {
      for (; e != null; e = e.nextSibling) {
        var t = e.nodeType;
        if (t === 1 || t === 3) break;
        if (t === 8) {
          if (
            ((t = e.data),
            t === `$` ||
              t === `$!` ||
              t === `$?` ||
              t === `$~` ||
              t === `&` ||
              t === `F!` ||
              t === `F`)
          )
            break;
          if (t === `/$` || t === `/&`) return null;
        }
      }
      return e;
    }
    var lf = null;
    function uf(e) {
      e = e.nextSibling;
      for (var t = 0; e;) {
        if (e.nodeType === 8) {
          var n = e.data;
          if (n === `/$` || n === `/&`) {
            if (t === 0) return cf(e.nextSibling);
            t--;
          } else
            (n !== `$` &&
              n !== `$!` &&
              n !== `$?` &&
              n !== `$~` &&
              n !== `&`) ||
              t++;
        }
        e = e.nextSibling;
      }
      return null;
    }
    function df(e) {
      e = e.previousSibling;
      for (var t = 0; e;) {
        if (e.nodeType === 8) {
          var n = e.data;
          if (
            n === `$` ||
            n === `$!` ||
            n === `$?` ||
            n === `$~` ||
            n === `&`
          ) {
            if (t === 0) return e;
            t--;
          } else (n !== `/$` && n !== `/&`) || t++;
        }
        e = e.previousSibling;
      }
      return null;
    }
    function ff(e, t, n) {
      switch (((t = Bd(n)), e)) {
        case `html`:
          if (((e = t.documentElement), !e)) throw Error(i(452));
          return e;
        case `head`:
          if (((e = t.head), !e)) throw Error(i(453));
          return e;
        case `body`:
          if (((e = t.body), !e)) throw Error(i(454));
          return e;
        default:
          throw Error(i(451));
      }
    }
    function pf(e) {
      for (var t = e.attributes; t.length;) e.removeAttributeNode(t[0]);
      _t(e);
    }
    var mf = new Map(),
      hf = new Set();
    function gf(e) {
      return typeof e.getRootNode == `function`
        ? e.getRootNode()
        : e.nodeType === 9
          ? e
          : e.ownerDocument;
    }
    var _f = T.d;
    T.d = { f: vf, r: yf, D: Sf, C: Cf, L: wf, m: Tf, X: Df, S: Ef, M: Of };
    function vf() {
      var e = _f.f(),
        t = bu();
      return e || t;
    }
    function yf(e) {
      var t = yt(e);
      t !== null && t.tag === 5 && t.type === `form` ? Ts(t) : _f.r(e);
    }
    var bf = typeof document > `u` ? null : document;
    function xf(e, t, n) {
      var r = bf;
      if (r && typeof t == `string` && t) {
        var i = Lt(t);
        ((i = `link[rel="` + e + `"][href="` + i + `"]`),
          typeof n == `string` && (i += `[crossorigin="` + n + `"]`),
          hf.has(i) ||
            (hf.add(i),
            (e = { rel: e, crossOrigin: n, href: t }),
            r.querySelector(i) === null &&
              ((t = r.createElement(`link`)),
              Pd(t, `link`, e),
              St(t),
              r.head.appendChild(t))));
      }
    }
    function Sf(e) {
      (_f.D(e), xf(`dns-prefetch`, e, null));
    }
    function Cf(e, t) {
      (_f.C(e, t), xf(`preconnect`, e, t));
    }
    function wf(e, t, n) {
      _f.L(e, t, n);
      var r = bf;
      if (r && e && t) {
        var i = `link[rel="preload"][as="` + Lt(t) + `"]`;
        t === `image` && n && n.imageSrcSet
          ? ((i += `[imagesrcset="` + Lt(n.imageSrcSet) + `"]`),
            typeof n.imageSizes == `string` &&
              (i += `[imagesizes="` + Lt(n.imageSizes) + `"]`))
          : (i += `[href="` + Lt(e) + `"]`);
        var a = i;
        switch (t) {
          case `style`:
            a = Af(e);
            break;
          case `script`:
            a = Pf(e);
        }
        mf.has(a) ||
          ((e = h(
            {
              rel: `preload`,
              href: t === `image` && n && n.imageSrcSet ? void 0 : e,
              as: t,
            },
            n,
          )),
          mf.set(a, e),
          r.querySelector(i) !== null ||
            (t === `style` && r.querySelector(jf(a))) ||
            (t === `script` && r.querySelector(Ff(a))) ||
            ((t = r.createElement(`link`)),
            Pd(t, `link`, e),
            St(t),
            r.head.appendChild(t)));
      }
    }
    function Tf(e, t) {
      _f.m(e, t);
      var n = bf;
      if (n && e) {
        var r = t && typeof t.as == `string` ? t.as : `script`,
          i =
            `link[rel="modulepreload"][as="` +
            Lt(r) +
            `"][href="` +
            Lt(e) +
            `"]`,
          a = i;
        switch (r) {
          case `audioworklet`:
          case `paintworklet`:
          case `serviceworker`:
          case `sharedworker`:
          case `worker`:
          case `script`:
            a = Pf(e);
        }
        if (
          !mf.has(a) &&
          ((e = h({ rel: `modulepreload`, href: e }, t)),
          mf.set(a, e),
          n.querySelector(i) === null)
        ) {
          switch (r) {
            case `audioworklet`:
            case `paintworklet`:
            case `serviceworker`:
            case `sharedworker`:
            case `worker`:
            case `script`:
              if (n.querySelector(Ff(a))) return;
          }
          ((r = n.createElement(`link`)),
            Pd(r, `link`, e),
            St(r),
            n.head.appendChild(r));
        }
      }
    }
    function Ef(e, t, n) {
      _f.S(e, t, n);
      var r = bf;
      if (r && e) {
        var i = xt(r).hoistableStyles,
          a = Af(e);
        t ||= `default`;
        var o = i.get(a);
        if (!o) {
          var s = { loading: 0, preload: null };
          if ((o = r.querySelector(jf(a)))) s.loading = 5;
          else {
            ((e = h({ rel: `stylesheet`, href: e, "data-precedence": t }, n)),
              (n = mf.get(a)) && Rf(e, n));
            var c = (o = r.createElement(`link`));
            (St(c),
              Pd(c, `link`, e),
              (c._p = new Promise(function (e, t) {
                ((c.onload = e), (c.onerror = t));
              })),
              c.addEventListener(`load`, function () {
                s.loading |= 1;
              }),
              c.addEventListener(`error`, function () {
                s.loading |= 2;
              }),
              (s.loading |= 4),
              Lf(o, t, r));
          }
          ((o = { type: `stylesheet`, instance: o, count: 1, state: s }),
            i.set(a, o));
        }
      }
    }
    function Df(e, t) {
      _f.X(e, t);
      var n = bf;
      if (n && e) {
        var r = xt(n).hoistableScripts,
          i = Pf(e),
          a = r.get(i);
        a ||
          ((a = n.querySelector(Ff(i))),
          a ||
            ((e = h({ src: e, async: !0 }, t)),
            (t = mf.get(i)) && zf(e, t),
            (a = n.createElement(`script`)),
            St(a),
            Pd(a, `link`, e),
            n.head.appendChild(a)),
          (a = { type: `script`, instance: a, count: 1, state: null }),
          r.set(i, a));
      }
    }
    function Of(e, t) {
      _f.M(e, t);
      var n = bf;
      if (n && e) {
        var r = xt(n).hoistableScripts,
          i = Pf(e),
          a = r.get(i);
        a ||
          ((a = n.querySelector(Ff(i))),
          a ||
            ((e = h({ src: e, async: !0, type: `module` }, t)),
            (t = mf.get(i)) && zf(e, t),
            (a = n.createElement(`script`)),
            St(a),
            Pd(a, `link`, e),
            n.head.appendChild(a)),
          (a = { type: `script`, instance: a, count: 1, state: null }),
          r.set(i, a));
      }
    }
    function kf(e, t, n, r) {
      var a = (a = ye.current) ? gf(a) : null;
      if (!a) throw Error(i(446));
      switch (e) {
        case `meta`:
        case `title`:
          return null;
        case `style`:
          return typeof n.precedence == `string` && typeof n.href == `string`
            ? ((t = Af(n.href)),
              (n = xt(a).hoistableStyles),
              (r = n.get(t)),
              r ||
                ((r = { type: `style`, instance: null, count: 0, state: null }),
                n.set(t, r)),
              r)
            : { type: `void`, instance: null, count: 0, state: null };
        case `link`:
          if (
            n.rel === `stylesheet` &&
            typeof n.href == `string` &&
            typeof n.precedence == `string`
          ) {
            e = Af(n.href);
            var o = xt(a).hoistableStyles,
              s = o.get(e);
            if (
              (s ||
                ((a = a.ownerDocument || a),
                (s = {
                  type: `stylesheet`,
                  instance: null,
                  count: 0,
                  state: { loading: 0, preload: null },
                }),
                o.set(e, s),
                (o = a.querySelector(jf(e))) &&
                  !o._p &&
                  ((s.instance = o), (s.state.loading = 5)),
                mf.has(e) ||
                  ((n = {
                    rel: `preload`,
                    as: `style`,
                    href: n.href,
                    crossOrigin: n.crossOrigin,
                    integrity: n.integrity,
                    media: n.media,
                    hrefLang: n.hrefLang,
                    referrerPolicy: n.referrerPolicy,
                  }),
                  mf.set(e, n),
                  o || Nf(a, e, n, s.state))),
              t && r === null)
            )
              throw Error(i(528, ``));
            return s;
          }
          if (t && r !== null) throw Error(i(529, ``));
          return null;
        case `script`:
          return (
            (t = n.async),
            (n = n.src),
            typeof n == `string` &&
            t &&
            typeof t != `function` &&
            typeof t != `symbol`
              ? ((t = Pf(n)),
                (n = xt(a).hoistableScripts),
                (r = n.get(t)),
                r ||
                  ((r = {
                    type: `script`,
                    instance: null,
                    count: 0,
                    state: null,
                  }),
                  n.set(t, r)),
                r)
              : { type: `void`, instance: null, count: 0, state: null }
          );
        default:
          throw Error(i(444, e));
      }
    }
    function Af(e) {
      return `href="` + Lt(e) + `"`;
    }
    function jf(e) {
      return `link[rel="stylesheet"][` + e + `]`;
    }
    function Mf(e) {
      return h({}, e, { "data-precedence": e.precedence, precedence: null });
    }
    function Nf(e, t, n, r) {
      e.querySelector(`link[rel="preload"][as="style"][` + t + `]`)
        ? (r.loading = 1)
        : ((t = e.createElement(`link`)),
          (r.preload = t),
          t.addEventListener(`load`, function () {
            return (r.loading |= 1);
          }),
          t.addEventListener(`error`, function () {
            return (r.loading |= 2);
          }),
          Pd(t, `link`, n),
          St(t),
          e.head.appendChild(t));
    }
    function Pf(e) {
      return `[src="` + Lt(e) + `"]`;
    }
    function Ff(e) {
      return `script[async]` + e;
    }
    function If(e, t, n) {
      if ((t.count++, t.instance === null))
        switch (t.type) {
          case `style`:
            var r = e.querySelector(`style[data-href~="` + Lt(n.href) + `"]`);
            if (r) return ((t.instance = r), St(r), r);
            var a = h({}, n, {
              "data-href": n.href,
              "data-precedence": n.precedence,
              href: null,
              precedence: null,
            });
            return (
              (r = (e.ownerDocument || e).createElement(`style`)),
              St(r),
              Pd(r, `style`, a),
              Lf(r, n.precedence, e),
              (t.instance = r)
            );
          case `stylesheet`:
            a = Af(n.href);
            var o = e.querySelector(jf(a));
            if (o) return ((t.state.loading |= 4), (t.instance = o), St(o), o);
            ((r = Mf(n)),
              (a = mf.get(a)) && Rf(r, a),
              (o = (e.ownerDocument || e).createElement(`link`)),
              St(o));
            var s = o;
            return (
              (s._p = new Promise(function (e, t) {
                ((s.onload = e), (s.onerror = t));
              })),
              Pd(o, `link`, r),
              (t.state.loading |= 4),
              Lf(o, n.precedence, e),
              (t.instance = o)
            );
          case `script`:
            return (
              (o = Pf(n.src)),
              (a = e.querySelector(Ff(o)))
                ? ((t.instance = a), St(a), a)
                : ((r = n),
                  (a = mf.get(o)) && ((r = h({}, n)), zf(r, a)),
                  (e = e.ownerDocument || e),
                  (a = e.createElement(`script`)),
                  St(a),
                  Pd(a, `link`, r),
                  e.head.appendChild(a),
                  (t.instance = a))
            );
          case `void`:
            return null;
          default:
            throw Error(i(443, t.type));
        }
      else
        t.type === `stylesheet` &&
          !(t.state.loading & 4) &&
          ((r = t.instance), (t.state.loading |= 4), Lf(r, n.precedence, e));
      return t.instance;
    }
    function Lf(e, t, n) {
      for (
        var r = n.querySelectorAll(
            `link[rel="stylesheet"][data-precedence],style[data-precedence]`,
          ),
          i = r.length ? r[r.length - 1] : null,
          a = i,
          o = 0;
        o < r.length;
        o++
      ) {
        var s = r[o];
        if (s.dataset.precedence === t) a = s;
        else if (a !== i) break;
      }
      a
        ? a.parentNode.insertBefore(e, a.nextSibling)
        : ((t = n.nodeType === 9 ? n.head : n),
          t.insertBefore(e, t.firstChild));
    }
    function Rf(e, t) {
      ((e.crossOrigin ??= t.crossOrigin),
        (e.referrerPolicy ??= t.referrerPolicy),
        (e.title ??= t.title));
    }
    function zf(e, t) {
      ((e.crossOrigin ??= t.crossOrigin),
        (e.referrerPolicy ??= t.referrerPolicy),
        (e.integrity ??= t.integrity));
    }
    var Bf = null;
    function Vf(e, t, n) {
      if (Bf === null) {
        var r = new Map(),
          i = (Bf = new Map());
        i.set(n, r);
      } else ((i = Bf), (r = i.get(n)), r || ((r = new Map()), i.set(n, r)));
      if (r.has(e)) return r;
      for (
        r.set(e, null), n = n.getElementsByTagName(e), i = 0;
        i < n.length;
        i++
      ) {
        var a = n[i];
        if (
          !(
            a[gt] ||
            a[F] ||
            (e === `link` && a.getAttribute(`rel`) === `stylesheet`)
          ) &&
          a.namespaceURI !== `http://www.w3.org/2000/svg`
        ) {
          var o = a.getAttribute(t) || ``;
          o = e + o;
          var s = r.get(o);
          s ? s.push(a) : r.set(o, [a]);
        }
      }
      return r;
    }
    function Hf(e, t, n) {
      ((e = e.ownerDocument || e),
        e.head.insertBefore(
          n,
          t === `title` ? e.querySelector(`head > title`) : null,
        ));
    }
    function Uf(e, t, n) {
      if (n === 1 || t.itemProp != null) return !1;
      switch (e) {
        case `meta`:
        case `title`:
          return !0;
        case `style`:
          if (
            typeof t.precedence != `string` ||
            typeof t.href != `string` ||
            t.href === ``
          )
            break;
          return !0;
        case `link`:
          if (
            typeof t.rel != `string` ||
            typeof t.href != `string` ||
            t.href === `` ||
            t.onLoad ||
            t.onError
          )
            break;
          switch (t.rel) {
            case `stylesheet`:
              return (
                (e = t.disabled),
                typeof t.precedence == `string` && e == null
              );
            default:
              return !0;
          }
        case `script`:
          if (
            t.async &&
            typeof t.async != `function` &&
            typeof t.async != `symbol` &&
            !t.onLoad &&
            !t.onError &&
            t.src &&
            typeof t.src == `string`
          )
            return !0;
      }
      return !1;
    }
    function Wf(e) {
      return !(e.type === `stylesheet` && !(e.state.loading & 3));
    }
    function Gf(e, t, n, r) {
      if (
        n.type === `stylesheet` &&
        (typeof r.media != `string` || !1 !== matchMedia(r.media).matches) &&
        !(n.state.loading & 4)
      ) {
        if (n.instance === null) {
          var i = Af(r.href),
            a = t.querySelector(jf(i));
          if (a) {
            ((t = a._p),
              typeof t == `object` &&
                t &&
                typeof t.then == `function` &&
                (e.count++, (e = Jf.bind(e)), t.then(e, e)),
              (n.state.loading |= 4),
              (n.instance = a),
              St(a));
            return;
          }
          ((a = t.ownerDocument || t),
            (r = Mf(r)),
            (i = mf.get(i)) && Rf(r, i),
            (a = a.createElement(`link`)),
            St(a));
          var o = a;
          ((o._p = new Promise(function (e, t) {
            ((o.onload = e), (o.onerror = t));
          })),
            Pd(a, `link`, r),
            (n.instance = a));
        }
        (e.stylesheets === null && (e.stylesheets = new Map()),
          e.stylesheets.set(n, t),
          (t = n.state.preload) &&
            !(n.state.loading & 3) &&
            (e.count++,
            (n = Jf.bind(e)),
            t.addEventListener(`load`, n),
            t.addEventListener(`error`, n)));
      }
    }
    var Kf = 0;
    function qf(e, t) {
      return (
        e.stylesheets && e.count === 0 && Xf(e, e.stylesheets),
        0 < e.count || 0 < e.imgCount
          ? function (n) {
              var r = setTimeout(function () {
                if ((e.stylesheets && Xf(e, e.stylesheets), e.unsuspend)) {
                  var t = e.unsuspend;
                  ((e.unsuspend = null), t());
                }
              }, 6e4 + t);
              0 < e.imgBytes && Kf === 0 && (Kf = 62500 * Ld());
              var i = setTimeout(
                function () {
                  if (
                    ((e.waitingForImages = !1),
                    e.count === 0 &&
                      (e.stylesheets && Xf(e, e.stylesheets), e.unsuspend))
                  ) {
                    var t = e.unsuspend;
                    ((e.unsuspend = null), t());
                  }
                },
                (e.imgBytes > Kf ? 50 : 800) + t,
              );
              return (
                (e.unsuspend = n),
                function () {
                  ((e.unsuspend = null), clearTimeout(r), clearTimeout(i));
                }
              );
            }
          : null
      );
    }
    function Jf() {
      if (
        (this.count--,
        this.count === 0 && (this.imgCount === 0 || !this.waitingForImages))
      ) {
        if (this.stylesheets) Xf(this, this.stylesheets);
        else if (this.unsuspend) {
          var e = this.unsuspend;
          ((this.unsuspend = null), e());
        }
      }
    }
    var Yf = null;
    function Xf(e, t) {
      ((e.stylesheets = null),
        e.unsuspend !== null &&
          (e.count++,
          (Yf = new Map()),
          t.forEach(Zf, e),
          (Yf = null),
          Jf.call(e)));
    }
    function Zf(e, t) {
      if (!(t.state.loading & 4)) {
        var n = Yf.get(e);
        if (n) var r = n.get(null);
        else {
          ((n = new Map()), Yf.set(e, n));
          for (
            var i = e.querySelectorAll(
                `link[data-precedence],style[data-precedence]`,
              ),
              a = 0;
            a < i.length;
            a++
          ) {
            var o = i[a];
            (o.nodeName === `LINK` || o.getAttribute(`media`) !== `not all`) &&
              (n.set(o.dataset.precedence, o), (r = o));
          }
          r && n.set(null, r);
        }
        ((i = t.instance),
          (o = i.getAttribute(`data-precedence`)),
          (a = n.get(o) || r),
          a === r && n.set(null, i),
          n.set(o, i),
          this.count++,
          (r = Jf.bind(this)),
          i.addEventListener(`load`, r),
          i.addEventListener(`error`, r),
          a
            ? a.parentNode.insertBefore(i, a.nextSibling)
            : ((e = e.nodeType === 9 ? e.head : e),
              e.insertBefore(i, e.firstChild)),
          (t.state.loading |= 4));
      }
    }
    var Qf = {
      $$typeof: S,
      Provider: null,
      Consumer: null,
      _currentValue: fe,
      _currentValue2: fe,
      _threadCount: 0,
    };
    function $f(e, t, n, r, i, a, o, s, c) {
      ((this.tag = 1),
        (this.containerInfo = e),
        (this.pingCache = this.current = this.pendingChildren = null),
        (this.timeoutHandle = -1),
        (this.callbackNode =
          this.next =
          this.pendingContext =
          this.context =
          this.cancelPendingCommit =
            null),
        (this.callbackPriority = 0),
        (this.expirationTimes = it(-1)),
        (this.entangledLanes =
          this.shellSuspendCounter =
          this.errorRecoveryDisabledLanes =
          this.expiredLanes =
          this.warmLanes =
          this.pingedLanes =
          this.suspendedLanes =
          this.pendingLanes =
            0),
        (this.entanglements = it(0)),
        (this.hiddenUpdates = it(null)),
        (this.identifierPrefix = r),
        (this.onUncaughtError = i),
        (this.onCaughtError = a),
        (this.onRecoverableError = o),
        (this.pooledCache = null),
        (this.pooledCacheLanes = 0),
        (this.formState = c),
        (this.incompleteTransitions = new Map()));
    }
    function ep(e, t, n, r, i, a, o, s, c, l, u, d) {
      return (
        (e = new $f(e, t, n, o, c, l, u, d, s)),
        (t = 1),
        !0 === a && (t |= 24),
        (a = oi(3, null, null, t)),
        (e.current = a),
        (a.stateNode = e),
        (t = aa()),
        t.refCount++,
        (e.pooledCache = t),
        t.refCount++,
        (a.memoizedState = { element: r, isDehydrated: n, cache: t }),
        Ra(a),
        e
      );
    }
    function tp(e) {
      return e ? ((e = ii), e) : ii;
    }
    function np(e, t, n, r, i, a) {
      ((i = tp(i)),
        r.context === null ? (r.context = i) : (r.pendingContext = i),
        (r = Ba(t)),
        (r.payload = { element: n }),
        (a = a === void 0 ? null : a),
        a !== null && (r.callback = a),
        (n = Va(e, r, t)),
        n !== null && (hu(n, e, t), Ha(n, e, t)));
    }
    function rp(e, t) {
      if (((e = e.memoizedState), e !== null && e.dehydrated !== null)) {
        var n = e.retryLane;
        e.retryLane = n !== 0 && n < t ? n : t;
      }
    }
    function ip(e, t) {
      (rp(e, t), (e = e.alternate) && rp(e, t));
    }
    function ap(e) {
      if (e.tag === 13 || e.tag === 31) {
        var t = ti(e, 67108864);
        (t !== null && hu(t, e, 67108864), ip(e, 67108864));
      }
    }
    function op(e) {
      if (e.tag === 13 || e.tag === 31) {
        var t = pu();
        t = st(t);
        var n = ti(e, t);
        (n !== null && hu(n, e, t), ip(e, t));
      }
    }
    var sp = !0;
    function cp(e, t, n, r) {
      var i = w.T;
      w.T = null;
      var a = T.p;
      try {
        ((T.p = 2), up(e, t, n, r));
      } finally {
        ((T.p = a), (w.T = i));
      }
    }
    function lp(e, t, n, r) {
      var i = w.T;
      w.T = null;
      var a = T.p;
      try {
        ((T.p = 8), up(e, t, n, r));
      } finally {
        ((T.p = a), (w.T = i));
      }
    }
    function up(e, t, n, r) {
      if (sp) {
        var i = dp(r);
        if (i === null) (wd(e, t, r, fp, n), Cp(e, r));
        else if (Tp(i, e, t, n, r)) r.stopPropagation();
        else if ((Cp(e, r), t & 4 && -1 < Sp.indexOf(e))) {
          for (; i !== null;) {
            var a = yt(i);
            if (a !== null)
              switch (a.tag) {
                case 3:
                  if (
                    ((a = a.stateNode), a.current.memoizedState.isDehydrated)
                  ) {
                    var o = et(a.pendingLanes);
                    if (o !== 0) {
                      var s = a;
                      for (s.pendingLanes |= 2, s.entangledLanes |= 2; o;) {
                        var c = 1 << (31 - qe(o));
                        ((s.entanglements[1] |= c), (o &= ~c));
                      }
                      (rd(a), !(K & 6) && ((tu = Le() + 500), id(0, !1)));
                    }
                  }
                  break;
                case 31:
                case 13:
                  ((s = ti(a, 2)), s !== null && hu(s, a, 2), bu(), ip(a, 2));
              }
            if (((a = dp(r)), a === null && wd(e, t, r, fp, n), a === i)) break;
            i = a;
          }
          i !== null && r.stopPropagation();
        } else wd(e, t, r, null, n);
      }
    }
    function dp(e) {
      return ((e = en(e)), pp(e));
    }
    var fp = null;
    function pp(e) {
      if (((fp = null), (e = vt(e)), e !== null)) {
        var t = o(e);
        if (t === null) e = null;
        else {
          var n = t.tag;
          if (n === 13) {
            if (((e = s(t)), e !== null)) return e;
            e = null;
          } else if (n === 31) {
            if (((e = c(t)), e !== null)) return e;
            e = null;
          } else if (n === 3) {
            if (t.stateNode.current.memoizedState.isDehydrated)
              return t.tag === 3 ? t.stateNode.containerInfo : null;
            e = null;
          } else t !== e && (e = null);
        }
      }
      return ((fp = e), null);
    }
    function mp(e) {
      switch (e) {
        case `beforetoggle`:
        case `cancel`:
        case `click`:
        case `close`:
        case `contextmenu`:
        case `copy`:
        case `cut`:
        case `auxclick`:
        case `dblclick`:
        case `dragend`:
        case `dragstart`:
        case `drop`:
        case `focusin`:
        case `focusout`:
        case `input`:
        case `invalid`:
        case `keydown`:
        case `keypress`:
        case `keyup`:
        case `mousedown`:
        case `mouseup`:
        case `paste`:
        case `pause`:
        case `play`:
        case `pointercancel`:
        case `pointerdown`:
        case `pointerup`:
        case `ratechange`:
        case `reset`:
        case `resize`:
        case `seeked`:
        case `submit`:
        case `toggle`:
        case `touchcancel`:
        case `touchend`:
        case `touchstart`:
        case `volumechange`:
        case `change`:
        case `selectionchange`:
        case `textInput`:
        case `compositionstart`:
        case `compositionend`:
        case `compositionupdate`:
        case `beforeblur`:
        case `afterblur`:
        case `beforeinput`:
        case `blur`:
        case `fullscreenchange`:
        case `focus`:
        case `hashchange`:
        case `popstate`:
        case `select`:
        case `selectstart`:
          return 2;
        case `drag`:
        case `dragenter`:
        case `dragexit`:
        case `dragleave`:
        case `dragover`:
        case `mousemove`:
        case `mouseout`:
        case `mouseover`:
        case `pointermove`:
        case `pointerout`:
        case `pointerover`:
        case `scroll`:
        case `touchmove`:
        case `wheel`:
        case `mouseenter`:
        case `mouseleave`:
        case `pointerenter`:
        case `pointerleave`:
          return 8;
        case `message`:
          switch (Re()) {
            case ze:
              return 2;
            case Be:
              return 8;
            case Ve:
            case He:
              return 32;
            case D:
              return 268435456;
            default:
              return 32;
          }
        default:
          return 32;
      }
    }
    var hp = !1,
      gp = null,
      _p = null,
      vp = null,
      yp = new Map(),
      bp = new Map(),
      xp = [],
      Sp =
        `mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset`.split(
          ` `,
        );
    function Cp(e, t) {
      switch (e) {
        case `focusin`:
        case `focusout`:
          gp = null;
          break;
        case `dragenter`:
        case `dragleave`:
          _p = null;
          break;
        case `mouseover`:
        case `mouseout`:
          vp = null;
          break;
        case `pointerover`:
        case `pointerout`:
          yp.delete(t.pointerId);
          break;
        case `gotpointercapture`:
        case `lostpointercapture`:
          bp.delete(t.pointerId);
      }
    }
    function wp(e, t, n, r, i, a) {
      return e === null || e.nativeEvent !== a
        ? ((e = {
            blockedOn: t,
            domEventName: n,
            eventSystemFlags: r,
            nativeEvent: a,
            targetContainers: [i],
          }),
          t !== null && ((t = yt(t)), t !== null && ap(t)),
          e)
        : ((e.eventSystemFlags |= r),
          (t = e.targetContainers),
          i !== null && t.indexOf(i) === -1 && t.push(i),
          e);
    }
    function Tp(e, t, n, r, i) {
      switch (t) {
        case `focusin`:
          return ((gp = wp(gp, e, t, n, r, i)), !0);
        case `dragenter`:
          return ((_p = wp(_p, e, t, n, r, i)), !0);
        case `mouseover`:
          return ((vp = wp(vp, e, t, n, r, i)), !0);
        case `pointerover`:
          var a = i.pointerId;
          return (yp.set(a, wp(yp.get(a) || null, e, t, n, r, i)), !0);
        case `gotpointercapture`:
          return (
            (a = i.pointerId),
            bp.set(a, wp(bp.get(a) || null, e, t, n, r, i)),
            !0
          );
      }
      return !1;
    }
    function Ep(e) {
      var t = vt(e.target);
      if (t !== null) {
        var n = o(t);
        if (n !== null) {
          if (((t = n.tag), t === 13)) {
            if (((t = s(n)), t !== null)) {
              ((e.blockedOn = t),
                N(e.priority, function () {
                  op(n);
                }));
              return;
            }
          } else if (t === 31) {
            if (((t = c(n)), t !== null)) {
              ((e.blockedOn = t),
                N(e.priority, function () {
                  op(n);
                }));
              return;
            }
          } else if (
            t === 3 &&
            n.stateNode.current.memoizedState.isDehydrated
          ) {
            e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
            return;
          }
        }
      }
      e.blockedOn = null;
    }
    function Dp(e) {
      if (e.blockedOn !== null) return !1;
      for (var t = e.targetContainers; 0 < t.length;) {
        var n = dp(e.nativeEvent);
        if (n === null) {
          n = e.nativeEvent;
          var r = new n.constructor(n.type, n);
          (($t = r), n.target.dispatchEvent(r), ($t = null));
        } else return ((t = yt(n)), t !== null && ap(t), (e.blockedOn = n), !1);
        t.shift();
      }
      return !0;
    }
    function Op(e, t, n) {
      Dp(e) && n.delete(t);
    }
    function kp() {
      ((hp = !1),
        gp !== null && Dp(gp) && (gp = null),
        _p !== null && Dp(_p) && (_p = null),
        vp !== null && Dp(vp) && (vp = null),
        yp.forEach(Op),
        bp.forEach(Op));
    }
    function Ap(e, n) {
      e.blockedOn === n &&
        ((e.blockedOn = null),
        hp ||
          ((hp = !0),
          t.unstable_scheduleCallback(t.unstable_NormalPriority, kp)));
    }
    var jp = null;
    function Mp(e) {
      jp !== e &&
        ((jp = e),
        t.unstable_scheduleCallback(t.unstable_NormalPriority, function () {
          jp === e && (jp = null);
          for (var t = 0; t < e.length; t += 3) {
            var n = e[t],
              r = e[t + 1],
              i = e[t + 2];
            if (typeof r != `function`) {
              if (pp(r || n) === null) continue;
              break;
            }
            var a = yt(n);
            a !== null &&
              (e.splice(t, 3),
              (t -= 3),
              Cs(
                a,
                { pending: !0, data: i, method: n.method, action: r },
                r,
                i,
              ));
          }
        }));
    }
    function Np(e) {
      function t(t) {
        return Ap(t, e);
      }
      (gp !== null && Ap(gp, e),
        _p !== null && Ap(_p, e),
        vp !== null && Ap(vp, e),
        yp.forEach(t),
        bp.forEach(t));
      for (var n = 0; n < xp.length; n++) {
        var r = xp[n];
        r.blockedOn === e && (r.blockedOn = null);
      }
      for (; 0 < xp.length && ((n = xp[0]), n.blockedOn === null);)
        (Ep(n), n.blockedOn === null && xp.shift());
      if (((n = (e.ownerDocument || e).$$reactFormReplay), n != null))
        for (r = 0; r < n.length; r += 3) {
          var i = n[r],
            a = n[r + 1],
            o = i[ut] || null;
          if (typeof a == `function`) o || Mp(n);
          else if (o) {
            var s = null;
            if (a && a.hasAttribute(`formAction`)) {
              if (((i = a), (o = a[ut] || null))) s = o.formAction;
              else if (pp(i) !== null) continue;
            } else s = o.action;
            (typeof s == `function`
              ? (n[r + 1] = s)
              : (n.splice(r, 3), (r -= 3)),
              Mp(n));
          }
        }
    }
    function Pp() {
      function e(e) {
        e.canIntercept &&
          e.info === `react-transition` &&
          e.intercept({
            handler: function () {
              return new Promise(function (e) {
                return (i = e);
              });
            },
            focusReset: `manual`,
            scroll: `manual`,
          });
      }
      function t() {
        (i !== null && (i(), (i = null)), r || setTimeout(n, 20));
      }
      function n() {
        if (!r && !navigation.transition) {
          var e = navigation.currentEntry;
          e &&
            e.url != null &&
            navigation.navigate(e.url, {
              state: e.getState(),
              info: `react-transition`,
              history: `replace`,
            });
        }
      }
      if (typeof navigation == `object`) {
        var r = !1,
          i = null;
        return (
          navigation.addEventListener(`navigate`, e),
          navigation.addEventListener(`navigatesuccess`, t),
          navigation.addEventListener(`navigateerror`, t),
          setTimeout(n, 100),
          function () {
            ((r = !0),
              navigation.removeEventListener(`navigate`, e),
              navigation.removeEventListener(`navigatesuccess`, t),
              navigation.removeEventListener(`navigateerror`, t),
              i !== null && (i(), (i = null)));
          }
        );
      }
    }
    function Fp(e) {
      this._internalRoot = e;
    }
    ((Ip.prototype.render = Fp.prototype.render =
      function (e) {
        var t = this._internalRoot;
        if (t === null) throw Error(i(409));
        var n = t.current;
        np(n, pu(), e, t, null, null);
      }),
      (Ip.prototype.unmount = Fp.prototype.unmount =
        function () {
          var e = this._internalRoot;
          if (e !== null) {
            this._internalRoot = null;
            var t = e.containerInfo;
            (np(e.current, 2, null, e, null, null), bu(), (t[dt] = null));
          }
        }));
    function Ip(e) {
      this._internalRoot = e;
    }
    Ip.prototype.unstable_scheduleHydration = function (e) {
      if (e) {
        var t = lt();
        e = { blockedOn: null, target: e, priority: t };
        for (var n = 0; n < xp.length && t !== 0 && t < xp[n].priority; n++);
        (xp.splice(n, 0, e), n === 0 && Ep(e));
      }
    };
    var Lp = n.version;
    if (Lp !== `19.2.8`) throw Error(i(527, Lp, `19.2.8`));
    T.findDOMNode = function (e) {
      var t = e._reactInternals;
      if (t === void 0)
        throw typeof e.render == `function`
          ? Error(i(188))
          : ((e = Object.keys(e).join(`,`)), Error(i(268, e)));
      return (
        (e = d(t)),
        (e = e === null ? null : p(e)),
        (e = e === null ? null : e.stateNode),
        e
      );
    };
    var Rp = {
      bundleType: 0,
      version: `19.2.8`,
      rendererPackageName: `react-dom`,
      currentDispatcherRef: w,
      reconcilerVersion: `19.2.8`,
    };
    if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < `u`) {
      var zp = __REACT_DEVTOOLS_GLOBAL_HOOK__;
      if (!zp.isDisabled && zp.supportsFiber)
        try {
          ((We = zp.inject(Rp)), (Ge = zp));
        } catch {}
    }
    e.createRoot = function (e, t) {
      if (!a(e)) throw Error(i(299));
      var n = !1,
        r = ``,
        o = Ks,
        s = qs,
        c = Js;
      return (
        t != null &&
          (!0 === t.unstable_strictMode && (n = !0),
          t.identifierPrefix !== void 0 && (r = t.identifierPrefix),
          t.onUncaughtError !== void 0 && (o = t.onUncaughtError),
          t.onCaughtError !== void 0 && (s = t.onCaughtError),
          t.onRecoverableError !== void 0 && (c = t.onRecoverableError)),
        (t = ep(e, 1, !1, null, null, n, r, null, o, s, c, Pp)),
        (e[dt] = t.current),
        Sd(e),
        new Fp(t)
      );
    };
  }),
  g = o((e, t) => {
    function n() {
      if (!(
        typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > `u` ||
        typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != `function`
      ))
        try {
          __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n);
        } catch (e) {
          console.error(e);
        }
    }
    (n(), (t.exports = h()));
  }),
  _ = c(u(), 1),
  v = c(g(), 1),
  y = {
    32: [2, 2],
    33: [334, 113],
    34: [340, 113],
    35: [352, 113],
    36: [370, 113],
    37: [384, 113],
    38: [398, 113],
    39: [412, 113],
    40: [418, 113],
    41: [426, 113],
    42: [434, 113],
    43: [442, 113],
    44: [456, 113],
    45: [462, 113],
    46: [476, 113],
    47: [482, 113],
    48: [496, 113],
    49: [2, 150],
    50: [10, 150],
    51: [24, 150],
    52: [38, 150],
    53: [52, 150],
    54: [66, 150],
    55: [80, 150],
    56: [320, 113],
    57: [306, 113],
    58: [300, 113],
    59: [126, 113],
    60: [488, 76],
    61: [2, 113],
    62: [16, 113],
    63: [28, 113],
    64: [42, 113],
    65: [56, 113],
    66: [70, 113],
    67: [84, 113],
    68: [98, 113],
    69: [112, 113],
    70: [132, 113],
    71: [286, 113],
    72: [146, 113],
    73: [160, 113],
    74: [174, 113],
    75: [188, 113],
    76: [202, 113],
    77: [216, 113],
    78: [230, 113],
    79: [244, 113],
    80: [258, 113],
    81: [272, 113],
    82: [94, 150],
    83: [130, 150],
    84: [252, 187],
    85: [144, 150],
    86: [479, 150],
    87: [493, 150],
    88: [2, 187],
    89: [16, 187],
    90: [30, 187],
    91: [44, 187],
    92: [52, 187],
    93: [66, 187],
    94: [74, 187],
    95: [88, 187],
    96: [102, 187],
    97: [108, 187],
    98: [122, 187],
    99: [136, 187],
    100: [150, 187],
    101: [164, 187],
    102: [178, 187],
    103: [190, 187],
    104: [204, 187],
    105: [218, 187],
    106: [224, 187],
    107: [232, 187],
    108: [246, 187],
    109: [461, 150],
    110: [447, 150],
    111: [433, 150],
    112: [298, 150],
    113: [158, 150],
    114: [172, 150],
    115: [186, 150],
    116: [200, 150],
    117: [210, 150],
    118: [224, 150],
    119: [238, 150],
    120: [256, 150],
    121: [270, 150],
    122: [284, 150],
    123: [312, 150],
    124: [429, 150],
    125: [320, 150],
    126: [328, 150],
    160: [342, 150],
    161: [345, 150],
    162: [351, 150],
    163: [365, 150],
    164: [381, 150],
    165: [395, 150],
    166: [409, 150],
    167: [415, 150],
    168: [476, 76],
    169: [108, 150],
    170: [464, 76],
    171: [214, 39],
    172: [390, 2],
    174: [404, 2],
    175: [426, 2],
    176: [440, 2],
    177: [450, 2],
    178: [464, 2],
    179: [476, 2],
    180: [488, 2],
    181: [496, 2],
    182: [2, 39],
    183: [18, 39],
    184: [24, 39],
    185: [32, 39],
    186: [40, 39],
    187: [52, 39],
    188: [70, 39],
    189: [90, 39],
    190: [110, 39],
    191: [130, 39],
    192: [144, 39],
    193: [158, 39],
    194: [172, 39],
    195: [186, 39],
    196: [376, 2],
    197: [362, 2],
    198: [342, 2],
    199: [156, 2],
    200: [14, 2],
    201: [28, 2],
    202: [42, 2],
    203: [56, 2],
    204: [70, 2],
    205: [84, 2],
    206: [98, 2],
    207: [112, 2],
    208: [126, 2],
    209: [142, 2],
    210: [170, 2],
    211: [328, 2],
    212: [184, 2],
    213: [198, 2],
    214: [212, 2],
    215: [226, 2],
    216: [240, 2],
    217: [258, 2],
    218: [272, 2],
    219: [286, 2],
    220: [300, 2],
    221: [314, 2],
    222: [200, 39],
    223: [232, 39],
    224: [436, 76],
    225: [246, 39],
    226: [120, 76],
    227: [134, 76],
    228: [148, 76],
    229: [162, 76],
    230: [176, 76],
    231: [198, 76],
    232: [212, 76],
    233: [226, 76],
    234: [240, 76],
    235: [254, 76],
    236: [268, 76],
    237: [276, 76],
    238: [284, 76],
    239: [294, 76],
    240: [304, 76],
    241: [320, 76],
    242: [334, 76],
    243: [348, 76],
    244: [362, 76],
    245: [376, 76],
    246: [390, 76],
    247: [404, 76],
    248: [418, 76],
    249: [106, 76],
    250: [92, 76],
    251: [78, 76],
    252: [400, 39],
    253: [260, 39],
    254: [274, 39],
    255: [288, 39],
    260: [302, 39],
    261: [316, 39],
    262: [330, 39],
    263: [344, 39],
    280: [358, 39],
    281: [372, 39],
    287: [386, 39],
    304: [414, 39],
    305: [72, 76],
    321: [428, 39],
    322: [444, 39],
    323: [456, 39],
    324: [470, 39],
    346: [484, 39],
    347: [2, 76],
    350: [16, 76],
    351: [30, 76],
    377: [44, 76],
    378: [58, 76],
    379: [450, 76],
    380: [266, 187],
  },
  b = JSON.parse(
    `[{"name":"CARD_000_NAME","ID":0,"description":"CARD_000_DESC","stars":1,"price":0.55,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_001_NAME","ID":1,"description":"CARD_001_DESC","stars":1,"price":1.2,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_002_NAME","ID":2,"description":"CARD_002_DESC","stars":1,"price":0.51,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_003_NAME","ID":3,"description":"CARD_003_DESC","stars":1,"price":0.6,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_004_NAME","ID":4,"description":"CARD_004_DESC","stars":1,"price":0.5,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_005_NAME","ID":5,"description":"CARD_005_DESC","stars":1,"price":1.3,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_006_NAME","ID":6,"description":"CARD_006_DESC","stars":1,"price":1.5,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_007_NAME","ID":7,"description":"CARD_007_DESC","stars":1,"price":0.9,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_008_NAME","ID":8,"description":"CARD_008_DESC","stars":1,"price":1.6,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_009_NAME","ID":9,"description":"CARD_009_DESC","stars":1,"price":2,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_010_NAME","ID":10,"description":"CARD_010_DESC","stars":1,"price":2,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_011_NAME","ID":11,"description":"CARD_011_DESC","stars":1,"price":1.8,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_012_NAME","ID":12,"description":"CARD_012_DESC","stars":1,"price":0.58,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_013_NAME","ID":13,"description":"CARD_013_DESC","stars":1,"price":1.6,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_014_NAME","ID":14,"description":"CARD_014_DESC","stars":1,"price":0.51,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_015_NAME","ID":15,"description":"CARD_015_DESC","stars":3,"price":1.9,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_016_NAME","ID":16,"description":"CARD_016_DESC","stars":3,"price":1.5,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_017_NAME","ID":17,"description":"CARD_017_DESC","stars":2,"price":1.8,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_018_NAME","ID":18,"description":"CARD_018_DESC","stars":2,"price":1.9,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_019_NAME","ID":19,"description":"CARD_019_DESC","stars":2,"price":1.2,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_020_NAME","ID":20,"description":"CARD_020_DESC","stars":2,"price":2,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_021_NAME","ID":21,"description":"CARD_021_DESC","stars":2,"price":1.8,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_022_NAME","ID":22,"description":"CARD_022_DESC","stars":2,"price":2,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_023_NAME","ID":23,"description":"CARD_023_DESC","stars":2,"price":0.2,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_024_NAME","ID":24,"description":"CARD_024_DESC","stars":2,"price":0.6,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_025_NAME","ID":25,"description":"CARD_025_DESC","stars":3,"price":1.4,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_026_NAME","ID":26,"description":"CARD_026_DESC","stars":3,"price":-1,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_027_NAME","ID":27,"description":"CARD_027_DESC","stars":3,"price":2,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_028_NAME","ID":28,"description":"CARD_028_DESC","stars":4,"price":0.9,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_029_NAME","ID":29,"description":"CARD_029_DESC","stars":4,"price":1,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_030_NAME","ID":30,"description":"CARD_030_DESC","stars":1,"price":0.7,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_031_NAME","ID":31,"description":"CARD_031_DESC","stars":1,"price":0.4,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_032_NAME","ID":32,"description":"CARD_032_DESC","stars":1,"price":1.6,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_033_NAME","ID":33,"description":"CARD_033_DESC","stars":1,"price":1.6,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_034_NAME","ID":34,"description":"CARD_034_DESC","stars":1,"price":1.6,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_035_NAME","ID":35,"description":"CARD_035_DESC","stars":1,"price":1.6,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_036_NAME","ID":36,"description":"CARD_036_DESC","stars":1,"price":0.9,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_037_NAME","ID":37,"description":"CARD_037_DESC","stars":1,"price":1.8,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_038_NAME","ID":38,"description":"CARD_038_DESC","stars":1,"price":1.1,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_039_NAME","ID":39,"description":"CARD_039_DESC","stars":1,"price":1.2,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_040_NAME","ID":40,"description":"CARD_040_DESC","stars":1,"price":0.3,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_041_NAME","ID":41,"description":"CARD_041_DESC","stars":1,"price":0.1,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_042_NAME","ID":42,"description":"CARD_042_DESC","stars":1,"price":1.5,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_043_NAME","ID":43,"description":"CARD_043_DESC","stars":1,"price":0.8,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_044_NAME","ID":44,"description":"CARD_044_DESC","stars":1,"price":1.2,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_045_NAME","ID":45,"description":"CARD_045_DESC","stars":2,"price":1.2,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_046_NAME","ID":46,"description":"CARD_046_DESC","stars":2,"price":1.7,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_047_NAME","ID":47,"description":"CARD_047_DESC","stars":2,"price":1.3,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_048_NAME","ID":48,"description":"CARD_048_DESC","stars":2,"price":1.4,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_049_NAME","ID":49,"description":"CARD_049_DESC","stars":2,"price":1.9,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_050_NAME","ID":50,"description":"CARD_050_DESC","stars":2,"price":1,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_051_NAME","ID":51,"description":"CARD_051_DESC","stars":2,"price":1,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_052_NAME","ID":52,"description":"CARD_052_DESC","stars":2,"price":1,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_053_NAME","ID":53,"description":"CARD_053_DESC","stars":3,"price":1.8,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_054_NAME","ID":54,"description":"CARD_054_DESC","stars":3,"price":2,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_055_NAME","ID":55,"description":"CARD_055_DESC","stars":3,"price":1.8,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_056_NAME","ID":56,"description":"CARD_056_DESC","stars":3,"price":1.3,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_057_NAME","ID":57,"description":"CARD_057_DESC","stars":3,"price":1.5,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_058_NAME","ID":58,"description":"CARD_058_DESC","stars":4,"price":2,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_059_NAME","ID":59,"description":"CARD_059_DESC","stars":4,"price":1.8,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_060_NAME","ID":60,"description":"CARD_060_DESC","stars":3,"price":1.7,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_061_NAME","ID":61,"description":"CARD_061_DESC","stars":3,"price":1.1,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_062_NAME","ID":62,"description":"CARD_062_DESC","stars":1,"price":0.9,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_063_NAME","ID":63,"description":"CARD_063_DESC","stars":1,"price":1.1,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_064_NAME","ID":64,"description":"CARD_064_DESC","stars":1,"price":0.2,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_065_NAME","ID":65,"description":"CARD_065_DESC","stars":2,"price":1.9,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_066_NAME","ID":66,"description":"CARD_066_DESC","stars":1,"price":2,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_067_NAME","ID":67,"description":"CARD_067_DESC","stars":3,"price":2,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_068_NAME","ID":68,"description":"CARD_068_DESC","stars":1,"price":1.2,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_069_NAME","ID":69,"description":"CARD_069_DESC","stars":1,"price":0.8,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_070_NAME","ID":70,"description":"CARD_070_DESC","stars":2,"price":1.9,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_071_NAME","ID":71,"description":"CARD_071_DESC","stars":1,"price":0.6,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_072_NAME","ID":72,"description":"CARD_072_DESC","stars":2,"price":0.6,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_073_NAME","ID":73,"description":"CARD_073_DESC","stars":2,"price":1,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_074_NAME","ID":74,"description":"CARD_074_DESC","stars":1,"price":0.8,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_075_NAME","ID":75,"description":"CARD_075_DESC","stars":1,"price":0.4,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_076_NAME","ID":76,"description":"CARD_076_DESC","stars":1,"price":2.1,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_077_NAME","ID":77,"description":"CARD_077_DESC","stars":2,"price":1.7,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_078_NAME","ID":78,"description":"CARD_078_DESC","stars":1,"price":0.85,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_079_NAME","ID":79,"description":"CARD_079_DESC","stars":1,"price":1.7,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_080_NAME","ID":80,"description":"CARD_080_DESC","stars":2,"price":1.2,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_081_NAME","ID":81,"description":"CARD_081_DESC","stars":2,"price":1.2,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_082_NAME","ID":82,"description":"CARD_082_DESC","stars":3,"price":1.75,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_083_NAME","ID":83,"description":"CARD_083_DESC","stars":1,"price":1.45,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_084_NAME","ID":84,"description":"CARD_084_DESC","stars":1,"price":0.2,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_085_NAME","ID":85,"description":"CARD_085_DESC","stars":2,"price":0.4,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_086_NAME","ID":86,"description":"CARD_086_DESC","stars":3,"price":1.9,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_087_NAME","ID":87,"description":"CARD_087_DESC","stars":1,"price":1.25,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_088_NAME","ID":88,"description":"CARD_088_DESC","stars":1,"price":1.3,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_089_NAME","ID":89,"description":"CARD_089_DESC","stars":1,"price":0.9,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_090_NAME","ID":90,"description":"CARD_090_DESC","stars":3,"price":1.6,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_091_NAME","ID":91,"description":"CARD_091_DESC","stars":1,"price":0.7,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_092_NAME","ID":92,"description":"CARD_092_DESC","stars":1,"price":0.55,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_093_NAME","ID":93,"description":"CARD_093_DESC","stars":3,"price":2,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_094_NAME","ID":94,"description":"CARD_094_DESC","stars":2,"price":1.1,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_095_NAME","ID":95,"description":"CARD_095_DESC","stars":1,"price":1.3,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_096_NAME","ID":96,"description":"CARD_096_DESC","stars":1,"price":0.4,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_097_NAME","ID":97,"description":"CARD_097_DESC","stars":1,"price":0.6,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_098_NAME","ID":98,"description":"CARD_098_DESC","stars":2,"price":1.2,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_099_NAME","ID":99,"description":"CARD_099_DESC","stars":3,"price":1,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_100_NAME","ID":100,"description":"CARD_100_DESC","stars":1,"price":1.55,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_101_NAME","ID":101,"description":"CARD_101_DESC","stars":1,"price":1.85,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_102_NAME","ID":102,"description":"CARD_102_DESC","stars":1,"price":0.8,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_103_NAME","ID":103,"description":"CARD_103_DESC","stars":1,"price":0.65,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_104_NAME","ID":104,"description":"CARD_104_DESC","stars":1,"price":0.88,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_105_NAME","ID":105,"description":"CARD_105_DESC","stars":1,"price":0.3,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_106_NAME","ID":106,"description":"CARD_106_DESC","stars":1,"price":0.1,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_107_NAME","ID":107,"description":"CARD_107_DESC","stars":1,"price":1.9,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_108_NAME","ID":108,"description":"CARD_108_DESC","stars":1,"price":0.9,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_109_NAME","ID":109,"description":"CARD_109_DESC","stars":1,"price":1.1,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_110_NAME","ID":110,"description":"CARD_110_DESC","stars":1,"price":1.45,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_111_NAME","ID":111,"description":"CARD_111_DESC","stars":1,"price":1.65,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_112_NAME","ID":112,"description":"CARD_112_DESC","stars":1,"price":0.35,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_113_NAME","ID":113,"description":"CARD_113_DESC","stars":1,"price":0.15,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_114_NAME","ID":114,"description":"CARD_114_DESC","stars":2,"price":0.9,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_115_NAME","ID":115,"description":"CARD_115_DESC","stars":2,"price":1.3,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_116_NAME","ID":116,"description":"CARD_116_DESC","stars":2,"price":1.65,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_117_NAME","ID":117,"description":"CARD_117_DESC","stars":2,"price":1.9,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_118_NAME","ID":118,"description":"CARD_118_DESC","stars":2,"price":0.8,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_119_NAME","ID":119,"description":"CARD_119_DESC","stars":2,"price":1.6,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_120_NAME","ID":120,"description":"CARD_120_DESC","stars":2,"price":1.2,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_121_NAME","ID":121,"description":"CARD_121_DESC","stars":3,"price":2,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_122_NAME","ID":122,"description":"CARD_122_DESC","stars":3,"price":1.6,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_123_NAME","ID":123,"description":"CARD_123_DESC","stars":4,"price":1.3,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_124_NAME","ID":124,"description":"CARD_124_DESC","stars":4,"price":1.75,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_125_NAME","ID":125,"description":"CARD_125_DESC","stars":4,"price":0.76,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_126_NAME","ID":126,"description":"CARD_126_DESC","stars":4,"price":3,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_127_NAME","ID":127,"description":"CARD_127_DESC","stars":1,"price":1.1,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_128_NAME","ID":128,"description":"CARD_128_DESC","stars":1,"price":0.9,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_129_NAME","ID":129,"description":"CARD_129_DESC","stars":1,"price":1,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_130_NAME","ID":130,"description":"CARD_130_DESC","stars":1,"price":1.16,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_131_NAME","ID":131,"description":"CARD_131_DESC","stars":1,"price":1.04,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_132_NAME","ID":132,"description":"CARD_132_DESC","stars":1,"price":0.4,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_133_NAME","ID":133,"description":"CARD_133_DESC","stars":1,"price":0.75,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_134_NAME","ID":134,"description":"CARD_134_DESC","stars":2,"price":0.75,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_135_NAME","ID":135,"description":"CARD_135_DESC","stars":2,"price":0.6,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_136_NAME","ID":136,"description":"CARD_136_DESC","stars":2,"price":0.45,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_137_NAME","ID":137,"description":"CARD_137_DESC","stars":2,"price":1.1,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_138_NAME","ID":138,"description":"CARD_138_DESC","stars":2,"price":1,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_139_NAME","ID":139,"description":"CARD_139_DESC","stars":3,"price":1.8,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_140_NAME","ID":140,"description":"CARD_140_DESC","stars":3,"price":1.4,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_141_NAME","ID":141,"description":"CARD_141_DESC","stars":3,"price":1.85,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false},{"name":"CARD_142_NAME","ID":142,"description":"CARD_142_DESC","stars":4,"price":1.2,"quantity":[-1,-1,-1,-1,-1,-1,-1],"activate":false,"recent_unlock":false}]`,
  ),
  x = [
    {
      name: `BOOSTER_000_NAME`,
      description: `BOOSTER_000_DESC`,
      ID: 0,
      proba: [95, 4, 1, 0.1],
      quantity: [2, 3],
      price: 0,
      cooldown: 20,
      health: 20,
    },
    {
      name: `BOOSTER_001_NAME`,
      description: `BOOSTER_001_DESC`,
      ID: 1,
      proba: [70, 25, 4, 1],
      quantity: [3, 6],
      price: 10,
      cooldown: 35,
      health: 30,
    },
    {
      name: `BOOSTER_002_NAME`,
      description: `BOOSTER_002_DESC`,
      ID: 2,
      proba: [25, 35, 25, 15],
      quantity: [2, 4],
      price: 160,
      cooldown: 120,
      health: 40,
    },
    {
      name: `BOOSTER_003_NAME`,
      description: `BOOSTER_003_DESC`,
      ID: 3,
      proba: [99, 0.6, 0.3, 0.1],
      quantity: [5, 30],
      price: 200,
      cooldown: 300,
      health: 70,
    },
    {
      name: `BOOSTER_004_NAME`,
      description: `BOOSTER_004_DESC`,
      ID: 4,
      proba: [25, 25, 25, 25],
      quantity: [4, 4],
      price: 444,
      cooldown: 444,
      health: 44,
    },
    {
      name: `BOOSTER_005_NAME`,
      description: `BOOSTER_005_DESC`,
      ID: 5,
      proba: [0, 0, 0, 100],
      quantity: [0, 1],
      price: 100,
      cooldown: 200,
      health: 30,
    },
    {
      name: `BOOSTER_006_NAME`,
      description: `BOOSTER_006_DESC`,
      ID: 6,
      proba: [70, 25, 4, 1],
      quantity: [1, 1],
      price: 10,
      cooldown: 30,
      health: 25,
    },
    {
      name: `BOOSTER_007_NAME`,
      description: `BOOSTER_007_DESC`,
      ID: 7,
      proba: [70, 25, 4, 1],
      quantity: [1, 5],
      price: 10,
      cooldown: 60,
      health: 30,
    },
  ],
  ee = JSON.parse(
    `[{"ID":0,"name":"UPGRADE_000_NAME","level":0,"default_value":1,"values":[2,3,4,5,6,8,9,12,15,20],"prices":[5,15,150,400,5000,60000,250000,500000,1400000,5500000],"description":"UPGRADE_000_DESC","dependencies":[3]},{"ID":1,"name":"UPGRADE_001_NAME","level":0,"default_value":0,"values":[2,5,8,15,20,25,30,40,50],"prices":[15,34,98,343,1421,6815,37254,229064,1566816,8812373],"description":"UPGRADE_001_DESC","dependencies":[0]},{"ID":2,"name":"UPGRADE_002_NAME","level":0,"default_value":0,"values":[1,2,3,4],"prices":[0,10,30,300],"description":"UPGRADE_002_DESC","dependencies":[3]},{"ID":3,"name":"UPGRADE_003_NAME","level":0,"default_value":0,"values":[1,2,3,4,5,6,7,8],"prices":[0,8,50,130,600,3000,9000,15000],"description":"UPGRADE_003_DESC","dependencies":[]},{"ID":4,"name":"UPGRADE_004_NAME","level":0,"default_value":0,"values":[5,10,15,20,30,40,50,60,70,80],"prices":[20,120,3000,50000,460000,2300000,15307000,58192258,469000000,850000000],"description":"UPGRADE_004_DESC","dependencies":[3]},{"ID":5,"name":"UPGRADE_005_NAME","level":0,"default_value":0,"values":[1,5,10,15,20,25,30,35,40,50],"prices":[15,30,100,2500,8000,32000,200000,1300000,10000000,45500000],"description":"UPGRADE_005_DESC","dependencies":[3]},{"ID":6,"name":"UPGRADE_006_NAME","level":0,"default_value":0,"values":[1,5,10,20,40,50,75,100,250,500],"prices":[0,10,25,150,5500,20000,800000,1000000,2500000,5000000],"description":"UPGRADE_006_DESC","dependencies":[3]},{"ID":7,"name":"UPGRADE_007_NAME","level":0,"default_value":1,"values":[2,3,4,5,6,7,8,12,15,25,40],"prices":[5,16,57,233,1042,5120,27445,159638,1002380,67630270,170000000],"description":"UPGRADE_007_DESC","dependencies":[6]},{"ID":8,"name":"UPGRADE_008_NAME","level":0,"default_value":1,"values":[2,3,4,5,10,14,18,22,25,50],"prices":[20,50,500,5000,50000,500000,5000000,50000000,500000000,5000000000],"description":"UPGRADE_008_DESC","dependencies":[0]},{"ID":9,"name":"UPGRADE_009_NAME","level":0,"default_value":1,"values":[2,3,4,5,6,7,8,10,12,20],"prices":[930,125000,1050000,6490000,15600896,38775550,99532800,155784310,721220000,1000000000],"description":"UPGRADE_009_DESC","dependencies":[0]},{"ID":10,"name":"UPGRADE_010_NAME","level":0,"default_value":1,"values":[2,3,4,5,6,7],"prices":[30000,700700,6400000,42000000,120000000,554000000],"description":"UPGRADE_010_DESC","dependencies":[4,5]},{"ID":11,"name":"UPGRADE_011_NAME","level":0,"default_value":1,"values":[1.5,2,2.25,2.65,3,3.5,4,4.5,5,6,8],"prices":[20,110,1500,45000,250000,500000,1200000,9512000,22052000,55000000,148780000],"description":"UPGRADE_011_DESC","dependencies":[0]},{"ID":12,"name":"UPGRADE_012_NAME","level":0,"default_value":1,"values":[2,3,4,5,6,7,8,12,15,25,40],"prices":[30,96,346,1399,6255,30720,164670,957833,6014283,195781630,540000000],"description":"UPGRADE_012_DESC","dependencies":[7]},{"ID":13,"name":"UPGRADE_013_NAME","level":0,"default_value":1,"values":[2,3,4,5,6,7,8,12,15,25,40],"prices":[45,144,520,2099,9383,46080,247006,1436750,9021425,240000000,608672450],"description":"UPGRADE_013_DESC","dependencies":[12]},{"ID":14,"name":"UPGRADE_014_NAME","level":0,"default_value":1,"values":[2,3,4,5,6,7,8,12,15,25,40],"prices":[60,192,693,2799,12510,61440,329341,1915666,12028567,430000000,811563270],"description":"UPGRADE_014_DESC","dependencies":[13]},{"ID":15,"name":"UPGRADE_015_NAME","level":0,"default_value":1,"values":[2,3,4,5,6,7,8,10,15,25,40],"prices":[5,16,57,233,1042,5120,27445,159638,1002380,67630270,300000000],"description":"UPGRADE_015_DESC","dependencies":[1,7]},{"ID":16,"name":"UPGRADE_016_NAME","level":0,"default_value":1,"values":[2,3,4,5,6,7,8,10,15,25,40],"prices":[30,96,346,1399,6255,30720,164670,957833,6014283,155781630,600000000],"description":"UPGRADE_016_DESC","dependencies":[15,19]},{"ID":17,"name":"UPGRADE_017_NAME","level":0,"default_value":1,"values":[2,3,4,5,6,7,8,10,15,25,40],"prices":[45,144,520,2099,9383,46080,247006,1436750,9021425,308672450,850000000],"description":"UPGRADE_017_DESC","dependencies":[16,20]},{"ID":18,"name":"UPGRADE_018_NAME","level":0,"default_value":1,"values":[2,3,4,5,6,7,8,10,15,25,40],"prices":[60,192,693,2799,12510,61440,329341,1915666,12028567,601563270,1400000000],"description":"UPGRADE_018_DESC","dependencies":[17,21]},{"ID":19,"name":"UPGRADE_019_NAME","level":0,"default_value":0,"values":[1,2.5,4,8,10,15,22,25,30],"prices":[30,68,196,687,2842,13630,74508,458128,3133632,23624747],"description":"UPGRADE_019_DESC","dependencies":[1]},{"ID":20,"name":"UPGRADE_020_NAME","level":0,"default_value":0,"values":[0.67,1.33,2.67,4.67,6.67,8.33,11.67,13.33,16.67],"prices":[105,239,588,2405,9949,47707,260781,1603450,10967714,82686614],"description":"UPGRADE_020_DESC","dependencies":[19]},{"ID":21,"name":"UPGRADE_021_NAME","level":0,"default_value":0,"values":[0.22,0.44,0.89,1.55,2.22,2.77,3.89,4.44,5.55],"prices":[150,342,983,3435,14213,68153,372544,2290643,15668164,118123735],"description":"UPGRADE_021_DESC","dependencies":[20]},{"ID":22,"name":"UPGRADE_022_NAME","level":0,"default_value":0,"values":[1,2,3,4,5,10,20,30,40,50],"prices":[80000,124800,209952,379328,733308,1511652,3312588,7694820,18897808,37795616],"description":"UPGRADE_022_DESC","dependencies":[9,11]},{"ID":23,"name":"UPGRADE_023_NAME","level":0,"default_value":1,"values":[2,3,4,5,6,7,8,9,10],"prices":[90000,192000,627199,2621439,13436927,21499083,30165116,39214651,48626167],"description":"UPGRADE_023_DESC","dependencies":[22]},{"ID":24,"name":"UPGRADE_024_NAME","level":0,"default_value":1,"values":[2,3,4,5,6,7],"prices":[16800,80000,450000,9200000,90000000,400000000],"description":"UPGRADE_024_DESC","dependencies":[6]},{"ID":25,"name":"UPGRADE_025_NAME","level":0,"default_value":1000000,"values":[1000000000],"prices":[950000],"description":"UPGRADE_025_DESC","dependencies":[43]},{"ID":26,"name":"UPGRADE_026_NAME","level":0,"default_value":1000,"values":[10000],"prices":[1000],"description":"UPGRADE_026_DESC","dependencies":[27]},{"ID":27,"name":"UPGRADE_027_NAME","level":0,"default_value":100,"values":[1000],"prices":[100],"description":"UPGRADE_027_DESC","dependencies":[3]},{"ID":28,"name":"UPGRADE_028_NAME","level":0,"default_value":1,"values":[2,3,4,5,6,8],"prices":[450,1600,13200,45000,111000,550000],"description":"UPGRADE_028_DESC","dependencies":[8]},{"ID":29,"name":"UPGRADE_029_NAME","level":0,"default_value":0,"values":[1,2,3,4,5,8,12],"prices":[14000,76000,280000,450000,890000,2300000,15000000],"description":"UPGRADE_029_DESC","dependencies":[28]},{"ID":30,"name":"UPGRADE_030_NAME","level":0,"default_value":0,"values":[1,2,4,6,8,10,20],"prices":[27800,153200,396000,1215000,2423000,4610000,13000000],"description":"UPGRADE_030_DESC","dependencies":[28]},{"ID":31,"name":"UPGRADE_031_NAME","level":0,"default_value":0,"values":[5,8,15,20,25,30,40],"prices":[240,5500,24000,68000,445000,2200000,9400000],"description":"UPGRADE_031_DESC","dependencies":[24]},{"ID":32,"name":"UPGRADE_032_NAME","level":0,"default_value":0,"values":[1],"prices":[8000],"description":"UPGRADE_032_DESC","dependencies":[26]},{"ID":33,"name":"UPGRADE_033_NAME","level":0,"default_value":1,"values":[1.25,1.5,1.75,2,3,4],"prices":[8000,65000,140000,4200000,11000000,35000000],"description":"UPGRADE_033_DESC","dependencies":[32]},{"ID":34,"name":"UPGRADE_034_NAME","level":0,"default_value":0,"values":[1],"prices":[24000],"description":"UPGRADE_034_DESC","dependencies":[4,5]},{"ID":35,"name":"UPGRADE_035_NAME","level":0,"default_value":0,"values":[1],"prices":[1000],"description":"UPGRADE_035_DESC","dependencies":[1]},{"ID":36,"name":"UPGRADE_036_NAME","level":0,"default_value":0,"values":[1],"prices":[5000],"description":"UPGRADE_036_DESC","dependencies":[19]},{"ID":37,"name":"UPGRADE_037_NAME","level":0,"default_value":0,"values":[1],"prices":[25000],"description":"UPGRADE_037_DESC","dependencies":[20]},{"ID":38,"name":"UPGRADE_038_NAME","level":0,"default_value":0,"values":[1],"prices":[125000],"description":"UPGRADE_038_DESC","dependencies":[21]},{"ID":39,"name":"UPGRADE_039_NAME","level":0,"default_value":0,"values":[1],"prices":[50000],"description":"UPGRADE_039_DESC","dependencies":[26]},{"ID":40,"name":"UPGRADE_040_NAME","level":0,"default_value":0.0,"values":[1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0],"prices":[5000,10000,100000,750000,5000000,15000000,50000000,100000000,250000000,500000000],"description":"UPGRADE_040_DESC","dependencies":[39.0]},{"ID":41,"name":"UPGRADE_041_NAME","level":0,"default_value":0.0,"values":[1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0],"prices":[5000,10000,100000,750000,5000000,15000000,50000000,100000000,250000000,500000000],"description":"UPGRADE_041_DESC","dependencies":[39.0]},{"ID":42,"name":"UPGRADE_042_NAME","level":0,"default_value":0.0,"values":[1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0],"prices":[5000,10000,100000,750000,5000000,15000000,50000000,100000000,250000000,500000000],"description":"UPGRADE_042_DESC","dependencies":[39.0]},{"ID":43,"name":"UPGRADE_043_NAME","level":0,"default_value":10000,"values":[1000000],"prices":[9900],"description":"UPGRADE_043_DESC","dependencies":[26]},{"ID":44,"name":"UPGRADE_044_NAME","level":0,"default_value":0,"values":[0.07,0.14,0.29,0.51,0.74,0.92,1.29,1.48,1.85],"prices":[225,513,1474,5152,21319,102229,558816,3435964,23502246,177185602],"description":"UPGRADE_044_DESC","dependencies":[21]},{"ID":45,"name":"UPGRADE_045_NAME","level":0,"default_value":0,"values":[0.035,0.7,0.15,0.25,0.37,0.46,0.65,0.75,0.95],"prices":[3370,7690,22110,77280,319790,1533440,8382240,51539460,352533690,2657784030],"description":"UPGRADE_045_DESC","dependencies":[44]},{"ID":46,"name":"UPGRADE_046_NAME","level":0,"default_value":1,"values":[2,3,4,5,6,7,8,10,25,40],"prices":[120,380,1300,5400,24000,180000,900000,3815666,240285670,1601563270],"description":"UPGRADE_046_DESC","dependencies":[18]},{"ID":47,"name":"UPGRADE_047_NAME","level":0,"default_value":1,"values":[2,3,4,5,6,7,8,10,25,40],"prices":[180,576,2079,8397,37530,184320,988023,5746998,360857010,5434689810],"description":"UPGRADE_047_DESC","dependencies":[46]},{"ID":48,"name":"UPGRADE_048_NAME","level":0,"default_value":0,"values":[1],"prices":[625000],"description":"UPGRADE_048_DESC","dependencies":[44]},{"ID":49,"name":"UPGRADE_049_NAME","level":0,"default_value":0,"values":[1],"prices":[5000],"description":"UPGRADE_049_DESC","dependencies":[26]},{"ID":50,"name":"UPGRADE_050_NAME","level":0,"default_value":0,"values":[1],"prices":[50000],"description":"UPGRADE_050_DESC","dependencies":[49]},{"ID":51,"name":"UPGRADE_051_NAME","level":0,"default_value":0,"values":[1],"prices":[1000000],"description":"UPGRADE_051_DESC","dependencies":[50]},{"ID":52,"name":"UPGRADE_052_NAME","level":0,"default_value":0,"values":[1],"prices":[100000000],"description":"UPGRADE_052_DESC","dependencies":[25]},{"ID":53,"name":"UPGRADE_053_NAME","level":0,"default_value":1,"values":[1.5,2,3,4,5,8,12,20],"prices":[500000,1000000,5000000,10000000,25000000,50000000,100000000,800000000],"description":"UPGRADE_053_DESC","dependencies":[40,41,42]},{"ID":54,"name":"UPGRADE_054_NAME","level":0,"default_value":0,"values":[1],"prices":[1000],"description":"UPGRADE_054_DESC","dependencies":[43]},{"ID":55,"name":"UPGRADE_055_NAME","level":0,"default_value":0,"values":[1],"prices":[100000],"description":"UPGRADE_055_DESC","dependencies":[54]},{"ID":56,"name":"UPGRADE_056_NAME","level":0,"default_value":0,"values":[1],"prices":[100000],"description":"UPGRADE_056_DESC","dependencies":[54]},{"ID":57,"name":"UPGRADE_057_NAME","level":0,"default_value":0,"values":[1],"prices":[100000],"description":"UPGRADE_057_DESC","dependencies":[54]},{"ID":58,"name":"UPGRADE_058_NAME","level":0,"default_value":0,"values":[1],"prices":[100000],"description":"UPGRADE_058_DESC","dependencies":[54]},{"ID":59,"name":"UPGRADE_059_NAME","level":0,"default_value":0,"values":[1],"prices":[3125000],"description":"UPGRADE_059_DESC","dependencies":[45]},{"ID":60,"name":"UPGRADE_060_NAME","level":0,"default_value":0,"values":[1],"prices":[10000],"description":"UPGRADE_060_DESC","dependencies":[26]},{"ID":61,"name":"UPGRADE_061_NAME","level":0,"default_value":1,"values":[2,3,4,5,6],"prices":[100000,1000000,10000000,100000000,1000000000],"description":"UPGRADE_061_DESC","dependencies":[55]},{"ID":62,"name":"UPGRADE_062_NAME","level":0,"default_value":2,"values":[3,4,5,6],"prices":[100000,1000000,100000000,1000000000],"description":"UPGRADE_062_DESC","dependencies":[56]},{"ID":63,"name":"UPGRADE_063_NAME","level":0,"default_value":0,"values":[10,25,50,80],"prices":[100000,1000000,100000000,1000000000],"description":"UPGRADE_063_DESC","dependencies":[57]},{"ID":64,"name":"UPGRADE_064_NAME","level":0,"default_value":1,"values":[2,3,4,5,6],"prices":[100000,1000000,10000000,100000000,1000000000],"description":"UPGRADE_064_DESC","dependencies":[58]},{"ID":65,"name":"UPGRADE_065_NAME","level":0,"default_value":0,"values":[1],"prices":[500],"description":"UPGRADE_065_DESC","dependencies":[27]},{"ID":66,"name":"UPGRADE_066_NAME","level":0,"default_value":0,"values":[1],"prices":[10000000000],"description":"UPGRADE_066_DESC","dependencies":[25]}]`,
  ),
  S = {
    money: 0,
    money_max: 100,
    money_legacy: 0,
    card_record: 0,
    UI_unlock: [!1, !1, !1, !1, !1, !1, !1],
    modules_price: [0.05, 0.05, 0.05, 0.05],
    tutorial_done: !1,
    legacy_mode: !1,
    full_collection: !1,
    finished: !1,
    stats: {
      game_duration: 0,
      afk_duration: 0,
      nb_clicks: 0,
      nb_boosters_cracked: 0,
      nb_cards_duplicates: 0,
      nb_modules_win: 0,
      nb_money_total: 0,
      nb_money_spent: 0,
      nb_cards_stamped: 0,
      nb_coins: 0,
      nb_employee_cost: 0,
      nb_employee_clicks: 0,
      nb_boosters_triple: 0,
      nb_boosters_godpack: 0,
      nb_boosters_record: 0,
    },
    ver: 6,
  },
  C = {
    volume_music: 8,
    volume_effect: 8,
    lang: `en`,
    keyboard: `qwerty`,
    crt: 1,
    camera_shake: !0,
    moving_background: !0,
    voice: !0,
    flash: !0,
    screen_mode: 0,
    bulge: 5,
  },
  te = {
    FORMAT_SHOP: `Shop`,
    FORMAT_DUPLICATES: `Duplicates`,
    FORMAT_UPGRADES: `Upgrades`,
    FORMAT_COLLECTION: `Collection`,
    FORMAT_TYPE1: `metallic`,
    FORMAT_TYPE2: `gold`,
    FORMAT_TYPE3: `holographic`,
    FORMAT_TYPE4: `negative`,
    FORMAT_TYPE5: `glitched`,
    FORMAT_TYPE6: `FULL ART`,
    FORMAT_BOOSTERS: `Boosters`,
    FORMAT_BLISTER: `Blister`,
    FORMAT_LEFTCLICK: `Left Click`,
    FORMAT_RIGHTCLICK: `Right Click`,
    FORMAT_CARDS: `Cards`,
    UI_RECORD: `Record`,
    UI_NEW: `New`,
    UI_DESTROYED: `Destroyed!`,
    UI_DESTROYED_DUPLICATE: `Duplicate
storage
full`,
    UI_DESTROYED_BOOSTER: `No room
on the table`,
    UI_DESTROYED_NOCARD: `No cards
available`,
    UI_UNLOCKED_PRONOUN1: `unlocked`,
    UI_UNLOCKED_PRONOUN2: `unlocked`,
    UI_UNLOCKED_PRONOUN3: `unlocked`,
    UI_UNLOCKED_PRONOUN4: `unlocked`,
    UI_COMPLETE: `100% complete!`,
    UI_BOOSTER_CLICK: `Click`,
    UI_ROLL: `CRAZY GIFT`,
    UI_SAVING: `Saving...`,
    UI_BUTTON_SORT_STAR: `By stars`,
    UI_BUTTON_SORT_QUANTITY: `By quantity`,
    UI_BUTTON_SORT_ASCENDING: `ascending`,
    UI_BUTTON_SORT_DESCENDING: `descending`,
    UI_BUTTON_EMPLOYEE_SLEEP_NO: `active employees`,
    UI_BUTTON_EMPLOYEE_SLEEP_YES: `employees on break`,
    UI_GODPACK: `god pack`,
    UI_COLLECTION_FULL: `100% COLLECTION`,
    UI_ALARM_DUPLICATES: `Duplicates almost full`,
    UI_ALARM_MONEY: `Money maxed out`,
    UI_END_IMPOSSIBLE: `You must own every
card in the collection`,
    UI_CREDITS_MESSAGES: [
      `developed by
DOIGT`,
      `studio
FINGER GAMES`,
      `game designer
DOIGT`,
      `sound designer
DOIGT`,
    ],
    UI_TRIPLE: `tripled`,
    UI_MODULE_FULL: `You own every card`,
    SETTINGS_MUSIC: `Music Volume`,
    SETTINGS_SOUNDS: `Sound Volume`,
    SETTINGS_FULLSCREEN: `Fullscreen`,
    SETTINGS_CRT: `CRT Effect`,
    SETTINGS_SHAKE: `Screen Shake`,
    SETTINGS_FLASH: `Screen Flash`,
    SETTINGS_LANGUAGE: `Language`,
    SETTINGS_ACTUAL_LANGUAGE: `English`,
    SETTINGS_RESET: `Delete Save`,
    STATS: {
      game_duration: `Game duration`,
      afk_duration: `Time AFK`,
      nb_clicks: `Total clicks`,
      nb_boosters_cracked: `Boosters opened`,
      nb_cards_duplicates: `Duplicates obtained`,
      nb_modules_win: `Modules completed`,
      nb_money_total: `Money earned`,
      nb_money_spent: `Money spent`,
      nb_cards_stamped: `Stamps applied`,
      nb_coins: `Coins collected`,
      nb_employee_cost: `Employee costs`,
      nb_employee_clicks: `Employee clicks`,
      nb_boosters_triple: `{orange}Tripled boosters`,
      nb_boosters_godpack: `{godpack}[c_white] obtained`,
      nb_boosters_record: `Biggest booster`,
    },
    ROLL_DOUBLE_VARIANT: `Temporarily doubles rarities`,
    ROLL_DOUBLE_VALUE: `Temporarily doubles sale prices`,
    ROLL_DOUBLE_COOLDOWN: `Triples booster recharge speed`,
    ROLL_RAIN_COINS: `Coin Rain`,
    ROLL_RAIN_CARDS: `Card Rain`,
    ROLL_RAIN_BOOSTERS: `Booster Rain`,
    ROLL_ALL_BOOSTERS_VARIANT: `All boosters are {type5}`,
    ROLL_NEW_CARD: `New Card`,
    ROLL_SPEED: `Increased Speed`,
    ROLL_NOTHING: `Nothing :(`,
    ROLL_RESET: `{red}BANKRUPTCY`,
    ROLL_DOUBLE_MONEY: `[shake]Double Money`,
    MODULE_LAB: `Fusion Lab`,
    MODULE_LAB_OUTPUT: `Result`,
    MODULE_LAB_INPUTS: `Ingredients`,
    MODULE_LAB_LAUNCH: `Start Project`,
    MODULE_LAB_DESC: `{blue}Choose{black} a new card to create. It requires {blue}2 lower-tier variants{black} to fuse. Fusion starts as soon as you have {blue}found the right cards{black}.`,
    MODULE_LAB_FINISHED: `Fusion complete!`,
    MODULE_MEMORY: `Memory`,
    MODULE_MEMORY_WIN: `Memory complete!`,
    MODULE_MEMORY_DESC: `{blue}Flip{black} pairs of cards to reveal them. You must {blue}find every matching pair{black} within 5 attempts. There will always be one pair you don't own.`,
    MODULE_ARENA: `Arena`,
    MODULE_ARENA_HIM: [
      `skouizi`,
      `dark_tenebrum`,
      `DarkShadow27`,
      `KillerDu62`,
      `SkullHunter92`,
      `fan2cartes`,
      `NinjaWolf27`,
      `DragonSlayer94`,
      `DarkTitan92`,
    ],
    MODULE_ARENA_VS: `VS`,
    MODULE_ARENA_YOU: `You`,
    MODULE_ARENA_MISS: `Dodge!`,
    MODULE_ARENA_WIN: `You won!`,
    MODULE_ARENA_LOSE: `You lost!`,
    MODULE_ARENA_DRAW: `Draw!`,
    MODULE_ARENA_DESC: `Make your {blue}cards fight{black} an opponent's cards. If they are defeated, {blue}you steal their cards{black}. They will always have a card you don't own.`,
    MODULE_MUSEUM: `Museum`,
    MODULE_MUSEUM_INTRO: `Choose 5 cards
to display!`,
    MODULE_MUSEUM_ENTRIES: `Visitors`,
    MODULE_MUSEUM_PRICE: `Ticket Price`,
    MODULE_MUSEUM_PRICE_SHORT: `Ticket`,
    MODULE_MUSEUM_RISK: `Risk`,
    MODULE_MUSEUM_RISK_PRICE: `Deposit`,
    MODULE_MUSEUM_REWARD: `Profit`,
    MODULE_MUSEUM_IMPOSSIBLE: `You don't have the deposit`,
    MODULE_MUSEUM_WAITING: `Let's hope the price
doesn't scare them off...`,
    MODULE_MUSEUM_LOSE: `The exhibit is canceled!`,
    MODULE_MUSEUM_WIN: `The exhibit is happening!`,
    MODULE_MUSEUM_DESC: `{blue}Display 5 of your cards{black} in a museum. You can increase the {blue}admission price{black}, but also the {red}risk of the event failing{black} and costing you money.`,
    BOOSTER_000_NAME: `Starter Booster`,
    BOOSTER_000_DESC: `Free introductory boosters`,
    BOOSTER_001_NAME: `Standard Booster`,
    BOOSTER_001_DESC: `Boosters with a standard rarity distribution`,
    BOOSTER_002_NAME: `Deluxe Booster`,
    BOOSTER_002_DESC: `Boosters with better rarity odds`,
    BOOSTER_003_NAME: `Mega Booster`,
    BOOSTER_003_DESC: `Boosters packed with common cards`,
    BOOSTER_004_NAME: `Square Booster`,
    BOOSTER_004_DESC: `Perfectly balanced boosters`,
    BOOSTER_005_NAME: `Polarized Booster`,
    BOOSTER_005_DESC: `Boosters that are either incredibly rewarding or incredibly disappointing`,
    BOOSTER_006_NAME: `Time Booster`,
    BOOSTER_006_DESC: `Boosters whose quality improves over time`,
    BOOSTER_007_NAME: `Growth Booster`,
    BOOSTER_007_DESC: `Boosters that improve with every purchase`,
    UPGRADE_000_NAME: `{boosters} Damage`,
    UPGRADE_000_DESC: `{boosters} damage: -{value}`,
    UPGRADE_001_NAME: `{type1} Die`,
    UPGRADE_001_DESC: `{value}% chance to get a {type1} card`,
    UPGRADE_002_NAME: `Unlock Duplicates`,
    UPGRADE_002_DESC: `Storable duplicates: up to {value} {star}`,
    UPGRADE_003_NAME: `{boosters} Unlocked`,
    UPGRADE_003_DESC: `{boosters} types in the {shop}: {value}`,
    UPGRADE_004_NAME: `{boosters} cooldown`,
    UPGRADE_004_DESC: `{boosters} cooldown time: -{value}%`,
    UPGRADE_005_NAME: `Big Packs`,
    UPGRADE_005_DESC: `{value}% chance for {boosters} to be {orange}tripled`,
    UPGRADE_006_NAME: `Storage Capacity`,
    UPGRADE_006_DESC: `Max storable {duplicates}: {value}`,
    UPGRADE_007_NAME: `1 {star} Value`,
    UPGRADE_007_DESC: `Value of 1 {star} cards: x{value}`,
    UPGRADE_008_NAME: `Table Size`,
    UPGRADE_008_DESC: `Maximum {boosters} on the table: {value}`,
    UPGRADE_009_NAME: `Multi-Hand`,
    UPGRADE_009_DESC: `{value} cards can be flipped at once`,
    UPGRADE_010_NAME: `Surprise Bundles`,
    UPGRADE_010_DESC: `{boosters} can be bought in bundles of {value}`,
    UPGRADE_011_NAME: `Magician's Hands`,
    UPGRADE_011_DESC: `Card flip speed: x{value}`,
    UPGRADE_012_NAME: `2 {star} Value`,
    UPGRADE_012_DESC: `Value of 2 {star} cards: x{value}`,
    UPGRADE_013_NAME: `3 {star} Value`,
    UPGRADE_013_DESC: `Value of 3 {star} cards: x{value}`,
    UPGRADE_014_NAME: `4 {star} Value`,
    UPGRADE_014_DESC: `Value of 4 {star} cards: x{value}`,
    UPGRADE_015_NAME: `{type1} Value`,
    UPGRADE_015_DESC: `Value of {type1} cards: x{value}`,
    UPGRADE_016_NAME: `{type2} Value`,
    UPGRADE_016_DESC: `Value of {type2} cards: x{value}`,
    UPGRADE_017_NAME: `{type3} Value`,
    UPGRADE_017_DESC: `Value of {type3} cards: x{value}`,
    UPGRADE_018_NAME: `{type4} Value`,
    UPGRADE_018_DESC: `Value of {type4} cards: x{value}`,
    UPGRADE_019_NAME: `{type2} Die`,
    UPGRADE_019_DESC: `{value}% chance to get a {type2} card`,
    UPGRADE_020_NAME: `{type3} Die`,
    UPGRADE_020_DESC: `{value}% chance to get a {type3} card`,
    UPGRADE_021_NAME: `{type4} Die`,
    UPGRADE_021_DESC: `{value}% chance to get a {type4} card`,
    UPGRADE_022_NAME: `Clone Wars`,
    UPGRADE_022_DESC: `{value}% chance for flipped cards to clone`,
    UPGRADE_023_NAME: `Clone Quantity`,
    UPGRADE_023_DESC: `Number of clones: 1 to {value}`,
    UPGRADE_024_NAME: `Rising Demand`,
    UPGRADE_024_DESC: `{duplicates} sell in batches of {value}`,
    UPGRADE_025_NAME: `Multinational`,
    UPGRADE_025_DESC: `Max money: $infinite`,
    UPGRADE_026_NAME: `Start a Business`,
    UPGRADE_026_DESC: "Max money: ${value}",
    UPGRADE_027_NAME: `Wallet`,
    UPGRADE_027_DESC: `Max money: \${value}
{green}Coins can drop`,
    UPGRADE_028_NAME: `Shovel`,
    UPGRADE_028_DESC: `Cursor click radius: {value}`,
    UPGRADE_029_NAME: `Backhoe`,
    UPGRADE_029_DESC: `Hold {right_click} to auto-click {value}x per second`,
    UPGRADE_030_NAME: `Magnet`,
    UPGRADE_030_DESC: `A magnet pulls cards {value}x per second`,
    UPGRADE_031_NAME: `Bargain Hunter`,
    UPGRADE_031_DESC: `{duplicates} sold automatically: {value}% chance`,
    UPGRADE_032_NAME: `{blister}`,
    UPGRADE_032_DESC: `{boosters} can be wrapped; they are sold if they remain unopened`,
    UPGRADE_033_NAME: `Better Negotiation`,
    UPGRADE_033_DESC: `Potential {blister} value: x{value}`,
    UPGRADE_034_NAME: `Shady Dealer`,
    UPGRADE_034_DESC: `The {shop} regularly offers cards`,
    UPGRADE_035_NAME: `{type1} Seal`,
    UPGRADE_035_DESC: `{left_click} on a new {type1} card gives silver coins`,
    UPGRADE_036_NAME: `{type2} Seal`,
    UPGRADE_036_DESC: `{left_click} on a new {type2} card gives gold coins`,
    UPGRADE_037_NAME: `{type3} Seal`,
    UPGRADE_037_DESC: `{left_click} on a new {type3} card speeds up the game`,
    UPGRADE_038_NAME: `{type4} Seal`,
    UPGRADE_038_DESC: `{left_click} on a new {type4} card reverses a pack`,
    UPGRADE_039_NAME: `Recruitment Drive`,
    UPGRADE_039_DESC: `Allows you to hire employees`,
    UPGRADE_040_NAME: `Delivery Driver`,
    UPGRADE_040_DESC: `Delivery drivers: {value}
{red}-$50 {red}per second`,
    UPGRADE_041_NAME: `Card Opener`,
    UPGRADE_041_DESC: `Card openers: {value}
{red}-$50 {red}per second`,
    UPGRADE_042_NAME: `Salesperson`,
    UPGRADE_042_DESC: `Salespeople: {value}
{red}-$50 {red}per second`,
    UPGRADE_043_NAME: `Big-box store`,
    UPGRADE_043_DESC: `Max money: \${value}
`,
    UPGRADE_044_NAME: `{type5} Die`,
    UPGRADE_044_DESC: `{value}% chance to get a {type5} card`,
    UPGRADE_045_NAME: `{type6} Die`,
    UPGRADE_045_DESC: `{value}% chance to get a {type6} card`,
    UPGRADE_046_NAME: `{type5} Value`,
    UPGRADE_046_DESC: `Value of {type5} cards: x{value}`,
    UPGRADE_047_NAME: `{type6} Value`,
    UPGRADE_047_DESC: `Value of {type6} cards: x{value}`,
    UPGRADE_048_NAME: `{type5} Seal`,
    UPGRADE_048_DESC: `{left_click} on a new {type5} card shuffles a pack`,
    UPGRADE_049_NAME: `First DLC`,
    UPGRADE_049_DESC: `Adds {red}210 {black} new collectible cards`,
    UPGRADE_050_NAME: `Second DLC`,
    UPGRADE_050_DESC: `Adds {red}210 {black} new collectible cards`,
    UPGRADE_051_NAME: `Third DLC`,
    UPGRADE_051_DESC: `Adds {red}371 {black} new collectible cards`,
    UPGRADE_052_NAME: `Legacy`,
    UPGRADE_052_DESC: `{red}Unlocks {type6} {black}and {red}restarts {black}the game while keeping your current collection value`,
    UPGRADE_053_NAME: `Whip`,
    UPGRADE_053_DESC: `Work speed: x{value}
{red}(adjusted wages)`,
    UPGRADE_054_NAME: `Research & Development`,
    UPGRADE_054_DESC: `Unlocks development modules`,
    UPGRADE_055_NAME: `Fusion Lab`,
    UPGRADE_055_DESC: `Allows you to create cards by fusing lower-tier variants`,
    UPGRADE_056_NAME: `Memory Game`,
    UPGRADE_056_DESC: `Solve a memory game to receive all the cards, including a new one`,
    UPGRADE_057_NAME: `TCG Tournament`,
    UPGRADE_057_DESC: `Win a battle to steal your opponent's cards, including a new one`,
    UPGRADE_058_NAME: `Museum Exhibit`,
    UPGRADE_058_DESC: `Display your cards to make money, but beware of a flop!`,
    UPGRADE_059_NAME: `{type6} Seal`,
    UPGRADE_059_DESC: `{left_click} on a new {type6} card triggers {roll}`,
    UPGRADE_060_NAME: `Divine Grace`,
    UPGRADE_060_DESC: `{boosters} can miraculously transform into {godpack}`,
    UPGRADE_061_NAME: `Years of Study`,
    UPGRADE_061_DESC: `Fusion can create {typevalue} cards`,
    UPGRADE_062_NAME: `Simplification (Big Dummy)`,
    UPGRADE_062_DESC: `Number of lives: {value}`,
    UPGRADE_063_NAME: `Improved Gear`,
    UPGRADE_063_DESC: `Your troops have a {value}% chance to {orange}dodge{black} or land a {orange}critical hit{black}`,
    UPGRADE_064_NAME: `Extra Wing`,
    UPGRADE_064_DESC: `The museum can display {typevalue} cards`,
    UPGRADE_065_NAME: `Fire Alarm`,
    UPGRADE_065_DESC: `Alerts you when you're approaching the money or {duplicates} cap`,
    UPGRADE_066_NAME: `Total Domination`,
    UPGRADE_066_DESC: `Conquer the global collectible card market
{red}End of game`,
    CARD_000_NAME: `Tape Measure`,
    CARD_000_DESC: `Don't mention other units of measurement around him`,
    CARD_001_NAME: `Swiss Army Knife`,
    CARD_001_DESC: `Practical, versatile, and red`,
    CARD_002_NAME: `Nail`,
    CARD_002_DESC: `Used to attach objects or humans`,
    CARD_003_NAME: `Sponge`,
    CARD_003_DESC: `How much would you have to be paid to lick the green part after using it??`,
    CARD_004_NAME: `Dirty T-Shirt`,
    CARD_004_DESC: `It's an oversized fit`,
    CARD_005_NAME: `Mug`,
    CARD_005_DESC: `Can hold various liquids`,
    CARD_006_NAME: `Light Bulb`,
    CARD_006_DESC: `Blinded by the light`,
    CARD_007_NAME: `Post-it Note`,
    CARD_007_DESC: `Remember to buy more milk`,
    CARD_008_NAME: `Power Strip`,
    CARD_008_DESC: `Plug it into itself to generate infinite energy`,
    CARD_009_NAME: `Tails Side of a Coin`,
    CARD_009_DESC: `Heads or tails? It was heads, unfortunately`,
    CARD_010_NAME: `Heads Side of a Coin`,
    CARD_010_DESC: `Heads or tails? It was tails, unfortunately`,
    CARD_011_NAME: `Sanitary pad`,
    CARD_011_DESC: `Always keep one in your bag`,
    CARD_012_NAME: `Balloon`,
    CARD_012_DESC: `Filled with 99% air and 1% drool`,
    CARD_013_NAME: `Earbuds`,
    CARD_013_DESC: `Take 3 hours to untangle`,
    CARD_014_NAME: `A4 Sheet`,
    CARD_014_DESC: `A4 is 21 x 29.7 cm`,
    CARD_015_NAME: `Postage Stamp`,
    CARD_015_DESC: `Approved`,
    CARD_016_NAME: `Fire Hydrant`,
    CARD_016_DESC: `FIRE!`,
    CARD_017_NAME: `Fancy Toilet`,
    CARD_017_DESC: `Psssssht`,
    CARD_018_NAME: `Performance Pill`,
    CARD_018_DESC: `For those nights when everything isn't quite working`,
    CARD_019_NAME: `STOP Sign`,
    CARD_019_DESC: `STOP!! THAT'S ENOUGH! STOP!!!`,
    CARD_020_NAME: `MY Car`,
    CARD_020_DESC: `This is my car`,
    CARD_021_NAME: `Shower`,
    CARD_021_DESC: `This is NOT a bathtub`,
    CARD_022_NAME: `Smartphone`,
    CARD_022_DESC: `You really should answer...`,
    CARD_023_NAME: `Reassuring Man`,
    CARD_023_DESC: `:)`,
    CARD_024_NAME: `Mouse`,
    CARD_024_DESC: `For clicking cards more easily`,
    CARD_025_NAME: `Clamp Meter`,
    CARD_025_DESC: `I don't know what it's for either`,
    CARD_026_NAME: `Overdrawn Bank Card`,
    CARD_026_DESC: `You owe us $534,289`,
    CARD_027_NAME: `Saxophone`,
    CARD_027_DESC: `Belgian instrument (I mention it because I'm Belgian)`,
    CARD_028_NAME: `Fidget Spinner`,
    CARD_028_DESC: `It spins`,
    CARD_029_NAME: `Toilet Paper Roll`,
    CARD_029_DESC: `Triple-ply`,
    CARD_030_NAME: `Ugly Dog`,
    CARD_030_DESC: `WOOF WOOF (that means 'I'm ugly' in dog language)`,
    CARD_031_NAME: `Fly`,
    CARD_031_DESC: `Bzzzzzzzzz`,
    CARD_032_NAME: `Ace of Hearts`,
    CARD_032_DESC: `Only Aces because I was too lazy`,
    CARD_033_NAME: `Ace of Clubs`,
    CARD_033_DESC: `Only Aces because I was too lazy`,
    CARD_034_NAME: `Ace of Spades`,
    CARD_034_DESC: `Only Aces because I was too lazy`,
    CARD_035_NAME: `Ace of Diamonds`,
    CARD_035_DESC: `Only Aces because I was too lazy`,
    CARD_036_NAME: `Pickle`,
    CARD_036_DESC: `Disgusting in a hamburger`,
    CARD_037_NAME: `Coal`,
    CARD_037_DESC: `Looks familiar...`,
    CARD_038_NAME: `Horse`,
    CARD_038_DESC: `Perfectly drawn`,
    CARD_039_NAME: `Early signs of balding`,
    CARD_039_DESC: `No, it's just the lighting, don't worry`,
    CARD_040_NAME: `Emmental`,
    CARD_040_DESC: `I don't like cheese`,
    CARD_041_NAME: `My Dad`,
    CARD_041_DESC: ``,
    CARD_042_NAME: `Treble Clef`,
    CARD_042_DESC: `Indicates G on a musical staff`,
    CARD_043_NAME: `Spring Roll`,
    CARD_043_DESC: `Team veggie spring rolls`,
    CARD_044_NAME: `MP3 File`,
    CARD_044_DESC: `sndCardWoosh.mp3`,
    CARD_045_NAME: `Zebra`,
    CARD_045_DESC: `Perfectly drawn`,
    CARD_046_NAME: `Rainbow`,
    CARD_046_DESC: `Related to the refraction of light`,
    CARD_047_NAME: `Comté`,
    CARD_047_DESC: `I don't like cheese`,
    CARD_048_NAME: `Iron`,
    CARD_048_DESC: `Looks familiar...`,
    CARD_049_NAME: `Belgian Flag`,
    CARD_049_DESC: `Yeah, fries`,
    CARD_050_NAME: `Jack`,
    CARD_050_DESC: `See the Queen's description`,
    CARD_051_NAME: `Queen`,
    CARD_051_DESC: `See the King's description`,
    CARD_052_NAME: `King`,
    CARD_052_DESC: `See the Joker's description`,
    CARD_053_NAME: `Unicorn`,
    CARD_053_DESC: `Perfectly drawn`,
    CARD_054_NAME: `Gold`,
    CARD_054_DESC: `Looks familiar...`,
    CARD_055_NAME: `Sputnik`,
    CARD_055_DESC: `The world's first artificial satellite`,
    CARD_056_NAME: `Camembert`,
    CARD_056_DESC: `I don't like cheese`,
    CARD_057_NAME: `Joker`,
    CARD_057_DESC: `See the Jack's description`,
    CARD_058_NAME: `Diamond`,
    CARD_058_DESC: `Looks familiar...`,
    CARD_059_NAME: `Pegasus`,
    CARD_059_DESC: `Divinely drawn`,
    CARD_060_NAME: `Atom`,
    CARD_060_DESC: `Makes up all matter`,
    CARD_061_NAME: `Morgue AC Seal`,
    CARD_061_DESC: `Artist: Alphonse Robichu`,
    CARD_062_NAME: `Suspicious Snail`,
    CARD_062_DESC: `He knows`,
    CARD_063_NAME: `Mischievous Kidney`,
    CARD_063_DESC: `It was supposed to be a fish originally`,
    CARD_064_NAME: `Q`,
    CARD_064_DESC: `Well that's it`,
    CARD_065_NAME: `Spaceship`,
    CARD_065_DESC: `Ready for the battle`,
    CARD_066_NAME: `My Cat`,
    CARD_066_DESC: `His name is CHOCOLAT <3`,
    CARD_067_NAME: `Glutton`,
    CARD_067_DESC: `He's on the burger quest`,
    CARD_068_NAME: `Confident Jellyfish`,
    CARD_068_DESC: `Wow, she's so cool??`,
    CARD_069_NAME: `Straw Hat`,
    CARD_069_DESC: `Can be bought in one piece`,
    CARD_070_NAME: `Capitalist Pig`,
    CARD_070_DESC: `Has an account in the Cayman Islands`,
    CARD_071_NAME: `Scrambled Rubik's Cube`,
    CARD_071_DESC: `Way too lazy to solve it`,
    CARD_072_NAME: `Rubik's Cube`,
    CARD_072_DESC: `I don't dare touch it anymore`,
    CARD_073_NAME: `Lab Scientist`,
    CARD_073_DESC: `He's deeply invested in designing variants`,
    CARD_074_NAME: `French Fries`,
    CARD_074_DESC: `The famous BELGIAN dish`,
    CARD_075_NAME: `Never-Ending Voice Message`,
    CARD_075_DESC: `Yesss, I'll send you a voice message, it'll be faster, uh basically OH wait someone's calling me`,
    CARD_076_NAME: `Piggy Bank`,
    CARD_076_DESC: `Oink Oink`,
    CARD_077_NAME: `Maneki-Neko`,
    CARD_077_DESC: `Brings good luck`,
    CARD_078_NAME: `Tomato`,
    CARD_078_DESC: `Artist: Lucy`,
    CARD_079_NAME: `Questionable Foot`,
    CARD_079_DESC: `The smell is questionable too`,
    CARD_080_NAME: `Man with a Prominent Nose`,
    CARD_080_DESC: `What could he possibly smell??`,
    CARD_081_NAME: `Sniffed Cherry`,
    CARD_081_DESC: `But who does this nose belong to??`,
    CARD_082_NAME: `Axolotl`,
    CARD_082_DESC: `23 centimeters of cuteness`,
    CARD_083_NAME: `MargueRIP`,
    CARD_083_DESC: `She's pretty, but dead...`,
    CARD_084_NAME: `Cheap Costume`,
    CARD_084_DESC: `It's counterfeit, but it's practical`,
    CARD_085_NAME: `Sleep Paralysis`,
    CARD_085_DESC: `Don't turn around`,
    CARD_086_NAME: `White-Eyes Blue Lizard`,
    CARD_086_DESC: `ATK/3000   DEF/2500`,
    CARD_087_NAME: `Burnt-Out Robot`,
    CARD_087_DESC: `@grouk is this actually true??`,
    CARD_088_NAME: `Catchpa`,
    CARD_088_DESC: `Click the cat pictures`,
    CARD_089_NAME: `Perfectly Round Ball`,
    CARD_089_DESC: `4/3 * pi * r³`,
    CARD_090_NAME: `Stanley Cubic`,
    CARD_090_DESC: `That's a wrap !`,
    CARD_091_NAME: `Passport`,
    CARD_091_DESC: `Papers, please`,
    CARD_092_NAME: `Green Tea`,
    CARD_092_DESC: `It's not actually that green, though`,
    CARD_093_NAME: `Demigod`,
    CARD_093_DESC: `His other half is a taboo subject`,
    CARD_094_NAME: `Cute Little Guys`,
    CARD_094_DESC: `=(°u°)=`,
    CARD_095_NAME: `The Electrician`,
    CARD_095_DESC: `It's the electrician... Come here`,
    CARD_096_NAME: `Sticky Shower Curtain`,
    CARD_096_DESC: `We've all had it happen, right?`,
    CARD_097_NAME: `2:44 PM`,
    CARD_097_DESC: `The time doesn't match the image, I'm feeling a little silly`,
    CARD_098_NAME: `Gravity`,
    CARD_098_DESC: `Invented by Isaac Newton`,
    CARD_099_NAME: `The 100th Card Created`,
    CARD_099_DESC: `September 2 at 11:24 PM`,
    CARD_100_NAME: `Shamisen`,
    CARD_100_DESC: `What do you mean, 3 strings`,
    CARD_101_NAME: `C++ Language`,
    CARD_101_DESC: `The game wasn't programmed with it, but we respect`,
    CARD_102_NAME: `????`,
    CARD_102_DESC: `Are you serious right now??`,
    CARD_103_NAME: `Kebab Spit`,
    CARD_103_DESC: `Same as always, chef`,
    CARD_104_NAME: `The Invisible Man in 2020`,
    CARD_104_DESC: `He was affected just like everyone else`,
    CARD_105_NAME: `Winking Smiley`,
    CARD_105_DESC: `Used by people you really shouldn't hang out with`,
    CARD_106_NAME: `AI Slop`,
    CARD_106_DESC: `This card was not generated by AI tho`,
    CARD_107_NAME: `Blue Bird`,
    CARD_107_DESC: `I can still hear its whistle #nostalgia`,
    CARD_108_NAME: `Cinephile`,
    CARD_108_DESC: `He hates a famous 2014 space movie`,
    CARD_109_NAME: `Building Brick`,
    CARD_109_DESC: `The T-shaped one terrorizes bricklayers`,
    CARD_110_NAME: `The World's Smallest Violin`,
    CARD_110_DESC: `It really needs an audience`,
    CARD_111_NAME: `Suspicious Abstract Art`,
    CARD_111_DESC: `sus.........`,
    CARD_112_NAME: `YouTuber Apology Video`,
    CARD_112_DESC: `I know nothing I say will be able to....`,
    CARD_113_NAME: `Very, Very Ripe Banana`,
    CARD_113_DESC: `You really need to eat it soon`,
    CARD_114_NAME: `Explosion`,
    CARD_114_DESC: `BOOOOOOOM`,
    CARD_115_NAME: `Climate Change`,
    CARD_115_DESC: `+2°C by 2050 if we don't do anything lmao`,
    CARD_116_NAME: `Badly Framed Streamer`,
    CARD_116_DESC: `twitch.tv/doigt`,
    CARD_117_NAME: `Mister Fist`,
    CARD_117_DESC: `I'LL GIVE $300 MILLION TO THE CANDIDATE WHO SURVIVES 500 VOLTS`,
    CARD_118_NAME: `Guess my Fart`,
    CARD_118_DESC: `A game that isn't for everyone`,
    CARD_119_NAME: `Dungeon Item`,
    CARD_119_DESC: `It will only be used for this dungeon`,
    CARD_120_NAME: `Sun Seen at Night`,
    CARD_120_DESC: `It's the perfect time to attack it`,
    CARD_121_NAME: `Watermelon`,
    CARD_121_DESC: `Fruit made of 215% water (science)`,
    CARD_122_NAME: `Black Hole`,
    CARD_122_DESC: `Despite its gravitational pull, it doesn't attract me as much as you do`,
    CARD_123_NAME: `Six Seven`,
    CARD_123_DESC: `SIX SEVEN SIX SEVEN`,
    CARD_124_NAME: `Billy`,
    CARD_124_DESC: `Not just any slime, a legend...`,
    CARD_125_NAME: `Jimmy the slimy`,
    CARD_125_DESC: `He sends messages with winking smileys`,
    CARD_126_NAME: `Cthulhu`,
    CARD_126_DESC: `He's 13 centimeters tall`,
    CARD_127_NAME: `Zombie`,
    CARD_127_DESC: `Greuuuraaargh`,
    CARD_128_NAME: `Exponential Function`,
    CARD_128_DESC: `Okay, this is going up pretty fast though`,
    CARD_129_NAME: `Wind`,
    CARD_129_DESC: `Fffffffffffff`,
    CARD_130_NAME: `16:9 Aspect Ratio`,
    CARD_130_DESC: `If you leave this format, the game will break, so don't try it, thanks`,
    CARD_131_NAME: `4:3 Aspect Ratio`,
    CARD_131_DESC: `Old school`,
    CARD_132_NAME: `Influencer Merch`,
    CARD_132_DESC: `$5.99 for the new tar flavor`,
    CARD_133_NAME: `Red Button`,
    CARD_133_DESC: `Don't press it, it won't do anything`,
    CARD_134_NAME: `Fireball`,
    CARD_134_DESC: `Deals 25 damage—just kidding, it's literally just a drawing, calm down`,
    CARD_135_NAME: `Card Inside a Card`,
    CARD_135_DESC: `Card description: Card description`,
    CARD_136_NAME: `Bold Mustache`,
    CARD_136_DESC: `Not to say ugly`,
    CARD_137_NAME: `Huge Leg of Meat`,
    CARD_137_DESC: `You should probably cook it though`,
    CARD_138_NAME: `Unfinished Drawing`,
    CARD_138_DESC: `I didn't have time, I'm already behind schedule for the game's release`,
    CARD_139_NAME: `Unifying Megaphone`,
    CARD_139_DESC: `This is only the beginning`,
    CARD_140_NAME: `Sports Coach`,
    CARD_140_DESC: `BELIEVE`,
    CARD_141_NAME: `Hachiko`,
    CARD_141_DESC: `A symbol of loyalty and love`,
    CARD_142_NAME: `Sausageman`,
    CARD_142_DESC: `With great power comes great seasoning`,
  },
  ne = {
    FORMAT_SHOP: `Boutique`,
    FORMAT_DUPLICATES: `Doublons`,
    FORMAT_UPGRADES: `Améliorations`,
    FORMAT_COLLECTION: `Collection`,
    FORMAT_TYPE1: `métallique`,
    FORMAT_TYPE2: `dorée`,
    FORMAT_TYPE3: `holographique`,
    FORMAT_TYPE4: `négative`,
    FORMAT_TYPE5: `glitchée`,
    FORMAT_TYPE6: `FULL ART`,
    FORMAT_BOOSTERS: `Boosters`,
    FORMAT_BLISTER: `Blister`,
    FORMAT_LEFTCLICK: `Clic gauche`,
    FORMAT_RIGHTCLICK: `Clic droit`,
    FORMAT_CARDS: `Cartes`,
    UI_RECORD: `Record !`,
    UI_NEW: `Nouveau`,
    UI_DESTROYED: `Détruit !`,
    UI_DESTROYED_DUPLICATE: `Stock de
doublons
rempli !`,
    UI_DESTROYED_BOOSTER: `Plus de place
sur la table !`,
    UI_DESTROYED_NOCARD: `Pas de carte
disponibles !`,
    UI_UNLOCKED_PRONOUN1: `débloqué`,
    UI_UNLOCKED_PRONOUN2: `débloquée`,
    UI_UNLOCKED_PRONOUN3: `débloquées`,
    UI_UNLOCKED_PRONOUN4: `débloqués`,
    UI_COMPLETE: `100% complété !`,
    UI_BOOSTER_CLICK: `Cliquez`,
    UI_ROLL: `CADEAU DINGO`,
    UI_SAVING: `Sauvegarde...`,
    UI_BUTTON_SORT_STAR: `Par étoiles`,
    UI_BUTTON_SORT_QUANTITY: `Par quantité`,
    UI_BUTTON_SORT_ASCENDING: `croissant`,
    UI_BUTTON_SORT_DESCENDING: `décroissant`,
    UI_BUTTON_EMPLOYEE_SLEEP_NO: `employés actifs`,
    UI_BUTTON_EMPLOYEE_SLEEP_YES: `employés en pause`,
    UI_GODPACK: `god pack`,
    UI_COLLECTION_FULL: `Collection à 100% !`,
    UI_ALARM_DUPLICATES: `Doublons bientôt pleins !`,
    UI_ALARM_MONEY: `Argent max !`,
    UI_END_IMPOSSIBLE: `Vous devez posséder toutes
les cartes de la collection`,
    UI_CREDITS_MESSAGES: [
      `développé par
DOIGT`,
      `studio
FINGER GAMES`,
      `game designer
DOIGT`,
      `sound designer
DOIGT`,
    ],
    UI_TRIPLE: `triplé`,
    UI_MODULE_FULL: `Vous possédez toutes les cartes`,
    SETTINGS_MUSIC: `Volume musiques`,
    SETTINGS_SOUNDS: `Volume sonore`,
    SETTINGS_FULLSCREEN: `Plein écran`,
    SETTINGS_CRT: `Effet CRT`,
    SETTINGS_SHAKE: `Tremblements de caméra`,
    SETTINGS_FLASH: `Flash d'écran`,
    SETTINGS_LANGUAGE: `Langue`,
    SETTINGS_ACTUAL_LANGUAGE: `Français`,
    SETTINGS_RESET: `Détruire la sauvegarde`,
    STATS: {
      game_duration: `Temps de jeu`,
      afk_duration: `Temps passé AFK`,
      nb_clicks: `Clics totaux`,
      nb_boosters_cracked: `Boosters ouverts`,
      nb_cards_duplicates: `Doublons obtenus`,
      nb_modules_win: `Modules gagnés`,
      nb_money_total: `Pactole encaissé`,
      nb_money_spent: `Pactole dépensé`,
      nb_cards_stamped: `Tampons appliqués`,
      nb_coins: `Pièces récoltées`,
      nb_employee_cost: `Coût des employés`,
      nb_employee_clicks: `Clics des employés`,
      nb_boosters_triple: `Boosters {orange}triplés`,
      nb_boosters_godpack: `{godpack}[c_white] obtenus`,
      nb_boosters_record: `Plus gros booster`,
    },
    ROLL_DOUBLE_VARIANT: `Double temporairement les raretés`,
    ROLL_DOUBLE_VALUE: `Double temporairement les prix de vente`,
    ROLL_DOUBLE_COOLDOWN: `Triple la vitesse de recharge des boosters`,
    ROLL_RAIN_COINS: `Pluie de pièces`,
    ROLL_RAIN_CARDS: `Pluie de cartes`,
    ROLL_RAIN_BOOSTERS: `Pluie de boosters`,
    ROLL_ALL_BOOSTERS_VARIANT: `Tous les boosters sont {type5}`,
    ROLL_NEW_CARD: `Nouvelle carte`,
    ROLL_SPEED: `Vitesse accélérée`,
    ROLL_NOTHING: `Rien :(`,
    ROLL_RESET: `{red}BANQUEROUTE`,
    ROLL_DOUBLE_MONEY: `Argent [shake]doublé`,
    MODULE_LAB: `Labo de fusion`,
    MODULE_LAB_OUTPUT: `Résultat`,
    MODULE_LAB_INPUTS: `Ingrédients`,
    MODULE_LAB_LAUNCH: `Début du projet`,
    MODULE_LAB_DESC: `{blue}Choisissez{black} une nouvelle carte à créer. Elle demandera {blue}2 variants inférieurs{black} pour être fusionnée. La fusion démarrera dès que vous aurez {blue}trouvé les bonnes cartes{black}.`,
    MODULE_LAB_FINISHED: `Fusion terminée !`,
    MODULE_MEMORY: `Memory`,
    MODULE_MEMORY_WIN: `Memory réussi !`,
    MODULE_MEMORY_DESC: `{blue}Retournez{black} une pair de cartes pour les découvrir. Vous devez {blue}trouver chaque pair de cartes identiques{black} en 5 essais. Il existe forcément une paire non possédée.`,
    MODULE_ARENA: `Arène`,
    MODULE_ARENA_HIM: [
      `skouizi`,
      `dark_tenebrum`,
      `DarkShadow27`,
      `KillerDu62`,
      `SkullHunter92`,
      `fan2cartes`,
      `NinjaWolf27`,
      `DragonSlayer94`,
      `DarkTitan92`,
    ],
    MODULE_ARENA_VS: `VS`,
    MODULE_ARENA_YOU: `Vous`,
    MODULE_ARENA_MISS: `Esquive !`,
    MODULE_ARENA_WIN: `Vous avez gagné !`,
    MODULE_ARENA_LOSE: `Vous avez perdu !`,
    MODULE_ARENA_DRAW: `Match nul !`,
    MODULE_ARENA_DESC: `Faites {blue}combattre vos cartes{black} contre celles d'un adversaire. S'il est vaincu, {blue}vous volez ses cartes{black}. Il possède forcément une carte nouvelle.`,
    MODULE_MUSEUM: `Musée`,
    MODULE_MUSEUM_INTRO: `Choisis 5 cartes
à exposer !`,
    MODULE_MUSEUM_ENTRIES: `Visiteurs`,
    MODULE_MUSEUM_PRICE: `Prix du billet`,
    MODULE_MUSEUM_PRICE_SHORT: `Billet`,
    MODULE_MUSEUM_RISK: `Risque`,
    MODULE_MUSEUM_RISK_PRICE: `Caution`,
    MODULE_MUSEUM_REWARD: `Bénéfices`,
    MODULE_MUSEUM_IMPOSSIBLE: `Vous n'avez pas la caution`,
    MODULE_MUSEUM_WAITING: `Espérons que le prix
ne rebute pas...`,
    MODULE_MUSEUM_LOSE: `L'expo est annulée !`,
    MODULE_MUSEUM_WIN: `L'expo aura lieu !`,
    MODULE_MUSEUM_DESC: `{blue}Exposez 5 de vos cartes{black} dans un musée. Vous pouvez augmenter le {blue}prix d'entrée{black} mais aussi le {red}risque que l'événement soit un échec{black} et vous coûte de l'argent.`,
    BOOSTER_000_NAME: `Booster débutant`,
    BOOSTER_000_DESC: `Boosters d'introduction gratuits`,
    BOOSTER_001_NAME: `Booster standard`,
    BOOSTER_001_DESC: `Boosters avec une répartition de rareté classique`,
    BOOSTER_002_NAME: `Booster deluxe`,
    BOOSTER_002_DESC: `Boosters avec de meilleures chances de rareté`,
    BOOSTER_003_NAME: `Méga Booster`,
    BOOSTER_003_DESC: `Boosters remplis de cartes communes`,
    BOOSTER_004_NAME: `Booster au carré`,
    BOOSTER_004_DESC: `Boosters parfaitement équilibré`,
    BOOSTER_005_NAME: `Booster polarisé`,
    BOOSTER_005_DESC: `Boosters qui sont soit très récompensants soit très décevants`,
    BOOSTER_006_NAME: `Booster temporel`,
    BOOSTER_006_DESC: `Boosters dont la qualité s'améliore avec le temps`,
    BOOSTER_007_NAME: `Booster de croissance`,
    BOOSTER_007_DESC: `Boosters qui s'améliorent à chaque achat`,
    UPGRADE_000_NAME: `Dégâts de {boosters}`,
    UPGRADE_000_DESC: `Dégâts de {boosters} : -{value}`,
    UPGRADE_001_NAME: `Dé {type1}`,
    UPGRADE_001_DESC: `{value}% de chance d'avoir une carte {type1}`,
    UPGRADE_002_NAME: `Unlock duplicates`,
    UPGRADE_002_DESC: `Storable duplicates: up to {value} {star}`,
    UPGRADE_003_NAME: `{boosters} débloqués`,
    UPGRADE_003_DESC: `Types de {boosters} dans la {shop} : {value}`,
    UPGRADE_004_NAME: `Recharge des {boosters}`,
    UPGRADE_004_DESC: `Temps de recharge des {boosters} : -{value}%`,
    UPGRADE_005_NAME: `Gros paquets`,
    UPGRADE_005_DESC: `{value}% de chance que les {boosters} soient {orange}triplés`,
    UPGRADE_006_NAME: `Taille du stockage`,
    UPGRADE_006_DESC: `{duplicates} stockables max : {value}`,
    UPGRADE_007_NAME: `Valeur 1 {star}`,
    UPGRADE_007_DESC: `Valeur des cartes 1 {star} : x{value}`,
    UPGRADE_008_NAME: `Taille de la table`,
    UPGRADE_008_DESC: `Maximum de {boosters} sur la table : {value}`,
    UPGRADE_009_NAME: `Multi-mains`,
    UPGRADE_009_DESC: `{value} cartes retournables à la fois`,
    UPGRADE_010_NAME: `Lots surprise`,
    UPGRADE_010_DESC: `Les {boosters} peuvent être achetés par lots de {value}`,
    UPGRADE_011_NAME: `Mains de magicien`,
    UPGRADE_011_DESC: `Vitesse de retournement de cartes : x{value}`,
    UPGRADE_012_NAME: `Valeur 2 {star}`,
    UPGRADE_012_DESC: `Valeur des cartes 2 {star} : x{value}`,
    UPGRADE_013_NAME: `Valeur 3 {star}`,
    UPGRADE_013_DESC: `Valeur des cartes 3 {star} x{value}`,
    UPGRADE_014_NAME: `Valeur 4 {star}`,
    UPGRADE_014_DESC: `Valeur des cartes 4 {star} x{value}`,
    UPGRADE_015_NAME: `Valeur {type1}`,
    UPGRADE_015_DESC: `Valeur des cartes {type1} : x{value}`,
    UPGRADE_016_NAME: `Valeur {type2}`,
    UPGRADE_016_DESC: `Valeur des cartes {type2} : x{value}`,
    UPGRADE_017_NAME: `Valeur {type3}`,
    UPGRADE_017_DESC: `Valeur des cartes {type3} : x{value}`,
    UPGRADE_018_NAME: `Valeur {type4}`,
    UPGRADE_018_DESC: `Valeur des cartes {type4} : x{value}`,
    UPGRADE_019_NAME: `Dé {type2}`,
    UPGRADE_019_DESC: `{value}% de chance d'avoir une carte {type2}`,
    UPGRADE_020_NAME: `Dé {type3}`,
    UPGRADE_020_DESC: `{value}% de chance d'avoir une carte {type3}`,
    UPGRADE_021_NAME: `Dé {type4}`,
    UPGRADE_021_DESC: `{value}% de chance d'avoir une carte {type4}`,
    UPGRADE_022_NAME: `Guerre des clones`,
    UPGRADE_022_DESC: `{value}% de chance que les cartes retournées se dédoublent`,
    UPGRADE_023_NAME: `Quantité de clones`,
    UPGRADE_023_DESC: `Nombre de clones : 1 à {value}`,
    UPGRADE_024_NAME: `Demande en hausse`,
    UPGRADE_024_DESC: `Les {duplicates} se vendent par {value}`,
    UPGRADE_025_NAME: `Multinationale`,
    UPGRADE_025_DESC: `Argent max : infinie$`,
    UPGRADE_026_NAME: `Lancer une entreprise`,
    UPGRADE_026_DESC: `Argent max : {value}$`,
    UPGRADE_027_NAME: `Portefeuille`,
    UPGRADE_027_DESC: `Argent max : {value}$
{green}Des pièces peuvent tomber`,
    UPGRADE_028_NAME: `Pelle`,
    UPGRADE_028_DESC: `Rayon de clic du curseur : {value}`,
    UPGRADE_029_NAME: `Tractopelle`,
    UPGRADE_029_DESC: `Maintenir {right_click} auto-clique {value}x par seconde`,
    UPGRADE_030_NAME: `Aimant`,
    UPGRADE_030_DESC: `Un aimant attire les cartes {value}x par seconde`,
    UPGRADE_031_NAME: `Acheteur d'occasions`,
    UPGRADE_031_DESC: `{duplicates} vendus automatiquement : {value}% de chance`,
    UPGRADE_032_NAME: `{blister}`,
    UPGRADE_032_DESC: `Des {boosters} peuvent être emballés, ils sont vendus s'ils restent intacts`,
    UPGRADE_033_NAME: `négociation accrue`,
    UPGRADE_033_DESC: `Valeur potentielle du {blister} : x{value} `,
    UPGRADE_034_NAME: `Revendeur suspect`,
    UPGRADE_034_DESC: `La {shop} propose régulièrement des cartes`,
    UPGRADE_035_NAME: `Sceau {type1}`,
    UPGRADE_035_DESC: `{left_click} sur une nouvelle carte {type1} donne des pièces d'argent`,
    UPGRADE_036_NAME: `Sceau {type2}`,
    UPGRADE_036_DESC: `{left_click} sur une nouvelle carte {type2} donne des pièces d'or`,
    UPGRADE_037_NAME: `Sceau {type3}`,
    UPGRADE_037_DESC: `{left_click} sur une nouvelle carte {type3} accélère le jeu`,
    UPGRADE_038_NAME: `Sceau {type4}`,
    UPGRADE_038_DESC: `{left_click} sur une nouvelle carte {type4} inverse un paquet`,
    UPGRADE_039_NAME: `Campagne de recrutement`,
    UPGRADE_039_DESC: `Permet de recruter des employés`,
    UPGRADE_040_NAME: `Livreur`,
    UPGRADE_040_DESC: `Livreurs : {value}
{red}-50$ {red}par seconde`,
    UPGRADE_041_NAME: `Retourneur de cartes`,
    UPGRADE_041_DESC: `Retourneurs de cartes : {value}
{red}-50$ {red}par seconde`,
    UPGRADE_042_NAME: `Vendeur`,
    UPGRADE_042_DESC: `Vendeurs : {value}
{red}-50$ {red}par seconde`,
    UPGRADE_043_NAME: `Grosse boîte`,
    UPGRADE_043_DESC: `Argent max : {value}$
`,
    UPGRADE_044_NAME: `Dé {type5}`,
    UPGRADE_044_DESC: `{value}% de chance d'avoir une carte {type5}`,
    UPGRADE_045_NAME: `Dé {type6}`,
    UPGRADE_045_DESC: `{value}% de chance d'avoir une carte {type6}`,
    UPGRADE_046_NAME: `Valeur {type5}`,
    UPGRADE_046_DESC: `Valeur des cartes {type5} : x{value}`,
    UPGRADE_047_NAME: `Valeur {type6}`,
    UPGRADE_047_DESC: `Valeur des cartes {type6} : x{value}`,
    UPGRADE_048_NAME: `Sceau {type5}`,
    UPGRADE_048_DESC: `{left_click} sur une nouvelle carte {type5} mélange un paquet`,
    UPGRADE_049_NAME: `Premier DLC`,
    UPGRADE_049_DESC: `Ajoute {red}210 {black}nouvelles cartes à collectionner`,
    UPGRADE_050_NAME: `Second DLC`,
    UPGRADE_050_DESC: `Ajoute {red}210 {black}nouvelles cartes à collectionner`,
    UPGRADE_051_NAME: `Troisième DLC`,
    UPGRADE_051_DESC: `Ajoute {red}371 {black}nouvelles cartes à collectionner`,
    UPGRADE_052_NAME: `Héritage`,
    UPGRADE_052_DESC: `{red}Débloque le {type6} {black}et {red}relance {black}la partie en conservant la valeur de la collection actuelle`,
    UPGRADE_053_NAME: `Fouet`,
    UPGRADE_053_DESC: `Vitesse de travail : x{value}
{red}(salaire adapté)`,
    UPGRADE_054_NAME: `Recherche et développement`,
    UPGRADE_054_DESC: `Débloque des modules de développement`,
    UPGRADE_055_NAME: `Labo de fusion`,
    UPGRADE_055_DESC: `Permet de créer des cartes en fusionnant des variantes inférieures`,
    UPGRADE_056_NAME: `Jeu de Memory`,
    UPGRADE_056_DESC: `Résolvez un memory pour recevoir toutes les cartes dont une nouvelle`,
    UPGRADE_057_NAME: `Tournoi TCG`,
    UPGRADE_057_DESC: `Gagnez un combat pour voler les cartes de votre adversaire dont une nouvelle`,
    UPGRADE_058_NAME: `Exposition dans un musée`,
    UPGRADE_058_DESC: `Exposez vos cartes afin de gagner de l'argent mais gare au flop !`,
    UPGRADE_059_NAME: `Sceau {type6}`,
    UPGRADE_059_DESC: `{left_click} sur une nouvelle carte {type6} lance le {roll}`,
    UPGRADE_060_NAME: `Grâce divine`,
    UPGRADE_060_DESC: `Les {boosters} peuvent miraculeusement se transformer en {godpack}`,
    UPGRADE_061_NAME: `Années d'étude`,
    UPGRADE_061_DESC: `La fusion pourra créer des cartes {typevalue}`,
    UPGRADE_062_NAME: `Simplification (gros nul)`,
    UPGRADE_062_DESC: `Nombre de vies : {value}`,
    UPGRADE_063_NAME: `Équipement amélioré`,
    UPGRADE_063_DESC: `Vos troupes ont {value}% de chance d'{orange}esquiver{black} ou donner un {orange}coup critique{black}`,
    UPGRADE_064_NAME: `Aile supplémentaire`,
    UPGRADE_064_DESC: `Le musée pourra exposer des cartes {typevalue}`,
    UPGRADE_065_NAME: `Alarme incendie`,
    UPGRADE_065_DESC: `Alerte quand vous approchez le max d'argent ou {duplicates}`,
    UPGRADE_066_NAME: `Domination totale`,
    UPGRADE_066_DESC: `Conquérez le marché mondial des cartes à collectionner
{red}Fin de partie`,
    CARD_000_NAME: `Mètre ruban`,
    CARD_000_DESC: `Ne mentionnez pas d'autres unités de mesure devant lui`,
    CARD_001_NAME: `Couteau suisse`,
    CARD_001_DESC: `Pratique, versatile et rouge`,
    CARD_002_NAME: `Clou`,
    CARD_002_DESC: `Utilisé pour attacher des objets ou des humains`,
    CARD_003_NAME: `Éponge`,
    CARD_003_DESC: `Pour combien lèches-tu la partie verte après usage ??`,
    CARD_004_NAME: `T-shirt sale`,
    CARD_004_DESC: `Il est en taille oversize`,
    CARD_005_NAME: `Tasse`,
    CARD_005_DESC: `Peut contenir divers liquides`,
    CARD_006_NAME: `Ampoule`,
    CARD_006_DESC: `Blinded by the light`,
    CARD_007_NAME: `Post-it`,
    CARD_007_DESC: `Penser à racheter du lait`,
    CARD_008_NAME: `Multiprise`,
    CARD_008_DESC: `Branchez-la à elle-même pour générer de l'énergie infinie`,
    CARD_009_NAME: `Pièce côté pile`,
    CARD_009_DESC: `Pile ou face ? C'était face malheureusement`,
    CARD_010_NAME: `Pièce côté face`,
    CARD_010_DESC: `Pile ou face ? C'était pile malheureusement`,
    CARD_011_NAME: `Serviette hygiénique`,
    CARD_011_DESC: `Toujours en garder une dans son sac`,
    CARD_012_NAME: `Ballon`,
    CARD_012_DESC: `Il ne manque pas d'air (enfin si parce qu'il est plein de CO2)`,
    CARD_013_NAME: `Écouteurs`,
    CARD_013_DESC: `Prennent 3 heures à être démêlés`,
    CARD_014_NAME: `Feuille A4`,
    CARD_014_DESC: `Le format A4 est de 21 x 29.7 cm`,
    CARD_015_NAME: `Timbre`,
    CARD_015_DESC: `T'es timbré ou quoi lol`,
    CARD_016_NAME: `Poteau incendie`,
    CARD_016_DESC: `AU FEU`,
    CARD_017_NAME: `Toilettes stylées`,
    CARD_017_DESC: `Psssssht`,
    CARD_018_NAME: `Pilule de soutien`,
    CARD_018_DESC: `Pour les nuits où tout n'est pas fonctionnel`,
    CARD_019_NAME: `Panneau STOP`,
    CARD_019_DESC: `STOP !! CA SUFFIT ! ARRÊTEZ !!!`,
    CARD_020_NAME: `MA voiture`,
    CARD_020_DESC: `Il s'agit de ma voiture`,
    CARD_021_NAME: `Douche`,
    CARD_021_DESC: `Ce n'est PAS une baignoire`,
    CARD_022_NAME: `Smartphone`,
    CARD_022_DESC: `Il faudrait vraiment que tu répondes...`,
    CARD_023_NAME: `Homme rassurant`,
    CARD_023_DESC: `:)`,
    CARD_024_NAME: `Souris`,
    CARD_024_DESC: `Pour mieux cliquer sur les cartes`,
    CARD_025_NAME: `Pince ampèremétrique`,
    CARD_025_DESC: `Je sais pas non plus à quoi ça sert`,
    CARD_026_NAME: `Carte bleu à découvert`,
    CARD_026_DESC: `Vous nous devez 534 millions d'euros`,
    CARD_027_NAME: `Saxophone`,
    CARD_027_DESC: `Instrument belge (je le précise car je suis belge)`,
    CARD_028_NAME: `Fidget spinner`,
    CARD_028_DESC: `Il tourne`,
    CARD_029_NAME: `Rouleau de PQ`,
    CARD_029_DESC: `Triple épaisseur`,
    CARD_030_NAME: `Chien hideux`,
    CARD_030_DESC: `OUAF OUAF (ça veut dire 'je suis hideux' en chien)`,
    CARD_031_NAME: `Mouche`,
    CARD_031_DESC: `Bzzzzzzzzz`,
    CARD_032_NAME: `As de Coeur`,
    CARD_032_DESC: `Il n'y a que les As car j'avais la flemme`,
    CARD_033_NAME: `As de Trèfle`,
    CARD_033_DESC: `Il n'y a que les As car j'avais la flemme`,
    CARD_034_NAME: `As de Pique`,
    CARD_034_DESC: `Il n'y a que les As car j'avais la flemme`,
    CARD_035_NAME: `As de Carreau`,
    CARD_035_DESC: `Il n'y a que les As car j'avais la flemme`,
    CARD_036_NAME: `Cornichon`,
    CARD_036_DESC: `Immonde dans un hamburger`,
    CARD_037_NAME: `Charbon`,
    CARD_037_DESC: `Il semble familier...`,
    CARD_038_NAME: `Cheval`,
    CARD_038_DESC: `Parfaitement dessiné`,
    CARD_039_NAME: `Léger début de calvitie`,
    CARD_039_DESC: `Non mais tkt c'est l'éclairage`,
    CARD_040_NAME: `Emmental`,
    CARD_040_DESC: `Je n'aime pas le fromage`,
    CARD_041_NAME: `Mon père`,
    CARD_041_DESC: ``,
    CARD_042_NAME: `Clé de Sol`,
    CARD_042_DESC: `Indique le sol sur une partition`,
    CARD_043_NAME: `Nem`,
    CARD_043_DESC: `Team nems aux légumes`,
    CARD_044_NAME: `Fichier MP3`,
    CARD_044_DESC: `sndCardWoosh.mp3`,
    CARD_045_NAME: `Zèbre`,
    CARD_045_DESC: `Parfaitement dessiné`,
    CARD_046_NAME: `Arc-en-ciel`,
    CARD_046_DESC: `Lié à la réfraction de la lumière`,
    CARD_047_NAME: `Comté`,
    CARD_047_DESC: `Je n'aime pas le fromage`,
    CARD_048_NAME: `Fer`,
    CARD_048_DESC: `Il semble familier...`,
    CARD_049_NAME: `Drapeau belge`,
    CARD_049_DESC: `Oui les frites une fois septante`,
    CARD_050_NAME: `Valet`,
    CARD_050_DESC: `Se référer à la description de la Dame`,
    CARD_051_NAME: `Dame`,
    CARD_051_DESC: `Se référer à la description du Roi`,
    CARD_052_NAME: `Roi`,
    CARD_052_DESC: `Se référer à la description du Valet`,
    CARD_053_NAME: `Licorne`,
    CARD_053_DESC: `Parfaitement dessinée`,
    CARD_054_NAME: `Or`,
    CARD_054_DESC: `Il semble familier...`,
    CARD_055_NAME: `Spoutnik`,
    CARD_055_DESC: `Premier satellite artificiel au monde`,
    CARD_056_NAME: `Camembert`,
    CARD_056_DESC: `Je n'aime pas le fromage`,
    CARD_057_NAME: `Joker`,
    CARD_057_DESC: `Se référer à la description du Valet`,
    CARD_058_NAME: `Diamant`,
    CARD_058_DESC: `Il semble familier...`,
    CARD_059_NAME: `Pégase`,
    CARD_059_DESC: `Divinement dessiné`,
    CARD_060_NAME: `Atome`,
    CARD_060_DESC: `Compose toute la matière`,
    CARD_061_NAME: `Joint d'étanchéité pour climatiseur de morgue`,
    CARD_061_DESC: `Artiste : Alphonse Robichu`,
    CARD_062_NAME: `Escargot suspicieux`,
    CARD_062_DESC: `Il sait`,
    CARD_063_NAME: `Rein malicieux`,
    CARD_063_DESC: `C'était censé être un poisson à la base`,
    CARD_064_NAME: `Q`,
    CARD_064_DESC: `Quel Q`,
    CARD_065_NAME: `Vaisseau spatial`,
    CARD_065_DESC: `Prêt pour la bogar`,
    CARD_066_NAME: `Mon chat`,
    CARD_066_DESC: `Son nom est CHOCOLAT <3`,
    CARD_067_NAME: `Glouton`,
    CARD_067_DESC: `Il est en quête d'un burger`,
    CARD_068_NAME: `Méduse confiante`,
    CARD_068_DESC: `Wow elle est si cool ??`,
    CARD_069_NAME: `Chapeau de paille`,
    CARD_069_DESC: `Achetable en une pièce`,
    CARD_070_NAME: `Cochon capitaliste`,
    CARD_070_DESC: `Possède un compte aux Îles Caïmans`,
    CARD_071_NAME: `Rubik's cube mélangé`,
    CARD_071_DESC: `Trop la flemme de le faire`,
    CARD_072_NAME: `Rubik's cube`,
    CARD_072_DESC: `J'ose plus y toucher`,
    CARD_073_NAME: `Scientifique du Labo`,
    CARD_073_DESC: `Il est très investi dans la conception de variants`,
    CARD_074_NAME: `Frites`,
    CARD_074_DESC: `Le fameux plat BELGE`,
    CARD_075_NAME: `Message vocal interminable`,
    CARD_075_DESC: `Ouiiii j'te fais un vocal ce sera plus rapide, euh en gros AH attends on me`,
    CARD_076_NAME: `Tirelire`,
    CARD_076_DESC: `Gruik Gruik`,
    CARD_077_NAME: `Maneki-Neko`,
    CARD_077_DESC: `Il porte bonheur`,
    CARD_078_NAME: `Tomate`,
    CARD_078_DESC: `Artiste : Lucy`,
    CARD_079_NAME: `Pied discutable`,
    CARD_079_DESC: `L'odeur aussi`,
    CARD_080_NAME: `Homme au nez proéminent`,
    CARD_080_DESC: `Que peut-il bien sentir ??`,
    CARD_081_NAME: `Cerise reniflée`,
    CARD_081_DESC: `Mais à qui appartient ce nez ??`,
    CARD_082_NAME: `Axolotl`,
    CARD_082_DESC: `23 centimètres de mignonneté`,
    CARD_083_NAME: `MargueRIP`,
    CARD_083_DESC: `Elle est jolie mais morte...`,
    CARD_084_NAME: `Costume pas cher`,
    CARD_084_DESC: `C'est de la contrefaçon mais c'est pratique`,
    CARD_085_NAME: `Paralysie du sommeil`,
    CARD_085_DESC: `Ne te retourne pas`,
    CARD_086_NAME: `Lézard bleu aux yeux blancs`,
    CARD_086_DESC: `ATK/3000   DEF/2500`,
    CARD_087_NAME: `Robot en burn-out`,
    CARD_087_DESC: `@grouk est-ce que c vrai ??`,
    CARD_088_NAME: `Catchpa`,
    CARD_088_DESC: `Cliquez sur les images de chat`,
    CARD_089_NAME: `Boule parfaitement ronde`,
    CARD_089_DESC: `4/3 * pi * r³`,
    CARD_090_NAME: `Stanley Cubique`,
    CARD_090_DESC: `C'est dans la boîte`,
    CARD_091_NAME: `Passeport`,
    CARD_091_DESC: `Vos papiers, s'il vous plait`,
    CARD_092_NAME: `Thé vert`,
    CARD_092_DESC: `Il est pas si vert que ça d'ailleurs`,
    CARD_093_NAME: `Demi-dieu`,
    CARD_093_DESC: `Sa seconde moitié est un sujet tabou`,
    CARD_094_NAME: `Petits bonshommes mignons`,
    CARD_094_DESC: `=(°u°)=`,
    CARD_095_NAME: `L'électricien`,
    CARD_095_DESC: `C'est l'électricien... Viens là`,
    CARD_096_NAME: `Rideau de douche qui colle`,
    CARD_096_DESC: `JE DETESTE`,
    CARD_097_NAME: `14h44`,
    CARD_097_DESC: `L'heure ne correspond pas à l'image, je suis un peu foufou`,
    CARD_098_NAME: `Gravité`,
    CARD_098_DESC: `Inventé par Isaac Newton`,
    CARD_099_NAME: `La centième carte créée`,
    CARD_099_DESC: `Le 02 Septembre à 23h24`,
    CARD_100_NAME: `Shamisen`,
    CARD_100_DESC: `Comment ça 3 cordes`,
    CARD_101_NAME: `Language C++`,
    CARD_101_DESC: `Le jeu n'a pas été programmé avec lui mais on respecte l'ancien`,
    CARD_102_NAME: `????`,
    CARD_102_DESC: `T'es sérieux là ??`,
    CARD_103_NAME: `Broche de kebab`,
    CARD_103_DESC: `Comme d'hab chef`,
    CARD_104_NAME: `L'homme invisible en 2020`,
    CARD_104_DESC: `Il était concerné comme tout le monde`,
    CARD_105_NAME: `Smiley clin d'oeil`,
    CARD_105_DESC: `Utilisé par des gens infréquentables`,
    CARD_106_NAME: `AI Slop`,
    CARD_106_DESC: `La carte n'a pas été générée par IA`,
    CARD_107_NAME: `Oiseau bleu`,
    CARD_107_DESC: `J'entends encore son sifflement #nostalgie`,
    CARD_108_NAME: `Cinéphile`,
    CARD_108_DESC: `Il déteste un célèbre film spatial de 2014`,
    CARD_109_NAME: `Brique de construction`,
    CARD_109_DESC: `Celle en forme de T terrorise les maçons`,
    CARD_110_NAME: `Le Plus petit violon du monde`,
    CARD_110_DESC: `Il a vraiment besoin d'un public`,
    CARD_111_NAME: `Art abstrait suspect`,
    CARD_111_DESC: `sus.........`,
    CARD_112_NAME: `Vidéo d'excuse de vidéaste`,
    CARD_112_DESC: `Je sais que rien de ce que je dirai ne pourra....`,
    CARD_113_NAME: `Banane très très mûre`,
    CARD_113_DESC: `Faut vraiment pas tarder à la manger là`,
    CARD_114_NAME: `Explosion`,
    CARD_114_DESC: `BOUUUUUUUUUUM`,
    CARD_115_NAME: `Dérèglement climatique`,
    CARD_115_DESC: `+2°C en 2050 si on agit pas (ça dénonce)`,
    CARD_116_NAME: `Streamer mal cadré`,
    CARD_116_DESC: `twitch.tv/doigt`,
    CARD_117_NAME: `Mister Fist`,
    CARD_117_DESC: `JE DONNE 300 MILLIONS AU CANDIDAT QUI SURVIT À 500 VOLTS`,
    CARD_118_NAME: `Guess my Fart`,
    CARD_118_DESC: `Un jeu qui ne plaît pas à tout le monde`,
    CARD_119_NAME: `Objet du donjon`,
    CARD_119_DESC: `Il sera utilisé uniquement pour ce donjon`,
    CARD_120_NAME: `Soleil vu de nuit`,
    CARD_120_DESC: `C'est le moment idéal pour l'attaquer`,
    CARD_121_NAME: `Pastèque`,
    CARD_121_DESC: `Libérez-la`,
    CARD_122_NAME: `Trou noir`,
    CARD_122_DESC: `Malgré sa force gravitationnelle, il ne m'attire pas autant que toi`,
    CARD_123_NAME: `Six Seven`,
    CARD_123_DESC: `SIX SEVEN SIX SEVEN`,
    CARD_124_NAME: `Billy`,
    CARD_124_DESC: `Pas un simple slime, une légende...`,
    CARD_125_NAME: `Nathan le coulant`,
    CARD_125_DESC: `Il envoie des messages avec des smileys clin d'oeil`,
    CARD_126_NAME: `Cthulhu`,
    CARD_126_DESC: `Il mesure 13 centimètres`,
    CARD_127_NAME: `Zombie`,
    CARD_127_DESC: `Greuuuraaargh`,
    CARD_128_NAME: `Fonction exponentielle`,
    CARD_128_DESC: `Hey ça monte vite quand même`,
    CARD_129_NAME: `Vent`,
    CARD_129_DESC: `Fffffffffffff`,
    CARD_130_NAME: `Format 16:9`,
    CARD_130_DESC: `Si vous quittez ce format, le jeu bug donc n'essayez pas, merci`,
    CARD_131_NAME: `Format 4:3`,
    CARD_131_DESC: `À l'ancienne`,
    CARD_132_NAME: `Produit dérivé d'influenceur`,
    CARD_132_DESC: `5,99 euros pour la nouvelle saveur goudron`,
    CARD_133_NAME: `Bouton rouge`,
    CARD_133_DESC: `N'appuyez pas dessus ça ne fera rien`,
    CARD_134_NAME: `Boule de feu`,
    CARD_134_DESC: `Inflige 25 dégâts non je rigole c'est juste un dessin calme toi`,
    CARD_135_NAME: `Carte dans une carte`,
    CARD_135_DESC: `Description de la carte : Description de la carte`,
    CARD_136_NAME: `Moustache audacieuse`,
    CARD_136_DESC: `Pour ne pas dire moche`,
    CARD_137_NAME: `Gros gigot`,
    CARD_137_DESC: `Pensez à le cuire quand même`,
    CARD_138_NAME: `Dessin pas terminé`,
    CARD_138_DESC: `J'avais pas le temps je suis à la bourre sur la sortie du jeu`,
    CARD_139_NAME: `Mégaphone fédérateur`,
    CARD_139_DESC: `C'est que le début`,
    CARD_140_NAME: `Coach sportif`,
    CARD_140_DESC: `BELIEVE`,
    CARD_141_NAME: `Hachiko`,
    CARD_141_DESC: `Symbole de fidélité et d'amour`,
    CARD_142_NAME: `Saucisseman`,
    CARD_142_DESC: `Un grand pouvoir implique de grands assaisonnements`,
  },
  re = {
    FORMAT_SHOP: `Sklep`,
    FORMAT_DUPLICATES: `Duplikaty`,
    FORMAT_UPGRADES: `Ulepszenia`,
    FORMAT_COLLECTION: `Kolekcja`,
    FORMAT_TYPE1: `Metaliczna`,
    FORMAT_TYPE2: `Złota`,
    FORMAT_TYPE3: `Holograficzna`,
    FORMAT_TYPE4: `Negatywowa`,
    FORMAT_TYPE5: `Zglitchowana`,
    FORMAT_TYPE6: `FULL ART`,
    FORMAT_BOOSTERS: `Paczki`,
    FORMAT_BLISTER: `Blister`,
    FORMAT_LEFTCLICK: `LPM`,
    FORMAT_RIGHTCLICK: `PPM`,
    FORMAT_CARDS: `Karty`,
    UI_RECORD: `Rekord`,
    UI_NEW: `Nowe`,
    UI_DESTROYED: `Zniszczone!`,
    UI_DESTROYED_DUPLICATE: `Magazyn
duplikatów
pełny`,
    UI_DESTROYED_BOOSTER: `Brak miejsca
na stole`,
    UI_DESTROYED_NOCARD: `Brak dostępnych
kart`,
    UI_UNLOCKED_PRONOUN1: `odblokowane`,
    UI_UNLOCKED_PRONOUN2: `odblokowane`,
    UI_UNLOCKED_PRONOUN3: `odblokowane`,
    UI_UNLOCKED_PRONOUN4: `odblokowane`,
    UI_COMPLETE: `Ukończono w 100%`,
    UI_BOOSTER_CLICK: `Kliknij`,
    UI_ROLL: `SZALONY PREZENT`,
    UI_SAVING: `Zapisywanie...`,
    UI_BUTTON_SORT_STAR: `Według gwiazdek`,
    UI_BUTTON_SORT_QUANTITY: `Według liczby`,
    UI_BUTTON_SORT_ASCENDING: `rosnąco`,
    UI_BUTTON_SORT_DESCENDING: `malejąco`,
    UI_BUTTON_EMPLOYEE_SLEEP_NO: `aktywni pracownicy`,
    UI_BUTTON_EMPLOYEE_SLEEP_YES: `pracownicy na przerwie`,
    UI_GODPACK: `boska paczka`,
    UI_COLLECTION_FULL: `100% KOLEKCJI`,
    UI_ALARM_DUPLICATES: `Magazyn duplikatów prawie pełny`,
    UI_ALARM_MONEY: `Osiągnięto limit pieniędzy`,
    UI_END_IMPOSSIBLE: `Musisz mieć wszystkie
karty z kolekcji`,
    UI_CREDITS_MESSAGES: [
      `twórca gry
DOIGT`,
      `studio
FINGER GAMES`,
      `projekt gry
DOIGT`,
      `udźwiękowienie
DOIGT`,
    ],
    UI_TRIPLE: `potrójne`,
    UI_MODULE_FULL: `Masz wszystkie karty`,
    SETTINGS_MUSIC: `Głośność muzyki`,
    SETTINGS_SOUNDS: `Głośność dźwięków`,
    SETTINGS_FULLSCREEN: `Pełny ekran`,
    SETTINGS_CRT: `Efekt CRT`,
    SETTINGS_SHAKE: `Wstrząsy ekranu`,
    SETTINGS_FLASH: `Błyski ekranu`,
    SETTINGS_LANGUAGE: `Język`,
    SETTINGS_ACTUAL_LANGUAGE: `Polski`,
    SETTINGS_RESET: `Usuń zapis`,
    STATS: {
      game_duration: `Czas gry`,
      afk_duration: `Czas bezczynności`,
      nb_clicks: `Liczba kliknięć`,
      nb_boosters_cracked: `Otwarte paczki`,
      nb_cards_duplicates: `Zdobyte duplikaty`,
      nb_modules_win: `Ukończone moduły`,
      nb_money_total: `Zarobione pieniądze`,
      nb_money_spent: `Wydane pieniądze`,
      nb_cards_stamped: `Przybite pieczęcie`,
      nb_coins: `Zdobyte monety`,
      nb_employee_cost: `Koszty pracowników`,
      nb_employee_clicks: `Kliknięcia pracowników`,
      nb_boosters_triple: `{orange}Potrójne paczki`,
      nb_boosters_godpack: `[c_white]zdobyto {godpack}`,
      nb_boosters_record: `Największa paczka`,
    },
    ROLL_DOUBLE_VARIANT: `Tymczasowo podwaja rzadkość`,
    ROLL_DOUBLE_VALUE: `Tymczasowo podwaja ceny sprzedaży`,
    ROLL_DOUBLE_COOLDOWN: `Paczki odnawiają się 3 razy szybciej`,
    ROLL_RAIN_COINS: `Deszcz monet`,
    ROLL_RAIN_CARDS: `Deszcz kart`,
    ROLL_RAIN_BOOSTERS: `Deszcz paczek`,
    ROLL_ALL_BOOSTERS_VARIANT: `Wszystkie paczki otrzymują wariant {type5}`,
    ROLL_NEW_CARD: `Nowa karta`,
    ROLL_SPEED: `Zwiększona prędkość`,
    ROLL_NOTHING: `Nic :(`,
    ROLL_RESET: `{red}BANKRUCTWO`,
    ROLL_DOUBLE_MONEY: `[shake]Podwójna forsa`,
    MODULE_LAB: `Laboratorium fuzji`,
    MODULE_LAB_OUTPUT: `Wynik`,
    MODULE_LAB_INPUTS: `Składniki`,
    MODULE_LAB_LAUNCH: `Rozpocznij projekt`,
    MODULE_LAB_DESC: `{blue}Wybierz{black} nową kartę do stworzenia. Do fuzji potrzebujesz {blue}2 wariantów niższego poziomu{black}. Fuzja rozpocznie się, gdy tylko {blue}znajdziesz odpowiednie karty{black}.`,
    MODULE_LAB_FINISHED: `Fuzja zakończona!`,
    MODULE_MEMORY: `Memory`,
    MODULE_MEMORY_WIN: `Wszystkie pary znalezione!`,
    MODULE_MEMORY_DESC: `{blue}Odkrywaj{black} po dwie karty. Musisz {blue}znaleźć wszystkie pary{black} w ciągu 5 prób. Wśród par zawsze znajdzie się karta, której jeszcze nie masz.`,
    MODULE_ARENA: `Arena`,
    MODULE_ARENA_HIM: [
      `skouizi`,
      `dark_tenebrum`,
      `DarkShadow27`,
      `KillerDu62`,
      `SkullHunter92`,
      `fan2cartes`,
      `NinjaWolf27`,
      `DragonSlayer94`,
      `DarkTitan92`,
    ],
    MODULE_ARENA_VS: `VS`,
    MODULE_ARENA_YOU: `Ty`,
    MODULE_ARENA_MISS: `Unik!`,
    MODULE_ARENA_WIN: `Wygrałeś!`,
    MODULE_ARENA_LOSE: `Przegrałeś!`,
    MODULE_ARENA_DRAW: `Remis!`,
    MODULE_ARENA_DESC: `Niech twoje {blue}karty walczą{black} z kartami przeciwnika. Jeśli pokonasz jego karty, {blue}zabierzesz je dla siebie{black}. Wśród nich zawsze będzie karta, której jeszcze nie masz.`,
    MODULE_MUSEUM: `Muzeum`,
    MODULE_MUSEUM_INTRO: `Wybierz 5 kart
do wystawienia!`,
    MODULE_MUSEUM_ENTRIES: `Odwiedzający`,
    MODULE_MUSEUM_PRICE: `Cena biletu`,
    MODULE_MUSEUM_PRICE_SHORT: `Bilet`,
    MODULE_MUSEUM_RISK: `Ryzyko`,
    MODULE_MUSEUM_RISK_PRICE: `Depozyt`,
    MODULE_MUSEUM_REWARD: `Zysk`,
    MODULE_MUSEUM_IMPOSSIBLE: `Nie masz środków na depozyt`,
    MODULE_MUSEUM_WAITING: `Miejmy nadzieję, że cena
ich nie wystraszy...`,
    MODULE_MUSEUM_LOSE: `Wystawa odwołana!`,
    MODULE_MUSEUM_WIN: `Wystawa się odbędzie!`,
    MODULE_MUSEUM_DESC: `{blue}Wystaw 5 swoich kart{black} w muzeum. Możesz podnieść {blue}cenę wstępu{black}, ale zwiększysz też {red}ryzyko niepowodzenia wystawy{black} i straty pieniędzy.`,
    BOOSTER_000_NAME: `Paczka startowa`,
    BOOSTER_000_DESC: `Darmowe paczki na dobry początek`,
    BOOSTER_001_NAME: `Zwykła paczka`,
    BOOSTER_001_DESC: `Paczki ze standardowym rozkładem rzadkości kart`,
    BOOSTER_002_NAME: `Paczka deluxe`,
    BOOSTER_002_DESC: `Paczki z większą szansą na rzadkie karty`,
    BOOSTER_003_NAME: `Megapaczka`,
    BOOSTER_003_DESC: `Paczki wypchane zwykłymi kartami`,
    BOOSTER_004_NAME: `Kwadratowa paczka`,
    BOOSTER_004_DESC: `Idealnie zrównoważone paczki`,
    BOOSTER_005_NAME: `Spolaryzowana paczka`,
    BOOSTER_005_DESC: `Paczki, które albo zachwycą, albo potwornie rozczarują`,
    BOOSTER_006_NAME: `Paczka czasu`,
    BOOSTER_006_DESC: `Paczki, których jakość rośnie z czasem`,
    BOOSTER_007_NAME: `Rosnąca paczka`,
    BOOSTER_007_DESC: `Paczki, których jakość rośnie z każdym zakupem`,
    UPGRADE_000_NAME: `{boosters}: obrażenia`,
    UPGRADE_000_DESC: `{boosters}: obrażenia -{value}`,
    UPGRADE_001_NAME: `Kostka {type1}`,
    UPGRADE_001_DESC: `{value}% szansy na kartę w wariancie {type1}`,
    UPGRADE_002_NAME: `Odblokuj duplikaty`,
    UPGRADE_002_DESC: `Możesz przechowywać duplikaty o maksymalnie {value} {star}`,
    UPGRADE_003_NAME: `{boosters}: dostępne rodzaje`,
    UPGRADE_003_DESC: `{shop} ({boosters}): liczba rodzajów {value}`,
    UPGRADE_004_NAME: `{boosters}: czas odnowienia`,
    UPGRADE_004_DESC: `{boosters}: czas odnowienia -{value}%`,
    UPGRADE_005_NAME: `Wielkie paczki`,
    UPGRADE_005_DESC: `{boosters}: {value}% szansy na {orange}potrojenie`,
    UPGRADE_006_NAME: `Pojemność magazynu`,
    UPGRADE_006_DESC: `{duplicates}: limit przechowywania {value}`,
    UPGRADE_007_NAME: `Wartość kart 1 {star}`,
    UPGRADE_007_DESC: `Wartość kart 1 {star}: x{value}`,
    UPGRADE_008_NAME: `Rozmiar stołu`,
    UPGRADE_008_DESC: `{boosters} na stole: maksymalnie {value}`,
    UPGRADE_009_NAME: `Wieloręka`,
    UPGRADE_009_DESC: `Liczba kart odwracanych jednocześnie: {value}`,
    UPGRADE_010_NAME: `Zestawy niespodzianki`,
    UPGRADE_010_DESC: `{boosters} dostępne w zestawach po {value}`,
    UPGRADE_011_NAME: `Dłonie magika`,
    UPGRADE_011_DESC: `Szybkość odwracania kart: x{value}`,
    UPGRADE_012_NAME: `Wartość kart 2 {star}`,
    UPGRADE_012_DESC: `Wartość kart 2 {star}: x{value}`,
    UPGRADE_013_NAME: `Wartość kart 3 {star}`,
    UPGRADE_013_DESC: `Wartość kart 3 {star}: x{value}`,
    UPGRADE_014_NAME: `Wartość kart 4 {star}`,
    UPGRADE_014_DESC: `Wartość kart 4 {star}: x{value}`,
    UPGRADE_015_NAME: `Wartość {type1}`,
    UPGRADE_015_DESC: `Wartość kart w wariancie {type1}: x{value}`,
    UPGRADE_016_NAME: `Wartość {type2}`,
    UPGRADE_016_DESC: `Wartość kart w wariancie {type2}: x{value}`,
    UPGRADE_017_NAME: `Wartość {type3}`,
    UPGRADE_017_DESC: `Wartość kart w wariancie {type3}: x{value}`,
    UPGRADE_018_NAME: `Wartość {type4}`,
    UPGRADE_018_DESC: `Wartość kart w wariancie {type4}: x{value}`,
    UPGRADE_019_NAME: `Kostka {type2}`,
    UPGRADE_019_DESC: `{value}% szansy na kartę w wariancie {type2}`,
    UPGRADE_020_NAME: `Kostka {type3}`,
    UPGRADE_020_DESC: `{value}% szansy na kartę w wariancie {type3}`,
    UPGRADE_021_NAME: `Kostka {type4}`,
    UPGRADE_021_DESC: `{value}% szansy na kartę w wariancie {type4}`,
    UPGRADE_022_NAME: `Wojny klonów`,
    UPGRADE_022_DESC: `{value}% szansy na sklonowanie kart przy odwracaniu`,
    UPGRADE_023_NAME: `Liczba klonów`,
    UPGRADE_023_DESC: `Liczba klonów: od 1 do {value}`,
    UPGRADE_024_NAME: `Rosnący popyt`,
    UPGRADE_024_DESC: `{duplicates} sprzedają się partiami po {value}`,
    UPGRADE_025_NAME: `Międzynarodowa korporacja`,
    UPGRADE_025_DESC: `Limit pieniędzy: $1000000000000000000000000`,
    UPGRADE_026_NAME: `Załóż firmę`,
    UPGRADE_026_DESC: "Limit pieniędzy: ${value}",
    UPGRADE_027_NAME: `Portfel`,
    UPGRADE_027_DESC: `Limit pieniędzy: \${value}
{green}Mogą wypadać monety`,
    UPGRADE_028_NAME: `Łopata`,
    UPGRADE_028_DESC: `Promień kliknięcia kursora: {value}`,
    UPGRADE_029_NAME: `Koparka`,
    UPGRADE_029_DESC: `Przytrzymaj {right_click}, aby automatycznie klikać {value} razy na sekundę`,
    UPGRADE_030_NAME: `Magnes`,
    UPGRADE_030_DESC: `Magnes przyciąga karty {value} razy na sekundę`,
    UPGRADE_031_NAME: `Łowca okazji`,
    UPGRADE_031_DESC: `{duplicates}: {value}% szansy na automatyczną sprzedaż`,
    UPGRADE_032_NAME: `{blister}`,
    UPGRADE_032_DESC: `{boosters} mogą zostać zapakowane; jeśli pozostaną nieotwarte, zostaną sprzedane`,
    UPGRADE_033_NAME: `Lepsze negocjacje`,
    UPGRADE_033_DESC: `{blister}: potencjalna wartość x{value}`,
    UPGRADE_034_NAME: `Podejrzany handlarz`,
    UPGRADE_034_DESC: `{shop} regularnie oferuje karty`,
    UPGRADE_035_NAME: `Pieczęć {type1}`,
    UPGRADE_035_DESC: `Kliknij {left_click} nową kartę w wariancie {type1}, aby zdobyć srebrne monety`,
    UPGRADE_036_NAME: `Pieczęć {type2}`,
    UPGRADE_036_DESC: `Kliknij {left_click} nową kartę w wariancie {type2}, aby zdobyć złote monety`,
    UPGRADE_037_NAME: `Pieczęć {type3}`,
    UPGRADE_037_DESC: `Kliknij {left_click} nową kartę w wariancie {type3}, aby przyspieszyć grę`,
    UPGRADE_038_NAME: `Pieczęć {type4}`,
    UPGRADE_038_DESC: `Kliknij {left_click} nową kartę w wariancie {type4}, aby odwrócić paczkę`,
    UPGRADE_039_NAME: `Akcja rekrutacyjna`,
    UPGRADE_039_DESC: `Pozwala zatrudniać pracowników`,
    UPGRADE_040_NAME: `Dostawca`,
    UPGRADE_040_DESC: `Dostawcy: {value}
{red}-$50 {red}na sekundę`,
    UPGRADE_041_NAME: `Otwieracz kart`,
    UPGRADE_041_DESC: `Otwieracze kart: {value}
{red}-$50 {red}na sekundę`,
    UPGRADE_042_NAME: `Sprzedawca`,
    UPGRADE_042_DESC: `Sprzedawcy: {value}
{red}-$50 {red}na sekundę`,
    UPGRADE_043_NAME: `Hipermarket`,
    UPGRADE_043_DESC: `Limit pieniędzy: \${value}
`,
    UPGRADE_044_NAME: `Kostka {type5}`,
    UPGRADE_044_DESC: `{value}% szansy na kartę w wariancie {type5}`,
    UPGRADE_045_NAME: `Kostka {type6}`,
    UPGRADE_045_DESC: `{value}% szansy na kartę w wariancie {type6}`,
    UPGRADE_046_NAME: `Wartość {type5}`,
    UPGRADE_046_DESC: `Wartość kart w wariancie {type5}: x{value}`,
    UPGRADE_047_NAME: `Wartość {type6}`,
    UPGRADE_047_DESC: `Wartość kart w wariancie {type6}: x{value}`,
    UPGRADE_048_NAME: `Pieczęć {type5}`,
    UPGRADE_048_DESC: `Kliknij {left_click} nową kartę w wariancie {type5}, aby przetasować paczkę`,
    UPGRADE_049_NAME: `Pierwsze DLC`,
    UPGRADE_049_DESC: `Dodaje {red}210 {black}nowych kart do kolekcji`,
    UPGRADE_050_NAME: `Drugie DLC`,
    UPGRADE_050_DESC: `Dodaje {red}210 {black}nowych kart do kolekcji`,
    UPGRADE_051_NAME: `Trzecie DLC`,
    UPGRADE_051_DESC: `Dodaje {red}371 {black}nowych kart do kolekcji`,
    UPGRADE_052_NAME: `Dziedzictwo`,
    UPGRADE_052_DESC: `{red}Odblokowuje {type6} {black}i {red}rozpoczyna grę od nowa{black}, zachowując obecną wartość twojej kolekcji`,
    UPGRADE_053_NAME: `Bat`,
    UPGRADE_053_DESC: `Szybkość pracy: x{value}
{red}(odpowiednio dostosowane płace)`,
    UPGRADE_054_NAME: `Badania i rozwój`,
    UPGRADE_054_DESC: `Odblokowuje moduły rozwoju`,
    UPGRADE_055_NAME: `Laboratorium fuzji`,
    UPGRADE_055_DESC: `Pozwala tworzyć karty przez łączenie wariantów niższego poziomu`,
    UPGRADE_056_NAME: `Memory`,
    UPGRADE_056_DESC: `Znajdź wszystkie pary w grze memory, aby otrzymać wszystkie karty, w tym jedną nową`,
    UPGRADE_057_NAME: `Turniej TCG`,
    UPGRADE_057_DESC: `Wygraj walkę, aby ukraść karty przeciwnika, w tym jedną nową`,
    UPGRADE_058_NAME: `Wystawa w muzeum`,
    UPGRADE_058_DESC: `Wystaw swoje karty, aby zarobić, ale uważaj na klapę!`,
    UPGRADE_059_NAME: `Pieczęć {type6}`,
    UPGRADE_059_DESC: `Kliknij {left_click} nową kartę w wariancie {type6}, aby uruchomić {roll}`,
    UPGRADE_060_NAME: `Boska łaska`,
    UPGRADE_060_DESC: `{boosters} mogą cudownie zmienić się w paczki typu {godpack}`,
    UPGRADE_061_NAME: `Lata nauki`,
    UPGRADE_061_DESC: `Karty dostępne do stworzenia przez fuzję: {typevalue}`,
    UPGRADE_062_NAME: `Ułatwienie (dla głąbów)`,
    UPGRADE_062_DESC: `Liczba żyć: {value}`,
    UPGRADE_063_NAME: `Lepszy ekwipunek`,
    UPGRADE_063_DESC: `Twoje oddziały mają {value}% szansy na {orange}unik{black} lub {orange}trafienie krytyczne{black}`,
    UPGRADE_064_NAME: `Dodatkowe skrzydło`,
    UPGRADE_064_DESC: `Karty dostępne do wystawienia w muzeum: {typevalue}`,
    UPGRADE_065_NAME: `Alarm przeciwpożarowy`,
    UPGRADE_065_DESC: `Ostrzega, gdy pieniądze lub {duplicates} zbliżają się do limitu`,
    UPGRADE_066_NAME: `Całkowita dominacja`,
    UPGRADE_066_DESC: `Podbij światowy rynek kart kolekcjonerskich
{red}Koniec gry`,
    CARD_000_NAME: `Metrówka`,
    CARD_000_DESC: `Nie wspominaj przy niej o innych jednostkach miary`,
    CARD_001_NAME: `Szwajcarski scyzoryk`,
    CARD_001_DESC: `Praktyczny, wszechstronny i czerwony`,
    CARD_002_NAME: `Gwóźdź`,
    CARD_002_DESC: `Służy do mocowania przedmiotów lub ludzi`,
    CARD_003_NAME: `Gąbka`,
    CARD_003_DESC: `Za ile poliżesz zieloną stronę po zmywaniu??`,
    CARD_004_NAME: `Brudny T-shirt`,
    CARD_004_DESC: `To krój oversize`,
    CARD_005_NAME: `Kubek`,
    CARD_005_DESC: `Pomieści różne płyny`,
    CARD_006_NAME: `Żarówka`,
    CARD_006_DESC: `Oślepieni blaskiem`,
    CARD_007_NAME: `Karteczka samoprzylepna`,
    CARD_007_DESC: `Pamiętaj, żeby kupić mleko`,
    CARD_008_NAME: `Listwa zasilająca`,
    CARD_008_DESC: `Podłącz ją do niej samej, aby uzyskać nieskończoną energię`,
    CARD_009_NAME: `Reszka`,
    CARD_009_DESC: `Orzeł czy reszka? Niestety wypadł orzeł`,
    CARD_010_NAME: `Orzeł`,
    CARD_010_DESC: `Orzeł czy reszka? Niestety wypadła reszka`,
    CARD_011_NAME: `Podpaska`,
    CARD_011_DESC: `Zawsze miej jedną w torbie`,
    CARD_012_NAME: `Balon`,
    CARD_012_DESC: `Wypełniony w 99% powietrzem i w 1% śliną`,
    CARD_013_NAME: `Słuchawki douszne`,
    CARD_013_DESC: `Rozplątanie zajmuje 3 godziny`,
    CARD_014_NAME: `Kartka A4`,
    CARD_014_DESC: `A4 ma wymiary 21 x 29,7 cm`,
    CARD_015_NAME: `Stempel`,
    CARD_015_DESC: `Zatwierdzono`,
    CARD_016_NAME: `Hydrant`,
    CARD_016_DESC: `POŻAR!`,
    CARD_017_NAME: `Wypasiony sedes`,
    CARD_017_DESC: `Psssssz`,
    CARD_018_NAME: `Tabletka na potencję`,
    CARD_018_DESC: `Na te noce, kiedy nie wszystko działa jak trzeba`,
    CARD_019_NAME: `Znak STOP`,
    CARD_019_DESC: `STOP!! WYSTARCZY! STOP!!!`,
    CARD_020_NAME: `MÓJ samochód`,
    CARD_020_DESC: `Niemiec płakał, jak sprzedawał`,
    CARD_021_NAME: `Prysznic`,
    CARD_021_DESC: `To NIE jest wanna`,
    CARD_022_NAME: `Smartfon`,
    CARD_022_DESC: `Lepiej odbierz...`,
    CARD_023_NAME: `Uspokajający mężczyzna`,
    CARD_023_DESC: `:)`,
    CARD_024_NAME: `Myszka`,
    CARD_024_DESC: `Żeby łatwiej klikać karty`,
    CARD_025_NAME: `Miernik cęgowy`,
    CARD_025_DESC: `Też nie wiem, do czego służy`,
    CARD_026_NAME: `Karta z debetem`,
    CARD_026_DESC: `Wisisz nam 534 289 dolarów`,
    CARD_027_NAME: `Saksofon`,
    CARD_027_DESC: `Belgijski instrument (wspominam o tym, bo jestem Belgiem)`,
    CARD_028_NAME: `Fidget spinner`,
    CARD_028_DESC: `Kręci się`,
    CARD_029_NAME: `Rolka papieru toaletowego`,
    CARD_029_DESC: `Trzywarstwowy`,
    CARD_030_NAME: `Brzydki pies`,
    CARD_030_DESC: `HAU HAU (to znaczy „jestem brzydki” po psiemu)`,
    CARD_031_NAME: `Mucha`,
    CARD_031_DESC: `Bzzzzzzzzz`,
    CARD_032_NAME: `As kier`,
    CARD_032_DESC: `Same asy, bo nie chciało mi się robić reszty`,
    CARD_033_NAME: `As trefl`,
    CARD_033_DESC: `Same asy, bo nie chciało mi się robić reszty`,
    CARD_034_NAME: `As pik`,
    CARD_034_DESC: `Same asy, bo nie chciało mi się robić reszty`,
    CARD_035_NAME: `As karo`,
    CARD_035_DESC: `Same asy, bo nie chciało mi się robić reszty`,
    CARD_036_NAME: `Ogórek konserwowy`,
    CARD_036_DESC: `W hamburgerze jest obrzydliwy`,
    CARD_037_NAME: `Węgiel`,
    CARD_037_DESC: `Wygląda znajomo...`,
    CARD_038_NAME: `Koń`,
    CARD_038_DESC: `Perfekcyjnie narysowany`,
    CARD_039_NAME: `Pierwsze oznaki łysienia`,
    CARD_039_DESC: `To nie zakola, to wysokie czoło`,
    CARD_040_NAME: `Emmentaler`,
    CARD_040_DESC: `Nie lubię sera`,
    CARD_041_NAME: `Mój tata`,
    CARD_041_DESC: ``,
    CARD_042_NAME: `Klucz wiolinowy`,
    CARD_042_DESC: `Wskazuje położenie dźwięku G na pięciolinii`,
    CARD_043_NAME: `Sajgonka`,
    CARD_043_DESC: `Team sajgonki warzywne`,
    CARD_044_NAME: `Plik MP3`,
    CARD_044_DESC: `sndCardWoosh.mp3`,
    CARD_045_NAME: `Zebra`,
    CARD_045_DESC: `Perfekcyjnie narysowana`,
    CARD_046_NAME: `Tęcza`,
    CARD_046_DESC: `Ma związek z załamaniem światła`,
    CARD_047_NAME: `Comté`,
    CARD_047_DESC: `Nie lubię sera`,
    CARD_048_NAME: `Żelazo`,
    CARD_048_DESC: `Wygląda znajomo...`,
    CARD_049_NAME: `Flaga Belgii`,
    CARD_049_DESC: `No tak, frytki`,
    CARD_050_NAME: `Walet`,
    CARD_050_DESC: `Zobacz opis damy`,
    CARD_051_NAME: `Dama`,
    CARD_051_DESC: `Zobacz opis króla`,
    CARD_052_NAME: `Król`,
    CARD_052_DESC: `Zobacz opis jokera`,
    CARD_053_NAME: `Jednorożec`,
    CARD_053_DESC: `Perfekcyjnie narysowany`,
    CARD_054_NAME: `Złoto`,
    CARD_054_DESC: `Wygląda znajomo...`,
    CARD_055_NAME: `Sputnik`,
    CARD_055_DESC: `Pierwszy sztuczny satelita Ziemi`,
    CARD_056_NAME: `Camembert`,
    CARD_056_DESC: `Nie lubię sera`,
    CARD_057_NAME: `Joker`,
    CARD_057_DESC: `Zobacz opis waleta`,
    CARD_058_NAME: `Diament`,
    CARD_058_DESC: `Wygląda znajomo...`,
    CARD_059_NAME: `Pegaz`,
    CARD_059_DESC: `Bosko narysowany`,
    CARD_060_NAME: `Atom`,
    CARD_060_DESC: `Tworzy całą materię`,
    CARD_061_NAME: `Morgue AC Seal`,
    CARD_061_DESC: `Autor: Alphonse Robichu`,
    CARD_062_NAME: `Podejrzany ślimak`,
    CARD_062_DESC: `On wie`,
    CARD_063_NAME: `Psotna nerka`,
    CARD_063_DESC: `Pierwotnie miała być rybą`,
    CARD_064_NAME: `Q`,
    CARD_064_DESC: `No i tyle`,
    CARD_065_NAME: `Statek kosmiczny`,
    CARD_065_DESC: `Gotowy do bitwy`,
    CARD_066_NAME: `Mój kot`,
    CARD_066_DESC: `Ma na imię CHOCOLAT <3`,
    CARD_067_NAME: `Łakomczuch`,
    CARD_067_DESC: `Wyruszył na misję po burgera`,
    CARD_068_NAME: `Pewna siebie meduza`,
    CARD_068_DESC: `Wow, skąd u niej tyle luzu?`,
    CARD_069_NAME: `Słomkowy kapelusz`,
    CARD_069_DESC: `Do kupienia w jednym kawałku`,
    CARD_070_NAME: `Kapitalistyczna świnia`,
    CARD_070_DESC: `Ma konto na Kajmanach`,
    CARD_071_NAME: `Pomieszana kostka Rubika`,
    CARD_071_DESC: `A nie można po prostu przekleić naklejek?`,
    CARD_072_NAME: `Kostka Rubika`,
    CARD_072_DESC: `Nie ruszaj, to na pokaz`,
    CARD_073_NAME: `Naukowiec z laboratorium`,
    CARD_073_DESC: `Całkowicie pochłania go opracowywanie wariantów`,
    CARD_074_NAME: `Frytki`,
    CARD_074_DESC: `Słynne BELGIJSKIE danie`,
    CARD_075_NAME: `Niekończąca się głosówka`,
    CARD_075_DESC: `Taaak, wyślę ci głosówkę, będzie szybciej, yyy ogólnie O czekaj, ktoś dzwoni`,
    CARD_076_NAME: `Świnka skarbonka`,
    CARD_076_DESC: `Chrum chrum`,
    CARD_077_NAME: `Maneki-neko`,
    CARD_077_DESC: `Przynosi szczęście`,
    CARD_078_NAME: `Pomidor`,
    CARD_078_DESC: `Autor: Lucy`,
    CARD_079_NAME: `Podejrzana stopa`,
    CARD_079_DESC: `Zapach też jest podejrzany`,
    CARD_080_NAME: `Mężczyzna z wydatnym nosem`,
    CARD_080_DESC: `Co on takiego wyczuwa??`,
    CARD_081_NAME: `Obwąchana wiśnia`,
    CARD_081_DESC: `Ale do kogo należy ten nos?`,
    CARD_082_NAME: `Aksolotl`,
    CARD_082_DESC: `23 centymetry słodyczy`,
    CARD_083_NAME: `MargueRIP`,
    CARD_083_DESC: `Ładna, ale martwa...`,
    CARD_084_NAME: `Tani kostium`,
    CARD_084_DESC: `Podróbka, ale praktyczna`,
    CARD_085_NAME: `Paraliż senny`,
    CARD_085_DESC: `Nie odwracaj się`,
    CARD_086_NAME: `Białooka niebieska jaszczurka`,
    CARD_086_DESC: `ATK/3000   DEF/2500`,
    CARD_087_NAME: `Wypalony robot`,
    CARD_087_DESC: `@grouk czy to serio prawda??`,
    CARD_088_NAME: `Catchpa`,
    CARD_088_DESC: `Kliknij obrazki z kotami`,
    CARD_089_NAME: `Idealnie okrągła piłka`,
    CARD_089_DESC: `4/3 * pi * r³`,
    CARD_090_NAME: `Stanley Cubic`,
    CARD_090_DESC: `Koniec zdjęć`,
    CARD_091_NAME: `Paszport`,
    CARD_091_DESC: `Papers, please`,
    CARD_092_NAME: `Zielona herbata`,
    CARD_092_DESC: `W sumie to nie jest aż taka zielona`,
    CARD_093_NAME: `Półbóg`,
    CARD_093_DESC: `Jego druga połowa to temat tabu`,
    CARD_094_NAME: `Urocze maluchy`,
    CARD_094_DESC: `=(°u°)=`,
    CARD_095_NAME: `Elektryk`,
    CARD_095_DESC: `To elektryk... Chodź tutaj`,
    CARD_096_NAME: `Przyklejająca się zasłona prysznicowa`,
    CARD_096_DESC: `Każdemu się to zdarzyło, prawda?`,
    CARD_097_NAME: `14:44`,
    CARD_097_DESC: `Godzina nie zgadza się z obrazkiem, taki ze mnie śmieszek`,
    CARD_098_NAME: `Grawitacja`,
    CARD_098_DESC: `Wynaleziona przez Isaaca Newtona`,
    CARD_099_NAME: `Setna stworzona karta`,
    CARD_099_DESC: `2 września o 23:24`,
    CARD_100_NAME: `Shamisen`,
    CARD_100_DESC: `Jak to tylko 3 struny?`,
    CARD_101_NAME: `Język C++`,
    CARD_101_DESC: `Gra nie powstała w tym języku, ale szanujemy`,
    CARD_102_NAME: `????`,
    CARD_102_DESC: `Ty tak na serio??`,
    CARD_103_NAME: `Rożen z kebabem`,
    CARD_103_DESC: `To, co zawsze, szefie`,
    CARD_104_NAME: `Niewidzialny człowiek w 2020 roku`,
    CARD_104_DESC: `Jego też to dotknęło, jak wszystkich`,
    CARD_105_NAME: `Mrugająca buźka`,
    CARD_105_DESC: `Używają jej ludzie, od których lepiej trzymać się z daleka`,
    CARD_106_NAME: `AI slop`,
    CARD_106_DESC: `Akurat tej karty nie wygenerowało AI`,
    CARD_107_NAME: `Niebieski ptaszek`,
    CARD_107_DESC: `Wciąż słyszę jego ćwierkanie #nostalgia`,
    CARD_108_NAME: `Kinoman`,
    CARD_108_DESC: `Nie znosi pewnego słynnego filmu o kosmosie z 2014 roku`,
    CARD_109_NAME: `Cegła`,
    CARD_109_DESC: `Ta w kształcie litery T terroryzuje murarzy`,
    CARD_110_NAME: `Najmniejsze skrzypce świata`,
    CARD_110_DESC: `Naprawdę potrzebują publiczności`,
    CARD_111_NAME: `Podejrzana sztuka abstrakcyjna`,
    CARD_111_DESC: `sus.........`,
    CARD_112_NAME: `Filmik z przeprosinami youtubera`,
    CARD_112_DESC: `Bardzo żałuję doboru tych słów...`,
    CARD_113_NAME: `Bardzo, bardzo dojrzały banan`,
    CARD_113_DESC: `Naprawdę trzeba go już zjeść`,
    CARD_114_NAME: `Eksplozja`,
    CARD_114_DESC: `BOOOOOOOM`,
    CARD_115_NAME: `Zmiana klimatu`,
    CARD_115_DESC: `+2°C do 2050 roku, jeśli nic nie zrobimy XD`,
    CARD_116_NAME: `Źle wykadrowany streamer`,
    CARD_116_DESC: `twitch.tv/doigt`,
    CARD_117_NAME: `Mister Fist`,
    CARD_117_DESC: `DAM 300 MILIONÓW DOLARÓW UCZESTNIKOWI, KTÓRY PRZEŻYJE 500 WOLTÓW`,
    CARD_118_NAME: `Guess my Fart`,
    CARD_118_DESC: `Gra nie dla każdego`,
    CARD_119_NAME: `Przedmiot z lochu`,
    CARD_119_DESC: `Przyda się tylko w tym lochu`,
    CARD_120_NAME: `Słońce widziane nocą`,
    CARD_120_DESC: `Idealna pora, żeby je zaatakować`,
    CARD_121_NAME: `Arbuz`,
    CARD_121_DESC: `Owoc składający się w 215% z wody (nauka)`,
    CARD_122_NAME: `Czarna dziura`,
    CARD_122_DESC: `Mimo swojej grawitacji nie przyciąga mnie tak mocno jak ty`,
    CARD_123_NAME: `Six Seven`,
    CARD_123_DESC: `SIX SEVEN SIX SEVEN`,
    CARD_124_NAME: `Billy`,
    CARD_124_DESC: `To nie byle jaki glut, to legenda...`,
    CARD_125_NAME: `Śliski Jimmy`,
    CARD_125_DESC: `Wysyła wiadomości z mrugającymi buźkami`,
    CARD_126_NAME: `Cthulhu`,
    CARD_126_DESC: `Ma 13 centymetrów wzrostu`,
    CARD_127_NAME: `Zombie`,
    CARD_127_DESC: `Greuuuraaargh`,
    CARD_128_NAME: `Funkcja wykładnicza`,
    CARD_128_DESC: `Dobra, to jednak rośnie całkiem szybko`,
    CARD_129_NAME: `Wiatr`,
    CARD_129_DESC: `Fffffffffffff`,
    CARD_130_NAME: `Proporcje 16:9`,
    CARD_130_DESC: `Jeśli zmienisz te proporcje, gra się zepsuje, więc nie próbuj, dzięki`,
    CARD_131_NAME: `Proporcje 4:3`,
    CARD_131_DESC: `Stara szkoła`,
    CARD_132_NAME: `Merch influencera`,
    CARD_132_DESC: `5,99 dolara za smakowe powietrze`,
    CARD_133_NAME: `Czerwony przycisk`,
    CARD_133_DESC: `Nie wciskaj, i tak nic nie zrobi`,
    CARD_134_NAME: `Kula ognia`,
    CARD_134_DESC: `Zadaje 25 obrażeń. Żartuję, to dosłownie tylko rysunek, spokojnie`,
    CARD_135_NAME: `Karta w karcie`,
    CARD_135_DESC: `Opis karty: Opis karty`,
    CARD_136_NAME: `Wyrazisty wąs`,
    CARD_136_DESC: `Żeby nie powiedzieć brzydki`,
    CARD_137_NAME: `Ogromny udziec`,
    CARD_137_DESC: `Lepiej go jednak upiec`,
    CARD_138_NAME: `Niedokończony rysunek`,
    CARD_138_DESC: `Nie było czasu, już i tak nie wyrabiam się z premierą gry`,
    CARD_139_NAME: `Jednoczący megafon`,
    CARD_139_DESC: `To dopiero początek`,
    CARD_140_NAME: `Trener sportowy`,
    CARD_140_DESC: `UWIERZ`,
    CARD_141_NAME: `Hachiko`,
    CARD_141_DESC: `Symbol lojalności i miłości`,
    CARD_142_NAME: `Kiełbasoman`,
    CARD_142_DESC: `Z wielką mocą wiąże się wielkie doprawienie`,
  },
  ie = {
    FORMAT_SHOP: `Mağaza`,
    FORMAT_DUPLICATES: `Kopyalar`,
    FORMAT_UPGRADES: `Geliştirmeler`,
    FORMAT_COLLECTION: `Koleksiyon`,
    FORMAT_TYPE1: `metalik`,
    FORMAT_TYPE2: `altın`,
    FORMAT_TYPE3: `holografik`,
    FORMAT_TYPE4: `negatif`,
    FORMAT_TYPE5: `glitchli`,
    FORMAT_TYPE6: `FULL ART`,
    FORMAT_BOOSTERS: `Booster`,
    FORMAT_BLISTER: `Blister`,
    FORMAT_LEFTCLICK: `Sol Tık`,
    FORMAT_RIGHTCLICK: `Sağ Tık`,
    FORMAT_CARDS: `Kartlar`,
    UI_RECORD: `Rekor`,
    UI_NEW: `Yeni`,
    UI_DESTROYED: `Yok edildi!`,
    UI_DESTROYED_DUPLICATE: `Kopya
deposu
dolu`,
    UI_DESTROYED_BOOSTER: `Masada
yer yok`,
    UI_DESTROYED_NOCARD: `Uygun kart
yok`,
    UI_UNLOCKED_PRONOUN1: `açıldı`,
    UI_UNLOCKED_PRONOUN2: `açıldı`,
    UI_UNLOCKED_PRONOUN3: `açıldı`,
    UI_UNLOCKED_PRONOUN4: `açıldı`,
    UI_COMPLETE: `%100 tamamlandı!`,
    UI_BOOSTER_CLICK: `Tıkla`,
    UI_ROLL: `ÇILGIN HEDİYE`,
    UI_SAVING: `Kaydediliyor...`,
    UI_BUTTON_SORT_STAR: `Yıldız sayısına göre`,
    UI_BUTTON_SORT_QUANTITY: `Adede göre`,
    UI_BUTTON_SORT_ASCENDING: `artan`,
    UI_BUTTON_SORT_DESCENDING: `azalan`,
    UI_BUTTON_EMPLOYEE_SLEEP_NO: `aktif çalışanlar`,
    UI_BUTTON_EMPLOYEE_SLEEP_YES: `moladaki çalışanlar`,
    UI_GODPACK: `God Pack`,
    UI_COLLECTION_FULL: `KOLEKSİYON %100`,
    UI_ALARM_DUPLICATES: `Kopya deposu dolmak üzere`,
    UI_ALARM_MONEY: `Para limitine ulaşıldı`,
    UI_END_IMPOSSIBLE: `Koleksiyondaki tüm
kartlara sahip olmalısın`,
    UI_CREDITS_MESSAGES: [
      `geliştirici
DOIGT`,
      `stüdyo
FINGER GAMES`,
      `oyun tasarımcısı
DOIGT`,
      `ses tasarımcısı
DOIGT`,
    ],
    UI_TRIPLE: `3 katına çıktı`,
    UI_MODULE_FULL: `Tüm kartlara sahipsin`,
    SETTINGS_MUSIC: `Müzik Sesi`,
    SETTINGS_SOUNDS: `Efekt Sesi`,
    SETTINGS_FULLSCREEN: `Tam Ekran`,
    SETTINGS_CRT: `CRT Efekti`,
    SETTINGS_SHAKE: `Ekran Sarsıntısı`,
    SETTINGS_FLASH: `Ekran Parlaması`,
    SETTINGS_LANGUAGE: `Dil`,
    SETTINGS_ACTUAL_LANGUAGE: `Türkçe`,
    SETTINGS_RESET: `Kaydı Sil`,
    STATS: {
      game_duration: `Oyun süresi`,
      afk_duration: `AFK süresi`,
      nb_clicks: `Toplam tıklama`,
      nb_boosters_cracked: `Açılan boosterlar`,
      nb_cards_duplicates: `Elde edilen kopyalar`,
      nb_modules_win: `Tamamlanan modüller`,
      nb_money_total: `Kazanılan para`,
      nb_money_spent: `Harcanan para`,
      nb_cards_stamped: `Uygulanan damgalar`,
      nb_coins: `Toplanan jetonlar`,
      nb_employee_cost: `Çalışan giderleri`,
      nb_employee_clicks: `Çalışan tıklamaları`,
      nb_boosters_triple: `{orange}3 katına çıkan boosterlar`,
      nb_boosters_godpack: `Elde edilen {godpack}[c_white]`,
      nb_boosters_record: `En büyük booster`,
    },
    ROLL_DOUBLE_VARIANT: `Nadirlikleri geçici olarak 2 katına çıkarır`,
    ROLL_DOUBLE_VALUE: `Satış fiyatlarını geçici olarak 2 katına çıkarır`,
    ROLL_DOUBLE_COOLDOWN: `Booster yenilenme hızını 3 katına çıkarır`,
    ROLL_RAIN_COINS: `Jeton Yağmuru`,
    ROLL_RAIN_CARDS: `Kart Yağmuru`,
    ROLL_RAIN_BOOSTERS: `Booster Yağmuru`,
    ROLL_ALL_BOOSTERS_VARIANT: `Tüm boosterlar {type5} olur`,
    ROLL_NEW_CARD: `Yeni Kart`,
    ROLL_SPEED: `Hız Artışı`,
    ROLL_NOTHING: `Hiçbir şey :(`,
    ROLL_RESET: `{red}İFLAS`,
    ROLL_DOUBLE_MONEY: `[shake]2 Kat Para`,
    MODULE_LAB: `Füzyon Laboratuvarı`,
    MODULE_LAB_OUTPUT: `Sonuç`,
    MODULE_LAB_INPUTS: `Malzemeler`,
    MODULE_LAB_LAUNCH: `Projeyi Başlat`,
    MODULE_LAB_DESC: `Oluşturacağın yeni kartı {blue}seç{black}. Birleştirmek için {blue}2 alt seviye varyant{black} gerekir. {blue}Doğru kartları bulduğunda{black} füzyon hemen başlar.`,
    MODULE_LAB_FINISHED: `Füzyon tamamlandı!`,
    MODULE_MEMORY: `Hafıza Oyunu`,
    MODULE_MEMORY_WIN: `Hafıza oyunu tamamlandı!`,
    MODULE_MEMORY_DESC: `Kartları ikişer ikişer {blue}çevirerek aç{black}. 5 deneme içinde {blue}tüm eşleşen çiftleri bulmalısın{black}. Her zaman koleksiyonunda bulunmayan bir kart çifti olacak.`,
    MODULE_ARENA: `Arena`,
    MODULE_ARENA_HIM: [
      `skouizi`,
      `dark_tenebrum`,
      `DarkShadow27`,
      `KillerDu62`,
      `SkullHunter92`,
      `fan2cartes`,
      `NinjaWolf27`,
      `DragonSlayer94`,
      `DarkTitan92`,
    ],
    MODULE_ARENA_VS: `VS`,
    MODULE_ARENA_YOU: `Sen`,
    MODULE_ARENA_MISS: `Kaçındı!`,
    MODULE_ARENA_WIN: `Kazandın!`,
    MODULE_ARENA_LOSE: `Kaybettin!`,
    MODULE_ARENA_DRAW: `Berabere!`,
    MODULE_ARENA_DESC: `Kartlarını rakibinin kartlarıyla {blue}savaştır{black}. Rakibinin kartları yenilirse, {blue}onun kartlarını çalarsın{black}. Rakibinde her zaman koleksiyonunda olmayan bir kart bulunur.`,
    MODULE_MUSEUM: `Müze`,
    MODULE_MUSEUM_INTRO: `Sergilemek için
5 kart seç!`,
    MODULE_MUSEUM_ENTRIES: `Ziyaretçiler`,
    MODULE_MUSEUM_PRICE: `Bilet Fiyatı`,
    MODULE_MUSEUM_PRICE_SHORT: `Bilet`,
    MODULE_MUSEUM_RISK: `Risk`,
    MODULE_MUSEUM_RISK_PRICE: `Teminat`,
    MODULE_MUSEUM_REWARD: `Kâr`,
    MODULE_MUSEUM_IMPOSSIBLE: `Teminat için yeterli paran yok`,
    MODULE_MUSEUM_WAITING: `Umarız bilet fiyatı
onları kaçırmaz...`,
    MODULE_MUSEUM_LOSE: `Sergi iptal edildi!`,
    MODULE_MUSEUM_WIN: `Sergi gerçekleşecek!`,
    MODULE_MUSEUM_DESC: `Müzede {blue}kartlarından 5'ini sergile{black}. {blue}Giriş ücretini{black} artırabilirsin, ancak bu aynı zamanda {red}serginin başarısız olma riskini{black} artırır ve para kaybetmene yol açabilir.`,
    BOOSTER_000_NAME: `Başlangıç Boosterı`,
    BOOSTER_000_DESC: `Ücretsiz başlangıç boosterları`,
    BOOSTER_001_NAME: `Standart Booster`,
    BOOSTER_001_DESC: `Standart nadirlik oranlarına sahip boosterlar`,
    BOOSTER_002_NAME: `Deluxe Booster`,
    BOOSTER_002_DESC: `Daha iyi nadirlik oranlarına sahip boosterlar`,
    BOOSTER_003_NAME: `Mega Booster`,
    BOOSTER_003_DESC: `Bol miktarda yaygın kart içeren boosterlar`,
    BOOSTER_004_NAME: `Kare Booster`,
    BOOSTER_004_DESC: `Mükemmel dengelenmiş boosterlar`,
    BOOSTER_005_NAME: `Polarize Booster`,
    BOOSTER_005_DESC: `Ya müthiş ödüller veren ya da tam bir hayal kırıklığı olan boosterlar`,
    BOOSTER_006_NAME: `Zaman Boosterı`,
    BOOSTER_006_DESC: `Kalitesi zamanla artan boosterlar`,
    BOOSTER_007_NAME: `Gelişim Boosterı`,
    BOOSTER_007_DESC: `Her satın alımda gelişen boosterlar`,
    UPGRADE_000_NAME: `{boosters} Hasarı`,
    UPGRADE_000_DESC: `{boosters} hasarı: -{value}`,
    UPGRADE_001_NAME: `Zar ({type1})`,
    UPGRADE_001_DESC: `Bir {type1} kart çıkma ihtimali: %{value}`,
    UPGRADE_002_NAME: `Kopyaların Kilidini Aç`,
    UPGRADE_002_DESC: `Depolanabilir kopyalar: en fazla {value} {star}`,
    UPGRADE_003_NAME: `Açılan {boosters} Türleri`,
    UPGRADE_003_DESC: `{shop}: {value} {boosters} türü`,
    UPGRADE_004_NAME: `{boosters} Bekleme Süresi`,
    UPGRADE_004_DESC: `{boosters} bekleme süresi: -%{value}`,
    UPGRADE_005_NAME: `Büyük Paketler`,
    UPGRADE_005_DESC: `{boosters}, %{value} ihtimalle {orange}3 katına çıkar`,
    UPGRADE_006_NAME: `Depolama Kapasitesi`,
    UPGRADE_006_DESC: `{duplicates} için depolama sınırı: {value}`,
    UPGRADE_007_NAME: `1 {star} Kart Değeri`,
    UPGRADE_007_DESC: `1 {star} kart değeri: x{value}`,
    UPGRADE_008_NAME: `Masa Kapasitesi`,
    UPGRADE_008_DESC: `Masada en fazla {value} {boosters}`,
    UPGRADE_009_NAME: `Çok Elli`,
    UPGRADE_009_DESC: `Aynı anda {value} kart çevrilebilir`,
    UPGRADE_010_NAME: `Sürpriz Paketler`,
    UPGRADE_010_DESC: `Tek seferde {value} {boosters} satın alınabilir`,
    UPGRADE_011_NAME: `Sihirbazın Elleri`,
    UPGRADE_011_DESC: `Kart çevirme hızı: x{value}`,
    UPGRADE_012_NAME: `2 {star} Kart Değeri`,
    UPGRADE_012_DESC: `2 {star} kart değeri: x{value}`,
    UPGRADE_013_NAME: `3 {star} Kart Değeri`,
    UPGRADE_013_DESC: `3 {star} kart değeri: x{value}`,
    UPGRADE_014_NAME: `4 {star} Kart Değeri`,
    UPGRADE_014_DESC: `4 {star} kart değeri: x{value}`,
    UPGRADE_015_NAME: `Kart Değeri ({type1})`,
    UPGRADE_015_DESC: `{type1} kart değeri: x{value}`,
    UPGRADE_016_NAME: `Kart Değeri ({type2})`,
    UPGRADE_016_DESC: `{type2} kart değeri: x{value}`,
    UPGRADE_017_NAME: `Kart Değeri ({type3})`,
    UPGRADE_017_DESC: `{type3} kart değeri: x{value}`,
    UPGRADE_018_NAME: `Kart Değeri ({type4})`,
    UPGRADE_018_DESC: `{type4} kart değeri: x{value}`,
    UPGRADE_019_NAME: `Zar ({type2})`,
    UPGRADE_019_DESC: `Bir {type2} kart çıkma ihtimali: %{value}`,
    UPGRADE_020_NAME: `Zar ({type3})`,
    UPGRADE_020_DESC: `Bir {type3} kart çıkma ihtimali: %{value}`,
    UPGRADE_021_NAME: `Zar ({type4})`,
    UPGRADE_021_DESC: `Bir {type4} kart çıkma ihtimali: %{value}`,
    UPGRADE_022_NAME: `Klon Savaşları`,
    UPGRADE_022_DESC: `Çevrilen kartların klonlanma ihtimali: %{value}`,
    UPGRADE_023_NAME: `Klon Sayısı`,
    UPGRADE_023_DESC: `Klon sayısı: 1–{value}`,
    UPGRADE_024_NAME: `Artan Talep`,
    UPGRADE_024_DESC: `{duplicates}, {value} adetlik gruplar hâlinde satılır`,
    UPGRADE_025_NAME: `Çok Uluslu Şirket`,
    UPGRADE_025_DESC: `Para limiti: $10000000000000000000000000000`,
    UPGRADE_026_NAME: `İş Kur`,
    UPGRADE_026_DESC: "Para limiti: ${value}",
    UPGRADE_027_NAME: `Cüzdan`,
    UPGRADE_027_DESC: `Para limiti: \${value}
{green}Jetonlar düşebilir`,
    UPGRADE_028_NAME: `Kürek`,
    UPGRADE_028_DESC: `Tıklama yarıçapı: {value}`,
    UPGRADE_029_NAME: `Kepçe`,
    UPGRADE_029_DESC: `{right_click} basılıyken saniyede {value} kez otomatik tıklar`,
    UPGRADE_030_NAME: `Mıknatıs`,
    UPGRADE_030_DESC: `Mıknatıs saniyede {value} kez kart çeker`,
    UPGRADE_031_NAME: `Fırsat Avcısı`,
    UPGRADE_031_DESC: `{duplicates} için otomatik satış ihtimali: %{value}`,
    UPGRADE_032_NAME: `{blister}`,
    UPGRADE_032_DESC: `{boosters} paketlenebilir; açılmadan kalırsa satılır`,
    UPGRADE_033_NAME: `Pazarlık Ustalığı`,
    UPGRADE_033_DESC: `Olası {blister} değeri: x{value}`,
    UPGRADE_034_NAME: `Tekinsiz Satıcı`,
    UPGRADE_034_DESC: `{shop} düzenli olarak kart sunar`,
    UPGRADE_035_NAME: `Damga ({type1})`,
    UPGRADE_035_DESC: `Yeni bir {type1} karta {left_click} yapınca gümüş jeton kazanırsın`,
    UPGRADE_036_NAME: `Damga ({type2})`,
    UPGRADE_036_DESC: `Yeni bir {type2} karta {left_click} yapınca altın jeton kazanırsın`,
    UPGRADE_037_NAME: `Damga ({type3})`,
    UPGRADE_037_DESC: `Yeni bir {type3} karta {left_click} yapınca oyun hızlanır`,
    UPGRADE_038_NAME: `Damga ({type4})`,
    UPGRADE_038_DESC: `Yeni bir {type4} karta {left_click} yapınca bir paket tersine döner`,
    UPGRADE_039_NAME: `İşe Alım Kampanyası`,
    UPGRADE_039_DESC: `Çalışan işe almanı sağlar`,
    UPGRADE_040_NAME: `Kurye`,
    UPGRADE_040_DESC: `Kuryeler: {value}
{red}-$50 {red}/saniye`,
    UPGRADE_041_NAME: `Kart Açıcı`,
    UPGRADE_041_DESC: `Kart açıcılar: {value}
{red}-$50 {red}/saniye`,
    UPGRADE_042_NAME: `Satış Görevlisi`,
    UPGRADE_042_DESC: `Satış görevlileri: {value}
{red}-$50 {red}/saniye`,
    UPGRADE_043_NAME: `Hipermarket`,
    UPGRADE_043_DESC: `Para limiti: \${value}
`,
    UPGRADE_044_NAME: `Zar ({type5})`,
    UPGRADE_044_DESC: `Bir {type5} kart çıkma ihtimali: %{value}`,
    UPGRADE_045_NAME: `Zar ({type6})`,
    UPGRADE_045_DESC: `Bir {type6} kart çıkma ihtimali: %{value}`,
    UPGRADE_046_NAME: `Kart Değeri ({type5})`,
    UPGRADE_046_DESC: `{type5} kart değeri: x{value}`,
    UPGRADE_047_NAME: `Kart Değeri ({type6})`,
    UPGRADE_047_DESC: `{type6} kart değeri: x{value}`,
    UPGRADE_048_NAME: `Damga ({type5})`,
    UPGRADE_048_DESC: `Yeni bir {type5} karta {left_click} yapınca bir paket karıştırılır`,
    UPGRADE_049_NAME: `İlk DLC`,
    UPGRADE_049_DESC: `{red}210 {black}yeni koleksiyon kartı ekler`,
    UPGRADE_050_NAME: `İkinci DLC`,
    UPGRADE_050_DESC: `{red}210 {black}yeni koleksiyon kartı ekler`,
    UPGRADE_051_NAME: `Üçüncü DLC`,
    UPGRADE_051_DESC: `{red}371 {black}yeni koleksiyon kartı ekler`,
    UPGRADE_052_NAME: `Miras`,
    UPGRADE_052_DESC: `{red}{type6} kilidini açar{black} ve mevcut koleksiyon değerini koruyarak {red}oyunu yeniden başlatır{black}`,
    UPGRADE_053_NAME: `Kırbaç`,
    UPGRADE_053_DESC: `Çalışma hızı: x{value}
{red}(ücretler değişir)`,
    UPGRADE_054_NAME: `Ar-Ge`,
    UPGRADE_054_DESC: `Geliştirme modüllerinin kilidini açar`,
    UPGRADE_055_NAME: `Füzyon Laboratuvarı`,
    UPGRADE_055_DESC: `Alt seviye varyantları birleştirerek yeni kartlar oluşturmanı sağlar`,
    UPGRADE_056_NAME: `Hafıza Oyunu`,
    UPGRADE_056_DESC: `Hafıza oyununu tamamla; çıkan tüm kartları kazan, içlerinden biri koleksiyonunda olmayan bir kart olacak`,
    UPGRADE_057_NAME: `TCG Turnuvası`,
    UPGRADE_057_DESC: `Savaşı kazan ve rakibinin kartlarını ele geçir; içlerinden biri koleksiyonunda olmayan yeni bir kart olacak`,
    UPGRADE_058_NAME: `Müze Sergisi`,
    UPGRADE_058_DESC: `Kartlarını sergileyerek para kazan, ama serginin fiyaskoyla sonuçlanmasına dikkat!`,
    UPGRADE_059_NAME: `Damga ({type6})`,
    UPGRADE_059_DESC: `Yeni bir {type6} karta {left_click} yapınca {roll} etkinleşir`,
    UPGRADE_060_NAME: `İlahi Lütuf`,
    UPGRADE_060_DESC: `{boosters} mucizevi şekilde {godpack} hâline dönüşebilir`,
    UPGRADE_061_NAME: `Yılların Birikimi`,
    UPGRADE_061_DESC: `Füzyon artık {typevalue} kartlar oluşturabilir`,
    UPGRADE_062_NAME: `Basitleştirme (Koca Aptal)`,
    UPGRADE_062_DESC: `Can sayısı: {value}`,
    UPGRADE_063_NAME: `Gelişmiş Ekipman`,
    UPGRADE_063_DESC: `Birliklerinin {orange}kaçınma{black} veya {orange}kritik vuruş yapma{black} ihtimali: %{value}`,
    UPGRADE_064_NAME: `Ek Müze Kanadı`,
    UPGRADE_064_DESC: `Müzede artık {typevalue} kartlar sergilenebilir`,
    UPGRADE_065_NAME: `Yangın Alarmı`,
    UPGRADE_065_DESC: `{duplicates} için depolama sınırına veya para limitine yaklaştığında seni uyarır`,
    UPGRADE_066_NAME: `Mutlak Hâkimiyet`,
    UPGRADE_066_DESC: `Küresel koleksiyon kartı pazarına hükmet
{red}Oyunun sonu`,
    CARD_000_NAME: `Şerit Metre`,
    CARD_000_DESC: `Onun yanında başka ölçü birimlerinden bahsetme`,
    CARD_001_NAME: `İsviçre Çakısı`,
    CARD_001_DESC: `Pratik, çok yönlü ve kırmızı`,
    CARD_002_NAME: `Çivi`,
    CARD_002_DESC: `Nesneleri veya insanları tutturmak için kullanılır`,
    CARD_003_NAME: `Sünger`,
    CARD_003_DESC: `Kullandıktan sonra yeşil tarafını yalamak için kaç para isterdin??`,
    CARD_004_NAME: `Kirli Tişört`,
    CARD_004_DESC: `Oversize model`,
    CARD_005_NAME: `Kupa`,
    CARD_005_DESC: `Çeşit çeşit sıvı tutabilir`,
    CARD_006_NAME: `Ampul`,
    CARD_006_DESC: `Işıktan gözüm kamaştı`,
    CARD_007_NAME: `Post-it`,
    CARD_007_DESC: `Daha fazla süt almayı unutma`,
    CARD_008_NAME: `Çoklu Priz`,
    CARD_008_DESC: `Sonsuz enerji üretmek için fişini kendine tak`,
    CARD_009_NAME: `Paranın Tura Yüzü`,
    CARD_009_DESC: `Yazı mı tura mı? Ne yazık ki yazı geldi`,
    CARD_010_NAME: `Paranın Yazı Yüzü`,
    CARD_010_DESC: `Yazı mı tura mı? Ne yazık ki tura geldi`,
    CARD_011_NAME: `Hijyenik Ped`,
    CARD_011_DESC: `Çantanda her zaman bir tane bulundur`,
    CARD_012_NAME: `Balon`,
    CARD_012_DESC: `İçi %99 hava, %1 salya`,
    CARD_013_NAME: `Kulak İçi Kulaklık`,
    CARD_013_DESC: `Düğümünü çözmek 3 saat sürer`,
    CARD_014_NAME: `A4 Kâğıdı`,
    CARD_014_DESC: `A4, 21 x 29,7 cm'dir`,
    CARD_015_NAME: `Posta Pulu`,
    CARD_015_DESC: `Onaylandı`,
    CARD_016_NAME: `Yangın Musluğu`,
    CARD_016_DESC: `YANGIN!`,
    CARD_017_NAME: `Lüks Klozet`,
    CARD_017_DESC: `Foşşşşşş`,
    CARD_018_NAME: `Performans Hapı`,
    CARD_018_DESC: `Bazı geceler işler pek yolunda gitmez ya`,
    CARD_019_NAME: `DUR Tabelası`,
    CARD_019_DESC: `DUR!! YETER ARTIK! DUR!!!`,
    CARD_020_NAME: `BENİM Arabam`,
    CARD_020_DESC: `Bu benim arabam`,
    CARD_021_NAME: `Duş`,
    CARD_021_DESC: `Bu bir küvet DEĞİL`,
    CARD_022_NAME: `Akıllı Telefon`,
    CARD_022_DESC: `Gerçekten açsan iyi olur...`,
    CARD_023_NAME: `Güven Veren Adam`,
    CARD_023_DESC: `:)`,
    CARD_024_NAME: `Fare`,
    CARD_024_DESC: `Kartlara daha kolay tıklamak için`,
    CARD_025_NAME: `Pens Ampermetre`,
    CARD_025_DESC: `Ben de bunun ne işe yaradığını bilmiyorum`,
    CARD_026_NAME: `Eksiye Düşmüş Banka Kartı`,
    CARD_026_DESC: `Bize $534.289 borçlusun`,
    CARD_027_NAME: `Saksafon`,
    CARD_027_DESC: `Belçika enstrümanı (Belçikalı olduğum için söylüyorum)`,
    CARD_028_NAME: `Stres Çarkı`,
    CARD_028_DESC: `Dönüyor`,
    CARD_029_NAME: `Tuvalet Kağıdı Rulosu`,
    CARD_029_DESC: `3 katlı`,
    CARD_030_NAME: `Çirkin Köpek`,
    CARD_030_DESC: `HAV HAV (köpek dilinde 'çirkinim' demek)`,
    CARD_031_NAME: `Sinek`,
    CARD_031_DESC: `Vızzzzzzzzz`,
    CARD_032_NAME: `Kupa Ası`,
    CARD_032_DESC: `Sadece aslar var, çünkü çok üşendim`,
    CARD_033_NAME: `Sinek Ası`,
    CARD_033_DESC: `Sadece aslar var, çünkü çok üşendim`,
    CARD_034_NAME: `Maça Ası`,
    CARD_034_DESC: `Sadece aslar var, çünkü çok üşendim`,
    CARD_035_NAME: `Karo Ası`,
    CARD_035_DESC: `Sadece aslar var, çünkü çok üşendim`,
    CARD_036_NAME: `Turşu`,
    CARD_036_DESC: `Hamburgerin içinde iğrenç`,
    CARD_037_NAME: `Kömür`,
    CARD_037_DESC: `Tanıdık geldi...`,
    CARD_038_NAME: `At`,
    CARD_038_DESC: `Kusursuz çizilmiş`,
    CARD_039_NAME: `Kelleşmenin İlk Belirtileri`,
    CARD_039_DESC: `Yok yok, sadece ışık öyle gösteriyor, merak etme`,
    CARD_040_NAME: `Emmental`,
    CARD_040_DESC: `Peynir sevmiyorum`,
    CARD_041_NAME: `Babam`,
    CARD_041_DESC: ``,
    CARD_042_NAME: `Sol Anahtarı`,
    CARD_042_DESC: `Portede sol notasının yerini gösterir`,
    CARD_043_NAME: `Çin Böreği`,
    CARD_043_DESC: `Biz sebzeli Çin böreği takımındayız`,
    CARD_044_NAME: `MP3 Dosyası`,
    CARD_044_DESC: `sndCardWoosh.mp3`,
    CARD_045_NAME: `Zebra`,
    CARD_045_DESC: `Kusursuz çizilmiş`,
    CARD_046_NAME: `Gökkuşağı`,
    CARD_046_DESC: `Işığın kırılmasıyla ilgili`,
    CARD_047_NAME: `Comté`,
    CARD_047_DESC: `Peynir sevmiyorum`,
    CARD_048_NAME: `Demir`,
    CARD_048_DESC: `Tanıdık geldi...`,
    CARD_049_NAME: `Belçika Bayrağı`,
    CARD_049_DESC: `Evet, patates kızartması`,
    CARD_050_NAME: `Vale`,
    CARD_050_DESC: `Kız kartının açıklamasına bak`,
    CARD_051_NAME: `Kız`,
    CARD_051_DESC: `Papaz kartının açıklamasına bak`,
    CARD_052_NAME: `Papaz`,
    CARD_052_DESC: `Joker'in açıklamasına bak`,
    CARD_053_NAME: `Tek Boynuzlu At`,
    CARD_053_DESC: `Kusursuz çizilmiş`,
    CARD_054_NAME: `Altın`,
    CARD_054_DESC: `Tanıdık geldi...`,
    CARD_055_NAME: `Sputnik`,
    CARD_055_DESC: `Dünyanın ilk yapay uydusu`,
    CARD_056_NAME: `Camembert`,
    CARD_056_DESC: `Peynir sevmiyorum`,
    CARD_057_NAME: `Joker`,
    CARD_057_DESC: `Vale'nin açıklamasına bak`,
    CARD_058_NAME: `Elmas`,
    CARD_058_DESC: `Tanıdık geldi...`,
    CARD_059_NAME: `Pegasus`,
    CARD_059_DESC: `İlahi şekilde çizilmiş`,
    CARD_060_NAME: `Atom`,
    CARD_060_DESC: `Tüm maddelerin yapı taşıdır`,
    CARD_061_NAME: `Morg Kliması Contası`,
    CARD_061_DESC: `Sanatçı: Alphonse Robichu`,
    CARD_062_NAME: `Şüpheli Salyangoz`,
    CARD_062_DESC: `O biliyor`,
    CARD_063_NAME: `Muzip Böbrek`,
    CARD_063_DESC: `Aslında başta balık olacaktı`,
    CARD_064_NAME: `Q`,
    CARD_064_DESC: `Eh, bu kadar`,
    CARD_065_NAME: `Uzay Gemisi`,
    CARD_065_DESC: `Savaşa hazır`,
    CARD_066_NAME: `Kedim`,
    CARD_066_DESC: `Adı CHOCOLAT <3`,
    CARD_067_NAME: `Obur`,
    CARD_067_DESC: `Hamburger peşinde`,
    CARD_068_NAME: `Özgüvenli Denizanası`,
    CARD_068_DESC: `Vay be, ne kadar havalı??`,
    CARD_069_NAME: `Hasır Şapka`,
    CARD_069_DESC: `Tek parça hâlinde satın alınabilir`,
    CARD_070_NAME: `Kapitalist Domuz`,
    CARD_070_DESC: `Cayman Adaları'nda hesabı var`,
    CARD_071_NAME: `Karıştırılmış Rubik Küp`,
    CARD_071_DESC: `Çözmeye fena üşeniyorum`,
    CARD_072_NAME: `Rubik Küp`,
    CARD_072_DESC: `Artık ellemeye cesaret edemiyorum`,
    CARD_073_NAME: `Laboratuvar Bilimcisi`,
    CARD_073_DESC: `Varyant tasarımına kendini fena kaptırmış`,
    CARD_074_NAME: `Patates Kızartması`,
    CARD_074_DESC: `Meşhur BELÇİKA yemeği`,
    CARD_075_NAME: `Bitmek Bilmeyen Sesli Mesaj`,
    CARD_075_DESC: `Eveeet, sana sesli mesaj atayım, daha hızlı olur, şey, aslında—AA dur, biri arıyor`,
    CARD_076_NAME: `Domuz Kumbara`,
    CARD_076_DESC: `Oink Oink`,
    CARD_077_NAME: `Maneki-Neko`,
    CARD_077_DESC: `İyi şans getirir`,
    CARD_078_NAME: `Domates`,
    CARD_078_DESC: `Sanatçı: Lucy`,
    CARD_079_NAME: `Şüpheli Ayak`,
    CARD_079_DESC: `Kokusu da şüpheli`,
    CARD_080_NAME: `Koca Burunlu Adam`,
    CARD_080_DESC: `Acaba neyin kokusunu alıyor??`,
    CARD_081_NAME: `Koklanmış Kiraz`,
    CARD_081_DESC: `Ama bu burun kimin??`,
    CARD_082_NAME: `Aksolotl`,
    CARD_082_DESC: `23 santimetrelik sevimlilik`,
    CARD_083_NAME: `MargueRIP`,
    CARD_083_DESC: `Güzel ama ölü...`,
    CARD_084_NAME: `Ucuz Kostüm`,
    CARD_084_DESC: `Çakma ama işe yarıyor`,
    CARD_085_NAME: `Uyku Felci`,
    CARD_085_DESC: `Arkana dönme`,
    CARD_086_NAME: `Beyaz Gözlü Mavi Kertenkele`,
    CARD_086_DESC: `ATK/3000   DEF/2500`,
    CARD_087_NAME: `Yanıp Tükenmiş Robot`,
    CARD_087_DESC: `@grouk bu gerçekten doğru mu??`,
    CARD_088_NAME: `CATPCHA`,
    CARD_088_DESC: `Kedi resimlerine tıkla`,
    CARD_089_NAME: `Kusursuz Yuvarlak Top`,
    CARD_089_DESC: `4/3 * pi * r³`,
    CARD_090_NAME: `Stanley Kübik`,
    CARD_090_DESC: `Çekimler tamam!`,
    CARD_091_NAME: `Pasaport`,
    CARD_091_DESC: `Papers, Please`,
    CARD_092_NAME: `Yeşil Çay`,
    CARD_092_DESC: `Aslında o kadar da yeşil değil`,
    CARD_093_NAME: `Yarı Tanrı`,
    CARD_093_DESC: `Diğer yarısını söyleyemiyoruz maalesef`,
    CARD_094_NAME: `Sevimli Ufaklıklar`,
    CARD_094_DESC: `=(°u°)=`,
    CARD_095_NAME: `Elektrikçi`,
    CARD_095_DESC: `Elektrikçi geldi... Buraya gel`,
    CARD_096_NAME: `Yapışkan Duş Perdesi`,
    CARD_096_DESC: `Hepimizin başına gelmiştir, değil mi?`,
    CARD_097_NAME: `14:44`,
    CARD_097_DESC: `Saat görselle uyuşmuyor, kendimi biraz aptal hissettim`,
    CARD_098_NAME: `Yerçekimi`,
    CARD_098_DESC: `Isaac Newton tarafından icat edildi`,
    CARD_099_NAME: `Oluşturulan 100. Kart`,
    CARD_099_DESC: `2 Eylül, 23:24`,
    CARD_100_NAME: `Shamisen`,
    CARD_100_DESC: `Nasıl yani, 3 tel mi?`,
    CARD_101_NAME: `C++ Dili`,
    CARD_101_DESC: `Oyun bununla programlanmadı ama saygımız sonsuz`,
    CARD_102_NAME: `????`,
    CARD_102_DESC: `Ciddi misin şu an??`,
    CARD_103_NAME: `Kebap Şişi`,
    CARD_103_DESC: `Her zamankinden, usta`,
    CARD_104_NAME: `2020'deki Görünmez Adam`,
    CARD_104_DESC: `O da herkes gibi etkilendi`,
    CARD_105_NAME: `Göz Kırpan Gülen Yüz`,
    CARD_105_DESC: `Gerçekten takılmaman gereken tipler kullanır`,
    CARD_106_NAME: `Yapay Zekâ Çöpü`,
    CARD_106_DESC: `Ama bu kart yapay zekâyla üretilmedi`,
    CARD_107_NAME: `Mavi Kuş`,
    CARD_107_DESC: `Hâlâ ıslığını duyabiliyorum #nostalji`,
    CARD_108_NAME: `Sinefil`,
    CARD_108_DESC: `2014 yapımı ünlü bir uzay filminden nefret ediyor`,
    CARD_109_NAME: `İnşaat Tuğlası`,
    CARD_109_DESC: `T şeklindeki, duvar ustalarının korkulu rüyası`,
    CARD_110_NAME: `Dünyanın En Küçük Kemanı`,
    CARD_110_DESC: `Bir dinleyeni olsa fena olmaz`,
    CARD_111_NAME: `Şüpheli Soyut Eser`,
    CARD_111_DESC: `sus.........`,
    CARD_112_NAME: `YouTuber Özür Videosu`,
    CARD_112_DESC: `Biliyorum, söyleyeceğim hiçbir şey...`,
    CARD_113_NAME: `Çok, Çok Olgun Muz`,
    CARD_113_DESC: `Bunu artık gerçekten yemelisin`,
    CARD_114_NAME: `Patlama`,
    CARD_114_DESC: `BUUUUUUUM`,
    CARD_115_NAME: `İklim Değişikliği`,
    CARD_115_DESC: `Hiçbir şey yapmazsak 2050'ye kadar +2°C, lol`,
    CARD_116_NAME: `Kötü Kadrajlı Yayıncı`,
    CARD_116_DESC: `twitch.tv/doigt`,
    CARD_117_NAME: `Mr. Yumruk`,
    CARD_117_DESC: `500 VOLTA DAYANAN YARIŞMACIYA 300 MİLYON DOLAR VERECEĞİM`,
    CARD_118_NAME: `Osuruğumu Tahmin Et`,
    CARD_118_DESC: `Herkese göre olmayan bir oyun`,
    CARD_119_NAME: `Zindan Eşyası`,
    CARD_119_DESC: `Yalnızca bu zindanda kullanılacak`,
    CARD_120_NAME: `Gece Görünen Güneş`,
    CARD_120_DESC: `Ona saldırmak için tam zamanı`,
    CARD_121_NAME: `Karpuz`,
    CARD_121_DESC: `%215 sudan oluşan meyve (bilim)`,
    CARD_122_NAME: `Kara Delik`,
    CARD_122_DESC: `Kütleçekimine rağmen beni senin kadar kendine çekemiyor`,
    CARD_123_NAME: `Six Seven`,
    CARD_123_DESC: `SIX SEVEN SIX SEVEN`,
    CARD_124_NAME: `Billy`,
    CARD_124_DESC: `Sıradan bir slime değil, bir efsane...`,
    CARD_125_NAME: `Kaypak Jimmy`,
    CARD_125_DESC: `Göz kırpan suratlarla mesaj atıyor`,
    CARD_126_NAME: `Cthulhu`,
    CARD_126_DESC: `13 santimetre boyunda`,
    CARD_127_NAME: `Zombi`,
    CARD_127_DESC: `Grrrrraaaah`,
    CARD_128_NAME: `Üstel Fonksiyon`,
    CARD_128_DESC: `Tamam, ama bu bayağı hızlı yükseliyor`,
    CARD_129_NAME: `Rüzgâr`,
    CARD_129_DESC: `Vuuuuuuuu`,
    CARD_130_NAME: `16:9 En-Boy Oranı`,
    CARD_130_DESC: `Bu en-boy oranını değiştirirsen oyun bozulur, o yüzden deneme, teşekkürler`,
    CARD_131_NAME: `4:3 En-Boy Oranı`,
    CARD_131_DESC: `Eski usul`,
    CARD_132_NAME: `Influencer Ürünü`,
    CARD_132_DESC: `Yeni katran aroması: $5,99`,
    CARD_133_NAME: `Kırmızı Düğme`,
    CARD_133_DESC: `Basma, hiçbir şey yapmayacak`,
    CARD_134_NAME: `Ateş Topu`,
    CARD_134_DESC: `25 hasar verir—şaka şaka, dümdüz bir çizim bu, sakin ol`,
    CARD_135_NAME: `Kart İçinde Kart`,
    CARD_135_DESC: `Kart açıklaması: Kart açıklaması`,
    CARD_136_NAME: `İddialı Bıyık`,
    CARD_136_DESC: `Çirkin demeyelim de`,
    CARD_137_NAME: `Kocaman But`,
    CARD_137_DESC: `Gerçi önce pişirsen iyi olur`,
    CARD_138_NAME: `Bitmemiş Çizim`,
    CARD_138_DESC: `Vaktim kalmadı, oyunun çıkış takviminde zaten gerideyim`,
    CARD_139_NAME: `Birleştiren Megafon`,
    CARD_139_DESC: `Bu daha başlangıç`,
    CARD_140_NAME: `Antrenör`,
    CARD_140_DESC: `İNAN`,
    CARD_141_NAME: `Hachiko`,
    CARD_141_DESC: `Sadakat ve sevginin simgesi`,
    CARD_142_NAME: `Sosis Adam`,
    CARD_142_DESC: `Büyük güç, büyük baharat getirir`,
  },
  ae = {
    mscBoard1: 1,
    mscBoard2: 0.78,
    mscBoard3: 0.86,
    mscBoard4: 0.88,
    mscBoard5: 0.64,
    mscBoardRush: 1,
    mscCollectionFull: 0.95,
    mscEnding: 1,
    mscModuleArena: 0.89,
    mscModuleLab: 0.8,
    mscModuleMemory: 0.84,
    mscModuleMuseum: 1,
    mscTitle: 0.86,
    mscTuto: 1,
    sndApplause: 0.78,
    sndBarTick: 0.77,
    sndBoosterHurt: 0.77,
    sndBoosterHurt2: 0.86,
    sndCardDraw1: 0.65,
    sndCardDraw2: 0.75,
    sndCardDraw3: 0.84,
    sndCardFlip1: 1,
    sndCardFull: 0.91,
    sndCardNew0: 0.66,
    sndCardNew1: 0.62,
    sndCardNew2: 0.62,
    sndCardNew3: 0.64,
    sndCardNew4: 0.64,
    sndCardNew5: 0.65,
    sndCardNew6: 1,
    sndCardNotnew: 0.6,
    sndCardRecord: 0.63,
    sndCardStamp: 0.92,
    sndClick1: 0.45,
    sndCoin: 0.94,
    sndExplosion1: 0.59,
    sndExplosion2: 0.47,
    sndHover: 0.29,
    sndHurt1: 1,
    sndModuleLabLaunched: 1,
    sndModuleMuseum1: 0.65,
    sndModuleMuseum2: 0.45,
    sndModuleMuseum3: 1,
    sndMoney1: 0.8,
    sndUpgrade1: 0.5,
    sndVoiceEN123: 1,
    sndVoiceEN124: 1,
    sndVoiceEN125: 1,
    sndVoiceEN126: 1,
    sndVoiceEN142: 1,
    sndVoiceEN28: 1,
    sndVoiceEN29: 1,
    sndVoiceEN58: 1,
    sndVoiceEN59: 1,
    sndVoiceFR123: 1,
    sndVoiceFR124: 1,
    sndVoiceFR125: 1,
    sndVoiceFR126: 1,
    sndVoiceFR142: 1,
    sndVoiceFR28: 1,
    sndVoiceFR29: 1,
    sndVoiceFR58: 1,
    sndVoiceFR59: 1,
    sndWoosh1: 1,
    sndWooshEnter: 1,
    sndWooshExit: 1,
    sndWrong1: 1,
  },
  oe = { en: te, fr: ne, pl: re, tr: ie },
  se = ae,
  ce = (e) => JSON.parse(JSON.stringify(e));
function le() {
  return ce(b);
}
function ue() {
  return ce(x);
}
function de() {
  return ce(ee);
}
function w() {
  return ce(S);
}
function T() {
  return ce(C);
}
var fe = {};
function pe(e) {
  return fe[e] || `/ctp/game/audio/${e}.mp3`;
}
var me = class {
    ctx = null;
    master = null;
    buffers = new Map();
    loading = new Map();
    playing = new Map();
    sfxVolume = 0.8;
    musicVolume = 0.8;
    music = null;
    musicName = ``;
    musicGain = 1;
    musicPitch = 1;
    extraMusic = new Map();
    unlock() {
      if (!this.ctx) {
        let e = window.AudioContext || window.webkitAudioContext;
        if (!e) return;
        ((this.ctx = new e()),
          (this.master = this.ctx.createGain()),
          this.master.connect(this.ctx.destination));
      }
      this.ctx.state === `suspended` && this.ctx.resume();
    }
    has(e) {
      return !!e;
    }
    load(e) {
      if (!this.ctx) return Promise.resolve(null);
      let t = this.loading.get(e);
      if (t) return t;
      let n = this.ctx,
        r = pe(e),
        i = fetch(r)
          .then((e) => {
            if (!e.ok) throw Error(`HTTP ${e.status}`);
            return e.arrayBuffer();
          })
          .then((e) => n.decodeAudioData(e))
          .then((t) => (this.buffers.set(e, t), t))
          .catch(() => null);
      return (this.loading.set(e, i), i);
    }
    play(e, t = 1, n = 1, r = !1) {
      this.unlock();
      let i = this.buffers.get(e);
      if (!i) {
        this.load(e).then((i) => {
          i && this.play(e, t, n, r);
        });
        return;
      }
      if (!this.ctx || !this.master) return;
      let a = this.ctx.createBufferSource();
      ((a.buffer = i),
        (a.loop = r),
        (a.playbackRate.value = Math.max(0.1, Math.min(4, n))));
      let o = this.ctx.createGain();
      ((o.gain.value = Math.max(0, t * (se[e] ?? 1) * this.sfxVolume)),
        a.connect(o).connect(this.master),
        a.start(),
        this.playing.set(
          e,
          this.ctx.currentTime + i.duration / a.playbackRate.value,
        ));
    }
    isPlaying(e) {
      if (
        this.musicName === e &&
        this.music &&
        !this.music.paused &&
        !this.music.ended
      )
        return !0;
      let t = this.extraMusic.get(e);
      if (t && !t.paused && !t.ended) return !0;
      if (!this.ctx) return !1;
      let n = this.playing.get(e);
      return n !== void 0 && n > this.ctx.currentTime;
    }
    // Stop every background track except `e` (the music channel is strictly single-track)
    stopOtherMusic(e) {
      this.music && this.musicName !== e && this.stopMusic();
      for (let [t, n] of this.extraMusic)
        t !== e && (n.pause(), this.extraMusic.delete(t));
    }
    anyMusicPlaying() {
      if (this.music && !this.music.paused && !this.music.ended) return !0;
      for (let e of this.extraMusic.values()) if (!e.paused && !e.ended) return !0;
      return !1;
    }
    playMusic(e, t = !1) {
      this.stopMusic();
      for (let e of this.extraMusic.values()) e.pause();
      this.extraMusic.clear();
      let n = pe(e),
        r = new Audio(n);
      ((r.loop = t),
        (r.preservesPitch = !1),
        (r.playbackRate = this.musicPitch),
        (r.volume = this.musicVolumeFor(e)),
        (this.music = r),
        (this.musicName = e),
        r.play().catch(() => {}));
    }
    playTrack(e, t = 1, n = !1, r = 0, i = 1) {
      let a = pe(e);
      (this.stopOtherMusic(e), this.stopMusic(), this.extraMusic.get(e)?.pause());
      let o = new Audio(a);
      ((o.loop = n),
        (o.preservesPitch = !1),
        (o.playbackRate = Math.max(0.25, Math.min(4, i))),
        (o.volume = Math.max(
          0,
          Math.min(1, t * (se[e] ?? 1) * this.musicVolume),
        )),
        r > 0 &&
          o.addEventListener(
            `loadedmetadata`,
            () => {
              o.duration &&
                (o.currentTime = n
                  ? r % o.duration
                  : Math.min(r, o.duration - 0.05));
            },
            { once: !0 },
          ),
        this.extraMusic.set(e, o),
        o.play().catch(() => {}));
    }
    setTrackVolume(e, t) {
      let n = this.extraMusic.get(e);
      n && (n.volume = Math.max(0, Math.min(1, t)));
    }
    stopTrack(e) {
      let t = this.extraMusic.get(e);
      (t && (t.pause(), this.extraMusic.delete(e)),
        this.musicName === e && this.stopMusic());
    }
    stopMusic() {
      this.music &&
        (this.music.pause(), (this.music = null), (this.musicName = ``));
    }
    stopAll() {
      this.stopMusic();
      for (let e of this.extraMusic.values()) e.pause();
      this.extraMusic.clear();
    }
    musicVolumeFor(e) {
      return Math.max(
        0,
        Math.min(1, this.musicGain * this.musicVolume * (se[e] ?? 1)),
      );
    }
    updateEmitter(e, t) {
      if (((this.musicGain = e), (this.musicPitch = t), this.music)) {
        this.music.volume = this.musicVolumeFor(this.musicName);
        let e = Math.max(0.25, Math.min(4, t));
        Math.abs(this.music.playbackRate - e) > 0.005 &&
          (this.music.playbackRate = e);
      }
    }
    suspend() {
      this.music?.pause();
      for (let e of this.extraMusic.values()) e.pause();
      this.ctx?.suspend();
    }
    resume() {
      (this.music &&
        this.music.paused &&
        !this.music.ended &&
        this.music.play().catch(() => {}),
        this.music ||
          this.extraMusic.forEach((e) => {
            e.paused && !e.ended && e.play().catch(() => {});
          }),
        this.ctx?.resume());
    }
  },
  he = 280,
  ge = 12,
  E = 380,
  _e = class {
    x = -100;
    y = -100;
    leftDown = !1;
    leftPressed = !1;
    leftReleased = !1;
    downStarted = !1;
    rightDown = !1;
    rightPressed = !1;
    rightReleased = !1;
    keys = new Set();
    keysPressed = new Set();
    touch = !1;
    touchX = -100;
    touchY = -100;
    touchActive = !1;
    touchUpAt = -1e9;
    longPress = null;
    downAt = { x: 0, y: 0, cx: 0, cy: 0, t: 0 };
    moved = !1;
    primary = null;
    fingers = new Map();
    fourTapAt = 0;
    cleanup = null;
    onGesture = null;
    onFourFingerTap = null;
    pend = { press: !1, release: !1, down: !1 };
    attach(e, t) {
      let n = (e) => {
          let n = t.toRoom(e.clientX, e.clientY);
          ((this.x = n.x),
            (this.y = n.y),
            e.pointerType !== `mouse` &&
              ((this.touchX = n.x), (this.touchY = n.y)));
        },
        r = () => {
          this.longPress !== null &&
            (window.clearTimeout(this.longPress), (this.longPress = null));
        },
        i = (t) => {
          (t.preventDefault(), this.onGesture?.());
          let r = t.pointerType !== `mouse`;
          if (r) {
            if (
              (this.fingers.set(t.pointerId, t.timeStamp),
              this.fingers.size >= 4)
            ) {
              let e = t.timeStamp,
                n = [...this.fingers.values()];
              (Math.max(...n) - Math.min(...n) < 700 &&
                e - this.fourTapAt > 800 &&
                ((this.fourTapAt = e), this.onFourFingerTap?.()),
                this.cancelPrimary());
              return;
            }
            if (this.primary !== null && this.primary !== t.pointerId) return;
          }
          if (
            ((this.touch = r),
            e.setPointerCapture?.(t.pointerId),
            n(t),
            t.button === 2)
          ) {
            ((this.rightDown = !0), (this.rightPressed = !0));
            return;
          }
          if (
            ((this.primary = t.pointerId),
            (this.downAt = {
              x: this.x,
              y: this.y,
              cx: t.clientX,
              cy: t.clientY,
              t: t.timeStamp,
            }),
            (this.moved = !1),
            (this.leftDown = !0),
            (this.pend.down = !0),
            !r)
          ) {
            this.pend.press = !0;
            return;
          }
          ((this.touchActive = !0),
            (this.longPress = window.setTimeout(() => {
              ((this.longPress = null),
                !this.moved &&
                  this.leftDown &&
                  ((this.rightDown = !0), (this.rightPressed = !0)));
            }, E)));
        },
        a = (e) => {
          (e.pointerType === `mouse` ||
            this.primary === null ||
            e.pointerId === this.primary) &&
            (n(e),
            this.leftDown &&
              Math.hypot(
                e.clientX - this.downAt.cx,
                e.clientY - this.downAt.cy,
              ) > ge &&
              ((this.moved = !0), this.rightDown || r()));
        },
        o = (e) => {
          let t = e.pointerType !== `mouse`;
          if (
            (t && this.fingers.delete(e.pointerId),
            (t && e.pointerId !== this.primary) ||
              (n(e),
              r(),
              (e.button === 2 || (t && this.rightDown)) &&
                ((this.rightDown = !1), (this.rightReleased = !0)),
              e.button === 2 && !t))
          )
            return;
          let i = this.leftDown;
          ((this.leftDown = !1),
            (this.primary = null),
            i &&
              (t &&
                (e.timeStamp - this.downAt.t < he &&
                  !this.moved &&
                  e.type !== `pointercancel` &&
                  (this.pend.press = !0),
                (this.touchActive = !1),
                (this.touchUpAt = performance.now())),
              (this.pend.release = !0),
              t &&
                window.setTimeout(() => {
                  this.leftDown || ((this.x = -100), (this.y = -100));
                }, 120)));
        },
        s = (e) => e.preventDefault(),
        c = (e) => {
          (this.onGesture?.(),
            this.keys.has(e.code) || this.keysPressed.add(e.code),
            this.keys.add(e.code));
        },
        l = (e) => this.keys.delete(e.code);
      (e.addEventListener(`pointerdown`, i),
        e.addEventListener(`pointermove`, a),
        e.addEventListener(`pointerup`, o),
        e.addEventListener(`pointercancel`, o),
        e.addEventListener(`contextmenu`, s),
        window.addEventListener(`keydown`, c),
        window.addEventListener(`keyup`, l),
        (this.cleanup = () => {
          (e.removeEventListener(`pointerdown`, i),
            e.removeEventListener(`pointermove`, a),
            e.removeEventListener(`pointerup`, o),
            e.removeEventListener(`pointercancel`, o),
            e.removeEventListener(`contextmenu`, s),
            window.removeEventListener(`keydown`, c),
            window.removeEventListener(`keyup`, l));
        }));
    }
    cancelPrimary() {
      (this.longPress !== null && window.clearTimeout(this.longPress),
        (this.longPress = null),
        this.leftDown && (this.pend.release = !0),
        (this.leftDown = !1),
        (this.rightDown = !1),
        (this.primary = null),
        (this.touchActive = !1),
        (this.touchUpAt = performance.now()));
    }
    detach() {
      this.cleanup?.();
    }
    beginStep() {
      (this.pend.press && (this.leftPressed = !0),
        this.pend.release && (this.leftReleased = !0),
        this.pend.down && (this.downStarted = !0),
        (this.pend.press = this.pend.release = this.pend.down = !1));
    }
    endStep() {
      ((this.leftPressed = !1),
        (this.leftReleased = !1),
        (this.downStarted = !1),
        (this.rightPressed = !1),
        (this.rightReleased = !1),
        this.keysPressed.clear());
    }
  },
  ve = {
    w: 2048,
    h: 2048,
    sprites: JSON.parse(
      `{"sAlarm":{"w":40,"h":40,"ox":20,"oy":12,"sp":0.0,"st":0,"bb":[5,10,34,32],"f":[[1602,1287],[1644,1287]]},"sBGBoard":{"w":50,"h":50,"ox":0,"oy":0,"sp":30.0,"st":0,"bb":[0,0,49,49],"f":[[1996,1215],[926,1287],[978,1287],[1030,1287],[1082,1287],[1134,1287],[1186,1287],[1238,1287],[1290,1287],[1342,1287],[1394,1287],[1446,1287]]},"sBGEnding_1":{"w":320,"h":180,"ox":0,"oy":0,"sp":0.0,"st":0,"bb":[10,4,308,43],"f":[[2,215]]},"sBGEnding_2":{"w":320,"h":180,"ox":0,"oy":0,"sp":0.0,"st":0,"bb":[8,107,306,179],"f":[[324,215]]},"sBGEnding_3":{"w":320,"h":180,"ox":0,"oy":0,"sp":0.0,"st":0,"bb":[17,42,319,179],"f":[[646,215]]},"sBGEnding_4":{"w":320,"h":180,"ox":0,"oy":0,"sp":0.0,"st":0,"bb":[11,59,224,157],"f":[[968,215]]},"sBGEnding_5":{"w":320,"h":180,"ox":0,"oy":0,"sp":0.0,"st":0,"bb":[0,142,319,179],"f":[[1290,215]]},"sBGEnding":{"w":320,"h":180,"ox":0,"oy":0,"sp":0.0,"st":0,"bb":[0,0,319,179],"f":[[1612,215]]},"sBGMenuIntro_1":{"w":320,"h":180,"ox":0,"oy":0,"sp":0.0,"st":0,"bb":[27,14,281,163],"f":[[2,397]]},"sBooster0":{"w":100,"h":100,"ox":50,"oy":50,"sp":0.0,"st":0,"bb":[22,6,77,94],"f":[[1934,215],[1605,397]]},"sBooster0Plastic":{"w":100,"h":100,"ox":76,"oy":13,"sp":0.0,"st":0,"bb":[22,6,77,94],"f":[[1707,397],[1809,397]]},"sBooster1":{"w":100,"h":100,"ox":50,"oy":50,"sp":0.0,"st":0,"bb":[22,6,77,94],"f":[[1911,397],[2,579]]},"sBooster1Plastic":{"w":100,"h":100,"ox":76,"oy":13,"sp":30.0,"st":0,"bb":[22,6,77,13],"f":[[104,579]]},"sBooster2":{"w":100,"h":100,"ox":50,"oy":50,"sp":0.0,"st":0,"bb":[22,6,77,94],"f":[[206,579],[308,579]]},"sBooster2Plastic":{"w":100,"h":100,"ox":76,"oy":13,"sp":30.0,"st":0,"bb":[22,6,77,13],"f":[[410,579]]},"sBooster3":{"w":100,"h":100,"ox":50,"oy":50,"sp":0.0,"st":0,"bb":[9,6,91,94],"f":[[512,579],[614,579]]},"sBooster3Plastic":{"w":100,"h":100,"ox":76,"oy":13,"sp":30.0,"st":0,"bb":[22,6,77,13],"f":[[716,579]]},"sBooster4":{"w":100,"h":100,"ox":50,"oy":62,"sp":0.0,"st":0,"bb":[22,18,77,77],"f":[[818,579],[920,579]]},"sBooster4Plastic":{"w":100,"h":100,"ox":76,"oy":13,"sp":30.0,"st":0,"bb":[22,6,77,13],"f":[[1022,579]]},"sBooster5":{"w":100,"h":100,"ox":50,"oy":50,"sp":0.0,"st":0,"bb":[22,6,77,94],"f":[[1124,579],[1226,579]]},"sBooster5Plastic":{"w":100,"h":100,"ox":76,"oy":13,"sp":30.0,"st":0,"bb":[22,6,77,13],"f":[[1328,579]]},"sBooster6":{"w":100,"h":100,"ox":50,"oy":50,"sp":0.0,"st":0,"bb":[22,6,77,94],"f":[[1430,579],[1532,579]]},"sBooster6Plastic":{"w":100,"h":100,"ox":76,"oy":13,"sp":30.0,"st":0,"bb":[22,6,77,13],"f":[[1634,579]]},"sBooster7":{"w":150,"h":150,"ox":75,"oy":75,"sp":0.0,"st":0,"bb":[44,7,105,123],"f":[[324,397],[476,397]]},"sBooster7Plastic":{"w":100,"h":100,"ox":76,"oy":39,"sp":30.0,"st":0,"bb":[22,8,77,39],"f":[[1736,579]]},"sBooster8":{"w":100,"h":100,"ox":50,"oy":50,"sp":0.0,"st":0,"bb":[22,6,77,94],"f":[[1838,579],[1940,579]]},"sBooster8Plastic":{"w":100,"h":100,"ox":76,"oy":39,"sp":30.0,"st":0,"bb":[22,32,77,39],"f":[[2,681]]},"sBoosterBlister":{"w":400,"h":400,"ox":200,"oy":200,"sp":0.0,"st":0,"bb":[156,137,242,263],"k":0.5,"f":[[1595,2]],"tw":200,"th":200},"sBoosterBlister2":{"w":400,"h":400,"ox":200,"oy":200,"sp":0.0,"st":0,"bb":[156,137,242,263],"k":0.5,"f":[[1797,2]],"tw":200,"th":200},"sBoosterFissuration":{"w":100,"h":100,"ox":50,"oy":50,"sp":0.0,"st":0,"bb":[24,16,76,86],"f":[[104,681],[206,681],[308,681],[410,681]]},"sCardArt0":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[938,681],[990,681]]},"sCardArt1":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[5,5,46,57],"f":[[1042,681],[1094,681]]},"sCardArt10":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1146,681],[1198,681]]},"sCardArt100":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1250,681],[1302,681]]},"sCardArt101":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1354,681],[1406,681]]},"sCardArt102":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1458,681],[1510,681]]},"sCardArt103":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1562,681],[1614,681]]},"sCardArt104":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1666,681],[1718,681]]},"sCardArt105":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1770,681],[1822,681]]},"sCardArt106":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1874,681],[1926,681]]},"sCardArt107":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1978,681],[2,783]]},"sCardArt108":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[54,783],[106,783]]},"sCardArt109":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[158,783],[210,783]]},"sCardArt11":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[262,783],[314,783]]},"sCardArt110":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[366,783],[418,783]]},"sCardArt111":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[470,783],[522,783]]},"sCardArt112":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[574,783],[626,783]]},"sCardArt113":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[678,783],[730,783]]},"sCardArt114":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[782,783],[834,783]]},"sCardArt115":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[886,783],[938,783]]},"sCardArt116":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[990,783],[1042,783]]},"sCardArt117":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1094,783],[1146,783]]},"sCardArt118":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1198,783],[1250,783]]},"sCardArt119":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1302,783],[1354,783]]},"sCardArt12":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1406,783],[1458,783]]},"sCardArt120":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1510,783],[1562,783]]},"sCardArt121":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1614,783],[1666,783]]},"sCardArt122":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1718,783],[1770,783]]},"sCardArt123":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1822,783],[1874,783]]},"sCardArt124":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1926,783],[1978,783]]},"sCardArt125":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[2,855],[54,855]]},"sCardArt126":{"w":150,"h":210,"ox":75,"oy":105,"sp":30.0,"st":0,"bb":[10,28,146,160],"f":[[379,2],[531,2]]},"sCardArt127":{"w":150,"h":210,"ox":75,"oy":105,"sp":30.0,"st":0,"bb":[54,74,96,127],"f":[[683,2],[835,2]]},"sCardArt128":{"w":150,"h":210,"ox":75,"oy":105,"sp":30.0,"st":0,"bb":[54,74,96,127],"f":[[987,2],[1139,2]]},"sCardArt129":{"w":150,"h":210,"ox":75,"oy":105,"sp":30.0,"st":0,"bb":[54,74,96,127],"f":[[1291,2],[1443,2]]},"sCardArt13":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[106,855],[158,855]]},"sCardArt130":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[210,855],[262,855]]},"sCardArt131":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[314,855],[366,855]]},"sCardArt132":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[418,855],[470,855]]},"sCardArt133":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[522,855],[574,855]]},"sCardArt134":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[626,855],[678,855]]},"sCardArt135":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[730,855],[782,855]]},"sCardArt136":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[834,855],[886,855]]},"sCardArt137":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[938,855],[990,855]]},"sCardArt138":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1042,855],[1094,855]]},"sCardArt139":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1146,855],[1198,855]]},"sCardArt14":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1250,855],[1302,855]]},"sCardArt140":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1354,855],[1406,855]]},"sCardArt141":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1458,855],[1510,855]]},"sCardArt142":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1562,855],[1614,855]]},"sCardArt15":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1666,855],[1718,855]]},"sCardArt16":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1770,855],[1822,855]]},"sCardArt17":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1874,855],[1926,855]]},"sCardArt18":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1978,855],[2,927]]},"sCardArt19":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[54,927],[106,927]]},"sCardArt2":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[158,927],[210,927]]},"sCardArt20":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[262,927],[314,927]]},"sCardArt21":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[366,927],[418,927]]},"sCardArt22":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[470,927],[522,927]]},"sCardArt23":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[574,927],[626,927]]},"sCardArt24":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[678,927],[730,927]]},"sCardArt25":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[782,927],[834,927]]},"sCardArt26":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[886,927],[938,927]]},"sCardArt27":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[990,927],[1042,927]]},"sCardArt28":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1094,927],[1146,927]]},"sCardArt29":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1198,927],[1250,927]]},"sCardArt3":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1302,927],[1354,927]]},"sCardArt30":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1406,927],[1458,927]]},"sCardArt31":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1510,927],[1562,927]]},"sCardArt32":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1614,927]]},"sCardArt33":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1666,927]]},"sCardArt34":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1718,927]]},"sCardArt35":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1770,927]]},"sCardArt36":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1822,927],[1874,927]]},"sCardArt37":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1926,927],[1978,927]]},"sCardArt38":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[2,999],[54,999]]},"sCardArt39":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[106,999],[158,999]]},"sCardArt4":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[210,999],[262,999]]},"sCardArt40":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[314,999],[366,999]]},"sCardArt41":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[0,0,0,0],"f":[[418,999]]},"sCardArt42":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[470,999],[522,999]]},"sCardArt43":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[574,999],[626,999]]},"sCardArt44":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[678,999],[730,999]]},"sCardArt45":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[782,999],[834,999]]},"sCardArt46":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[886,999],[938,999]]},"sCardArt47":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[990,999],[1042,999]]},"sCardArt48":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1094,999],[1146,999]]},"sCardArt49":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1198,999],[1250,999]]},"sCardArt5":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1302,999],[1354,999]]},"sCardArt50":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1406,999]]},"sCardArt51":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1458,999]]},"sCardArt52":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1510,999]]},"sCardArt53":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1562,999],[1614,999]]},"sCardArt54":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1666,999],[1718,999]]},"sCardArt55":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1770,999],[1822,999]]},"sCardArt56":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1874,999],[1926,999]]},"sCardArt57":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1978,999],[2,1071]]},"sCardArt58":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[54,1071],[106,1071]]},"sCardArt59":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[1,1,49,57],"f":[[158,1071],[210,1071]]},"sCardArt6":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[262,1071],[314,1071]]},"sCardArt60":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[366,1071],[418,1071]]},"sCardArt61":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[470,1071],[522,1071]]},"sCardArt62":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[574,1071],[626,1071]]},"sCardArt63":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[678,1071],[730,1071]]},"sCardArt64":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[782,1071],[834,1071]]},"sCardArt65":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[886,1071],[938,1071]]},"sCardArt66":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[990,1071],[1042,1071]]},"sCardArt67":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1094,1071],[1146,1071]]},"sCardArt68":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1198,1071],[1250,1071]]},"sCardArt69":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1302,1071],[1354,1071]]},"sCardArt7":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1406,1071],[1458,1071]]},"sCardArt70":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1510,1071],[1562,1071]]},"sCardArt71":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1614,1071],[1666,1071]]},"sCardArt72":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1718,1071],[1770,1071]]},"sCardArt73":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1822,1071],[1874,1071]]},"sCardArt74":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1926,1071],[1978,1071]]},"sCardArt75":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[2,1143],[54,1143]]},"sCardArt76":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[106,1143],[158,1143]]},"sCardArt77":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[210,1143],[262,1143]]},"sCardArt78":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[314,1143],[366,1143]]},"sCardArt79":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[418,1143],[470,1143]]},"sCardArt8":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[522,1143],[574,1143]]},"sCardArt80":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[626,1143],[678,1143]]},"sCardArt81":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[730,1143],[782,1143]]},"sCardArt82":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[834,1143],[886,1143]]},"sCardArt83":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,2,46,57],"f":[[938,1143],[990,1143]]},"sCardArt84":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1042,1143],[1094,1143]]},"sCardArt85":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1146,1143],[1198,1143]]},"sCardArt86":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,3,46,58],"f":[[1250,1143],[1302,1143]]},"sCardArt87":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1354,1143],[1406,1143]]},"sCardArt88":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1458,1143],[1510,1143]]},"sCardArt89":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1562,1143],[1614,1143]]},"sCardArt9":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1666,1143],[1718,1143]]},"sCardArt90":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1770,1143],[1822,1143]]},"sCardArt91":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1874,1143],[1926,1143]]},"sCardArt92":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[1978,1143],[2,1215]]},"sCardArt93":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,1,46,57],"f":[[54,1215],[106,1215]]},"sCardArt94":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[158,1215],[210,1215]]},"sCardArt95":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[262,1215],[314,1215]]},"sCardArt96":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[366,1215],[418,1215]]},"sCardArt97":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[470,1215],[522,1215]]},"sCardArt98":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,46,57],"f":[[574,1215],[626,1215]]},"sCardArt99":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[2,4,48,57],"f":[[678,1215],[730,1215]]},"sCardBack":{"w":50,"h":70,"ox":25,"oy":35,"sp":0.0,"st":0,"bb":[0,0,49,69],"f":[[782,1215],[834,1215],[886,1215],[938,1215]]},"sCardBackground":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[4,4,45,67],"f":[[990,1215],[1042,1215]]},"sCardBase":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[0,0,49,69],"f":[[1094,1215]]},"sCardBorder":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[0,0,49,69],"f":[[1146,1215]]},"sCardLock":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[0,0,49,69],"f":[[1198,1215],[1250,1215]]},"sCardSeal":{"w":50,"h":70,"ox":25,"oy":35,"sp":0.0,"st":0,"bb":[6,13,44,52],"f":[[1302,1215]]},"sCardStars":{"w":50,"h":70,"ox":25,"oy":35,"sp":30.0,"st":0,"bb":[8,59,41,65],"f":[[1354,1215],[1406,1215],[1458,1215],[1510,1215]]},"sCardTop":{"w":50,"h":70,"ox":25,"oy":35,"sp":0.0,"st":0,"bb":[2,2,47,67],"f":[[1562,1215],[1614,1215]]},"sCoin":{"w":15,"h":15,"ox":7,"oy":7,"sp":0.0,"st":0,"bb":[1,1,12,12],"f":[[846,1427],[863,1427],[880,1427],[897,1427]]},"sCursor":{"w":20,"h":20,"ox":9,"oy":9,"sp":0.0,"st":0,"bb":[1,2,18,16],"f":[[477,1390],[499,1390]]},"sDancer1":{"w":20,"h":20,"ox":10,"oy":10,"sp":5.0,"st":0,"bb":[3,2,16,18],"f":[[521,1390],[543,1390],[565,1390],[587,1390]]},"sDancer2":{"w":20,"h":20,"ox":10,"oy":10,"sp":10.0,"st":0,"bb":[5,2,15,18],"f":[[609,1390],[631,1390],[653,1390],[675,1390],[697,1390],[719,1390]]},"sDancer3":{"w":50,"h":50,"ox":25,"oy":25,"sp":3.0,"st":0,"bb":[21,10,39,33],"f":[[1498,1287],[1550,1287]]},"sFinalImage":{"w":160,"h":90,"ox":0,"oy":0,"sp":2.0,"st":0,"bb":[0,0,159,89],"f":[[614,681],[776,681]]},"sFXImpact":{"w":8,"h":8,"ox":4,"oy":4,"sp":30.0,"st":0,"bb":[0,0,7,7],"f":[[926,1427]]},"sGUIArrows":{"w":20,"h":20,"ox":10,"oy":10,"sp":0.0,"st":0,"bb":[4,2,17,16],"f":[[741,1390]]},"sGUIButton":{"w":40,"h":25,"ox":20,"oy":12,"sp":0.0,"st":0,"bb":[0,0,39,24],"f":[[394,1390]],"ns":[2,2,2,2]},"sGUICheckbox":{"w":20,"h":20,"ox":0,"oy":0,"sp":30.0,"st":0,"bb":[2,2,17,17],"f":[[763,1390],[785,1390]]},"sGUIMenu":{"w":25,"h":25,"ox":12,"oy":12,"sp":30.0,"st":0,"bb":[2,2,22,22],"f":[[436,1390]]},"sGUIOutline":{"w":8,"h":8,"ox":4,"oy":4,"sp":30.0,"st":0,"bb":[0,0,7,7],"f":[[936,1427],[946,1427]],"ns":[1,1,1,1]},"sGUISlidebar":{"w":40,"h":15,"ox":0,"oy":7,"sp":0.0,"st":0,"bb":[0,0,39,14],"f":[[506,1427],[548,1427]]},"sHand":{"w":64,"h":64,"ox":21,"oy":56,"sp":0.0,"st":0,"bb":[17,13,44,40],"f":[[1666,1215],[1732,1215]]},"sLogo":{"w":1500,"h":844,"ox":750,"oy":422,"sp":30.0,"st":0,"bb":[356,123,1086,718],"k":0.25,"f":[[2,2]],"tw":375,"th":211},"sMagnet":{"w":40,"h":40,"ox":21,"oy":20,"sp":0.0,"st":0,"bb":[12,12,25,27],"f":[[1686,1287],[1728,1287]]},"sMenuStudioDev":{"w":1000,"h":1000,"ox":500,"oy":500,"sp":30.0,"st":0,"bb":[217,226,781,981],"k":0.125,"f":[[1478,397]],"tw":125,"th":125},"sMenuStudioLogo":{"w":1920,"h":1080,"ox":936,"oy":619,"sp":30.0,"st":0,"bb":[256,227,1673,1042],"k":0.125,"f":[[1236,397]],"tw":240,"th":135},"sModule":{"w":20,"h":20,"ox":10,"oy":10,"sp":0.0,"st":0,"bb":[2,1,17,18],"f":[[807,1390],[829,1390],[851,1390],[873,1390]]},"sModuleArenaCrown":{"w":100,"h":100,"ox":50,"oy":40,"sp":30.0,"st":0,"bb":[37,28,62,46],"f":[[512,681]]},"sModuleMuseum":{"w":20,"h":20,"ox":10,"oy":10,"sp":0.0,"st":0,"bb":[4,2,15,18],"f":[[895,1390],[917,1390]]},"sScientist":{"w":150,"h":150,"ox":75,"oy":82,"sp":0.0,"st":0,"bb":[43,52,104,136],"f":[[628,397],[780,397],[932,397],[1084,397]]},"sUIBar":{"w":10,"h":10,"ox":0,"oy":5,"sp":0.0,"st":0,"bb":[0,0,9,9],"f":[[2033,1390],[914,1427]],"ns":[2,2,3,2]},"sUIButton":{"w":20,"h":20,"ox":10,"oy":10,"sp":0.0,"st":0,"bb":[1,1,18,18],"f":[[939,1390],[961,1390],[983,1390],[1005,1390],[1027,1390],[1049,1390],[1071,1390],[1093,1390]]},"sUICadre":{"w":20,"h":20,"ox":0,"oy":0,"sp":0.0,"st":0,"bb":[0,4,19,19],"f":[[1115,1390],[1137,1390]],"ns":[3,3,3,3]},"sUIClick":{"w":30,"h":48,"ox":15,"oy":32,"sp":0.0,"st":0,"bb":[2,19,27,44],"f":[[1999,2],[2013,397]]},"sUIDealer":{"w":32,"h":32,"ox":16,"oy":16,"sp":0.0,"st":0,"bb":[4,2,27,29],"f":[[360,1390]]},"sUIHeart":{"w":16,"h":16,"ox":2,"oy":3,"sp":30.0,"st":0,"bb":[1,2,13,13],"f":[[1313,1390]]},"sUIOngletsIcon":{"w":20,"h":20,"ox":10,"oy":10,"sp":0.0,"st":0,"bb":[1,1,18,18],"f":[[1159,1390],[1181,1390],[1203,1390],[1225,1390]]},"sUIRollGift":{"w":64,"h":64,"ox":31,"oy":28,"sp":30.0,"st":0,"bb":[22,13,39,35],"f":[[1798,1215]]},"sUIShopClick":{"w":64,"h":64,"ox":34,"oy":30,"sp":30.0,"st":0,"bb":[29,25,40,41],"f":[[1864,1215],[1930,1215]]},"sUIStar_1":{"w":21,"h":35,"ox":9,"oy":3,"sp":30.0,"st":0,"bb":[0,14,20,34],"f":[[1770,1287]]},"suistar":{"w":21,"h":35,"ox":9,"oy":3,"sp":30.0,"st":0,"bb":[0,14,20,34],"f":[[1793,1287]]},"sUITutorialInput":{"w":30,"h":15,"ox":15,"oy":7,"sp":30.0,"st":0,"bb":[1,1,25,12],"f":[[590,1427],[622,1427],[654,1427],[686,1427]]},"sUITutorialInput2":{"w":30,"h":15,"ox":15,"oy":7,"sp":30.0,"st":0,"bb":[1,1,25,12],"f":[[718,1427],[750,1427],[782,1427],[814,1427]]},"sUIUnlock":{"w":12,"h":23,"ox":6,"oy":11,"sp":30.0,"st":0,"bb":[2,1,9,21],"f":[[463,1390]]},"sUIUpgrade":{"w":20,"h":20,"ox":10,"oy":10,"sp":0.0,"st":0,"bb":[0,0,19,19],"f":[[1247,1390],[1269,1390],[1291,1390]]},"sUIUpgradeIcons":{"w":16,"h":16,"ox":8,"oy":8,"sp":0.0,"st":0,"bb":[0,0,15,15],"f":[[1331,1390],[1349,1390],[1367,1390],[1385,1390],[1403,1390],[1421,1390],[1439,1390],[1457,1390],[1475,1390],[1493,1390],[1511,1390],[1529,1390],[1547,1390],[1565,1390],[1583,1390],[1601,1390],[1619,1390],[1637,1390],[1655,1390],[1673,1390],[1691,1390],[1709,1390],[1727,1390],[1745,1390],[1763,1390],[1781,1390],[1799,1390],[1817,1390],[1835,1390],[1853,1390],[1871,1390],[1889,1390],[1907,1390],[1925,1390],[1943,1390],[1961,1390],[1979,1390],[1997,1390],[2015,1390],[2,1427],[20,1427],[38,1427],[56,1427],[74,1427],[92,1427],[110,1427],[128,1427],[146,1427],[164,1427],[182,1427],[200,1427],[218,1427],[236,1427],[254,1427],[272,1427],[290,1427],[308,1427],[326,1427],[344,1427],[362,1427],[380,1427],[398,1427],[416,1427],[434,1427],[452,1427],[470,1427],[488,1427]]},"pt_shape_pixel":{"w":64,"h":64,"ox":32,"oy":32,"sp":0,"st":0,"bb":[0,0,63,63],"f":[[2,1287]]},"pt_shape_disk":{"w":64,"h":64,"ox":32,"oy":32,"sp":0,"st":0,"bb":[0,0,63,63],"f":[[68,1287]]},"pt_shape_square":{"w":64,"h":64,"ox":32,"oy":32,"sp":0,"st":0,"bb":[0,0,63,63],"f":[[134,1287]]},"pt_shape_star":{"w":64,"h":64,"ox":32,"oy":32,"sp":0,"st":0,"bb":[0,0,63,63],"f":[[200,1287]]},"pt_shape_circle":{"w":64,"h":64,"ox":32,"oy":32,"sp":0,"st":0,"bb":[0,0,63,63],"f":[[266,1287]]},"pt_shape_ring":{"w":64,"h":64,"ox":32,"oy":32,"sp":0,"st":0,"bb":[0,0,63,63],"f":[[332,1287]]},"pt_shape_sphere":{"w":64,"h":64,"ox":32,"oy":32,"sp":0,"st":0,"bb":[0,0,63,63],"f":[[398,1287]]},"pt_shape_flare":{"w":64,"h":64,"ox":32,"oy":32,"sp":0,"st":0,"bb":[0,0,63,63],"f":[[464,1287]]},"pt_shape_spark":{"w":64,"h":64,"ox":32,"oy":32,"sp":0,"st":0,"bb":[0,0,63,63],"f":[[530,1287]]},"pt_shape_explosion":{"w":64,"h":64,"ox":32,"oy":32,"sp":0,"st":0,"bb":[0,0,63,63],"f":[[596,1287]]},"pt_shape_cloud":{"w":64,"h":64,"ox":32,"oy":32,"sp":0,"st":0,"bb":[0,0,63,63],"f":[[662,1287]]},"pt_shape_smoke":{"w":64,"h":64,"ox":32,"oy":32,"sp":0,"st":0,"bb":[0,0,63,63],"f":[[728,1287]]},"pt_shape_snow":{"w":64,"h":64,"ox":32,"oy":32,"sp":0,"st":0,"bb":[0,0,63,63],"f":[[794,1287]]},"pt_shape_line":{"w":64,"h":64,"ox":32,"oy":32,"sp":0,"st":0,"bb":[0,0,63,63],"f":[[860,1287]]}}`,
    ),
    white: [956, 1427],
    font: {
      size: 24,
      lineHeight: 35,
      glyphs: {
        32: [2036, 215, 10, 35, 10, 0],
        33: [2042, 579, 4, 35, 6, 0],
        34: [16, 1390, 10, 35, 12, 0],
        35: [2030, 681, 16, 35, 18, 0],
        36: [2, 1353, 12, 35, 14, 0],
        37: [16, 1353, 12, 35, 14, 0],
        38: [30, 1353, 12, 35, 14, 0],
        39: [288, 1390, 4, 35, 6, 0],
        40: [176, 1390, 6, 35, 8, 0],
        41: [184, 1390, 6, 35, 8, 0],
        42: [192, 1390, 6, 35, 10, 2],
        43: [44, 1353, 12, 35, 14, 0],
        44: [294, 1390, 4, 35, 6, 0],
        45: [58, 1353, 12, 35, 14, 0],
        46: [300, 1390, 4, 35, 6, 0],
        47: [72, 1353, 12, 35, 14, 0],
        48: [86, 1353, 12, 35, 14, 0],
        49: [200, 1390, 6, 35, 8, 0],
        50: [100, 1353, 12, 35, 14, 0],
        51: [114, 1353, 12, 35, 14, 0],
        52: [128, 1353, 12, 35, 14, 0],
        53: [142, 1353, 12, 35, 14, 0],
        54: [156, 1353, 12, 35, 14, 0],
        55: [170, 1353, 12, 35, 14, 0],
        56: [184, 1353, 12, 35, 14, 0],
        57: [198, 1353, 12, 35, 14, 0],
        58: [306, 1390, 4, 35, 6, 0],
        59: [312, 1390, 4, 35, 6, 0],
        60: [28, 1390, 10, 35, 12, 0],
        61: [212, 1353, 12, 35, 14, 0],
        62: [40, 1390, 10, 35, 12, 0],
        63: [226, 1353, 12, 35, 14, 0],
        64: [240, 1353, 12, 35, 14, 0],
        65: [254, 1353, 12, 35, 14, 0],
        66: [268, 1353, 12, 35, 14, 0],
        67: [282, 1353, 12, 35, 14, 0],
        68: [296, 1353, 12, 35, 14, 0],
        69: [310, 1353, 12, 35, 14, 0],
        70: [324, 1353, 12, 35, 14, 0],
        71: [338, 1353, 12, 35, 14, 0],
        72: [352, 1353, 12, 35, 14, 0],
        73: [366, 1353, 12, 35, 14, 0],
        74: [380, 1353, 12, 35, 14, 0],
        75: [394, 1353, 12, 35, 14, 0],
        76: [408, 1353, 12, 35, 14, 0],
        77: [422, 1353, 12, 35, 14, 0],
        78: [436, 1353, 12, 35, 14, 0],
        79: [450, 1353, 12, 35, 14, 0],
        80: [464, 1353, 12, 35, 14, 0],
        81: [478, 1353, 12, 35, 14, 0],
        82: [492, 1353, 12, 35, 14, 0],
        83: [506, 1353, 12, 35, 14, 0],
        84: [520, 1353, 12, 35, 14, 0],
        85: [534, 1353, 12, 35, 14, 0],
        86: [548, 1353, 12, 35, 14, 0],
        87: [2030, 783, 16, 35, 18, 0],
        88: [562, 1353, 12, 35, 14, 0],
        89: [576, 1353, 12, 35, 14, 0],
        90: [590, 1353, 12, 35, 14, 0],
        91: [208, 1390, 6, 35, 8, 0],
        92: [604, 1353, 12, 35, 14, 0],
        93: [216, 1390, 6, 35, 8, 0],
        94: [618, 1353, 12, 35, 14, 0],
        95: [632, 1353, 12, 35, 14, 0],
        96: [318, 1390, 4, 35, 6, 0],
        97: [646, 1353, 12, 35, 14, 0],
        98: [660, 1353, 12, 35, 14, 0],
        99: [674, 1353, 12, 35, 14, 0],
        100: [688, 1353, 12, 35, 14, 0],
        101: [702, 1353, 12, 35, 14, 0],
        102: [52, 1390, 10, 35, 12, 0],
        103: [716, 1353, 12, 35, 14, 0],
        104: [730, 1353, 12, 35, 14, 0],
        105: [324, 1390, 4, 35, 6, 0],
        106: [224, 1390, 6, 35, 6, -2],
        107: [744, 1353, 12, 35, 14, 0],
        108: [330, 1390, 4, 35, 6, 0],
        109: [2030, 855, 16, 35, 18, 0],
        110: [758, 1353, 12, 35, 14, 0],
        111: [772, 1353, 12, 35, 14, 0],
        112: [786, 1353, 12, 35, 14, 0],
        113: [800, 1353, 12, 35, 14, 0],
        114: [814, 1353, 12, 35, 14, 0],
        115: [828, 1353, 12, 35, 14, 0],
        116: [136, 1390, 8, 35, 10, 0],
        117: [842, 1353, 12, 35, 14, 0],
        118: [856, 1353, 12, 35, 14, 0],
        119: [2030, 927, 16, 35, 18, 0],
        120: [870, 1353, 12, 35, 14, 0],
        121: [884, 1353, 12, 35, 14, 0],
        122: [898, 1353, 12, 35, 14, 0],
        123: [232, 1390, 6, 35, 8, 0],
        124: [2044, 1287, 2, 35, 4, 0],
        125: [240, 1390, 6, 35, 8, 0],
        126: [912, 1353, 12, 35, 14, 0],
        160: [2045, 397, 1, 35, 10, 0],
        161: [336, 1390, 4, 35, 6, 0],
        162: [926, 1353, 12, 35, 14, 0],
        163: [2031, 2, 14, 35, 16, 0],
        164: [940, 1353, 12, 35, 14, 0],
        165: [954, 1353, 12, 35, 14, 0],
        166: [342, 1390, 4, 35, 6, 0],
        167: [968, 1353, 12, 35, 14, 0],
        168: [64, 1390, 10, 35, 12, 0],
        169: [1816, 1287, 20, 35, 22, 0],
        170: [76, 1390, 10, 35, 12, 0],
        171: [2030, 999, 16, 35, 18, 0],
        172: [982, 1353, 12, 35, 14, 0],
        174: [1838, 1287, 20, 35, 22, 0],
        175: [996, 1353, 12, 35, 14, 0],
        176: [146, 1390, 8, 35, 10, 0],
        177: [1010, 1353, 12, 35, 14, 0],
        178: [88, 1390, 10, 35, 12, 0],
        179: [100, 1390, 10, 35, 12, 0],
        180: [248, 1390, 6, 35, 8, 0],
        181: [1024, 1353, 12, 35, 14, 0],
        182: [1980, 1287, 14, 35, 16, 0],
        183: [348, 1390, 4, 35, 6, 0],
        184: [256, 1390, 6, 35, 8, 0],
        185: [264, 1390, 6, 35, 8, 0],
        186: [112, 1390, 10, 35, 12, 0],
        187: [2030, 1071, 16, 35, 18, 0],
        188: [1882, 1287, 18, 35, 20, 0],
        189: [1902, 1287, 18, 35, 20, 0],
        190: [1922, 1287, 18, 35, 20, 0],
        191: [1038, 1353, 12, 35, 14, 0],
        192: [1052, 1353, 12, 35, 14, 0],
        193: [1066, 1353, 12, 35, 14, 0],
        194: [1080, 1353, 12, 35, 14, 0],
        195: [1094, 1353, 12, 35, 14, 0],
        196: [1108, 1353, 12, 35, 14, 0],
        197: [1122, 1353, 12, 35, 14, 0],
        198: [1942, 1287, 18, 35, 20, 0],
        199: [1136, 1353, 12, 35, 14, 0],
        200: [1150, 1353, 12, 35, 14, 0],
        201: [1164, 1353, 12, 35, 14, 0],
        202: [1178, 1353, 12, 35, 14, 0],
        203: [1192, 1353, 12, 35, 14, 0],
        204: [1206, 1353, 12, 35, 14, 0],
        205: [1220, 1353, 12, 35, 14, 0],
        206: [1234, 1353, 12, 35, 14, 0],
        207: [1248, 1353, 12, 35, 14, 0],
        208: [1996, 1287, 14, 35, 16, 0],
        209: [1262, 1353, 12, 35, 14, 0],
        210: [1276, 1353, 12, 35, 14, 0],
        211: [1290, 1353, 12, 35, 14, 0],
        212: [1304, 1353, 12, 35, 14, 0],
        213: [1318, 1353, 12, 35, 14, 0],
        214: [1332, 1353, 12, 35, 14, 0],
        215: [1346, 1353, 12, 35, 14, 0],
        216: [2030, 1143, 16, 35, 16, -2],
        217: [1360, 1353, 12, 35, 14, 0],
        218: [1374, 1353, 12, 35, 14, 0],
        219: [1388, 1353, 12, 35, 14, 0],
        220: [1402, 1353, 12, 35, 14, 0],
        221: [1416, 1353, 12, 35, 14, 0],
        222: [1430, 1353, 12, 35, 14, 0],
        223: [1444, 1353, 12, 35, 14, 0],
        224: [1458, 1353, 12, 35, 14, 0],
        225: [1472, 1353, 12, 35, 14, 0],
        226: [1486, 1353, 12, 35, 14, 0],
        227: [1500, 1353, 12, 35, 14, 0],
        228: [1514, 1353, 12, 35, 14, 0],
        229: [1528, 1353, 12, 35, 14, 0],
        230: [1860, 1287, 20, 35, 22, 0],
        231: [1542, 1353, 12, 35, 14, 0],
        232: [1556, 1353, 12, 35, 14, 0],
        233: [1570, 1353, 12, 35, 14, 0],
        234: [1584, 1353, 12, 35, 14, 0],
        235: [1598, 1353, 12, 35, 14, 0],
        236: [272, 1390, 6, 35, 6, -2],
        237: [280, 1390, 6, 35, 8, 0],
        238: [156, 1390, 8, 35, 8, -2],
        239: [166, 1390, 8, 35, 8, -2],
        240: [2012, 1287, 14, 35, 16, 0],
        241: [1612, 1353, 12, 35, 14, 0],
        242: [1626, 1353, 12, 35, 14, 0],
        243: [1640, 1353, 12, 35, 14, 0],
        244: [1654, 1353, 12, 35, 14, 0],
        245: [1668, 1353, 12, 35, 14, 0],
        246: [1682, 1353, 12, 35, 14, 0],
        247: [1696, 1353, 12, 35, 14, 0],
        248: [1962, 1287, 16, 35, 16, -2],
        249: [1710, 1353, 12, 35, 14, 0],
        250: [1724, 1353, 12, 35, 14, 0],
        251: [1738, 1353, 12, 35, 14, 0],
        252: [1752, 1353, 12, 35, 14, 0],
        253: [1766, 1353, 12, 35, 14, 0],
        254: [1780, 1353, 12, 35, 14, 0],
        255: [1794, 1353, 12, 35, 14, 0],
        260: [1808, 1353, 12, 35, 14, 0],
        261: [1822, 1353, 12, 35, 14, 0],
        262: [1836, 1353, 12, 35, 14, 0],
        263: [1850, 1353, 12, 35, 14, 0],
        280: [1864, 1353, 12, 35, 14, 0],
        281: [1878, 1353, 12, 35, 14, 0],
        287: [1892, 1353, 12, 35, 14, 0],
        304: [1906, 1353, 12, 35, 14, 0],
        305: [354, 1390, 4, 35, 6, 0],
        321: [2028, 1287, 14, 35, 14, -2],
        322: [124, 1390, 10, 35, 10, -2],
        323: [1920, 1353, 12, 35, 14, 0],
        324: [1934, 1353, 12, 35, 14, 0],
        346: [1948, 1353, 12, 35, 14, 0],
        347: [1962, 1353, 12, 35, 14, 0],
        350: [1976, 1353, 12, 35, 14, 0],
        351: [1990, 1353, 12, 35, 14, 0],
        377: [2004, 1353, 12, 35, 14, 0],
        378: [2018, 1353, 12, 35, 14, 0],
        379: [2032, 1353, 12, 35, 14, 0],
        380: [2, 1390, 12, 35, 14, 0],
      },
    },
  },
  ye = `precision highp float;
uniform sampler2D gm_BaseTexture;
`,
  be = `//
// SittingDuck's Advanced CRT Shader for GameMaker - Version 3.0
//
varying vec2 v_vTexcoord;

uniform vec2 u_content_size;
uniform vec2 u_output_size;
uniform vec2 u_output_offset;

uniform float u_aspect_ratio;
uniform float u_zoom;
uniform float u_curvature;
uniform float u_do_int_scale;
uniform float u_image_softness;
uniform float u_do_tate;
uniform float u_min_sigma;
uniform float u_max_sigma;
uniform float u_line_brightness;
uniform float u_mask_strength;
uniform float u_slot_strength;
uniform float u_mask_do_shadow;
uniform float u_mask_tex_width;
uniform float u_mask_scale;
uniform float u_mask_repeat_on_three;
uniform float u_do_mask_mirror;
uniform float u_mask_fade;
uniform float u_border_width;
uniform float u_border_brightness;
uniform float u_time;
uniform float u_bloom_strength;
uniform float u_deconvergence;
uniform float u_gamma;
uniform float u_do_interlace;

uniform sampler2D u_mask_sampler;
uniform sampler2D u_slot_sampler;
uniform sampler2D u_bloom_sampler;

// Cheap RNG function
float rand(vec2 p) {
    return fract(sin(dot(p, vec2(12.9898,78.233))) * 43758.5453);
}

// Functions to convert a color from linear to either sRGB or an arbitrary gamma
// https://gamedev.stackexchange.com/questions/92015/optimized-linear-to-srgb-glsl
vec4 fromLinear(vec4 linearRGB)
{
	if (u_gamma > 0.0) {
		return vec4(pow(linearRGB.rgb, vec3(1.0/u_gamma)), linearRGB.a);
	} else {
		bvec3 cutoff = lessThan(linearRGB.rgb, vec3(0.0031308));
		vec3 higher = vec3(1.055)*pow(linearRGB.rgb, vec3(1.0/2.4)) - vec3(0.055);
		vec3 lower = linearRGB.rgb * vec3(12.92);
	
		return vec4(mix(higher, lower, vec3(cutoff)), linearRGB.a);
	}
}

vec4 toLinear(vec4 sRGB)
{
    bvec3 cutoff = lessThan(sRGB.rgb, vec3(0.04045));
    vec3 higher = pow((sRGB.rgb + vec3(0.055))/vec3(1.055), vec3(2.4));
    vec3 lower = sRGB.rgb/vec3(12.92);

    return vec4(mix(higher, lower, vec3(cutoff)), sRGB.a);
}

// Function to sample the content with variable sharpness and with simulated beam deconvergence
vec4 sample_image(vec2 uv) {
    // Convert normalized UV to pixel coordinates
    vec2 pixels = uv * u_content_size;
    
    // Calculate the center of the texel containing the current UV
    vec2 nearest_center = floor(pixels) + 0.5;
    
    // Convert back to normalized UV space
    vec2 nearest_uv = nearest_center / u_content_size;
    
    // Lerp  between the snapped center and the original UV
    // 0.0 = Nearest neighbor (sharp)
    // 1.0 = Bilinear (soft)
	uv = mix(nearest_uv, uv, u_image_softness);
	
	// Calculate deconvergence in content pixel units
	vec2 deconvergence = u_deconvergence / u_content_size;
	vec4 final_ = vec4(texture2D(gm_BaseTexture, uv+deconvergence).r, texture2D(gm_BaseTexture, uv).g, texture2D(gm_BaseTexture, uv-deconvergence).b, 1.0);
	
	// If after a dedither / Sonic waterfall blurring behavior, use this instead
	//vec2 hblur = vec2(0.5/u_content_size.x, 0.0);
	//vec4 final_ = mix(texture2D(gm_BaseTexture, uv+hblur), texture2D(gm_BaseTexture, uv-hblur), 0.5);
    return toLinear(final_);
}

// Barrel warp: maps a screen texcoord (0..1, y down) to a content uv.
// The middle of every side lands exactly on the screen edge and the corners curve inwards,
// so the whole bulge is always visible and nothing is pushed off-screen.
vec2 crt_warp(vec2 t) {
    vec2 c = t - 0.5;
    float r2 = dot(c, c);
    return c * ((1.0 + u_curvature * r2) / (1.0 + u_curvature * 0.25)) + 0.5;
}

// Returns the warped uv plus an anti-aliased (~1.5 output px) mask for the curved screen edge
vec4 geometry() {
    vec2 uv = crt_warp(v_vTexcoord);
    vec2 px = min(uv, 1.0 - uv) * u_output_size;
    float edge = clamp(min(px.x, px.y) / 1.5 + 0.5, 0.0, 1.0);
    return vec4(clamp(uv, 0.0, 1.0), edge, 0.0);
}

// Continuous periodic Gaussian, analytically averaged over an output pixel.
// No nearest-line floor/sign selection: all phases, including the equator, agree.
float scanline_sinc(float x) {
    return abs(x) < 0.0001 ? 1.0 - x * x / 6.0 : sin(x) / x;
}
float get_scanline_brightness(vec2 uv, vec2 footprint) {
    float axis_pos = mix(uv.y * u_content_size.y, uv.x * u_content_size.x, u_do_tate);
    float period = mix(1.0, 2.0, u_do_interlace);
    float field = mod(floor(u_time), 2.0) * u_do_interlace;
    float phase = 6.28318530718 * (axis_pos - 0.5 - field) / period;
    float brightness = dot(texture2D(gm_BaseTexture, uv).rgb, vec3(0.299, 0.587, 0.114));
    float sigma = mix(u_min_sigma, u_max_sigma, brightness) / period;
    float total_weight = 1.0;
    for (int i = 1; i <= 4; i++) {
        float harmonic = float(i);
        float coefficient = exp(-19.7392088022 * sigma * sigma * harmonic * harmonic);
        vec2 extent = 3.14159265359 * harmonic * footprint / period;
        total_weight += 2.0 * coefficient * cos(harmonic * phase)
            * scanline_sinc(extent.x) * scanline_sinc(extent.y);
    }
    return clamp(2.50662827463 * sigma * total_weight, 0.0, 1.0) * u_line_brightness;
}

// Function to find the color of the phosphor mask at the given fragment
vec3 get_mask_color(float fadeout) {
	// Mirror the phosphor mask if required by the user
	float mirror = 1.0 - 2.0 * u_do_mask_mirror;
	
	// For the rgbx mask, the user can choose whether they want to drop the black column of pixels
	float repeat = 1.0 - (u_mask_repeat_on_three * 0.25);
	
	// Get from screen space to mask space
	vec2 num_triads = u_output_size / (u_mask_tex_width * u_mask_scale * repeat * mirror);
	vec2 mask_uv = mod(v_vTexcoord, 1.0 / num_triads) * num_triads * repeat;
	vec2 slot_uv = v_vTexcoord * u_output_size / vec2(u_mask_tex_width * 2.0 * repeat, 8.0) / u_mask_scale;
	
	// Convert to shadow mask (stagger) if desired
	mask_uv.x += (floor(mask_uv.y * 2.0 / repeat) / (2.0 * (1.0 + u_mask_repeat_on_three))) * u_mask_do_shadow;
	
	// Rotate the mask if in TATE mode
	mask_uv.xy = (u_do_tate > 0.5) ? mask_uv.yx : mask_uv.xy;
	slot_uv.xy = (u_do_tate > 0.5) ? slot_uv.yx : slot_uv.xy;
	
	// Sample the mask for a color
	vec3 mask_color = texture2D(u_mask_sampler, mask_uv).xyz;
	
	// Subtract the slot mask from the color if desired
	mask_color *= 1.0 - (texture2D(u_slot_sampler, slot_uv).xyz * u_slot_strength);
	
	// Mix between the reduced brightness mask and white, and return
	return mix(vec3(1.0), mask_color, u_mask_strength / max(1e-4, mix(1.0, fadeout, u_mask_fade)));
}

// Function to apply a basic blur to the screen borders
vec3 reflection(vec2 uv, float dist) {
	vec4 color = vec4(0.0);

	// Simple one-pass stochastic blur using 8 samples
	// (It's really just the Kawase upscale kernel, but stretched with distance)
	vec2 texel = 8.0 / u_content_size;
	texel *= dist / u_border_width;
	texel *= rand(uv + vec2(mod(u_time*64.0, 1000.0)));
	vec2 h = texel * 1.0;
	vec2 c = texel * 1.5;
			
	// Diagonals
	color += texture2D( gm_BaseTexture, uv + vec2( -h.x, -h.y)) * 2.0;
	color += texture2D( gm_BaseTexture, uv + vec2( -h.x,  h.y)) * 2.0;
	color += texture2D( gm_BaseTexture, uv + vec2(  h.x, -h.y)) * 2.0;
	color += texture2D( gm_BaseTexture, uv + vec2(  h.x,  h.y)) * 2.0;
	// Cardinals
	color += texture2D( gm_BaseTexture, uv + vec2( 0.0, -c.y));
	color += texture2D( gm_BaseTexture, uv + vec2( 0.0,  c.y));
	color += texture2D( gm_BaseTexture, uv + vec2(  -c.x, 0.0));
	color += texture2D( gm_BaseTexture, uv + vec2(  c.x,  0.0));
	// Reduce the values back down to 0-1
	color /= 12.0;
	
	// Add the result to the output
	return color.xyz * u_border_brightness * 0.1;
}

// Function to sample from the bloom texture
// This is the same dual kawase upscale filter as used in the bloom pre-pass
// We just have to do it one more time here because the final_ bloom texture is half res
vec4 get_bloom(sampler2D sampler, vec2 texCoords) {
	vec2 halfpixel = vec2(1.0/u_content_size) * 0.5;
    vec2 o = halfpixel;

    vec4 color = vec4(0.0);

    // Sample 4 edge centers with 1x weight each
    color += texture2D(sampler, texCoords + vec2(-o.x * 2.0, 0.0));
    color += texture2D(sampler, texCoords + vec2( o.x * 2.0, 0.0));
    color += texture2D(sampler, texCoords + vec2(0.0, -o.y * 2.0));
    color += texture2D(sampler, texCoords + vec2(0.0,  o.y * 2.0));

    // Sample 4 diagonal corners with 2x weight each
    color += texture2D(sampler, texCoords + vec2(-o.x,  o.y)) * 2.0;
    color += texture2D(sampler, texCoords + vec2( o.x,  o.y)) * 2.0;
    color += texture2D(sampler, texCoords + vec2(-o.x, -o.y)) * 2.0;
    color += texture2D(sampler, texCoords + vec2( o.x, -o.y)) * 2.0;

    // Apply bloom strength and normalize by total weight
    return toLinear(color / 12.0);
}

// Function like sqrt() over [0..1], but symmetrical along the y=1-x diagonal
float rational_curve(float x, float c) {
    return (x * (c + 1.0)) / (x * c + 1.0);
}

void main()
{
	// Get the warped UVs and the curved-edge mask
	vec4 bits = geometry();
	vec2 uv = bits.xy;
	float edge = bits.z;

	// Sample the content
	vec4 color = sample_image(uv);

	// Warp-aware pixel footprint on both axes, also valid for rotated scanlines.
    vec2 dx = crt_warp(v_vTexcoord + vec2(0.5 / u_output_size.x, 0.0))
            - crt_warp(v_vTexcoord - vec2(0.5 / u_output_size.x, 0.0));
    vec2 dy = crt_warp(v_vTexcoord + vec2(0.0, 0.5 / u_output_size.y))
            - crt_warp(v_vTexcoord - vec2(0.0, 0.5 / u_output_size.y));
    vec2 footprint = abs(mix(vec2(dx.y, dy.y) * u_content_size.y,
                            vec2(dx.x, dy.x) * u_content_size.x, u_do_tate));
    float scan_lum = get_scanline_brightness(uv, footprint);
	color.rgb *= scan_lum;
	color.rgb *= get_mask_color(scan_lum);

	// Bloom
	if (u_bloom_strength > 0.0) {
		color.rgb = mix(color.rgb, get_bloom(u_bloom_sampler, uv).rgb, 0.1 * u_bloom_strength);
	}

	// Black outside the curved screen
	color.rgb *= edge;

	//gl_FragColor = fromLinear(color);
	
	// Dithering to reduce banding
    vec4 final_output = fromLinear(color);
    
    float n1 = rand(v_vTexcoord + mod(u_time, 100.0));
    float n2 = rand(v_vTexcoord + mod(u_time + 0.5678, 100.0));
    
    float tri_noise = n1 - n2; 

    final_output.rgb += tri_noise / 255.0;
    
    gl_FragColor = final_output;
}
`,
  xe = `varying vec2 v_vTexcoord;

uniform vec2 u_texel_size;

void main() {
    // Dual Kawase downsample: sample center + 4 diagonal corners
    vec2 halfpixel = u_texel_size * 0.5;
    vec2 o = halfpixel;

    // Sample center with 4x weight
    vec4 color = texture2D(gm_BaseTexture, v_vTexcoord) * 4.0;

    // Sample 4 diagonal corners with 1x weight each
    color += texture2D(gm_BaseTexture, v_vTexcoord + vec2(-o.x, -o.y));
    color += texture2D(gm_BaseTexture, v_vTexcoord + vec2( o.x, -o.y));
    color += texture2D(gm_BaseTexture, v_vTexcoord + vec2(-o.x,  o.y));
    color += texture2D(gm_BaseTexture, v_vTexcoord + vec2( o.x,  o.y));

    // Apply normalize by total weight
    gl_FragColor = (color / 8.0);
}
`,
  Se = `varying vec2 v_vTexcoord;

uniform vec2 u_texel_size;

void main() {
    // Dual Kawase upsample: sample 4 edge centers + 4 diagonal corners
    vec2 halfpixel = u_texel_size * 0.5;
    vec2 o = halfpixel;

    vec4 color = vec4(0.0);

    // Sample 4 edge centers with 1x weight each
    color += texture2D(gm_BaseTexture, v_vTexcoord + vec2(-o.x * 2.0, 0.0));
    color += texture2D(gm_BaseTexture, v_vTexcoord + vec2( o.x * 2.0, 0.0));
    color += texture2D(gm_BaseTexture, v_vTexcoord + vec2(0.0, -o.y * 2.0));
    color += texture2D(gm_BaseTexture, v_vTexcoord + vec2(0.0,  o.y * 2.0));

    // Sample 4 diagonal corners with 2x weight each
    color += texture2D(gm_BaseTexture, v_vTexcoord + vec2(-o.x,  o.y)) * 2.0;
    color += texture2D(gm_BaseTexture, v_vTexcoord + vec2( o.x,  o.y)) * 2.0;
    color += texture2D(gm_BaseTexture, v_vTexcoord + vec2(-o.x, -o.y)) * 2.0;
    color += texture2D(gm_BaseTexture, v_vTexcoord + vec2( o.x, -o.y)) * 2.0;

    // Apply normalize by total weight
    gl_FragColor = (color / 12.0);
}
`,
  Ce = `//
// Simple passthrough fragment shader
//
varying vec2 v_vTexcoord;
varying vec4 v_vColour;

uniform float gm_pPreMultiplyAlpha;
uniform vec2 gm_pSurfaceDimensions;
uniform float g_DisplacementX;
uniform float g_DisplacementY;
uniform float g_Opacity;
uniform vec4 g_Colour;

void main()
{
	vec4 texcol = texture2D( gm_BaseTexture, v_vTexcoord );
	
	vec2 offset = vec2(-g_DisplacementX / gm_pSurfaceDimensions.x, -g_DisplacementY / gm_pSurfaceDimensions.y);
	vec2 v_vTexcoordShadow = v_vTexcoord + offset;
	
	float shadowalpha = texture2D( gm_BaseTexture, v_vTexcoordShadow ).a;	
	vec4 shadowcol = vec4(g_Colour.r, g_Colour.g, g_Colour.b, shadowalpha * g_Opacity);	

	if (gm_pPreMultiplyAlpha != 0.0)
	{
		texcol.a = clamp(texcol.a, 0.001, 1.0);	// need to do this to prevent NaNs
		texcol.rgb /= texcol.a;				
	}
	
	// Combine texture and shadow	
	vec4 finalcol;	
	finalcol.rgb = ((shadowcol.rgb * shadowcol.a) * (1.0 - texcol.a)) + texcol.rgb;		
	finalcol.a = shadowcol.a + ((1.0 - shadowcol.a) * texcol.a);
	
    gl_FragColor = v_vColour * finalcol;
}
`,
  we = `/*
	"Outline" by Xor

	Sample the alpha channel 3 units in all directions.
	If the largest alpha within the radius is above a threshold,
	use the "g_OutlineColour".

	The pixel scale can be adjusted with "g_OutlinePixelScale".
*/


//Texel size for offset calculations
uniform vec2 gm_pSurfaceTexelSize;

//Outline colour (and alpha)
uniform vec4 g_OutlineColour;
//Outline radius in pixels
uniform float g_OutlineRadius;
//Pixel scale (useful for pixel art)
uniform float g_OutlinePixelScale;

varying vec2 v_vTexcoord;
varying vec4 v_vColour;

//Max number of samples in each direction
#define MAX_RADIUS 3.0
//Total samples = sqr(RADIUS*2+1)
//In this case, 49 samples (+1 base sample) which seems acceptable

//Alpha threshold for outline
#define THRESHOLD 0.0

void main()
{
	//Base colour for overlaying
	vec4 base_colour = texture2D(gm_BaseTexture, v_vTexcoord);

	//Outline total alpha
	float outline = 0.0;

	//Compute the radius squared
	float radius_sqr = g_OutlineRadius * g_OutlineRadius;

	//Look through all the samples
	for(float x = -MAX_RADIUS; x <= MAX_RADIUS; x++)
	for(float y = -MAX_RADIUS; y <= MAX_RADIUS; y++)
	{
		//Skip samples outside radius
		if (x*x + y*y > radius_sqr) continue;

		//Compute sample offset in pixels
		vec2 offset = vec2(x,y) * g_OutlinePixelScale;
		//Compute sample coordinates
		vec2 coord = v_vTexcoord + offset * gm_pSurfaceTexelSize;
		//Sample texture
		vec4 samp = texture2D(gm_BaseTexture, coord);

		//Store the largest alpha sample
		outline = max(outline, samp.a);
	}
	//Set outline colour and alpha
	vec4 colour = g_OutlineColour * float(outline > THRESHOLD);
	//Blend with base colour
	colour = mix(colour, base_colour, base_colour.a>THRESHOLD ? outline: 0.0);

	//Output result
	gl_FragColor = v_vColour * colour;
}
`,
  Te = `//
// Simple passthrough fragment shader
//
varying vec2 v_vTexcoord;
varying vec4 v_vColour;

uniform vec2 gm_pSurfaceDimensions;
uniform float gm_pPreMultiplyAlpha;
uniform vec2 gm_pSurfaceTexelSize;
uniform vec2 gm_pCamOffset;
uniform float gm_pTime;

uniform sampler2D g_DistortTexture;
//uniform vec2 g_DistortTextureDimensions;
uniform vec2 g_DistortTextureTexelSize;
uniform float g_Distort1Speed;
uniform float g_Distort2Speed;
uniform vec2 g_Distort1Scale;
uniform vec2 g_Distort2Scale;
uniform float g_Distort1Amount;
uniform float g_Distort2Amount;
uniform float g_ChromaSpreadAmount;
uniform float g_CamOffsetScale;
uniform vec4 g_GlintCol;
uniform vec4 g_TintCol;
uniform vec4 g_AddCol;

void main()
{
	// Using the reciprocal of the scale values is more intuitive for the user
	vec2 rcpDistort1Scale = vec2(1.0 / g_Distort1Scale.x, 1.0 / g_Distort1Scale.y);
	vec2 rcpDistort2Scale = vec2(1.0 / g_Distort2Scale.x, 1.0 / g_Distort2Scale.y);
	
	vec2 noise1coord = ((v_vTexcoord * gm_pSurfaceDimensions) * g_DistortTextureTexelSize) * rcpDistort1Scale;
	vec2 noise2coord = ((v_vTexcoord * gm_pSurfaceDimensions) * g_DistortTextureTexelSize) * rcpDistort2Scale;	
	noise1coord.y += g_Distort1Speed;
	noise2coord.y += g_Distort2Speed;	
	
	noise1coord += (gm_pCamOffset * g_DistortTextureTexelSize) * rcpDistort1Scale * g_CamOffsetScale;	
	noise2coord += (gm_pCamOffset * g_DistortTextureTexelSize) * rcpDistort2Scale * g_CamOffsetScale;
	
	vec4 noise1col = texture2D( g_DistortTexture, noise1coord );
	vec4 noise2col = texture2D( g_DistortTexture, noise2coord );	
	noise1col -= 0.5;
	noise2col -= 0.5;	
	
	vec4 blendednoisecol = (noise1col * g_Distort1Amount) + (noise2col * g_Distort2Amount);	
	
	vec4 tempcol = blendednoisecol / ((g_Distort1Amount + g_Distort2Amount) * 0.5);	
	float colscale = dot(tempcol.rg, tempcol.rg);
	colscale *= 0.70711;
	colscale *= colscale;
	colscale *= colscale;	
	
	vec2 sampleoffset = blendednoisecol.xy * gm_pSurfaceTexelSize;
	vec2 sampleoffset_r = sampleoffset * (1.0 + g_ChromaSpreadAmount);
	vec2 sampleoffset_g = sampleoffset * (1.0 + (g_ChromaSpreadAmount * 0.5));
	vec2 sampleoffset_b = sampleoffset * 1.0;
	
	vec4 wobbledcol;
	wobbledcol.r = texture2D( gm_BaseTexture, v_vTexcoord + sampleoffset_r ).r;
	wobbledcol.g = texture2D( gm_BaseTexture, v_vTexcoord + sampleoffset_g ).g;
	wobbledcol.b = texture2D( gm_BaseTexture, v_vTexcoord + sampleoffset_b ).b;
	wobbledcol.a = texture2D( gm_BaseTexture, v_vTexcoord + sampleoffset_r ).a;

	float colmul = 1.0;
	if (gm_pPreMultiplyAlpha > 0.0)
	{
		colmul = wobbledcol.a;
	}
	
	wobbledcol.rgb += vec3(colscale, colscale, colscale) * (g_GlintCol.rgb * colmul);
	wobbledcol.rgb *= g_TintCol.rgb;
	wobbledcol.rgb += (g_AddCol.rgb * colmul);
	    
	gl_FragColor = v_vColour * wobbledcol;
}
`,
  Ee = `/*
	"Disk Glow" by Xor

	Performs a weighted blur in a disk radius.
	This uses a fibonacci disk to space out samples, decreasing sample weight with sample radius.
	It also uses an exponential falloff function for weighting brighter samples over darker samples.
*/
varying vec2 v_vTexcoord;
varying vec4 v_vColour;

//Get surface texel size for sample scale
uniform vec2 gm_pSurfaceTexelSize;

//Radius for blur disk
uniform float g_GlowRadius;
//Gamma exponent for boosting brightness
uniform float g_GlowGamma;

//Number of samples for blur
//36 seems adequate for balance between quality and performance
#define SAMPLES 36
//Radius multiplier based off of samples.
//Should follow this forumla: 1.0 / sqrt(SAMPLES)
//In this case: 1.0 / 6.0 or 1.66...
#define RADIUS 0.1666667

void main()
{
	//Sample total for averaging (numerator)
	vec4 sample_total = vec4(0.0, 0.0, 0.0, 0.0);
	//Weight total for averaging (denominator)
	vec4 weight_total = vec4(0.0, 0.0, 0.0, 0.0);
	//Golden angle rotation matrix (for well distributed samples)
	mat2 golden_angle = mat2(-0.7373688, -0.6754904, 0.6754904,  -0.7373688);

	//Used for iterated radius
	float radius = 1.0;
	//Starting sample point (scaled to match radius)
	vec2 pnt = vec2(RADIUS,0) * g_GlowRadius;
	//Iterate through samples
	for(int i = 0; i<SAMPLES; i++)
	{
		//Increase radius (approximation for sqrt(i+2))
		radius += 1.0 / radius;
		//Rotate sample point
		pnt *= golden_angle;

		//Compute new sample coordinates
		vec2 coord = v_vTexcoord + pnt * (radius-1.0) * gm_pSurfaceTexelSize;
		//Sample texture
		vec4 samp = texture2D(gm_BaseTexture, coord);
		//Compute weight from brightness gamma and radius falloff
		vec4 weight = exp(samp * g_GlowGamma) / radius;
		//Add sample and weight totals
		sample_total += samp * weight;
		weight_total += weight;
	}

	//Compute color from weighted average
	vec4 colour = sample_total / weight_total;
	//Factor in "v_vColour"
    gl_FragColor = v_vColour * colour;
}
`,
  De = 480;
function Oe(e, t, n, r = { l: 0, r: 0, t: 0, b: 0 }) {
  let i = r.l * n,
    a = r.r * n,
    o = Math.max(r.t, r.b) * n,
    s = o,
    c = Math.max(1, e - i - a),
    l = Math.max(1, t - o - s),
    u = Math.round((180 * c) / l);
  ((u = Math.max(320, Math.min(De, u))), u % 2 && u++);
  let d = 0 * n,
    f = Math.max(
      0.01,
      Math.min((c / u) * 1, (l / 180) * 1, (c - 2 * d) / u, (l - 2 * d) / 180),
    ),
    p = Math.floor(u * f),
    m = Math.floor(180 * f),
    h = Math.floor(i + (c - p) / 2),
    g = Math.floor(s + (l - m) / 2);
  return { appW: u, s: f, outW: p, outH: m, outX: h, outY: g };
}
function ke() {
  return { l: 0, r: 0, t: 0, b: 0 };
}
var Ae = ve,
  je = {
    normal: 0,
    metallic: 1,
    gold: 2,
    holo: 3,
    negative: 4,
    glitched: 5,
    plastic: 6,
    solid: 7,
    module: 8,
  };
function Me(e) {
  switch (e) {
    case 1:
      return je.metallic;
    case 2:
      return je.gold;
    case 3:
      return je.holo;
    case 4:
      return je.negative;
    case 5:
      return je.glitched;
    default:
      return je.normal;
  }
}
var Ne = `#version 300 es
in vec2 a_pos; in vec2 a_uv; in vec2 a_luv; in vec4 a_col; in vec2 a_extra;
uniform vec2 u_room; uniform vec2 u_view; uniform float u_flip;
out vec2 v_uv; out vec2 v_luv; out vec4 v_col; out float v_mode; out float v_angle;
void main(){
  vec2 p = (a_pos - u_view) / u_room;
  gl_Position = vec4(p.x*2.0-1.0, u_flip*(1.0-p.y*2.0), 0.0, 1.0);
  v_uv=a_uv; v_luv=a_luv; v_col=a_col; v_mode=a_extra.x; v_angle=a_extra.y;
}`,
  Pe = `#version 300 es
precision highp float;
in vec2 v_uv; in vec2 v_luv; in vec4 v_col; in float v_mode; in float v_angle;
uniform sampler2D u_tex; uniform float u_time; uniform vec2 u_texel;
out vec4 o;
vec2 rotuv(vec2 uv, float a){ float r=radians(a); mat2 m=mat2(cos(r),-sin(r),sin(r),cos(r)); return m*(uv-0.5)+0.5; }
void main(){
  vec4 base = texture(u_tex, v_uv);
  int mode = int(v_mode + 0.5);
  // The original shaders work in texture-page coordinates (v_vTexcoord on a 2048² page);
  // the atlas is also 2048², so v_uv reproduces their band sizes and sweep speeds.
  vec2 uv = v_uv;
  if (mode == 0) { o = base * v_col; return; }
  if (mode == 7) { o = vec4(v_col.rgb, base.a * v_col.a); return; }
  if (mode == 1 || mode == 8) {
    // shMetallic (greyscale) / shModule (keeps colours, u_time never set -> 0)
    if (base.a <= 0.01) discard;
    float t = mode == 1 ? u_time : 0.0;
    float lum = dot(base.rgb, vec3(0.299,0.587,0.114));
    vec3 col = base.rgb;
    if (mode == 1) { lum = pow(lum, 0.9); col = vec3(lum); }
    col += sin(uv.y * 1200.0) * 0.06;
    float sweep = fract(t * 0.1);
    float hl = pow(clamp(1.0 - abs(uv.x - sweep) * 6.0, 0.0, 1.0), 4.0);
    col += hl * 0.65;
    float an = pow(sin((uv.x + uv.y*0.2 + t*0.3)*25.0)*0.5+0.5, 6.0);
    col += an * 0.25;
    col = clamp(mix(col*0.75, col*1.4, lum), 0.0, 1.0);
    o = vec4(col, base.a) * v_col; return;
  }
  if (mode == 2) {
    // shGold
    vec3 gold = vec3(1.0, 0.84, 0.0);
    float b = dot(base.rgb, vec3(0.299,0.587,0.114));
    vec3 g = mix(gold*0.6, gold*1.1, b*0.8);
    float shine = pow(sin((uv.y + u_time*0.8)*10.0)*0.5+0.5, 15.0);
    o = vec4(g + shine, base.a) * v_col; return;
  }
  if (mode == 3) {
    // shHolo: u_angle = image_angle, u_time is never set (0); ignores the draw colour
    vec2 r = rotuv(uv, v_angle);
    float wave = sin(r.y*10.0)*0.5+0.5;
    vec3 rb = vec3(sin(wave*6.283)*0.5+0.5, sin(wave*6.283+2.094)*0.5+0.5, sin(wave*6.283+4.188)*0.5+0.5);
    o = vec4(mix(base.rgb, rb, 0.6), base.a); return;
  }
  if (mode == 4) {
    // shNegative: neither u_angle nor u_time is set, so the silver filet is fixed on the page
    float shine = pow(sin((uv.x + uv.y)*10.0)*0.5+0.5, 50.0);
    o = vec4(vec3(1.0) - base.rgb + vec3(0.8,0.85,1.0)*shine, base.a); return;
  }
  if (mode == 5) {
    // shSpectral
    float line = floor(uv.y * 60.0);
    float glitch = fract(sin(line + floor(u_time * 6.0)) * 43758.5453123);
    vec2 suv = vec2(clamp(uv.x + (glitch - 0.5) * 0.015, 0.002, 0.998), uv.y);
    vec4 sb = texture(u_tex, suv);
    float rr = texture(u_tex, suv + vec2(0.0015, 0.0)).r;
    float bb = texture(u_tex, suv - vec2(0.0015, 0.0)).b;
    vec3 c = vec3(rr, sb.g, bb) - sin(suv.y * 500.0 + u_time * 8.0) * 0.02;
    o = vec4(c, sb.a) * v_col; return;
  }
  if (mode == 6) {
    // shPlastic: local sprite coordinates are the closest match to a lone sprite page
    vec2 dir = vec2(cos(v_angle), sin(v_angle));
    float sp = dot(v_luv - 0.5, dir);
    float shine = smoothstep(-0.05, 0.0, sp) - smoothstep(0.0, 0.05, sp);
    o = vec4(base.rgb + shine*0.1, base.a); return;
  }
  o = base * v_col;
}`,
  Fe = `attribute vec2 a_p; uniform float u_flip; varying vec2 v_vTexcoord; varying vec4 v_vColour;
void main(){ v_vTexcoord = a_p; v_vColour = vec4(1.0); gl_Position = vec4(a_p.x*2.0-1.0, u_flip*(1.0-a_p.y*2.0), 0.0, 1.0); }`,
  Ie = `varying vec2 v_vTexcoord; uniform vec4 u_col;
void main(){ gl_FragColor = texture2D(gm_BaseTexture, v_vTexcoord) * u_col; }`,
  Le = `varying vec2 v_vTexcoord; uniform vec2 g_VignetteEdges; uniform float g_VignetteSharpness;
void main(){
  vec2 center = abs(v_vTexcoord - 0.5) * 2.0;
  vec2 coord = pow(center, vec2(g_VignetteSharpness));
  float vignette = pow(length(coord), 1.0 / g_VignetteSharpness);
  vignette = max((vignette-g_VignetteEdges.x) / (g_VignetteEdges.y-g_VignetteEdges.x), 0.0);
  gl_FragColor = vec4(0.0, 0.0, 0.0, min(vignette, 1.0));
}`,
  Re = 12,
  ze = 6e3;
function ctpWarp(e, t, n) {
  let r = e - 0.5,
    i = t - 0.5,
    a = (1 + n * (r * r + i * i)) / (1 + n * 0.25);
  return [r * a + 0.5, i * a + 0.5];
}
function Be(e, t = 1) {
  return {
    // Bulge slider 0..10 (t = bulge / 5). 0.3 at the default pulls the corners in a few tens of
    // pixels while the middle of each side still touches the screen edge.
    curvature: e > 0 ? 0.3 * t : 0,
    deconvergence: 0.1 * e,
    softness: 0.25 * e,
    brightness: 1 + e * 0.6,
    bloom: 0.05 * e,
    mask: 0.5 * e,
  };
}
var Ve = class {
  gl;
  canvas;
  prog;
  buf;
  vbo;
  vao;
  quadVbo;
  quads = 0;
  tex = null;
  fxTex = {};
  ready = !1;
  uView;
  uTime;
  uRoom;
  uFlip;
  viewX = 0;
  viewY = 0;
  time = 0;
  frames = 0;
  appW = 320;
  padX = 0;
  outX = 0;
  outY = 0;
  outW = 1;
  outH = 1;
  dpr = 1;
  scale = 1;
  offX = 0;
  offY = 0;
  tgtH = 180;
  tgtScale = 1;
  tgtOffX = 0;
  tgtOffY = 0;
  toFbo = !1;
  app = null;
  temp = null;
  temp2 = null;
  layers = new Map();
  bloom = [];
  progs = {};
  blendMode = `normal`;
  curv = 0;
  gui = null;
  guiActive = !1;
  constructor(e) {
    this.canvas = e;
    let t = e.getContext(`webgl2`, {
      alpha: !1,
      antialias: !1,
      premultipliedAlpha: !1,
      preserveDrawingBuffer: !1,
    });
    if (!t) throw Error(`WebGL2 is not available on this device`);
    this.gl = t;
    let n = this.link(Ne, Pe);
    ((this.prog = n),
      t.useProgram(n),
      (this.buf = new Float32Array(ze * 6 * Re)),
      (this.vao = t.createVertexArray()),
      t.bindVertexArray(this.vao),
      (this.vbo = t.createBuffer()),
      t.bindBuffer(t.ARRAY_BUFFER, this.vbo),
      t.bufferData(t.ARRAY_BUFFER, this.buf.byteLength, t.DYNAMIC_DRAW));
    let r = (e, r, i) => {
      let a = t.getAttribLocation(n, e);
      (t.enableVertexAttribArray(a),
        t.vertexAttribPointer(a, r, t.FLOAT, !1, 48, i * 4));
    };
    (r(`a_pos`, 2, 0),
      r(`a_uv`, 2, 2),
      r(`a_luv`, 2, 4),
      r(`a_col`, 4, 6),
      r(`a_extra`, 2, 10),
      t.bindVertexArray(null),
      t.uniform2f(t.getUniformLocation(n, `u_texel`), 1 / Ae.w, 1 / Ae.h),
      t.uniform1i(t.getUniformLocation(n, `u_tex`), 0),
      (this.uView = t.getUniformLocation(n, `u_view`)),
      (this.uTime = t.getUniformLocation(n, `u_time`)),
      (this.uRoom = t.getUniformLocation(n, `u_room`)),
      (this.uFlip = t.getUniformLocation(n, `u_flip`)),
      (this.quadVbo = t.createBuffer()),
      t.bindBuffer(t.ARRAY_BUFFER, this.quadVbo),
      t.bufferData(
        t.ARRAY_BUFFER,
        new Float32Array([0, 0, 1, 0, 0, 1, 0, 1, 1, 0, 1, 1]),
        t.STATIC_DRAW,
      ),
      t.enable(t.BLEND),
      this.setBlendDefault());
    let i = (e, n, r) => {
      let i = this.link(Fe, ye + n),
        a = {};
      for (let e of [`u_flip`, `gm_BaseTexture`, ...r])
        a[e] = t.getUniformLocation(i, e);
      this.progs[e] = { p: i, u: a };
    };
    (i(`copy`, Ie, [`u_col`]),
      i(`shadow`, Ce, [
        `gm_pPreMultiplyAlpha`,
        `gm_pSurfaceDimensions`,
        `g_DisplacementX`,
        `g_DisplacementY`,
        `g_Opacity`,
        `g_Colour`,
      ]),
      i(`outline`, we, [
        `gm_pSurfaceTexelSize`,
        `g_OutlineColour`,
        `g_OutlineRadius`,
        `g_OutlinePixelScale`,
      ]),
      i(`underwater`, Te, [
        `gm_pSurfaceDimensions`,
        `gm_pPreMultiplyAlpha`,
        `gm_pSurfaceTexelSize`,
        `gm_pCamOffset`,
        `g_DistortTexture`,
        `g_DistortTextureTexelSize`,
        `g_Distort1Speed`,
        `g_Distort2Speed`,
        `g_Distort1Scale`,
        `g_Distort2Scale`,
        `g_Distort1Amount`,
        `g_Distort2Amount`,
        `g_ChromaSpreadAmount`,
        `g_CamOffsetScale`,
        `g_GlintCol`,
        `g_TintCol`,
        `g_AddCol`,
      ]),
      i(`vignette`, Le, [`g_VignetteEdges`, `g_VignetteSharpness`]),
      i(
        `warp`,
        `varying vec2 v_vTexcoord; uniform float u_curvature; uniform vec2 u_output_size;
vec2 crt_warp(vec2 t){ vec2 c = t - 0.5; return c * ((1.0 + u_curvature * dot(c, c)) / (1.0 + u_curvature * 0.25)) + 0.5; }
void main(){
  vec2 uv = crt_warp(v_vTexcoord);
  vec2 px = min(uv, 1.0 - uv) * u_output_size;
  float edge = clamp(min(px.x, px.y) / 1.5 + 0.5, 0.0, 1.0);
  gl_FragColor = texture2D(gm_BaseTexture, clamp(uv, 0.0, 1.0)) * edge;
}`,
        [`u_curvature`, `u_output_size`],
      ),
      i(`glow`, Ee, [`gm_pSurfaceTexelSize`, `g_GlowRadius`, `g_GlowGamma`]),
      i(`bloomDown`, xe, [`u_texel_size`]),
      i(`bloomUp`, Se, [`u_texel_size`]),
      i(
        `crt`,
        be,
        `u_content_size.u_output_size.u_output_offset.u_aspect_ratio.u_zoom.u_curvature.u_do_int_scale.u_image_softness.u_do_tate.u_min_sigma.u_max_sigma.u_line_brightness.u_mask_strength.u_slot_strength.u_mask_do_shadow.u_mask_tex_width.u_mask_scale.u_mask_repeat_on_three.u_do_mask_mirror.u_mask_fade.u_border_width.u_border_brightness.u_time.u_bloom_strength.u_deconvergence.u_gamma.u_do_interlace.u_mask_sampler.u_slot_sampler.u_bloom_sampler`.split(
          `.`,
        ),
      ));
  }
  link(e, t) {
    let n = this.gl,
      r = (e, t) => {
        let r = n.createShader(e);
        if (
          (n.shaderSource(r, t),
          n.compileShader(r),
          !n.getShaderParameter(r, n.COMPILE_STATUS))
        )
          throw Error(n.getShaderInfoLog(r) || `shader`);
        return r;
      },
      i = n.createProgram();
    if (
      (n.attachShader(i, r(n.VERTEX_SHADER, e)),
      n.attachShader(i, r(n.FRAGMENT_SHADER, t)),
      n.bindAttribLocation(i, 0, `a_p`),
      n.linkProgram(i),
      !n.getProgramParameter(i, n.LINK_STATUS))
    )
      throw Error(n.getProgramInfoLog(i) || `link`);
    return i;
  }
  setBlendDefault() {
    let e = this.gl;
    (e.blendEquation(e.FUNC_ADD),
      e.blendFuncSeparate(
        e.SRC_ALPHA,
        e.ONE_MINUS_SRC_ALPHA,
        e.ONE,
        e.ONE_MINUS_SRC_ALPHA,
      ));
  }
  setBlend(e) {
    if (e === this.blendMode) return;
    (this.flush(), (this.blendMode = e));
    let t = this.gl;
    e === `add`
      ? t.blendFuncSeparate(t.SRC_ALPHA, t.ONE, t.ONE, t.ONE_MINUS_SRC_ALPHA)
      : this.setBlendDefault();
  }
  loadImage(e) {
    let t = new Image();
    return (
      (t.crossOrigin = `anonymous`),
      (t.src = e),
      t.decode().then(() => t)
    );
  }
  makeTex(e, t, n, r, i) {
    let a = this.gl,
      o = a.createTexture();
    return (
      a.bindTexture(a.TEXTURE_2D, o),
      e
        ? a.texImage2D(a.TEXTURE_2D, 0, a.RGBA, a.RGBA, a.UNSIGNED_BYTE, e)
        : a.texImage2D(
            a.TEXTURE_2D,
            0,
            a.RGBA,
            t,
            n,
            0,
            a.RGBA,
            a.UNSIGNED_BYTE,
            null,
          ),
      a.texParameteri(a.TEXTURE_2D, a.TEXTURE_MIN_FILTER, r),
      a.texParameteri(a.TEXTURE_2D, a.TEXTURE_MAG_FILTER, r),
      a.texParameteri(a.TEXTURE_2D, a.TEXTURE_WRAP_S, i),
      a.texParameteri(a.TEXTURE_2D, a.TEXTURE_WRAP_T, i),
      o
    );
  }
  async loadSprites(e, t, n = {}) {
    let r = this.gl,
      i = this.makeTex(null, Ae.w, Ae.h, r.NEAREST, r.CLAMP_TO_EDGE);
    (r.bindTexture(r.TEXTURE_2D, i),
      r.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL, !1),
      r.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL, r.NONE));
    let a = { premultiplyAlpha: `none`, colorSpaceConversion: `none` },
      o = [];
    for (let [t, n] of Object.entries(Ae.sprites))
      n.f.forEach(([s, c], l) => {
        o.push(
          this.loadImage(`${e}/sprites/${t}_${l}.png`).then(async (e) => {
            let t = e;
            (n.tw &&
              n.th &&
              (n.tw !== e.width || n.th !== e.height) &&
              (t = await createImageBitmap(e, {
                ...a,
                resizeWidth: n.tw,
                resizeHeight: n.th,
                resizeQuality: `high`,
              })),
              r.bindTexture(r.TEXTURE_2D, i),
              r.texSubImage2D(
                r.TEXTURE_2D,
                0,
                s,
                c,
                r.RGBA,
                r.UNSIGNED_BYTE,
                t,
              ));
          }),
        );
      });
    (o.push(
      this.loadImage(`${e}/fonts/fontBase.png`).then(async (e) => {
        await Promise.all(
          Object.entries(Ae.font.glyphs).map(async ([n, o]) => {
            let [s, c, l, u] = o,
              d = t[n];
            if (!d || l <= 0 || u <= 0) return;
            let f = await createImageBitmap(e, d[0], d[1], l, u, a);
            (r.bindTexture(r.TEXTURE_2D, i),
              r.texSubImage2D(
                r.TEXTURE_2D,
                0,
                s,
                c,
                r.RGBA,
                r.UNSIGNED_BYTE,
                f,
              ));
          }),
        );
      }),
    ),
      await Promise.all(o),
      r.bindTexture(r.TEXTURE_2D, i),
      r.texSubImage2D(
        r.TEXTURE_2D,
        0,
        Ae.white[0],
        Ae.white[1],
        4,
        4,
        r.RGBA,
        r.UNSIGNED_BYTE,
        new Uint8Array(64).fill(255),
      ),
      (this.tex = i));
    let s = Object.keys(n),
      c = await Promise.all(s.map((e) => this.loadImage(n[e])));
    (s.forEach((e, t) => {
      this.fxTex[e] = this.makeTex(
        c[t],
        0,
        0,
        e === `underwater` || e === `heathaze` ? r.LINEAR : r.NEAREST,
        r.REPEAT,
      );
    }),
      (this.ready = !0));
  }
  async loadAtlas(e, t = {}) {
    let n = this.gl,
      r = fetch(e)
        .then((e) => {
          if (!e.ok) throw Error(`sprite sheet ${e.status}`);
          return e.blob();
        })
        .then((e) =>
          createImageBitmap(e, {
            premultiplyAlpha: `none`,
            colorSpaceConversion: `none`,
          }),
        ),
      [i, ...a] = await Promise.all([
        r,
        ...Object.values(t).map((e) => this.loadImage(e)),
      ]);
    (n.pixelStorei(n.UNPACK_PREMULTIPLY_ALPHA_WEBGL, !1),
      n.pixelStorei(n.UNPACK_COLORSPACE_CONVERSION_WEBGL, n.NONE),
      (this.tex = this.makeTex(i, 0, 0, n.NEAREST, n.CLAMP_TO_EDGE)),
      Object.keys(t).forEach((e, t) => {
        this.fxTex[e] = this.makeTex(
          a[t],
          0,
          0,
          e === `underwater` || e === `heathaze` ? n.LINEAR : n.NEAREST,
          n.REPEAT,
        );
      }),
      (this.ready = !0));
  }
  target(e, t, n) {
    let r = this.gl,
      i = this.makeTex(null, e, t, n ? r.LINEAR : r.NEAREST, r.CLAMP_TO_EDGE),
      a = r.createFramebuffer();
    return (
      r.bindFramebuffer(r.FRAMEBUFFER, a),
      r.framebufferTexture2D(
        r.FRAMEBUFFER,
        r.COLOR_ATTACHMENT0,
        r.TEXTURE_2D,
        i,
        0,
      ),
      r.bindFramebuffer(r.FRAMEBUFFER, null),
      { fb: a, tex: i, w: e, h: t }
    );
  }
  freeTarget(e) {
    e && (this.gl.deleteFramebuffer(e.fb), this.gl.deleteTexture(e.tex));
  }
  resize() {
    let e = Math.min(window.devicePixelRatio || 1, 3),
      t = this.canvas.clientWidth,
      n = this.canvas.clientHeight,
      r = Math.max(1, Math.round(t * e)),
      i = Math.max(1, Math.round(n * e));
    ((this.canvas.width !== r || this.canvas.height !== i) &&
      ((this.canvas.width = r), (this.canvas.height = i)),
      (this.dpr = e));
    let a = Oe(r, i, e, ke()),
      o = a.appW,
      s = a.s;
    if (
      ((this.outW = a.outW),
      (this.outH = a.outH),
      (this.outX = a.outX),
      (this.outY = a.outY),
      (this.scale = s),
      (this.offX = this.outX + ((o - 320) / 2) * s),
      (this.offY = this.outY),
      o !== this.appW || !this.app)
    ) {
      ((this.appW = o),
        (this.padX = (o - 320) / 2),
        this.freeTarget(this.app),
        this.freeTarget(this.temp),
        this.freeTarget(this.temp2));
      for (let e of this.layers.values()) this.freeTarget(e);
      for (let e of this.bloom) this.freeTarget(e);
      (this.layers.clear(),
        (this.app = this.target(o, 180, !0)),
        (this.temp = this.target(o, 180, !0)),
        (this.temp2 = this.target(o, 180, !0)),
        (this.bloom = [1, 2, 3].map((e) =>
          this.target(
            Math.max(1, Math.floor(o / 2 ** e)),
            Math.max(1, Math.floor(180 / 2 ** e)),
            !0,
          ),
        )));
    }
  }
  toRoom(e, t) {
    let n = this.canvas.getBoundingClientRect(),
      r = (e - n.left) * this.dpr,
      i = (t - n.top) * this.dpr;
    let a = ctpWarp((r - this.outX) / this.outW, (i - this.outY) / this.outH, this.curv);
    return { x: a[0] * this.appW - this.padX, y: a[1] * 180 };
  }
  get viewLeft() {
    return -this.padX;
  }
  get viewRight() {
    return 320 + this.padX;
  }
  bindTarget(e) {
    let t = this.gl;
    (this.flush(),
      e
        ? (t.bindFramebuffer(t.FRAMEBUFFER, e.fb),
          t.viewport(0, 0, e.w, e.h),
          (this.toFbo = !0),
          (this.tgtH = e.h),
          (this.tgtScale = 1),
          (this.tgtOffX = 0),
          (this.tgtOffY = 0))
        : (t.bindFramebuffer(t.FRAMEBUFFER, null),
          t.viewport(this.outX, this.outY, this.outW, this.outH),
          (this.toFbo = !1),
          (this.tgtH = this.canvas.height),
          (this.tgtScale = this.outW / this.appW),
          (this.tgtOffX = this.outX),
          (this.tgtOffY = this.outY)));
  }
  useSprites() {
    let e = this.gl;
    (e.useProgram(this.prog),
      e.bindVertexArray(this.vao),
      e.activeTexture(e.TEXTURE0),
      e.bindTexture(e.TEXTURE_2D, this.tex),
      e.uniform1f(this.uTime, this.time),
      e.uniform2f(this.uRoom, this.appW, 180),
      e.uniform1f(this.uFlip, this.toFbo ? -1 : 1),
      e.uniform2f(this.uView, this.viewX - this.padX, this.viewY),
      (this.blendMode = `normal`),
      this.setBlendDefault());
  }
  begin(e) {
    let t = this.gl;
    ((this.time = e),
      this.frames++,
      t.disable(t.SCISSOR_TEST),
      t.bindFramebuffer(t.FRAMEBUFFER, null),
      t.viewport(0, 0, this.canvas.width, this.canvas.height),
      t.clearColor(0, 0, 0, 1),
      t.clear(t.COLOR_BUFFER_BIT),
      this.bindTarget(this.app),
      t.clearColor(0, 0, 0, 1),
      t.clear(t.COLOR_BUFFER_BIT),
      (this.viewX = 0),
      (this.viewY = 0),
      this.useSprites());
  }
  beginLayer(e) {
    let t = this.gl,
      n = this.layers.get(e);
    (n || ((n = this.target(this.appW, 180, !1)), this.layers.set(e, n)),
      this.bindTarget(n),
      t.disable(t.SCISSOR_TEST),
      t.clearColor(0, 0, 0, 0),
      t.clear(t.COLOR_BUFFER_BIT),
      this.useSprites());
  }
  passQuad(e, t) {
    let n = this.gl;
    (n.useProgram(e.p),
      n.bindVertexArray(null),
      n.bindBuffer(n.ARRAY_BUFFER, this.quadVbo),
      n.enableVertexAttribArray(0),
      n.vertexAttribPointer(0, 2, n.FLOAT, !1, 8, 0),
      n.activeTexture(n.TEXTURE0),
      n.bindTexture(n.TEXTURE_2D, t),
      n.uniform1i(e.u.gm_BaseTexture, 0),
      n.uniform1f(e.u.u_flip, this.toFbo ? -1 : 1),
      n.drawArrays(n.TRIANGLES, 0, 6));
  }
  endLayer(e, t, n = 0, r = 0, i = !1) {
    let a = this.gl,
      o = this.layers.get(e);
    if (
      (this.flush(), a.disable(a.SCISSOR_TEST), this.bindTarget(this.app), !o)
    )
      return;
    (i &&
      this.padX > 0 &&
      (a.enable(a.SCISSOR_TEST), a.scissor(Math.round(this.padX), 0, 320, 180)),
      a.blendEquation(a.FUNC_ADD),
      a.blendFunc(a.ONE, a.ONE_MINUS_SRC_ALPHA));
    let s = this.appW;
    if (t.kind === `shadow`) {
      let e = this.progs.shadow;
      (a.useProgram(e.p),
        a.uniform1f(e.u.gm_pPreMultiplyAlpha, 1),
        a.uniform2f(e.u.gm_pSurfaceDimensions, s, 180),
        a.uniform1f(e.u.g_DisplacementX, t.dx),
        a.uniform1f(e.u.g_DisplacementY, t.dy),
        a.uniform1f(e.u.g_Opacity, t.opacity),
        a.uniform4f(e.u.g_Colour, 0, 0, 0, 1),
        this.passQuad(e, o.tex));
    } else if (t.kind === `outline`) {
      let e = this.progs.outline;
      (a.useProgram(e.p),
        a.uniform2f(e.u.gm_pSurfaceTexelSize, 1 / s, 1 / 180),
        a.uniform4f(e.u.g_OutlineColour, 0, 0, 0, 1),
        a.uniform1f(e.u.g_OutlineRadius, t.radius),
        a.uniform1f(e.u.g_OutlinePixelScale, 1),
        this.passQuad(e, o.tex));
    } else if (t.kind === `underwater` && t.enabled && this.fxTex.underwater) {
      let e = this.progs.underwater;
      (a.useProgram(e.p),
        a.uniform2f(e.u.gm_pSurfaceDimensions, s, 180),
        a.uniform1f(e.u.gm_pPreMultiplyAlpha, 1),
        a.uniform2f(e.u.gm_pSurfaceTexelSize, 1 / s, 1 / 180),
        a.uniform2f(e.u.gm_pCamOffset, n, r),
        a.activeTexture(a.TEXTURE1),
        a.bindTexture(a.TEXTURE_2D, this.fxTex.underwater),
        a.uniform1i(e.u.g_DistortTexture, 1),
        a.uniform2f(e.u.g_DistortTextureTexelSize, 1 / 256, 1 / 256));
      let t = performance.now() / 1e3;
      (a.uniform1f(e.u.g_Distort1Speed, (t * 0.004) % 1),
        a.uniform1f(e.u.g_Distort2Speed, (t * 0.015) % 1),
        a.uniform2f(e.u.g_Distort1Scale, 20, 2),
        a.uniform2f(e.u.g_Distort2Scale, 100, 10),
        a.uniform1f(e.u.g_Distort1Amount, 3),
        a.uniform1f(e.u.g_Distort2Amount, 6),
        a.uniform1f(e.u.g_ChromaSpreadAmount, 0),
        a.uniform1f(e.u.g_CamOffsetScale, 1),
        a.uniform4f(e.u.g_GlintCol, 0, 0, 0, 1),
        a.uniform4f(e.u.g_TintCol, 1, 1, 1, 1),
        a.uniform4f(e.u.g_AddCol, 0, 0, 0, 1),
        this.passQuad(e, o.tex));
    } else {
      let e = this.progs.copy;
      (a.useProgram(e.p),
        a.uniform4f(e.u.u_col, 1, 1, 1, 1),
        this.passQuad(e, o.tex));
    }
    (a.disable(a.SCISSOR_TEST), this.useSprites());
  }
  vignette() {
    let e = this.gl;
    (this.flush(), this.bindTarget(this.app), this.setBlendDefault());
    let t = this.progs.vignette;
    (e.useProgram(t.p),
      e.uniform2f(t.u.g_VignetteEdges, 1, 1.35),
      e.uniform1f(t.u.g_VignetteSharpness, 3),
      this.passQuad(t, this.app.tex),
      this.useSprites());
  }
  glow(e = 166, t = 3.6, n = 0.275) {
    let r = this.gl;
    this.flush();
    let i = this.progs.copy,
      a = this.temp,
      o = this.temp2;
    (this.bindTarget(a),
      r.disable(r.BLEND),
      r.useProgram(i.p),
      r.uniform4f(i.u.u_col, 1, 1, 1, 1),
      this.passQuad(i, this.app.tex));
    let s = Math.round(t),
      c = e ** (1 / t),
      l = c,
      u = this.progs.glow;
    for (let e = 0; e < s; e++) {
      (this.bindTarget(o),
        r.disable(r.BLEND),
        r.useProgram(u.p),
        r.uniform2f(u.u.gm_pSurfaceTexelSize, 1 / this.appW, 1 / 180),
        r.uniform1f(u.u.g_GlowRadius, l),
        r.uniform1f(u.u.g_GlowGamma, 1),
        this.passQuad(u, a.tex),
        this.bindTarget(this.app),
        r.enable(r.BLEND),
        r.blendEquation(r.MAX),
        r.useProgram(i.p),
        r.uniform4f(i.u.u_col, n, n, n, 1),
        this.passQuad(i, o.tex),
        r.blendEquation(r.FUNC_ADD),
        (l *= -c));
      let e = a;
      ((a = o), (o = e));
    }
    (r.enable(r.BLEND), this.bindTarget(this.app), this.useSprites());
  }
  present(e, t = 1) {
    let n = this.gl;
    this.flush();
    let r = Be(e, t),
      i = this.appW;
    if (((this.curv = r.curvature), n.disable(n.BLEND), r.bloom > 0)) {
      let e = this.progs.bloomDown,
        t = this.app;
      for (let r of this.bloom)
        (this.bindTarget(r),
          n.useProgram(e.p),
          n.uniform2f(e.u.u_texel_size, 1 / t.w, 1 / t.h),
          this.passQuad(e, t.tex),
          (t = r));
      let r = this.progs.bloomUp;
      for (let e = this.bloom.length - 2; e >= 0; e--)
        (this.bindTarget(this.bloom[e]),
          n.useProgram(r.p),
          n.uniform2f(
            r.u.u_texel_size,
            1 / this.bloom[e + 1].w,
            1 / this.bloom[e + 1].h,
          ),
          this.passQuad(r, this.bloom[e + 1].tex));
    }
    this.bindTarget(null);
    let a = this.progs.crt;
    n.useProgram(a.p);
    let o = a.u;
    (n.uniform2f(o.u_content_size, i, 180),
      n.uniform2f(o.u_output_size, this.outW, this.outH),
      n.uniform2f(o.u_output_offset, 0, 0),
      n.uniform1f(o.u_aspect_ratio, i / 180),
      n.uniform1f(o.u_zoom, 1),
      n.uniform1f(o.u_curvature, r.curvature),
      n.uniform1f(o.u_do_int_scale, 0),
      n.uniform1f(o.u_image_softness, r.softness),
      n.uniform1f(o.u_do_tate, 0),
      n.uniform1f(o.u_min_sigma, 0.225),
      n.uniform1f(o.u_max_sigma, 0.5),
      n.uniform1f(o.u_line_brightness, r.brightness),
      n.uniform1f(o.u_mask_strength, r.mask),
      n.uniform1f(o.u_slot_strength, 1),
      n.uniform1f(o.u_mask_do_shadow, 0),
      n.uniform1f(o.u_mask_tex_width, 4),
      n.uniform1f(o.u_mask_scale, 1),
      n.uniform1f(o.u_mask_repeat_on_three, 1),
      n.uniform1f(o.u_do_mask_mirror, 0),
      n.uniform1f(o.u_mask_fade, 1),
      n.uniform1f(o.u_border_width, 0),
      n.uniform1f(o.u_border_brightness, 0.2),
      n.uniform1f(o.u_time, this.frames),
      n.uniform1f(o.u_bloom_strength, r.bloom),
      n.uniform1f(o.u_deconvergence, r.deconvergence),
      n.uniform1f(o.u_gamma, -1),
      n.uniform1f(o.u_do_interlace, 0),
      n.activeTexture(n.TEXTURE1),
      n.bindTexture(n.TEXTURE_2D, this.fxTex.mask ?? this.tex),
      n.uniform1i(o.u_mask_sampler, 1),
      n.activeTexture(n.TEXTURE2),
      n.bindTexture(n.TEXTURE_2D, this.fxTex.slot ?? this.tex),
      n.uniform1i(o.u_slot_sampler, 2),
      n.activeTexture(n.TEXTURE3),
      n.bindTexture(n.TEXTURE_2D, this.bloom[0].tex),
      n.uniform1i(o.u_bloom_sampler, 3),
      this.passQuad(a, this.app.tex),
      n.enable(n.BLEND),
      (this.viewX = 0),
      (this.viewY = 0),
      this.beginGui());
  }
  // GUI, menus and the cursor are drawn after the CRT pass into a screen-resolution target,
  // then bent with the same warp so they follow the bulge (and line up with warped clicks).
  beginGui() {
    let e = this.gl;
    (this.flush(),
      (!this.gui || this.gui.w !== this.outW || this.gui.h !== this.outH) &&
        (this.freeTarget(this.gui),
        (this.gui = this.target(this.outW, this.outH, !0))),
      e.bindFramebuffer(e.FRAMEBUFFER, this.gui.fb),
      e.viewport(0, 0, this.outW, this.outH),
      (this.toFbo = !0),
      (this.tgtH = this.outH),
      (this.tgtScale = this.outW / this.appW),
      (this.tgtOffX = 0),
      (this.tgtOffY = 0),
      e.disable(e.SCISSOR_TEST),
      e.clearColor(0, 0, 0, 0),
      e.clear(e.COLOR_BUFFER_BIT),
      (this.guiActive = !0),
      this.useSprites());
  }
  setView(e, t) {
    (e !== this.viewX || t !== this.viewY) &&
      (this.flush(),
      (this.viewX = e),
      (this.viewY = t),
      this.gl.uniform2f(this.uView, e - this.padX, t));
  }
  setScissor(e) {
    this.flush();
    let t = this.gl;
    if (!e) {
      t.disable(t.SCISSOR_TEST);
      return;
    }
    t.enable(t.SCISSOR_TEST);
    let n = this.tgtScale,
      r = this.tgtOffX + (e.x - this.viewX + this.padX) * n,
      i = this.tgtOffY + (e.y - this.viewY) * n,
      a = e.w * n,
      o = e.h * n,
      s = this.toFbo ? i : this.tgtH - (i + o);
    t.scissor(
      Math.round(r),
      Math.round(s),
      Math.max(0, Math.round(a)),
      Math.max(0, Math.round(o)),
    );
  }
  flush() {
    if (this.quads === 0) return;
    let e = this.gl;
    (e.bindVertexArray(this.vao),
      e.bindBuffer(e.ARRAY_BUFFER, this.vbo),
      e.bufferSubData(
        e.ARRAY_BUFFER,
        0,
        this.buf.subarray(0, this.quads * 6 * Re),
      ),
      e.drawArrays(e.TRIANGLES, 0, this.quads * 6),
      (this.quads = 0));
  }
  quad(e, t, n, r, i, a, o, s) {
    this.quads >= ze && this.flush();
    let c = Ae.w,
      l = Ae.h,
      u = t / c,
      d = n / l,
      f = (t + r) / c,
      p = (n + i) / l,
      m = [u, d, f, d, f, p, u, p],
      h = [0, 0, 1, 0, 1, 1, 0, 1],
      g = [0, 1, 2, 0, 2, 3],
      _ = this.quads * 6 * Re,
      v = this.buf;
    for (let t of g) {
      let n = a[t] || a[0];
      ((v[_++] = e[t * 2]),
        (v[_++] = e[t * 2 + 1]),
        (v[_++] = m[t * 2]),
        (v[_++] = m[t * 2 + 1]),
        (v[_++] = h[t * 2]),
        (v[_++] = h[t * 2 + 1]),
        (v[_++] = n[0]),
        (v[_++] = n[1]),
        (v[_++] = n[2]),
        (v[_++] = n[3]),
        (v[_++] = o),
        (v[_++] = s));
    }
    this.quads++;
  }
  sprite(e) {
    return Ae.sprites[e];
  }
  draw(e, t, n, r, i = 1, a = 1, o = 0, s = 16777215, c = 1, l = 0) {
    let u = Ae.sprites[e];
    if (!u || u.f.length === 0 || c <= 0) return;
    let d = u.f[((Math.floor(t) % u.f.length) + u.f.length) % u.f.length],
      f = (o * Math.PI) / 180,
      p = Math.cos(f),
      m = Math.sin(f);
    if (u.ns && (i !== 1 || a !== 1)) {
      this.nineSlice(u, d, n, r, i, a, p, m, He(s, c), l);
      return;
    }
    let h = [
        [-u.ox, -u.oy],
        [u.w - u.ox, -u.oy],
        [u.w - u.ox, u.h - u.oy],
        [-u.ox, u.h - u.oy],
      ],
      g = [];
    for (let [e, t] of h) {
      let o = e * i,
        s = t * a;
      g.push(n + o * p + s * m, r - o * m + s * p);
    }
    let _ = He(s, c),
      v = l === je.plastic ? f : o;
    this.quad(g, d[0], d[1], u.tw ?? u.w, u.th ?? u.h, [_], l, v);
  }
  nineSlice(e, t, n, r, i, a, o, s, c, l) {
    let [u, d, f, p] = e.ns,
      m = Math.abs(e.w * i),
      h = Math.abs(e.h * a),
      g = e.ox * i,
      _ = e.oy * a,
      v = Math.min(u, m / 2),
      y = Math.min(f, m / 2),
      b = Math.min(d, h / 2),
      x = Math.min(p, h / 2),
      ee = [0, v, m - y, m],
      S = [0, b, h - x, h],
      C = [0, u, e.w - f, e.w],
      te = [0, d, e.h - p, e.h],
      ne = i < 0 ? -1 : 1,
      re = a < 0 ? -1 : 1,
      ie = (e, t) => {
        let i = e * ne - g * ne * ne,
          a = t * re - _ * re * re;
        return [n + i * o + a * s, r - i * s + a * o];
      };
    for (let e = 0; e < 3; e++)
      for (let n = 0; n < 3; n++) {
        if (ee[n + 1] - ee[n] <= 0 || S[e + 1] - S[e] <= 0) continue;
        let r = ie(ee[n], S[e]),
          i = ie(ee[n + 1], S[e]),
          a = ie(ee[n + 1], S[e + 1]),
          o = ie(ee[n], S[e + 1]);
        this.quad(
          [...r, ...i, ...a, ...o],
          t[0] + C[n],
          t[1] + te[e],
          C[n + 1] - C[n],
          te[e + 1] - te[e],
          [c],
          l,
          0,
        );
      }
  }
  drawStretched(e, t, n, r, i, a, o = 16777215, s = 1) {
    let c = Ae.sprites[e];
    if (!c) return;
    let l = c.f[Math.floor(t) % c.f.length];
    if (c.ns) {
      this.nineSlice(
        { ...c, ox: 0, oy: 0 },
        l,
        n,
        r,
        i / c.w,
        a / c.h,
        1,
        0,
        He(o, s),
        0,
      );
      return;
    }
    this.quad(
      [n, r, n + i, r, n + i, r + a, n, r + a],
      l[0],
      l[1],
      c.tw ?? c.w,
      c.th ?? c.h,
      [He(o, s)],
      0,
      0,
    );
  }
  drawPart(e, t, n, r, i, a, o, s, c = 1, l = 1, u = 16777215, d = 1) {
    let f = Ae.sprites[e];
    if (!f) return;
    let p = f.f[Math.floor(t) % f.f.length];
    if (
      ((i = Math.min(i, f.w - n)), (a = Math.min(a, f.h - r)), i <= 0 || a <= 0)
    )
      return;
    let m = f.k ?? 1,
      h = [o, s, o + i * c, s, o + i * c, s + a * l, o, s + a * l];
    this.quad(h, p[0] + n * m, p[1] + r * m, i * m, a * m, [He(u, d)], 0, 0);
  }
  rect(e, t, n, r, i, a = 1) {
    let o = Ae.white,
      s = [e, t, n, t, n, r, e, r];
    this.quad(s, o[0] + 1, o[1] + 1, 1, 1, [He(i, a)], 0, 0);
  }
  line(e, t, n, r, i, a, o = a, s = 1) {
    let c = n - e,
      l = r - t,
      u = Math.hypot(c, l) || 1,
      d = (-l / u) * (i / 2),
      f = (c / u) * (i / 2),
      p = Ae.white,
      m = He(a, s),
      h = He(o, s);
    this.quad(
      [e + d, t + f, n + d, r + f, n - d, r - f, e - d, t - f],
      p[0] + 1,
      p[1] + 1,
      1,
      1,
      [m, h, h, m],
      0,
      0,
    );
  }
  circle(e, t, n, r, i = 1, a = !1) {
    if (a) {
      // Outline rings are drawn as 1-room-pixel blocks so they stay pixel art
      // even on the screen-resolution GUI pass (cursor ring, touch ring).
      let o = Math.floor(e),
        s = Math.floor(t),
        c = Math.ceil(n) + 1;
      for (let e = -c; e <= c; e++)
        for (let t = -c; t <= c; t++)
          Math.abs(Math.hypot(t, e) - n) < 0.5 &&
            this.rect(o + t, s + e, o + t + 1, s + e + 1, r, i);
      return;
    }
    let o = Math.max(12, Math.min(48, Math.round(n * 2))),
      s = Ae.white,
      c = He(r, i);
    for (let l = 0; l < o; l++) {
      let u = (l / o) * Math.PI * 2,
        d = ((l + 1) / o) * Math.PI * 2;
      a
        ? this.line(
            e + Math.cos(u) * n,
            t + Math.sin(u) * n,
            e + Math.cos(d) * n,
            t + Math.sin(d) * n,
            1,
            r,
            r,
            i,
          )
        : this.quad(
            [
              e,
              t,
              e + Math.cos(u) * n,
              t + Math.sin(u) * n,
              e + Math.cos(d) * n,
              t + Math.sin(d) * n,
              e,
              t,
            ],
            s[0] + 1,
            s[1] + 1,
            1,
            1,
            [c],
            0,
            0,
          );
    }
  }
  circleProgress(e, t, n, r, i, a, o, s = 1) {
    ((i = Math.max(0, Math.min(100, i))),
      o && this.circle(e, t, n - r / 2, 0, s));
    let c = (i / 100) * 360,
      l = Ae.white,
      u = He(a, s),
      d = n,
      f = n - r;
    for (let n = 0; n + 4 <= c + 0.001; n += 4) {
      let r = (n, r) => [
          e + Math.cos(((n - 90) * Math.PI) / 180) * r,
          t + Math.sin(((n - 90) * Math.PI) / 180) * r,
        ],
        [i, a] = r(n, d),
        [o, s] = r(n + 4, d),
        [c, p] = r(n + 4, f),
        [m, h] = r(n, f);
      this.quad([i, a, o, s, c, p, m, h], l[0] + 1, l[1] + 1, 1, 1, [u], 0, 0);
    }
  }
  end() {
    if ((this.flush(), !this.guiActive)) return;
    this.guiActive = !1;
    let e = this.gl;
    (e.disable(e.SCISSOR_TEST),
      this.bindTarget(null),
      e.enable(e.BLEND),
      e.blendEquation(e.FUNC_ADD),
      e.blendFunc(e.ONE, e.ONE_MINUS_SRC_ALPHA));
    let t = this.progs.warp;
    (e.useProgram(t.p),
      e.uniform1f(t.u.u_curvature, this.curv),
      e.uniform2f(t.u.u_output_size, this.outW, this.outH),
      this.passQuad(t, this.gui.tex),
      this.setBlendDefault());
  }
};
function He(e, t) {
  return [((e >> 16) & 255) / 255, ((e >> 8) & 255) / 255, (e & 255) / 255, t];
}
function D(e) {
  let t = e & 255,
    n = (e >> 8) & 255,
    r = (e >> 16) & 255;
  return (t << 16) | (n << 8) | r;
}
var O = {
    white: 16777215,
    black: 0,
    red: 16711680,
    ltgray: 12632256,
    dkgray: 4210752,
    gray: 8421504,
    green: D(6946705),
    redSoft: D(6184703),
    yellow: D(9240561),
    blue: D(16755841),
    greenDark: D(3249231),
    gold: D(5877678),
    orange: D(6008319),
    pink: D(16224767),
    purple: D(8539010),
    brown: D(8212525),
  },
  Ue = Ae.font.glyphs,
  We = 36,
  Ge = {
    c_white: 16777215,
    c_black: 0,
    c_red: 16711680,
    c_lime: 65280,
    c_blue: 255,
    c_yellow: 16776960,
    c_orange: 16752704,
    c_ltgray: 12632256,
    c_ltgrey: 12632256,
    c_dkgray: 4210752,
    c_dkgrey: 4210752,
    c_gray: 8421504,
    c_grey: 8421504,
    c_aqua: 65535,
    c_fuchsia: 16711935,
    c_silver: 12632256,
  },
  Ke = () => ({
    scale: 1,
    color: 16777215,
    alpha: 1,
    wave: !1,
    shake: !1,
    rainbow: !1,
    wheel: !1,
    jitter: !1,
    blink: !1,
    wobble: !1,
    pulse: !1,
  }),
  qe = [
    `wave`,
    `shake`,
    `rainbow`,
    `wheel`,
    `jitter`,
    `blink`,
    `wobble`,
    `pulse`,
  ];
function Je(e, t) {
  let n = [],
    r = Ke(),
    i = 0;
  for (; i < e.length;) {
    let a = e[i];
    if (a === `[`) {
      let a = e.indexOf(`]`, i);
      if (a > i) {
        let o = e.slice(i + 1, a).trim();
        ((i = a + 1), (r = Ye(o, r, n, t)));
        continue;
      }
    }
    if (
      a ===
      `
`
    ) {
      (n.push({ k: `br` }), i++);
      continue;
    }
    let o = e.codePointAt(i),
      s = Ue[o] || Ue[63];
    (n.push({ k: `g`, code: o, w: (s ? s[4] : 10) * r.scale, s: r }),
      (i += o > 65535 ? 2 : 1));
  }
  return n;
}
function Ye(e, t, n, r) {
  let i = e.split(`,`).map((e) => e.trim()),
    a = i[0],
    o = { ...t };
  if (a === `/` || a === `/page`) return Ke();
  if (a === `/c` || a === `/color` || a === `/colour`)
    return ((o.color = 16777215), o);
  if (a.startsWith(`/`)) {
    let e = a.slice(1);
    return (
      qe.includes(e) && (o[e] = !1),
      a === `/scale` && (o.scale = 1),
      a === `/alpha` && (o.alpha = 1),
      o
    );
  }
  if (a === `scale`) return ((o.scale = parseFloat(i[1]) || 1), o);
  if (a === `alpha`)
    return ((o.alpha = parseFloat(i[1])), isNaN(o.alpha) && (o.alpha = 1), o);
  if (a in Ge) return ((o.color = Ge[a]), o);
  if (a.startsWith(`d#`))
    return ((o.color = D(parseInt(a.slice(2), 10) || 0)), o);
  if (a.startsWith(`#`) && a.length === 7)
    return ((o.color = parseInt(a.slice(1), 16)), o);
  if (qe.includes(a)) return ((o[a] = !0), o);
  if (a === `fa_left`) r.h = `left`;
  else if (a === `fa_center`) r.h = `center`;
  else if (a === `fa_right`) r.h = `right`;
  else if (a === `fa_top`) r.v = `top`;
  else if (a === `fa_middle`) r.v = `middle`;
  else if (a === `fa_bottom`) r.v = `bottom`;
  else if (Ae.sprites[a]) {
    let e = Ae.sprites[a],
      r = i[1] === void 0 ? -1 : parseInt(i[1], 10) || 0;
    n.push({ k: `s`, sprite: a, frame: r, w: e.w * t.scale * 1, s: t });
  }
  return o;
}
function Xe(e, t, n) {
  let r = [],
    i = [],
    a = () => {
      let e = 0,
        t = 0;
      for (let r of i)
        r.k !== `br` &&
          ((e += r.w),
          (t = Math.max(
            t,
            (r.k === `s` ? Ae.sprites[r.sprite].h : n) * r.s.scale,
          )));
      (r.push({ items: i, w: e, h: t || n * 0.5, lh: n }), (i = []));
    };
  if (t <= 0) {
    for (let t of e) t.k === `br` ? a() : i.push(t);
    return (a(), r);
  }
  let o = 0,
    s = [],
    c = 0,
    l = () => {
      if (o + c > t && i.length > 0) {
        for (
          ;
          i.length && i[i.length - 1].k === `g` && i[i.length - 1].code === 32;
        )
          i.pop();
        for (a(), o = 0; s.length && s[0].k === `g` && s[0].code === 32;)
          ((c -= s[0].w), s.shift());
      }
      (i.push(...s), (o += c), (s = []), (c = 0));
    };
  for (let t of e) {
    if (t.k === `br`) {
      (l(), a(), (o = 0));
      continue;
    }
    if (t.k === `g` && t.code === 32) {
      (l(), s.push(t), (c += t.w));
      continue;
    }
    (s.push(t), (c += t.w));
  }
  return (l(), a(), r);
}
function Ze(e, t, n) {
  let r = Math.floor(e * 6),
    i = e * 6 - r,
    a = n * (1 - t),
    o = n * (1 - i * t),
    s = n * (1 - (1 - i) * t),
    [c, l, u] = [
      [n, s, a],
      [o, n, a],
      [a, n, s],
      [a, o, n],
      [s, a, n],
      [n, a, o],
    ][((r % 6) + 6) % 6];
  return (
    (Math.round(c * 255) << 16) |
    (Math.round(l * 255) << 8) |
    Math.round(u * 255)
  );
}
var Qe = new Map();
function $e(e, t) {
  let n = `${t.halign}|${t.valign}|${t.width ?? -1}|${t.lineHeight ?? We}|${e}`,
    r = Qe.get(n);
  if (!r) {
    let i = { h: t.halign ?? `center`, v: t.valign ?? `middle` };
    ((r = { lines: Xe(Je(e, i), t.width ?? -1, t.lineHeight ?? We), align: i }),
      Qe.size > 800 && Qe.clear(),
      Qe.set(n, r));
  }
  return r;
}
function et(e, t = {}) {
  let { lines: n } = $e(e, t),
    r = 0,
    i = 0;
  for (let e of n) ((r = Math.max(r, e.w)), (i += e.h));
  return { w: r, h: i };
}
function k(e, t, n, r, i = {}) {
  let { lines: a, align: o } = $e(r, i),
    s = e.time * 60,
    c = 0;
  for (let e of a) c += e.h;
  let l = n;
  o.v === `middle` ? (l = n - c / 2) : o.v === `bottom` && (l = n - c);
  let u = 0,
    d = i.count ?? 1 / 0,
    f = i.alpha ?? 1;
  for (let n of a) {
    let r = t;
    o.h === `center`
      ? (r = t - Math.trunc(n.w / 2))
      : o.h === `right` && (r = t - n.w);
    for (let t of n.items) {
      if (t.k === `br`) continue;
      if (u >= d) return;
      let i = t.s,
        a = 0,
        o = 0,
        c = 1,
        p = 0,
        m = i.color;
      if (
        (i.wobble && (p = 20 * Math.sin(0.15 * s)),
        i.pulse &&
          (c *= 1 - 0.5 * (0.5 + 0.5 * Math.sin(0.05 * (250 * u + s)))),
        i.jitter &&
          (c *=
            0.7 +
            0.5 *
              nt(
                u / 149 + Math.floor(0.4 * s + 0.5) / 13,
                u / 727 - Math.floor(0.4 * s + 0.5) / 331,
              )),
        i.wave && (o += 1.5 * Math.sin(u + 0.05 * s)),
        i.wheel)
      ) {
        let e = 0.5 * u + 0.1 * s;
        ((a += 0.5 * Math.cos(e)), (o -= 0.5 * Math.sin(e)));
      }
      if (i.shake) {
        let e = 0.4 * s + 0.5,
          t = Math.floor(e),
          n = 1 - Math.abs(2 * (e - t) - 1);
        ((a += 2 * n * (2 * nt(u / 149 + t / 13, u / 727 - t / 331) - 1)),
          (o += 2 * n * (2 * nt(u / 501 - t / 19, u / 701 + t / 317) - 1)));
      }
      if (
        (i.rainbow &&
          (m = rt(m, Ze((((0.02 * u + 0.01 * s) % 1) + 1) % 1, 1, 1), 0.5)),
        i.blink && s % 40 >= 30)
      ) {
        ((r += t.w), u++);
        continue;
      }
      if (t.k === `g`) {
        let s = Ue[t.code];
        if (s && t.code !== 32) {
          let t = l + (n.h - n.lh * i.scale) / 2,
            u = s[2] * i.scale,
            d = s[3] * i.scale,
            h = r + s[5] * i.scale + u / 2,
            g = t + d / 2;
          tt(
            e,
            s,
            h - (u / 2) * c + a,
            g - (d / 2) * c + o,
            u * c,
            d * c,
            p,
            m,
            i.alpha * f,
          );
        }
      } else {
        let u = Ae.sprites[t.sprite];
        if (u) {
          let d = u.f.length,
            h =
              t.frame >= 0
                ? t.frame
                : d > 1
                  ? Math.floor((s / 60) * (u.sp ?? 0)) % d
                  : 0,
            g = l + (n.h - u.h * i.scale) / 2,
            _ = i.scale * c,
            v = r + (u.w * i.scale) / 2,
            y = g + (u.h * i.scale) / 2;
          e.draw(
            t.sprite,
            h,
            v - (u.w / 2) * _ + u.ox * _ + a,
            y - (u.h / 2) * _ + u.oy * _ + o,
            _,
            _,
            p,
            i.rainbow ? m : 16777215,
            i.alpha * f,
          );
        }
      }
      ((r += t.w), u++);
    }
    l += n.h;
  }
}
function tt(e, t, n, r, i, a, o, s, c) {
  let l = [n, r, n + i, r, n + i, r + a, n, r + a];
  if (o) {
    let e = n + i / 2,
      t = r + a / 2,
      s = (o * Math.PI) / 180,
      c = Math.cos(s),
      u = Math.sin(s);
    l = l.map((e, t) => e);
    for (let n = 0; n < 4; n++) {
      let r = l[n * 2] - e,
        i = l[n * 2 + 1] - t;
      ((l[n * 2] = e + r * c + i * u), (l[n * 2 + 1] = t - r * u + i * c));
    }
  }
  e.quad(l, t[0], t[1], t[2], t[3], [He(s, c)], 0, 0);
}
function nt(e, t) {
  let n = Math.sin(e * 12.9898 + t * 78.233) * 43758.5453;
  return n - Math.floor(n);
}
function rt(e, t, n) {
  let r = (r) => Math.round(((e >> r) & 255) * (1 - n) + ((t >> r) & 255) * n);
  return (r(16) << 16) | (r(8) << 8) | r(0);
}
function it(e, t, n, r, i = {}, a = 0.5) {
  (k(e, t + 1, n + 1, `[c_black][alpha, ${a}]` + at(r), i), k(e, t, n, r, i));
}
function at(e) {
  return e.replace(
    /\[(c_[a-z]+|d#\d+|#[0-9a-fA-F]{6}|rainbow|\/rainbow|alpha,[^\]]*)\]/g,
    ``,
  );
}
function ot(e, t = Math.random) {
  return t() * 100 < e;
}
function A(e, t = Math.random) {
  return Math.floor(t() * (Math.floor(e) + 1));
}
function j(e, t, n = Math.random) {
  let r = Math.floor(Math.min(e, t)),
    i = Math.floor(Math.max(e, t));
  return r + Math.floor(n() * (i - r + 1));
}
function M(e, t, n = Math.random) {
  return e + n() * (t - e);
}
function st(e, t = Math.random) {
  let n = e.slice();
  for (let e = n.length - 1; e > 0; e--) {
    let r = Math.floor(t() * (e + 1));
    [n[e], n[r]] = [n[r], n[e]];
  }
  return n;
}
function ct(e) {
  return e >= 10 ? Math.floor(e) : e;
}
function lt(e, t, n) {
  return Math.max(t, Math.min(n, e));
}
function N(e, t, n) {
  return e + (t - e) * n;
}
function P(e) {
  if (!isFinite(e)) return e > 0 ? `∞` : `-∞`;
  let t = Math.abs(e),
    n = ``,
    r = 1;
  if (t >= 1e9) ((n = `B`), (r = 1e9));
  else if (t >= 1e6) ((n = `M`), (r = 1e6));
  else if (t >= 1e3) ((n = `K`), (r = 1e3));
  else if (t >= 10) return String(Math.floor(e));
  else return String(Math.round(e * 100) / 100);
  let i = e / r;
  return (
    (i =
      i < 10
        ? Math.floor(i * 100) / 100
        : i < 100
          ? Math.floor(i * 10) / 10
          : Math.floor(i)),
    String(i) + n
  );
}
function F(e, t, n = e[t].level) {
  let r = e[t];
  return n <= 0 ? r.default_value : r.values[lt(n - 1, 0, r.values.length - 1)];
}
function ut(e, t) {
  let n = e[t];
  if (n.dependencies.length === 0) return !1;
  for (let t of n.dependencies) {
    let n = e[t];
    if (n.level <= 1 && n.level !== n.values.length) return !0;
  }
  return !1;
}
function dt(e) {
  return e.level >= e.values.length;
}
function ft(e) {
  for (let t of e)
    if (![66, 2, 32, 33, 52].includes(t.ID) && t.level < t.values.length)
      return !1;
  return !0;
}
function pt(e, t, n, r, i = 1, a = !1) {
  let o = e[n],
    s = [
      1 * F(t, 7) * i,
      5 * F(t, 12) * i,
      25 * F(t, 13) * i,
      125 * F(t, 14) * i,
    ],
    c = [
      1,
      4 * F(t, 15),
      16 * F(t, 16),
      64 * F(t, 17),
      128 * F(t, 18),
      256 * F(t, 46),
      1024 * F(t, 47),
    ];
  return (
    a && ((s = [1, 5, 25, 125]), (c = [1, 4, 16, 64, 128, 256, 1024])),
    Math.max(1, ct(o.price * s[o.stars - 1] * c[r]))
  );
}
function mt(e, t = 1, n = Math.random) {
  let r = 0;
  for (let [i, a] of [
    [1, 1],
    [19, 2],
    [20, 3],
    [21, 4],
    [44, 5],
    [45, 6],
  ])
    ot(F(e, i) * t, n) && (r = a);
  return r;
}
function ht(e, t = -1, n = Math.random) {
  let r = e.filter((e) => e.activate && (e.stars === t || t === -1));
  if (r.length !== 0) return r[Math.floor(n() * r.length)];
}
function gt(e, t = -1) {
  let n = [];
  for (let r of e)
    !r.activate ||
      (t !== -1 && r.stars !== t) ||
      r.quantity.forEach((e, t) => {
        e === -1 && n.push({ ID: r.ID, type: t });
      });
  return n;
}
function _t(e, t = -1) {
  let n = [];
  for (let r of e)
    !r.activate ||
      (t !== -1 && r.stars !== t) ||
      r.quantity.forEach((e, t) => {
        e >= 0 && n.push({ ID: r.ID, type: t });
      });
  return n;
}
function vt(e, t = -1) {
  let n = [];
  for (let r of e)
    if (!(!r.activate || (t !== -1 && r.stars !== t)))
      for (let e = 0; e < r.quantity.length; e++)
        for (let t = 0; t < r.quantity[e]; t++) n.push({ ID: r.ID, type: e });
  return n;
}
function yt(e) {
  let t = 0;
  for (let n of e) if (n.activate) for (let e of n.quantity) e > 0 && (t += e);
  return t;
}
function bt(e, t, n, r, i) {
  let a = !i && yt(e) < F(t, 6);
  return i || a
    ? (e[n].quantity[r]++,
      i && (e[n].recent_unlock = !0),
      { collected: !0, duplicate: a })
    : { collected: !1, duplicate: !1 };
}
function xt(e) {
  let t = 0;
  for (let n of e) for (let e of n.quantity) e >= 0 && t++;
  return t;
}
function St(e) {
  let t = 0;
  for (let n of e) n.activate && (t += n.quantity.length);
  return t;
}
function Ct(e, t = Math.random) {
  let n = [15, 8, 5, 2],
    r = [[], [], [], []];
  for (let t of e) t.activate || r[t.stars - 1].push(t);
  for (let i = 0; i < 4; i++) {
    let a = r[i];
    for (let r = 0; r < n[i] && !(a.length <= 0); r++)
      ((a = st(a, t)), (e[a[0].ID].activate = !0), (a = a.slice(1)));
  }
}
function wt(e, t) {
  return e[t].quantity.every((e) => e !== -1);
}
function Tt(e, t = Math.random) {
  let n = e.reduce((e, t) => e + Math.max(0, t), 0);
  if (n <= 0) return 1;
  let r = t() * n;
  for (let t = 0; t < e.length; t++)
    if (((r -= Math.max(0, e[t])), r < 0)) return t + 1;
  return e.length;
}
function Et(e, t, n) {
  return ((e * 60 * (100 - F(t, 4))) / 100) * Math.max(1, n / 2);
}
function Dt(e) {
  return Math.floor(e * 1e6);
}
function Ot(e, t, n) {
  let r = e[61 + t],
    i = r.prices[Math.max(0, r.level - 1)],
    a = n * 2.15;
  return a * 1e6 > i ? i / 1e6 : a;
}
function kt(e) {
  return 60 * Math.min(600, N(200, 600, e / 2));
}
var At = `crackthepack.save.v6`,
  jt = `crackthepack.options`,
  I = (function (e) {
    return (
      (e[(e.Background = 0)] = `Background`),
      (e[(e.InstancesBottom = 1)] = `InstancesBottom`),
      (e[(e.Instances = 2)] = `Instances`),
      (e[(e.InstancesTop = 3)] = `InstancesTop`),
      (e[(e.Particles = 4)] = `Particles`),
      (e[(e.Text = 5)] = `Text`),
      (e[(e.Handler = 6)] = `Handler`),
      (e[(e.UI = 7)] = `UI`),
      (e[(e.UI2 = 8)] = `UI2`),
      (e[(e.ParticlesUp = 9)] = `ParticlesUp`),
      (e[(e.TextUp = 10)] = `TextUp`),
      (e[(e.UIAssets = 11)] = `UIAssets`),
      (e[(e.Upgrades = 12)] = `Upgrades`),
      (e[(e.Logo = 13)] = `Logo`),
      (e[(e.Bottom = 14)] = `Bottom`),
      (e[(e.Sequence = 15)] = `Sequence`),
      (e[(e.CardsTop = 16)] = `CardsTop`),
      e
    );
  })({}),
  L = (e, t) => ({ kind: `shadow`, dx: e, dy: e, opacity: t }),
  Mt = { kind: `outline`, radius: 2 },
  Nt = { kind: `none` },
  R = (e, t) => ({ kind: `inst`, id: e, filter: t }),
  Pt = {
    rmGame: [
      { kind: `bg` },
      { kind: `vignette` },
      R(1, L(2, 0.6)),
      R(2, L(2, 0.6)),
      R(3, L(3, 0.6)),
      R(4, L(2, 0.6)),
      R(5, Mt),
      R(11, L(2, 0.6)),
      R(6, L(2, 0.5)),
      R(7, L(1, 0.6)),
      R(8, L(1, 0.6)),
      R(9, L(2, 0.6)),
      R(10, Mt),
      R(12, Nt),
      R(16, L(1, 0.6)),
      { kind: `glow` },
    ],
    rmMenu: [
      { kind: `bg` },
      { kind: `vignette` },
      R(2, L(2, 0.6)),
      R(13, L(3, 0.5)),
      R(4, L(2, 0.5)),
      R(5, Mt),
      R(7, L(2, 0.5)),
    ],
    rmMenuIntro: [
      { kind: `bg` },
      { kind: `vignette` },
      R(2, L(2, 0.6)),
      R(13, L(3, 0.5)),
      R(7, Nt),
      R(15, Nt),
    ],
    rmEnding: [
      { kind: `bg` },
      R(14, Nt),
      R(2, Nt),
      { kind: `vignette` },
      R(7, L(2, 0.5)),
      R(5, Mt),
    ],
    rmCredits: [
      { kind: `bg` },
      { kind: `vignette` },
      R(2, L(2, 0.6)),
      R(7, L(2, 0.5)),
    ],
  },
  z = class {
    g;
    x = 0;
    y = 0;
    xstart = 0;
    ystart = 0;
    xs = 1;
    ys = 1;
    angle = 0;
    blend = 16777215;
    alpha = 1;
    frame = 0;
    sprite = ``;
    layer = 2;
    dead = !1;
    visible = !0;
    active = !0;
    alarm = [-1, -1, -1, -1];
    order = 0;
    hovered = !1;
    constructor(e, t = 0, n = 0) {
      ((this.g = e), (this.x = this.xstart = t), (this.y = this.ystart = n));
    }
    sortKey() {
      return 0;
    }
    onAlarm(e) {}
    userEvent0() {}
    step() {}
    mouse() {}
    draw() {
      this.drawSelf();
    }
    drawGui() {}
    onDestroy() {}
    drawSelf(e = 0) {
      this.sprite &&
        this.g.r.draw(
          this.sprite,
          this.frame,
          this.x,
          this.y,
          this.xs,
          this.ys,
          this.angle,
          this.blend,
          this.alpha,
          e,
        );
    }
    destroy() {
      this.dead || ((this.dead = !0), this.onDestroy());
    }
    contains(e, t, n = 0) {
      let r = Ae.sprites[this.sprite];
      if (!r || !isFinite(this.xs) || !isFinite(this.ys)) return !1;
      let i = (this.angle * Math.PI) / 180,
        a = e - this.x,
        o = t - this.y,
        s = a * Math.cos(i) - o * Math.sin(i),
        c = a * Math.sin(i) + o * Math.cos(i),
        l = Math.min(-r.ox * this.xs, (r.w - r.ox) * this.xs),
        u = Math.max(-r.ox * this.xs, (r.w - r.ox) * this.xs),
        d = Math.min(-r.oy * this.ys, (r.h - r.oy) * this.ys),
        f = Math.max(-r.oy * this.ys, (r.h - r.oy) * this.ys);
      if (n <= 0) return s >= l && s <= u && c >= d && c <= f;
      let p = lt(s, l, u),
        m = lt(c, d, f);
      return Math.hypot(s - p, c - m) <= n;
    }
    mouseHover() {
      return !this.dead && this.contains(this.g.input.x, this.g.input.y);
    }
  },
  Ft = class {
    r;
    input = new _e();
    audio = new me();
    cards = le();
    boosters = ue();
    upgrades = de();
    stats = w();
    options = T();
    lang = oe.en;
    objects = [];
    frame = 0;
    timers = [];
    timerId = 0;
    orderSeq = 0;
    speedMod = 1;
    valueMod = 1;
    rarityMod = 1;
    backgroundIndex = 0;
    isFirstStamp = !0;
    ongletsInputs = 0;
    lastRush = 0;
    polarizedStreak = 0;
    godpackActive = !1;
    employeesSleep = !1;
    godpackCooldown = 36e3;
    camX = 0;
    camY = 0;
    shake = 0;
    autoClick = !1;
    mouseI = 5;
    cursorScale = 1;
    cursorImage = 0;
    lastCursor = { x: 0, y: 0 };
    musicI = 0;
    musicAlarm = -1;
    emitGain = 1;
    emitGainTo = 1;
    emitPitch = 1;
    emitPitchTo = 1;
    bgX = 0;
    bgY = 0;
    bgOffX = 0;
    bgOffY = 0;
    bgSide = 1;
    beatTimer = 0;
    bpm = [64.4, 150.2, 75.1, 70.7, 131.1];
    dupVersion = 0;
    onSave = null;
    started = !1;
    constructor(e) {
      this.r = e;
    }
    L(e) {
      let t = this.lang[e] ?? oe.en[e];
      return typeof t == `string` ? t : e;
    }
    Lany(e) {
      return this.lang[e] ?? oe.en[e];
    }
    up(e) {
      return F(this.upgrades, e);
    }
    price(e, t) {
      return pt(this.cards, this.upgrades, e, t, this.valueMod);
    }
    add(e, t) {
      return (
        t !== void 0 && (e.layer = t),
        (e.order = this.orderSeq++),
        this.objects.push(e),
        e
      );
    }
    all(e) {
      let t = [];
      for (let n of this.objects) !n.dead && n instanceof e && t.push(n);
      return t;
    }
    count(e) {
      let t = 0;
      for (let n of this.objects) !n.dead && n instanceof e && t++;
      return t;
    }
    later(e, t, n, r = !1, i) {
      let a = Math.max(1, Math.round(t === `seconds` ? e * 60 : e)),
        o = ++this.timerId;
      return (
        this.timers.push({
          at: this.frame + a,
          fn: n,
          loop: r ? a : 0,
          owner: i,
          id: o,
        }),
        o
      );
    }
    cancel(e) {
      this.timers = this.timers.filter((t) => t.id !== e);
    }
    sfx(e, t = 1, n = 1, r = !1, i = !0) {
      let a = lt(Math.min(10, 1 + this.stats.money / 2e6), 1, 10);
      ((!i || this.godpackActive) && (a = 1),
        r && (n = M(n / 1.5, n * 1.3)),
        this.audio.play(e, t / a, n));
    }
    cameraShake(e, t = !0) {
      if (!this.options.camera_shake) return;
      let n = 1 + (this.stats.money / 2e6) * 4;
      (t || (n = 1), (this.shake += e / n));
    }
    moneyAdd(e, t = !1, n) {
      ((this.stats.money += e),
        e > 0
          ? (this.stats.stats.nb_money_total = Math.round(
              this.stats.stats.nb_money_total + e,
            ))
          : (this.stats.stats.nb_money_spent = Math.round(
              this.stats.stats.nb_money_spent + e,
            )),
        t && e !== 0 && this.moneyHist?.(e, n));
    }
    moneyHist = null;
    popup = () => {};
    particle = () => {};
    flash = () => {};
    room = `rmGame`;
    titleStartedAt = 0;
    roomBuilders = {};
    drawBackground = null;
    optionsOpen = !1;
    gotoRoom(e) {
      for (let e of this.objects) e.dead || e.destroy();
      ((this.objects = []),
        (this.timers = this.timers.filter((e) => !e.owner)),
        (this.room = e),
        (this.drawBackground = null),
        (this.camX = this.camY = 0),
        (this.shake = 0),
        (this.optionsOpen = !1),
        this.roomBuilders[e]?.(this));
    }
    stampShop = null;
    save() {
      if (!this.stats.tutorial_done) return;
      let e = JSON.stringify({
        cards: this.cards,
        upgrades: this.upgrades,
        boosters: this.boosters,
        stats: this.stats,
      });
      try {
        (localStorage.setItem(At, e),
          localStorage.setItem(jt, JSON.stringify(this.options)));
      } catch {}
      try {
        typeof window.AndroidSave?.saveGame == `function` &&
          window.AndroidSave.saveGame(e);
      } catch {}
    }
    saveOptions() {
      try {
        localStorage.setItem(jt, JSON.stringify(this.options));
      } catch {}
    }
    load() {
      try {
        let e = localStorage.getItem(jt);
        e && (this.options = { ...T(), ...JSON.parse(e) });
        let t = localStorage.getItem(At);
        try {
          if (typeof window.AndroidSave?.loadGame == `function`) {
            let e = window.AndroidSave.loadGame();
            // Empty native data is an intentional reset; null means no external save yet.
            if (typeof e == `string`) t = e;
            else if (t && typeof window.AndroidSave?.saveGame == `function`)
              window.AndroidSave.saveGame(t);
          }
        } catch {}
        if (t) {
          let e = JSON.parse(t);
          e?.stats?.ver === 6 &&
            ((this.cards = e.cards),
            (this.upgrades = It(e.upgrades)),
            (this.boosters = e.boosters),
            (this.stats = {
              ...w(),
              ...e.stats,
              stats: { ...w().stats, ...e.stats.stats },
            }),
            this.stats.money_max === null && (this.stats.money_max = 1 / 0));
        }
      } catch {}
      ((this.stats.money_max === null || this.stats.money_max === void 0) &&
        (this.stats.money_max = 1 / 0),
        (this.lang = oe[this.options.lang] ?? oe.en),
        (this.audio.sfxVolume = this.options.volume_effect / 10),
        (this.audio.musicVolume = this.options.volume_music / 10));
    }
    resetSave() {
      localStorage.removeItem(At);
      try {
        typeof window.AndroidSave?.saveGame == `function` &&
          window.AndroidSave.saveGame(``);
      } catch {}
    }
    step() {
      (this.input.beginStep(),
        this.frame++,
        this.autoClickResetAt === this.frame && (this.autoClick = !1));
      let e = this.timers.filter((e) => e.at <= this.frame);
      if (e.length) {
        this.timers = this.timers.filter((e) => e.at > this.frame);
        for (let t of e)
          (t.owner && t.owner.dead) ||
            (t.loop && ((t.at = this.frame + t.loop), this.timers.push(t)),
            t.fn());
      }
      let t = this.objects.filter((e) => !e.dead && e.active);
      for (let e of t)
        for (let t = 0; t < e.alarm.length; t++)
          e.alarm[t] > 0 &&
            (--e.alarm[t],
            e.alarm[t] <= 0 && ((e.alarm[t] = -1), e.dead || e.onAlarm(t)));
      let n = this.room === `rmGame`;
      n && this.globalMouse();
      for (let e of t) e.dead || e.mouse();
      n && this.gameStep();
      for (let e of t) e.dead || e.step();
      ((this.objects = this.objects.filter((e) => !e.dead)),
        this.cameraStep(),
        this.input.endStep());
    }
    autoClickResetAt = -1;
    globalMouse() {
      let e = this.input;
      (e.leftPressed && ((this.cursorScale *= 2), this.stats.stats.nb_clicks++),
        e.rightDown &&
          this.up(29) > 0 &&
          ((this.cursorImage = 1),
          this.mouseI <= 0
            ? ((this.autoClick = !0),
              (this.autoClickResetAt = this.frame + 1),
              (this.mouseI = 60 / this.up(29)),
              (this.cursorScale *= 2))
            : this.mouseI--),
        e.rightReleased &&
          ((this.autoClick = !1),
          (this.mouseI = 60 / Math.max(1, this.up(29))),
          (this.cursorImage = 0)));
    }
    gameStep() {
      (this.speedMod > 1
        ? (this.speedMod -= 0.0015)
        : this.speedMod < 1 && (this.speedMod = N(this.speedMod, 1, 0.1)),
        (this.speedMod = lt(this.speedMod, 0.1, 2)),
        this.stats.money < 0 &&
          (this.stats.money = N(this.stats.money, 0, 0.1)),
        (this.cursorScale = N(this.cursorScale, 1, 0.4)),
        this.godpackCooldown >= 0 && this.godpackCooldown--,
        (this.mouseI = Math.min(60, this.mouseI)),
        this.musicStep());
    }
    cameraStep() {
      let e = () => (Math.random() < 0.5 ? -this.shake : this.shake);
      ((this.camX = N(this.camX, e(), 0.1)),
        (this.camY = N(this.camY, e(), 0.1)),
        (this.shake = lt(N(this.shake, 0, 0.1), 0, 60)));
    }
    isOngletSelected = () => !1;
    closeOnglets = () => {};
    moduleOpen = () => !1;
    shopCardsRefresh = () => {};
    musicStep() {
      if (this.musicAlarm > 0 && (this.musicAlarm--, this.musicAlarm <= 0)) {
        this.musicAlarm = 60 * (1 + Math.floor(Math.random() * 5));
        // Only start the next board track once nothing else is playing
        !this.audio.anyMusicPlaying() &&
          !this.godpackActive &&
          (this.musicI++,
          this.musicI > 5 && (this.musicI = 1),
          this.audio.playMusic(`mscBoard${this.musicI}`));
      }
      ((this.emitGain = N(this.emitGain, this.emitGainTo, 0.1)),
        (this.emitPitch = N(
          this.emitPitch,
          this.emitPitchTo + (this.speedMod - 1) / 2,
          0.1,
        )));
      let e = this.audio;
      ((e.isPlaying(`sndCardNew6`) || e.isPlaying(`sndModuleLabLaunched`)) &&
        (this.emitGain = 0),
        (this.emitGainTo = [
          `mscModuleArena`,
          `mscModuleLab`,
          `mscModuleMuseum`,
          `mscModuleMemory`,
        ].some((t) => e.isPlaying(t))
          ? 0
          : this.isOngletSelected()
            ? 0.3
            : 1),
        this.audio.updateEmitter(this.emitGain, this.emitPitch),
        (this.bgX = N(this.bgX, this.bgOffX, 0.3)),
        (this.bgY = N(this.bgY, this.bgOffY, 0.3)),
        this.options.moving_background &&
          ((this.bgOffX += 0.25 * this.speedMod),
          (this.bgOffY -= 0.25 * this.speedMod)));
      let t =
        60 /
        this.bpm[Math.max(0, this.musicI - 1)] /
        this.speedMod /
        this.emitPitchTo;
      if (this.audio.isPlaying(`mscBoard${this.musicI}`))
        for (this.beatTimer += 1 / 60; this.beatTimer >= t;)
          ((this.beatTimer -= t),
            this.options.moving_background &&
              ((this.bgOffX += 5 * this.bgSide), (this.bgSide *= -1)));
      else this.beatTimer = 0;
    }
    drawBoard() {
      let e = this.r,
        t = ((this.bgX % 50) + 50) % 50,
        n = ((this.bgY % 50) + 50) % 50;
      for (let r = -50; r < 230; r += 50)
        for (
          let i = Math.floor(e.viewLeft / 50) * 50 - 50;
          i < e.viewRight + 50;
          i += 50
        )
          e.draw(
            `sBGBoard`,
            this.backgroundIndex,
            i + t,
            r + n,
            1,
            1,
            0,
            13882323,
          );
      this.speedMod > 1 &&
        e.rect(
          e.viewLeft,
          0,
          e.viewRight,
          180,
          15288820,
          (this.speedMod - 1) / 2.2,
        );
    }
    draw(e) {
      let t = this.r;
      t.begin(e);
      let n = new Map();
      for (let e of this.objects) {
        if (e.dead || !e.visible || !e.active) continue;
        let t = n.get(e.layer);
        (t || n.set(e.layer, (t = [])), t.push(e));
      }
      for (let e of n.values())
        e.sort((e, t) => e.sortKey() - t.sortKey() || e.order - t.order);
      let r = Pt[this.room];
      for (let e of r)
        if (e.kind === `bg`)
          (t.beginLayer(-1),
            this.drawBackground?.(),
            t.endLayer(
              -1,
              this.room === `rmGame`
                ? {
                    kind: `underwater`,
                    enabled: this.options.moving_background,
                  }
                : { kind: `none` },
              this.camX,
              this.camY,
            ));
        else if (e.kind === `vignette`) t.vignette();
        else if (e.kind === `glow`) this.godpackActive && t.glow();
        else {
          let r = n.get(e.id),
            i = this.room === `rmGame` && e.id === 7;
          if (!r && !i) continue;
          if ((t.beginLayer(e.id), t.setView(this.camX, this.camY), r))
            for (let e of r) e.draw();
          (i && this.drawCursorWorld(),
            t.setView(0, 0),
            t.endLayer(e.id, e.filter));
        }
      t.present(this.options.crt, (this.options.bulge ?? 5) / 5);
      for (let e of r) {
        if (e.kind !== `inst`) continue;
        let t = n.get(e.id);
        if (t) for (let e of t) e.drawGui();
      }
      (this.drawGuiOverlay?.(),
        this.room === `rmGame`
          ? this.drawCursorGui()
          : (this.room === `rmMenu` || this.room === `rmEnding`) &&
            (this.input.touch
              ? this.drawTouchCursor(!0, !0)
              : t.draw(`sCursor`, 0, this.input.x, this.input.y)),
        t.end());
    }
    drawGuiOverlay = null;
    drawCursorWorld() {
      let e = this.r,
        t = this.input;
      if (t.touch) {
        (this.drawTouchCursor(!1, !1),
          this.cursorImage === 1 &&
            t.touchActive &&
            e.draw(
              `sCursor`,
              1,
              t.touchX,
              t.touchY,
              this.cursorScale,
              this.cursorScale,
              Math.sin(Date.now() * 0.008) * 30,
            ));
        return;
      }
      if (this.upgrades[28].level > 0) {
        let n = Math.sin(Date.now() / 400);
        e.circle(t.x, t.y, this.up(28) * 3 + n, O.white, 1, !0);
      }
      this.cursorImage === 1 &&
        e.draw(
          `sCursor`,
          1,
          t.x,
          t.y,
          this.cursorScale,
          this.cursorScale,
          Math.sin(Date.now() * 0.008) * 30,
        );
    }
    drawCursorGui() {
      let e = this.input;
      if (e.touch) {
        this.drawTouchCursor(!0, !1);
        return;
      }
      this.cursorImage === 0 &&
        this.r.draw(`sCursor`, 0, e.x, e.y, this.cursorScale, this.cursorScale);
    }
    drawTouchCursor(e, t) {
      let n = this.input,
        r = 0;
      if (
        !n.touchActive &&
        ((r = (performance.now() - n.touchUpAt) / 260), r >= 1)
      )
        return;
      let i = 1 - (1 - r) * (1 - r),
        a = 1 - r,
        o = this.r,
        s = n.touchX,
        c = n.touchY;
      if (t || !e) {
        let e =
          ((this.room === `rmGame` && this.upgrades[28].level > 0
            ? this.up(28) * 3
            : 6) +
            Math.sin(Date.now() / 400)) *
          (1 + 0.5 * i);
        o.circle(s, c, e, O.white, a, !0);
      }
      if (e && (this.cursorImage === 0 || !n.touchActive)) {
        let e = this.cursorScale * (1 - i);
        e > 0.05 && o.draw(`sCursor`, 0, s, c, e, e, 0, O.white, a);
      }
    }
    text(e, t, n, r) {
      k(this.r, e, t, n, r);
    }
  };
function It(e) {
  let t = de();
  return Array.isArray(e)
    ? t.map((t, n) =>
        e[n]
          ? {
              ...t,
              level: e[n].level ?? 0,
              values: e[n].values ?? t.values,
              prices: e[n].prices ?? t.prices,
            }
          : t,
      )
    : t;
}
var Lt = {
    partBlister: {
      EmitCount: 1,
      DelayMin: 0,
      DelayMax: 0,
      RegionWidth: 64,
      RegionHeight: 64,
      Sprite: `sBoosterBlister`,
      Texture: -1,
      FrameIndex: 0,
      LifetimeMin: 300,
      LifetimeMax: 600,
      ScaleX: 0.6,
      ScaleY: 0.6,
      SizeMinX: 1,
      SizeMaxX: 1,
      SizeIncreaseX: 0,
      SizeWiggleX: 0,
      SizeMinY: 1,
      SizeMaxY: 1,
      SizeIncreaseY: 0,
      SizeWiggleY: 0,
      SpeedMin: 5,
      SpeedMax: 7,
      SpeedIncrease: 0,
      GravityForce: 0.3,
      GravityDirection: 270,
      DirectionMin: 80,
      DirectionMax: 100,
      OrientationMin: 0,
      OrientationMax: 0,
      OrientationIncrease: 1,
      OrientationRelative: !1,
      StartColor: 4294967295,
      AdditiveBlend: !1,
    },
    partConfettis: {
      EmitCount: 15,
      DelayMin: 0,
      DelayMax: 0,
      RegionWidth: 13.852509,
      RegionHeight: 13.852509,
      Sprite: null,
      Texture: 4,
      FrameIndex: 0,
      LifetimeMin: 60,
      LifetimeMax: 120,
      ScaleX: 0.2,
      ScaleY: 0.2,
      SizeMinX: 1,
      SizeMaxX: 1,
      SizeIncreaseX: 0,
      SizeWiggleX: 0.5,
      SizeMinY: 1,
      SizeMaxY: 1,
      SizeIncreaseY: 0,
      SizeWiggleY: 0.5,
      SpeedMin: 1,
      SpeedMax: 3,
      SpeedIncrease: 0,
      GravityForce: 0.05,
      GravityDirection: 271,
      DirectionMin: 14,
      DirectionMax: 325,
      OrientationMin: 0,
      OrientationMax: 0,
      OrientationIncrease: 0,
      OrientationRelative: !1,
      StartColor: 4294967295,
      AdditiveBlend: !1,
    },
    partImpactBig: {
      EmitCount: 35,
      DelayMin: 0,
      DelayMax: 0,
      RegionWidth: 47.185852,
      RegionHeight: 45.825302,
      Sprite: null,
      Texture: 1,
      FrameIndex: 0,
      LifetimeMin: 15,
      LifetimeMax: 80,
      ScaleX: 0.1,
      ScaleY: 0.1,
      SizeMinX: 1,
      SizeMaxX: 1,
      SizeIncreaseX: 0,
      SizeWiggleX: 0.5,
      SizeMinY: 1,
      SizeMaxY: 1,
      SizeIncreaseY: 0,
      SizeWiggleY: 0.5,
      SpeedMin: 1,
      SpeedMax: 8,
      SpeedIncrease: -0.1,
      GravityForce: 0,
      GravityDirection: 270,
      DirectionMin: 0,
      DirectionMax: 360,
      OrientationMin: 0,
      OrientationMax: 0,
      OrientationIncrease: 0,
      OrientationRelative: !1,
      StartColor: 4294967295,
      AdditiveBlend: !1,
    },
    partImpactCards: {
      EmitCount: 1,
      DelayMin: 0,
      DelayMax: 0.2,
      RegionWidth: 14.655762,
      RegionHeight: 12.090378,
      Sprite: `sCardBack`,
      Texture: -1,
      FrameIndex: 0,
      LifetimeMin: 180,
      LifetimeMax: 180,
      ScaleX: 0.3,
      ScaleY: 0.3,
      SizeMinX: 1.5,
      SizeMaxX: 1.5,
      SizeIncreaseX: 0,
      SizeWiggleX: 0,
      SizeMinY: 1.5,
      SizeMaxY: 1.5,
      SizeIncreaseY: 0,
      SizeWiggleY: 0,
      SpeedMin: 7,
      SpeedMax: 9,
      SpeedIncrease: 0,
      GravityForce: 0,
      GravityDirection: 270,
      DirectionMin: 0,
      DirectionMax: 360,
      OrientationMin: 90,
      OrientationMax: 90,
      OrientationIncrease: 0,
      OrientationRelative: !0,
      StartColor: 4294967295,
      AdditiveBlend: !1,
    },
    partImpactSmall: {
      EmitCount: 5,
      DelayMin: 0,
      DelayMax: 0,
      RegionWidth: 13.852509,
      RegionHeight: 13.852509,
      Sprite: null,
      Texture: 1,
      FrameIndex: 0,
      LifetimeMin: 15,
      LifetimeMax: 25,
      ScaleX: 0.1,
      ScaleY: 0.1,
      SizeMinX: 1,
      SizeMaxX: 1,
      SizeIncreaseX: 0,
      SizeWiggleX: 0.5,
      SizeMinY: 1,
      SizeMaxY: 1,
      SizeIncreaseY: 0,
      SizeWiggleY: 0.5,
      SpeedMin: 1,
      SpeedMax: 3,
      SpeedIncrease: -0.1,
      GravityForce: 0,
      GravityDirection: 270,
      DirectionMin: 0,
      DirectionMax: 360,
      OrientationMin: 0,
      OrientationMax: 0,
      OrientationIncrease: 0,
      OrientationRelative: !1,
      StartColor: 4294967295,
      AdditiveBlend: !1,
    },
    partMagnet: {
      EmitCount: 5,
      DelayMin: 0,
      DelayMax: 0,
      RegionWidth: 13.852509,
      RegionHeight: 13.852509,
      Sprite: null,
      Texture: 1,
      FrameIndex: 0,
      LifetimeMin: 15,
      LifetimeMax: 25,
      ScaleX: 0.1,
      ScaleY: 0.1,
      SizeMinX: 0.5,
      SizeMaxX: 1,
      SizeIncreaseX: 0,
      SizeWiggleX: 0.5,
      SizeMinY: 0.5,
      SizeMaxY: 1,
      SizeIncreaseY: 0,
      SizeWiggleY: 0.5,
      SpeedMin: 1,
      SpeedMax: 4,
      SpeedIncrease: -0.1,
      GravityForce: 0,
      GravityDirection: 270,
      DirectionMin: -10,
      DirectionMax: 10,
      OrientationMin: 0,
      OrientationMax: 0,
      OrientationIncrease: 0,
      OrientationRelative: !1,
      StartColor: 4294967295,
      AdditiveBlend: !1,
    },
    partMetallic: {
      EmitCount: 2,
      DelayMin: 0,
      DelayMax: 0,
      RegionWidth: 13.852509,
      RegionHeight: 13.852509,
      Sprite: null,
      Texture: 0,
      FrameIndex: 0,
      LifetimeMin: 15,
      LifetimeMax: 60,
      ScaleX: 1,
      ScaleY: 1,
      SizeMinX: 1,
      SizeMaxX: 1,
      SizeIncreaseX: 0,
      SizeWiggleX: 0.5,
      SizeMinY: 1,
      SizeMaxY: 1,
      SizeIncreaseY: 0,
      SizeWiggleY: 0.5,
      SpeedMin: 1,
      SpeedMax: 1,
      SpeedIncrease: -0.01,
      GravityForce: 0,
      GravityDirection: 270,
      DirectionMin: 0,
      DirectionMax: 360,
      OrientationMin: 0,
      OrientationMax: 0,
      OrientationIncrease: 0,
      OrientationRelative: !1,
      StartColor: 4294967295,
      AdditiveBlend: !1,
    },
  },
  Rt = class extends z {
    text = ``;
    prefix = ``;
    scale = 0.5;
    width = -1;
    count = 0;
    draw() {
      ((this.count += 1),
        k(
          this.g.r,
          this.x,
          this.y,
          `${this.prefix}[scale, ${this.scale}]${this.text}`,
          {
            halign: `center`,
            valign: `middle`,
            width: this.width > 0 ? this.width : void 0,
            count: this.count,
          },
        ));
    }
  },
  zt = Lt,
  Bt = [
    `pt_shape_pixel`,
    `pt_shape_disk`,
    `pt_shape_square`,
    `pt_shape_line`,
    `pt_shape_star`,
    `pt_shape_circle`,
    `pt_shape_ring`,
    `pt_shape_sphere`,
    `pt_shape_flare`,
    `pt_shape_spark`,
    `pt_shape_explosion`,
    `pt_shape_cloud`,
    `pt_shape_smoke`,
    `pt_shape_snow`,
  ],
  Vt = {
    impactSmall: `partImpactSmall`,
    impactBig: `partImpactBig`,
    impactCards: `partImpactCards`,
    blister: `partBlister`,
    magnet: `partMagnet`,
    metallic: `partMetallic`,
    confettis: `partConfettis`,
  },
  Ht = (e, t) => e + Math.random() * (t - e),
  Ut = class extends z {
    em;
    parts = [];
    color;
    sysAlpha;
    sprite2;
    age = 0;
    constructor(e, t, n, r, i = 0, a = 16777215, o = 1) {
      (super(e, t, n),
        (this.em = zt[r] ?? zt.partImpactSmall),
        (this.color = a),
        (this.sysAlpha = o));
      let s = this.em;
      this.sprite2 = s.Sprite ?? Bt[Math.max(0, s.Texture)] ?? `pt_shape_disk`;
      for (let e = 0; e < s.EmitCount; e++) {
        let e = Ht(s.DirectionMin, s.DirectionMax) + i;
        this.parts.push({
          x: t + Ht(-s.RegionWidth / 2, s.RegionWidth / 2),
          y: n + Ht(-s.RegionHeight / 2, s.RegionHeight / 2),
          speed: Ht(s.SpeedMin, s.SpeedMax),
          dir: e,
          gx: 0,
          gy: 0,
          sx: Ht(s.SizeMinX, s.SizeMaxX),
          sy: Ht(s.SizeMinY, s.SizeMaxY),
          orient: s.OrientationRelative
            ? e + Ht(s.OrientationMin, s.OrientationMax)
            : Ht(s.OrientationMin, s.OrientationMax),
          life: Math.round(Ht(s.LifetimeMin, s.LifetimeMax)),
          delay: Math.round(Ht(s.DelayMin, s.DelayMax) * 60),
          ran: Math.random() * 1e3,
        });
      }
    }
    step() {
      this.age++;
      let e = this.em,
        t = (e.GravityDirection * Math.PI) / 180;
      for (let n of this.parts) {
        if (n.delay > 0) {
          n.delay--;
          continue;
        }
        let r = (n.dir * Math.PI) / 180;
        ((n.x += Math.cos(r) * n.speed + n.gx),
          (n.y -= Math.sin(r) * n.speed - n.gy),
          (n.gx += Math.cos(t) * e.GravityForce),
          (n.gy -= Math.sin(t) * e.GravityForce),
          (n.speed = Math.max(0, n.speed + e.SpeedIncrease)),
          (n.sx = Math.max(0, n.sx + e.SizeIncreaseX)),
          (n.sy = Math.max(0, n.sy + e.SizeIncreaseY)),
          (n.orient += e.OrientationIncrease),
          n.life--);
      }
      ((this.parts = this.parts.filter((e) => e.life > 0)),
        (this.parts.length === 0 || this.age >= 60) && this.destroy());
    }
    draw() {
      let e = this.em;
      for (let t of this.parts) {
        if (t.delay > 0) continue;
        let n = Math.sin((this.age + t.ran) * 0.4),
          r = (t.sx + e.SizeWiggleX * n) * e.ScaleX,
          i = (t.sy + e.SizeWiggleY * n) * e.ScaleY;
        this.g.r.draw(
          this.sprite2,
          e.FrameIndex,
          t.x,
          t.y,
          r,
          i,
          t.orient,
          this.color,
          this.sysAlpha,
        );
      }
    }
  },
  Wt = class extends z {
    color = 16777215;
    a = 0.4;
    step() {
      ((this.a += (0 - this.a) * 0.04), this.a <= 0.01 && this.destroy());
    }
    draw() {
      this.g.r.rect(-120, -50, 440, 230, this.color, this.a);
    }
  };
function Gt(e) {
  ((e.popup = (t, n, r, i, a, o, s = -1, c = I.Text) => {
    let l = e.add(new Rt(e, t, n), c);
    ((l.text = r),
      (l.prefix = i),
      (l.scale = a),
      (l.width = s),
      e.later(o, `seconds`, () => l.destroy(), !1, l));
  }),
    (e.particle = (t, n, r, i = 16777215, a = I.Particles, o = 1, s = 0) => {
      e.add(new Ut(e, n, r, Vt[t] ?? t, s, i, o), a);
    }),
    (e.flash = (t = 16777215, n = I.InstancesBottom) => {
      if (!e.options.flash) return;
      let r = e.add(new Wt(e, 0, 0), n);
      r.color = t;
    }));
}
var Kt = class extends z {
    name;
    xx;
    yy;
    lastXX;
    lastYY;
    roomX;
    roomY;
    title = ``;
    titleKey = ``;
    titleShadowOffset = 5;
    canSound = !1;
    funcDraw = null;
    constructor(e, t, n, r, i, a, o) {
      (super(e, n, r),
        (this.name = t),
        (this.roomX = n),
        (this.roomY = r),
        (this.xx = this.lastXX = n),
        (this.yy = this.lastYY = r),
        (this.xs = i),
        (this.ys = a),
        (this.blend = o),
        (this.sprite = `sUICadre`),
        (this.layer = I.Handler),
        e.later(2, `seconds`, () => (this.canSound = !0)));
    }
    w() {
      return 20 * this.xs;
    }
    h() {
      return 20 * this.ys;
    }
    step() {
      let e = this.g.r.padX,
        t = this.xx;
      if (
        (t + this.w() <= 0 ? (t -= e) : t >= 320 && (t += e),
        (this.x = N(this.x, t, 0.2)),
        (this.y = N(this.y, this.yy, 0.2)),
        this.lastXX !== this.xx || this.lastYY !== this.yy)
      ) {
        if (this.canSound) {
          let e = (e, t) => Math.hypot(e - 160, t - 90);
          e(this.xx, this.yy) < e(this.lastXX, this.lastYY)
            ? this.g.sfx(`sndWooshEnter`, 0.4, 0.5, !1, !1)
            : this.g.sfx(`sndWooshExit`, 0.5, 1, !1, !1);
        }
        ((this.lastXX = this.xx), (this.lastYY = this.yy));
      }
      this.alpha = 0.9;
    }
    pointIn(e, t) {
      return (
        e >= this.x &&
        e <= this.x + this.w() &&
        t >= this.y &&
        t <= this.y + this.h()
      );
    }
    draw() {
      this.drawSelf();
      let n = this.name === `upgrades`;
      n && this.funcDraw?.();
      let e = this.titleKey ? this.g.L(this.titleKey) : this.title;
      if (e) {
        let t =
          this.x +
          10 * this.xs +
          (this.name === `collection` ? 0 : this.titleShadowOffset);
        it(this.g.r, t, this.y + 8, `[wave][scale, .5]${e}`);
      }
      n || this.funcDraw?.();
    }
  },
  qt = class extends z {
    handler = null;
    hx = 0;
    hy = 0;
    link(e) {
      ((this.handler = Jt(this.g, e)),
        this.handler &&
          ((this.hx = this.handler.roomX), (this.hy = this.handler.roomY)));
    }
    linkNow(e) {
      ((this.handler = Jt(this.g, e)),
        this.handler &&
          ((this.hx = this.handler.x), (this.hy = this.handler.y)));
    }
    handlerLink() {
      let e = this.handler;
      !e ||
        e.dead ||
        ((this.x = N(this.x, this.xstart + (e.x - this.hx), 0.3)),
        (this.y = N(this.y, this.ystart + (e.y - this.hy), 0.3)));
    }
  };
function Jt(e, t) {
  return e.all(Kt).find((e) => e.name === t) ?? null;
}
function Yt(e, t, n) {
  return e.all(Kt).some((e) => e.pointIn(t, n));
}
function Xt(e, t = 1, n = 0) {
  let r = e.mouseHover(),
    i = r ? 1.2 : 1,
    a = r ? -20 : 0;
  ((e.xs = N(e.xs, i * t, 0.3)),
    (e.ys = N(e.ys, i * t, 0.3)),
    (e.angle = N(e.angle, a + n, 0.3)));
}
function Zt(e, t = !1) {
  let n = e.g,
    r = n.input;
  return !(
    !(r.leftPressed || n.autoClick) ||
    !e.contains(r.x, r.y, n.up(28) * 3) ||
    (t && Yt(n, r.x, r.y))
  );
}
function Qt(e, t, n = 1) {
  let r = e.g.r;
  for (let [i, a] of [
    [-n, 0],
    [n, 0],
    [0, -n],
    [0, n],
  ])
    r.draw(e.sprite, e.frame, e.x + i, e.y + a, e.xs, e.ys, e.angle, t, 1, 7);
}
var $t = [[`KeyQ`, `KeyA`], [`KeyW`, `KeyZ`], [`KeyE`], [`KeyR`]],
  en = [
    [`shop`, `xx`, -2, -350],
    [`duplicate`, `xx`, -10, -200],
    [`collection`, `yy`, 30, 2100],
    [`upgrades`, `yy`, 30, 200],
  ],
  tn = class e extends z {
    ID;
    isSelected = !1;
    onToggle = null;
    constructor(e, t, n, r) {
      (super(e, t, n),
        (this.ID = r),
        (this.sprite = `sUIOngletsIcon`),
        (this.frame = r),
        (this.layer = I.UI),
        (this.visible = e.stats.UI_unlock[r + 1]));
    }
    inputSprite() {
      return this.g.options.keyboard === `qwerty`
        ? `sUITutorialInput2`
        : `sUITutorialInput`;
    }
    mouse() {
      let e = this.g.input;
      e.leftPressed &&
        this.isSelected &&
        !Yt(this.g, e.x, e.y) &&
        ((this.isSelected = !1), this.g.cameraShake(3));
    }
    step() {
      let [t, n, r, i] = en[this.ID],
        a = Jt(this.g, t);
      ((this.blend = this.isSelected ? O.ltgray : O.white),
        a && (a[n] = this.isSelected ? r : i),
        Xt(this, 1, 0),
        (this.x = N(this.x, this.xstart, 0.2)),
        (this.y = N(this.y, this.ystart, 0.2)));
      let o = this.g.input;
      if (
        ($t[this.ID].some((e) => o.keysPressed.has(e)) ||
          (this.mouseHover() && o.leftPressed)) &&
        this.visible &&
        !this.g.moduleOpen()
      ) {
        if (this.isSelected) this.isSelected = !1;
        else {
          for (let t of this.g.all(e)) t.isSelected = !1;
          ((this.isSelected = !0), (this.xs *= 2), (this.ys *= 2));
        }
        (this.g.cameraShake(5, !1),
          this.g.sfx(`sndClick1`, 1, 0.8 + this.ID * 0.2),
          this.onToggle?.(),
          this.g.ongletsInputs++);
      }
      this.frame = this.ID;
    }
    draw() {
      let e = this.g.r,
        t = this.mouseHover();
      (t &&
        this.g.ongletsInputs < 20 &&
        !this.g.input.touch &&
        e.draw(this.inputSprite(), this.ID, this.x, this.y + 15),
        t && Qt(this, O.white));
      let n = yt(this.g.cards) / Math.max(1, this.g.up(6));
      if (
        ((n < 1 || this.ID !== 1) && this.drawSelf(),
        this.ID === 1 && !t && this.xs <= 1.1)
      ) {
        let t = N(16, 4, lt(n, 0, 1));
        e.drawPart(
          this.sprite,
          this.frame,
          0,
          0,
          100,
          t,
          this.x - 10,
          this.y - 10,
          1,
          1,
          O.dkgray,
          0.5,
        );
      }
      n >= 1 &&
        this.ID === 1 &&
        ((this.x += Math.random() * 2 - 1),
        (this.y += Math.random() * 2 - 1),
        (this.blend = O.redSoft),
        this.drawSelf());
    }
  },
  nn = class extends qt {
    show = 0;
    scale = 0.5;
    hist = [];
    histX = 0;
    constructor(e, t, n) {
      (super(e, t, n),
        (this.layer = I.UI),
        (this.histX = t - 5),
        this.link(`money`),
        (this.alarm[1] = 120),
        (e.moneyHist = (e, t) => this.push(e, t)));
    }
    push(e, t) {
      let n = this.hist[this.hist.length - 1];
      if (n && n.group === t) {
        let t = e / (n.quantity || 1);
        ((n.quantity += e),
          this.hist.length === 1 &&
            (n.nbAdd++, (this.alarm[0] += 60 * lt(t, 0.5, 3))));
      } else
        (this.hist.push({ quantity: e, group: t, nbAdd: 0 }),
          this.alarm[0] <= -1 && (this.alarm[0] = 180),
          this.hist.length > 10 && this.hist.splice(this.hist.length - 1, 1));
      this.histX -= 10;
    }
    onAlarm(e) {
      e === 0 &&
        this.hist.length > 0 &&
        (this.hist.splice(0, 1),
        (this.alarm[0] = 60 * (this.hist.length > 3 ? 0.1 : 1.5)));
    }
    step() {
      (this.hist.length <= 0 && (this.alarm[0] = -1),
        this.alarm[0] > 180 && (this.alarm[0] = 180));
    }
    drawGui() {
      let e = this.g;
      if (!(this.alarm[1] <= 0 && e.stats.UI_unlock[0])) return;
      this.handlerLink();
      let t = Math.floor(e.stats.money) > e.stats.money_max;
      ((this.show = N(this.show, e.stats.money, 0.5)),
        Math.abs(this.show - e.stats.money) < 0.01 &&
          (this.show = e.stats.money),
        (this.scale = N(this.scale, 0.4, 0.2)),
        (this.histX = N(this.histX, this.x - 5, 0.3)),
        t && (e.stats.money = N(e.stats.money, e.stats.money_max, 0.1)));
      let n = P(ct(this.show)),
        r = { halign: `right`, valign: `top` },
        i = this.x - e.camX,
        a = this.y - e.camY;
      for (let t = this.hist.length - 1; t >= 0; t--) {
        let n = this.hist[t],
          i = `[scale, ${this.scale}]${n.quantity >= 0 ? `+` : ``}${P(n.quantity)}`,
          o = (t === this.hist.length - 1 ? this.histX : this.x - 5) - e.camX,
          s = n.quantity >= 0 ? `[d#6946705]` : `[d#6184703]`,
          c = a + 10 - 7 + (this.hist.length - 1 - t) * 8;
        (k(e.r, o + 1, c + 1, `[c_black][alpha, .7]${i} $`, r),
          k(e.r, o, c, `${s}${i} [d#9240561]$`, r));
      }
      k(
        e.r,
        i + 1,
        a + 1 - 7,
        `[c_black][alpha, .5][scale, ${this.scale}]${n} $`,
        r,
      );
      let o = t ? `d#6184703` : `c_white`;
      k(e.r, i, a - 7, `[${o}][scale, ${this.scale}]${n} [d#9240561]$`, r);
    }
  },
  rn = class extends qt {
    func = () => {};
    name = ``;
    angleTo = 0;
    activate = !0;
    constructor(e, t, n, r, i, a) {
      (super(e, t, n),
        (this.sprite = `sUIButton`),
        (this.frame = r),
        (this.blend = i),
        (this.layer = I.UI),
        this.link(a));
    }
    mouse() {
      this.activate &&
        this.g.input.leftPressed &&
        this.mouseHover() &&
        (this.func(),
        (this.xs *= 3),
        (this.ys *= 3),
        this.g.cameraShake(5, !1),
        this.g.sfx(`sndBarTick`, 0.6, 1, !0, !1));
    }
    step() {
      (this.handlerLink(),
        Xt(this, 1, this.angleTo),
        !this.activate && this.g.up(39) && (this.activate = !0));
    }
    draw() {
      this.activate &&
        (this.drawSelf(),
        this.mouseHover() &&
          this.name &&
          k(
            this.g.r,
            this.x,
            this.y + (this.y < 30 ? 15 : -15),
            `[${this.x < 50 ? `fa_left` : `fa_center`}][scale, .5]${this.name}`,
            { valign: `middle` },
          ));
    }
  },
  an = class extends z {
    isActive = !1;
    nbAlert = 5;
    nbAlertI = 5;
    constructor(e, t, n) {
      (super(e, t, n),
        (this.sprite = `sAlarm`),
        (this.layer = I.InstancesTop),
        e.later(0.2, `seconds`, () => this.tick(), !0, this));
    }
    tick() {
      this.isActive &&
        this.alarm[0] <= 0 &&
        ((this.frame = +(this.frame === 0)),
        this.frame === 1 &&
          (this.nbAlertI--,
          this.nbAlertI > 0
            ? ((this.angle += Math.random() < 0.5 ? -20 : 20),
              this.g.popup(
                this.x + (Math.random() * 40 - 20),
                this.y + 10,
                `!`,
                `[shake][d#6184703]`,
                0.4,
                1,
              ),
              this.g.sfx(`sndBarTick`, 1, 2, !1, !0))
            : (this.frame = 0)),
        this.nbAlertI <= 0 &&
          ((this.alarm[0] = 300),
          (this.nbAlertI = this.nbAlert),
          (this.isActive = !1),
          (this.frame = 0)));
    }
    step() {
      ((this.g.up(65) === 0 || this.alarm[0] > 0) && (this.isActive = !1),
        this.isActive
          ? ((this.y = N(this.y, 14, 0.3)),
            (this.ys = N(this.ys, 1, 0.1)),
            (this.alpha = N(this.alpha, 1, 0.2)),
            (this.angle = N(this.angle, 0, 0.1)))
          : ((this.y = N(this.y, 4, 0.3)),
            (this.ys = N(this.ys, 0.5, 0.1)),
            (this.alpha = 0)));
    }
  };
function on(e) {
  if (e.up(65) !== 0) for (let t of e.all(an)) t.isActive = !0;
}
var sn = {
    shop: D(5801062),
    bar: D(7368816),
    duplicate: D(4689550),
    collection: D(8545871),
    upgrades: D(8539010),
  },
  cn = [`MODULE_LAB`, `MODULE_MEMORY`, `MODULE_ARENA`, `MODULE_MUSEUM`],
  ln = [10724259, 9411174, 5263561, 4486033],
  B = 6946705,
  un = 6184703;
function dn(e) {
  return Jt(e, `module`);
}
function fn(e, t) {
  let n = dn(e);
  n && ((n.xx += t ? -285 : 285), e.cameraShake(5, !1));
}
function pn(e) {
  let t = dn(e);
  t && (t.xx += 285);
}
function mn(e, t = ``, n = 4210752) {
  let r = dn(e);
  r && ((r.titleKey = t), (r.blend = D(n)));
}
function hn(e, t = 0, n = 0) {
  let r = dn(e);
  return { x: r.x + r.w() / 2 + t, y: r.y + r.h() / 2 + n };
}
function gn(e) {
  for (let t of e.all(rn)) t.handler?.name === `module` && t.destroy();
}
function _n(e) {
  let t = st(gt(e.cards)),
    n = 0;
  for (; n < 30 && t.length && !e.stats.legacy_mode && t[0].type === 6;)
    ((t = st(gt(e.cards))), n++);
  return t[0];
}
function vn(e) {
  return st(_t(e.cards))[0];
}
function yn(e, t) {
  if ((e.closeOnglets(), t === 0)) {
    e.add(new Cn(e, 385, 60), I.UI);
    let t = e.add(new rn(e, 564, 158, 1, D(un), `module`));
    t.func = () => e.all(Cn).forEach((e) => e.pickTarget());
    let n = e.add(new rn(e, 589, 158, 2, D(B), `module`));
    n.func = () => e.all(Cn).forEach((e) => e.launch());
  } else
    t === 1
      ? e.add(new On(e, 385, 60), I.UI)
      : t === 2
        ? e.add(new An(e, 385, 60), I.UI)
        : e.add(new Mn(e, 385, 60), I.UI);
  (fn(e, !0), mn(e, cn[t], ln[t]));
}
function bn(e) {
  return (
    e.all(Cn).some((e) => !e.isActivate) ||
    e.count(On) > 0 ||
    e.count(An) > 0 ||
    e.count(Mn) > 0
  );
}
var xn = class e extends qt {
    ID;
    isLock = !0;
    size = 1.5;
    infoLerp = 0;
    price;
    constructor(e, t, n, r) {
      (super(e, t, n),
        (this.ID = r),
        (this.sprite = `sModule`),
        (this.frame = r),
        (this.layer = I.Handler),
        (this.order = 1100 + r),
        (this.xs = this.ys = 1.5),
        (this.price = Dt(e.stats.modules_price[r])),
        this.link(`shop`));
    }
    userEvent0() {
      let t = this.g;
      if (this.isLock || t.godpackActive) return;
      let n = t.stats.money >= this.price || this.price === 0,
        r = gt(t.cards).length > 0 || this.ID === 3;
      if ((this.ID === 3 && xt(t.cards) <= 5 && (r = !1), this.alarm[0] <= 0)) {
        if (n && r) {
          let n = t.stats.modules_price;
          (t.moneyAdd(-this.price, !0, `module`),
            (this.alarm[0] = kt(n[this.ID])),
            t.sfx(`sndClick1`, 1, 1, !0, !1),
            t.sfx(`sndMoney1`, 1, 1, !1, !1),
            t.cameraShake(5, !1),
            (n[this.ID] = Ot(t.upgrades, this.ID, n[this.ID])),
            (this.price = Dt(n[this.ID])),
            t.later(0.1, `seconds`, () => yn(t, this.ID)));
          for (let n of t.all(e)) n.alarm[0] <= 600 && (n.alarm[0] = 600);
        } else if (!r) {
          (t.popup(
            320 / 2,
            180 / 2,
            t.L(`UI_MODULE_FULL`),
            `[d#${un}][shake]`,
            0.5,
            1.5,
            -1,
            I.TextUp,
          ),
            t.cameraShake(10, !1),
            t.sfx(`sndWrong1`, 0.8, 1, !0, !1));
          return;
        }
      } else ((this.alarm[0] -= 60), t.sfx(`sndClick1`, 1, 1.5));
      ((this.xs *= 1.3),
        (this.ys *= 1.3),
        (this.angle += 30),
        t.particle(`impactSmall`, this.x, this.y, 16777215, I.ParticlesUp));
    }
    step() {
      let e = this.g;
      this.handlerLink();
      let t = this.isLock;
      ((this.isLock = e.up(this.ID + 55) === 0),
        t !== this.isLock && (this.price = Dt(e.stats.modules_price[this.ID])),
        (this.y =
          this.ystart +
          (this.handler ? this.handler.y - this.hy : 0) +
          4 * Math.sin(Date.now() / 500)),
        (this.blend = this.alarm[0] <= 0 && !this.isLock ? O.white : O.dkgray),
        Xt(this, this.size, 10 * Math.sin(Date.now() / 400)),
        !this.isLock && Zt(this) && this.userEvent0());
    }
    draw() {
      if (this.isLock) return;
      let e = this.g,
        t = e.r,
        n = e.stats.money >= this.price || this.price <= 0;
      (t.draw(
        this.sprite,
        this.ID,
        this.x + 2,
        this.y + 2,
        this.xs,
        this.ys,
        this.angle,
        O.black,
        0.5,
      ),
        t.draw(
          this.sprite,
          this.ID,
          this.x,
          this.y,
          this.xs,
          this.ys,
          this.angle,
          this.blend,
          1,
          je.module,
        ));
      let r = this.mouseHover();
      (r && Qt(this, O.white, 2),
        (this.infoLerp = N(this.infoLerp, +!!r, 0.5)));
      let i = this.ystart + (this.handler ? this.handler.y - this.hy : 0) + 35;
      (k(
        t,
        this.x + 1,
        i + 1,
        `[scale, .5][wave][c_black][alpha, .5]${P(this.price)}$`,
      ),
        k(
          t,
          this.x,
          i,
          `[scale, .5][wave][${n ? `c_white` : `d#${un}`}]${P(this.price)}$`,
        ),
        this.alarm[0] > 0 &&
          k(t, this.x, this.y, `[scale, .5]${Math.floor(this.alarm[0] / 60)}`));
    }
    drawGui() {
      if (this.isLock || !this.mouseHover()) return;
      let e = this.g,
        t = [`LAB`, `MEMORY`, `ARENA`, `MUSEUM`],
        n = 75 * this.infoLerp;
      (Gr(
        e,
        50,
        n - 50,
        80,
        120,
        16777215,
        4210752,
        90,
        n - 42,
        `[scale, .35]${e.L(`UPGRADE_0${this.ID + 55}_NAME`)}`,
      ),
        Gr(
          e,
          55,
          n - 30,
          70,
          95,
          16777215,
          16777215,
          90,
          n - 30,
          `[scale, .32][c_black][fa_top]${rr(e, e.L(`MODULE_${t[this.ID]}_DESC`))}`,
        ));
    }
  },
  Sn = class extends qt {
    card;
    type = 0;
    price = 0;
    isLock = !0;
    isVisible = !1;
    size = 0.6;
    constructor(e, t, n) {
      (super(e, t, n),
        (this.card = e.cards[0]),
        (this.sprite = `sCardBase`),
        (this.layer = I.Handler),
        (this.order = 1050),
        (this.xs = this.ys = 0.5),
        (this.alarm[0] = 6),
        this.link(`shop`));
    }
    onAlarm(e) {
      if (e !== 0) return;
      let t = this.g;
      if (((this.alarm[0] = 3600), !this.isVisible)) return;
      let n = st(t.cards.filter((e) => e.activate));
      n.length &&
        ((this.isLock = !1),
        (this.card = n[0]),
        (this.type = 1 + A((t.stats.legacy_mode ? 6 : 5) - 1)),
        (this.price = Math.abs(t.price(this.card.ID, this.type)) * 3.5));
    }
    step() {
      let e = this.g;
      if (
        (this.handlerLink(),
        (this.isVisible = e.up(34) > 0),
        (this.y =
          this.ystart +
          (this.handler ? this.handler.y - this.hy : 0) +
          4 * Math.sin(Date.now() / 500)),
        Xt(this, this.size, 10 * Math.sin(Date.now() / 400)),
        this.isVisible &&
          !this.isLock &&
          Zt(this) &&
          e.stats.money >= this.price)
      ) {
        (e.moneyAdd(-this.price, !0, `shop`), (this.isLock = !0));
        let t = Zn(e, this.card, 60, this.type);
        ((t.typeLock = !0),
          (this.xs += 0.3),
          (this.ys += 0.3),
          (this.angle += 30),
          e.particle(
            `impactSmall`,
            e.input.x,
            e.input.y,
            16777215,
            I.Particles,
          ),
          e.cameraShake(8),
          e.popup(
            this.x,
            this.y,
            `Good deal... [c_white][sUIDealer]`,
            `[d#${B}][wave]`,
            0.5,
            2,
          ),
          e.sfx(`sndClick1`, 1, 1, !0),
          e.sfx(`sndMoney1`));
      }
    }
    draw() {
      if (!this.isVisible) return;
      let e = this.g,
        t = e.r,
        n = e.cards[this.card.ID].stars;
      if (this.isLock)
        Hn(
          e,
          this.card.ID,
          n,
          0,
          this.x,
          this.y,
          this.xs,
          this.ys,
          this.angle,
          O.dkgray,
        );
      else {
        let r = e.stats.money >= this.price || this.price <= 0;
        (t.draw(
          this.sprite,
          0,
          this.x + 2,
          this.y + 2,
          this.xs,
          this.ys,
          this.angle,
          O.black,
          0.5,
        ),
          this.mouseHover() && Qt(this, O.white, 2),
          Hn(
            e,
            this.card.ID,
            n,
            this.type,
            this.x,
            this.y,
            this.xs,
            this.ys,
            this.angle,
          ));
        let i =
          this.ystart + (this.handler ? this.handler.y - this.hy : 0) + 35;
        (k(
          t,
          this.x + 1,
          i + 1,
          `[scale, .5][wave][c_black][alpha, .5]${P(this.price)}$`,
        ),
          k(
            t,
            this.x,
            i,
            `[scale, .5][wave][${r ? `c_white` : `d#${un}`}]${P(this.price)}$`,
          ),
          e.cards[this.card.ID].quantity[this.type] === -1 &&
            k(
              t,
              this.x,
              this.y - 20,
              `[scale, .5][wave][d#${B}]${e.L(`UI_NEW`)}`,
            ));
      }
    }
  },
  Cn = class e extends qt {
    isActivate = !1;
    isImpossible = !1;
    stock = [0, 0, 0, 0, 0, 0, 0];
    percentI = 0;
    percent = 0;
    nbRequired = 2;
    barY;
    cloneID = 0;
    cloneType = 0;
    constructor(t, n, r) {
      (super(t, n, r),
        (this.barY = t.count(e) * 15),
        this.link(`module`),
        (this.alarm[1] = 60),
        t.later(1, `seconds`, () => this.pickTarget(), !1, this),
        t.audio.playTrack(`mscModuleLab`, 1, !0));
    }
    pickTarget() {
      let e = this.g;
      if (this.isActivate || this.isImpossible) return;
      let t = gt(e.cards);
      if (t.length <= 0) return this.impossible();
      t = st(t);
      let n = t[0],
        r = 0;
      for (; n.type === 0 || n.type > e.up(61);)
        if (((t = st(t)), (n = t[0]), ++r >= 250)) return this.impossible();
      ((this.cloneID = n.ID), (this.cloneType = n.type));
    }
    launch() {
      let e = this.g;
      if (this.isActivate || this.isImpossible) return;
      this.isActivate = !0;
      let t = hn(e);
      (e.popup(
        t.x,
        t.y,
        `${e.L(`MODULE_LAB_LAUNCH`)} !`,
        `[shake][d#${B}]`,
        0.6,
        2,
        -1,
        I.TextUp,
      ),
        e.later(2, `seconds`, () => {
          (pn(e), gn(e));
        }),
        e.cameraShake(20, !1),
        e.flash(16777215),
        e.sfx(`sndExplosion1`, 0.8, 0.8, !1, !1),
        e.sfx(`sndModuleLabLaunched`, 0.9, 0.9, !1, !1),
        e.audio.stopTrack(`mscModuleLab`));
    }
    impossible() {
      let e = this.g,
        t = hn(e);
      ((this.isImpossible = !0),
        e.cameraShake(10, !1),
        e.sfx(`sndWrong1`, 1, 1, !1, !1),
        e.popup(
          t.x,
          t.y,
          e.L(`UI_DESTROYED_NOCARD`),
          `[shake][d#${un}]`,
          0.5,
          2,
          -1,
          I.TextUp,
        ),
        e.later(2, `seconds`, () => pn(e)),
        e.later(3, `seconds`, () => {
          (this.destroy(), gn(e));
        }),
        e.audio.stopTrack(`mscModuleLab`));
    }
    onAlarm(e) {
      if (e !== 1) return;
      let t = this.g;
      if (((this.alarm[1] = 60), this.isActivate && t.count(Dn) === 0))
        for (let e = 0; e < this.cloneType; e++) {
          let n = e === this.cloneType - 1;
          if (this.stock[e] >= this.nbRequired) {
            (this.stock[e + 1]++,
              (this.stock[e] -= this.nbRequired),
              e >= Math.max(0, this.cloneType - 1)
                ? En(t, this.cloneID, e, n)
                : (this.alarm[1] = 1),
              n &&
                ((this.alarm[1] = 3e3),
                t.later(3, `seconds`, () => {
                  let e = Zn(t, t.cards[this.cloneID], 60, this.cloneType);
                  ((e.typeLock = !0), this.destroy());
                })));
            break;
          }
        }
      let n = this.nbRequired ** +this.cloneType,
        r = 0;
      for (let e = 0; e <= this.cloneType; e++)
        r += this.stock[e] * this.nbRequired ** +e;
      this.percent = n > 0 ? r / n : 0;
    }
    onDestroy() {
      for (let t of this.g.all(e)) t.barY > this.barY && (t.barY -= 15);
    }
    step() {
      (this.handlerLink(),
        (this.percentI = N(this.percentI, Math.min(1, this.percent), 0.1)));
    }
    draw() {
      let e = this.g,
        t = e.r;
      if (this.isImpossible) return;
      let n = e.cards[this.cloneID];
      if (this.isActivate)
        (t.draw(`sUIBar`, 0, 234, 8 + this.barY, 8, 1, 0, O.ltgray),
          t.draw(
            `sUIBar`,
            0,
            234,
            8 + this.barY,
            8 * this.percentI,
            1,
            0,
            D(8212525),
          ),
          t.draw(
            `sCardArt${this.cloneID}`,
            0,
            234,
            10 + this.barY,
            0.5,
            0.5,
            Math.sin(Date.now() * 0.001) * 30,
            O.white,
            1,
            Me(this.cloneType),
          ));
      else {
        let r = Math.sin(Date.now() * 0.008) * 5,
          i = this.x,
          a = this.y;
        (k(
          t,
          i - 30,
          a + 90 - 30,
          `[scale, .5][fa_left][d#9240561]${e.L(`MODULE_LAB_OUTPUT`)}`,
        ),
          Hn(
            e,
            this.cloneID,
            n.stars,
            this.cloneType,
            i,
            a + 90,
            0.5,
            0.5,
            Math.sin(Date.now() * 0.001) * 10,
          ),
          k(t, i + 40, a + 90, `[scale, .5][wave][d#${B}]${e.L(`UI_NEW`)}`),
          t.draw(`sUIButton`, 0, i - 25 + r, a + 90),
          k(
            t,
            i - 30,
            a + -10,
            `[scale, .5][fa_left][d#9240561]${e.L(`MODULE_LAB_INPUTS`)}`,
          ));
        for (let r = 0; r < this.cloneType; r++) {
          let o = Math.sin(Date.now() * 0.006) * 2,
            s = i - 10 + r * 40,
            c = a + -10 + 30;
          (Hn(
            e,
            this.cloneID,
            n.stars,
            r,
            s,
            c,
            0.5,
            0.5,
            Math.sin(Date.now() * 0.001) * 10,
          ),
            k(
              t,
              s,
              c + 25,
              `[scale, .5][fa_center]X${this.nbRequired ** +(this.cloneType - r)}`,
            ),
            t.draw(`sUIButton`, 0, s + 18 + o, c));
        }
      }
    }
  };
function wn(e, t, n) {
  return e.all(Cn).find((e) => e.cloneID === t && e.cloneType > n) ?? null;
}
function Tn(e, t, n) {
  return e.all(Cn).some((e) => e.cloneID === t && e.cloneType === n);
}
function En(e, t, n, r) {
  let i = e.count(Dn) > 0 ? 50 + A(250) : 158;
  e.add(new Dn(e, i, 133, t, n, r), I.UI2);
}
var Dn = class extends z {
    id;
    type;
    finish;
    stepN = 0;
    alphaBg = 0;
    constructor(e, t, n, r, i, a) {
      (super(e, t, n),
        (this.id = r),
        (this.type = i),
        (this.finish = a),
        (this.sprite = `sScientist`),
        (this.y += 200),
        e.later(
          1,
          `seconds`,
          () => {
            ((this.stepN = 1),
              (this.frame = 1),
              (this.y -= 30),
              (this.xs *= 0.7),
              (this.angle -= 15),
              e.sfx(`sndHover`, 1, 1.5, !1, !1));
          },
          !1,
          this,
        ),
        e.later(
          1.5,
          `seconds`,
          () => {
            ((this.stepN = 2),
              (this.frame = 2),
              (this.y -= 30),
              (this.xs *= 0.7),
              (this.angle += 15),
              e.sfx(`sndHover`, 1, 1.8, !1, !1));
          },
          !1,
          this,
        ),
        e.later(
          2,
          `seconds`,
          () => {
            ((this.stepN = 4),
              (this.frame = 3),
              (this.ystart += 50),
              e.flash(16777215),
              e.cameraShake(15, !1),
              e.sfx(`sndExplosion1`, 1, 0.5, !1, !1),
              e.sfx(`sndCardNotnew`, 1, 0.7, !0, !1),
              e.particle(`impactBig`, this.x, this.y - 50, 16777215, I.UI2),
              this.finish &&
                (e.sfx(`sndCardNew0`, 1, 0.5, !1, !1),
                e.popup(
                  this.x,
                  this.y - 80,
                  e.L(`MODULE_LAB_FINISHED`),
                  `[d#${B}][wave]`,
                  0.6,
                  2,
                  -1,
                  I.TextUp,
                )));
          },
          !1,
          this,
        ),
        e.later(
          4,
          `seconds`,
          () => {
            ((this.stepN = 5),
              (this.frame = 0),
              (this.ystart = 300),
              e.sfx(`sndWooshExit`, 1, 1, !1, !1));
          },
          !1,
          this,
        ),
        e.sfx(`sndWooshEnter`, 1, 1, !1, !1));
    }
    step() {
      ((this.x = N(this.x, this.xstart, 0.1)),
        (this.angle = N(this.angle, 0, 0.2)),
        (this.y = N(this.y, this.ystart, 0.2)),
        (this.xs = N(this.xs, 2, 0.2)),
        (this.ys = N(this.ys, 2, 0.2)),
        (this.alphaBg = N(this.alphaBg, this.stepN === 5 ? 0 : 0.5, 0.2)),
        this.stepN === 5 && this.y - 82 * this.ys > 180 && this.destroy());
    }
    draw() {
      let e = this.g;
      (e.r.rect(
        e.r.viewLeft - 10,
        -10,
        e.r.viewRight + 10,
        190,
        O.black,
        this.alphaBg,
      ),
        this.drawSelf());
      let t = Math.sin(Date.now() * 0.01) * 0.2,
        n = e.cards[this.id].stars;
      ((this.stepN === 1 || this.stepN === 2) &&
        Hn(e, this.id, n, this.type, this.x - 50, this.y - 20, 0.6, 0.6),
        this.stepN === 2 &&
          Hn(e, this.id, n, this.type, this.x + 50, this.y - 20, 0.6, 0.6),
        this.stepN === 4 &&
          Hn(
            e,
            this.id,
            n,
            this.type + 1,
            this.x,
            this.y - 100,
            0.8 + t,
            0.8 + t,
          ));
    }
  },
  On = class extends qt {
    nbTryMax;
    nbTry;
    canFlip = !0;
    constructor(e, t, n) {
      (super(e, t, n),
        (this.nbTryMax = this.nbTry = e.up(62)),
        this.link(`module`),
        e.later(1, `seconds`, () => this.deal(), !1, this),
        e.audio.playTrack(`mscModuleMemory`, 1, !0, 0, M(0.8, 1.2)));
    }
    deal() {
      let e = this.g,
        t = [];
      for (let n = 0; n < 5; n++) {
        let n = vn(e);
        n &&
          t.push(
            { ID: n.ID, type: n.type, isNew: !1 },
            { ID: n.ID, type: n.type, isNew: !1 },
          );
      }
      let n = _n(e);
      n &&
        t.push(
          { ID: n.ID, type: n.type, isNew: !0 },
          { ID: n.ID, type: n.type, isNew: !0 },
        );
      let r = st(t),
        i = 0;
      for (let t = 0; t < 3; t++)
        for (let n = 0; n < 4; n++) {
          let a = r[i++];
          if (!a) continue;
          let o = e.add(new kn(e, 140 + n * 40, 70 + t * 40, a), I.UI);
          e.later(
            0.1 + Math.random() * 0.5,
            `seconds`,
            () => {
              ((o.xs = 2),
                (o.visible = !0),
                e.sfx(`sndCardDraw1`, 1, 1, !0, !1));
            },
            !1,
            o,
          );
        }
      let a = e.all(kn).filter((e) => e.isNew);
      a[0] && (a[0].pairNum = 1);
    }
    check() {
      let e = this.g,
        t = e.all(kn).filter((e) => e.flip);
      t.length < 2 ||
        ((this.canFlip = !1),
        e.later(
          0.5,
          `seconds`,
          () => {
            let [n, r] = t,
              i = n.stats.ID === r.stats.ID && n.type === r.type;
            for (let t of [n, r])
              ((t.flip = !1),
                (t.angle -= 360),
                (t.scale = 0.5),
                i && ((t.valid = !0), e.sfx(`sndCardFlip1`, 1, 2, !0, !1)));
            if (
              !i &&
              (e.sfx(`sndWrong1`, 1, 1, !0, !1),
              e.cameraShake(10, !1),
              e.flash(D(un)),
              this.nbTry--,
              this.nbTry <= 0)
            ) {
              pn(e);
              for (let t of e.all(kn)) t.destroy();
              this.destroy();
            }
            this.canFlip = !0;
          },
          !1,
          this,
        ),
        e.later(
          1,
          `seconds`,
          () => {
            if (e.all(kn).filter((e) => e.valid).length < 12) return;
            let t = hn(e);
            for (let t of e.all(kn))
              e.later(
                0.1 + Math.random() * 0.5,
                `seconds`,
                () => {
                  ((t.vspeed = 2), (t.gravity = -0.5));
                },
                !1,
                t,
              );
            (e.later(2, `seconds`, () => {
              (pn(e), this.destroy());
            }),
              e.sfx(`sndModuleLabLaunched`, 1, 1, !1, !1),
              e.flash(D(B)),
              e.popup(
                t.x,
                t.y,
                `${e.L(`MODULE_MEMORY_WIN`)} !`,
                `[shake][d#${B}]`,
                0.6,
                2,
                -1,
                I.TextUp,
              ),
              e.audio.stopTrack(`mscModuleMemory`));
          },
          !1,
          this,
        ));
    }
    onDestroy() {
      this.g.audio.stopTrack(`mscModuleMemory`);
    }
    step() {
      this.handlerLink();
    }
    draw() {
      let e = this.g.r;
      for (let t = 0; t < this.nbTryMax; t++)
        (e.draw(
          `sUIHeart`,
          0,
          this.x - 28 + t * 16,
          this.y - 26,
          1,
          1,
          0,
          O.dkgray,
          0.5,
        ),
          t < this.nbTry &&
            e.draw(
              `sUIHeart`,
              0,
              this.x - 28 + t * 16,
              this.y - 26,
              1,
              1,
              0,
              D(un),
              1,
            ));
    }
  },
  kn = class extends z {
    flip = !1;
    valid = !1;
    scale = 0.5;
    type;
    isNew;
    pairNum = 0;
    stats;
    vspeed = 0;
    gravity = 0;
    constructor(e, t, n, r) {
      (super(e, t, n),
        (this.sprite = `sCardBack`),
        (this.visible = !1),
        (this.stats = e.cards[r.ID]),
        (this.type = r.type),
        (this.isNew = r.isNew),
        (this.xs = this.ys = 1));
    }
    mouse() {
      let e = this.g,
        t = e.all(On)[0];
      !this.visible ||
        !e.input.leftPressed ||
        !this.mouseHover() ||
        !t ||
        (!this.flip &&
          t.canFlip &&
          !this.valid &&
          ((this.angle += 360),
          (this.scale = 0.75),
          (this.flip = !0),
          (this.layer = I.UI2),
          t.check(),
          e.cameraShake(5, !1),
          e.sfx(`sndCardFlip1`, 1, 2, !0, !1)));
    }
    step() {
      if (
        ((this.angle = N(this.angle, Math.sin(Date.now() * 0.0015) * 20, 0.2)),
        (this.xs = N(this.xs, this.scale, 0.2)),
        (this.ys = this.xs),
        !this.flip && this.valid && (this.frame = 1),
        (this.vspeed += this.gravity),
        (this.y -= this.vspeed),
        this.y < -30)
      ) {
        if (this.pairNum !== 1) {
          let e = Zn(this.g, this.stats, 60, this.type);
          ((e.typeLock = !0), (e.backImage = 1));
        }
        this.destroy();
      }
    }
    draw() {
      let e = this.g;
      this.flip
        ? (Hn(
            e,
            this.stats.ID,
            this.stats.stars,
            this.type,
            this.x,
            this.y,
            this.xs,
            this.ys,
            this.angle,
          ),
          this.isNew &&
            k(
              e.r,
              this.x,
              this.y - 20,
              `[scale, .5][wave][fa_center][d#${B}]${e.L(`UI_NEW`)}`,
            ))
        : this.drawSelf();
    }
  },
  An = class extends qt {
    fightWinner = -1;
    fightLastTeam = A(1);
    fightCards = [];
    constructor(e, t, n) {
      (super(e, t, n),
        this.link(`module`),
        e.later(
          1,
          `seconds`,
          () => {
            let t = hn(e, 5),
              n = st([...(e.Lany(`MODULE_ARENA_HIM`) ?? [`?`])])[0];
            (e.popup(
              t.x,
              t.y,
              `[d#${un}]${n}\n[scale, 1.2][c_white]${e.L(`MODULE_ARENA_VS`)}\n[scale, .7][d#${B}]${e.L(`MODULE_ARENA_YOU`)}`,
              `[shake]`,
              0.7,
              2,
              -1,
              I.TextUp,
            ),
              e.cameraShake(20, !1),
              e.sfx(`sndExplosion2`, 1, 1, !0, !1));
          },
          !1,
          this,
        ),
        e.later(2, `seconds`, () => this.deal(), !1, this),
        e.later(4, `seconds`, () => (this.alarm[0] = 1), !1, this),
        e.audio.playTrack(`mscModuleArena`, 1, !0));
    }
    deal() {
      let e = this.g,
        t = [[], []];
      for (let n = 0; n < 6; n++) {
        let n = vn(e);
        n && t[0].push({ ID: n.ID, type: n.type, isNew: !1 });
      }
      for (let n = 0; n < 5; n++) {
        let n = vn(e);
        n && t[1].push({ ID: n.ID, type: n.type, isNew: !1 });
      }
      let n = _n(e);
      n && t[1].push({ ID: n.ID, type: n.type, isNew: !0 });
      for (let n = 0; n < 2; n++)
        st(t[n]).forEach((t, r) => {
          let i = e.add(
            new jn(e, 100 + r * 40, 140 - n * 70, e.cards[t.ID], n),
            I.UI,
          );
          ((i.type = t.type),
            (i.isNew = t.isNew),
            n === 1 && this.fightCards.push({ stats: i.stats, type: i.type }),
            e.later(
              0.1 + Math.random() * 0.5,
              `seconds`,
              () => {
                ((i.xs = 2),
                  (i.visible = !0),
                  e.sfx(`sndCardDraw1`, 1, 1, !0, !1));
              },
              !1,
              i,
            ));
        });
    }
    onAlarm(e) {
      if (e !== 0) return;
      let t = this.g,
        n = [[], []];
      for (let e of t.all(jn)) n[e.team].push(e);
      if (n[0].length <= 0 || n[1].length <= 0) {
        (n[0].length > n[1].length
          ? (this.fightWinner = 0)
          : n[0].length < n[1].length && (this.fightWinner = 1),
          this.end());
        return;
      }
      let r = +(this.fightLastTeam === 0),
        i = n[this.fightLastTeam][A(n[this.fightLastTeam].length - 1)];
      ((i.target = n[r][A(n[r].length - 1)]),
        i.attack(),
        (this.fightLastTeam = r),
        (this.alarm[0] = 60));
    }
    end() {
      let e = this.g,
        t = hn(e, 5, -5);
      (this.fightWinner === -1
        ? e.popup(
            t.x,
            t.y,
            `[d#${B}]${e.L(`MODULE_ARENA_DRAW`)}`,
            `[wave]`,
            0.7,
            2,
            -1,
            I.TextUp,
          )
        : this.fightWinner === 0
          ? (e.popup(
              t.x,
              t.y,
              `[d#${B}]${e.L(`MODULE_ARENA_WIN`)}`,
              `[wave]`,
              0.7,
              2,
              -1,
              I.TextUp,
            ),
            e.cameraShake(20, !1),
            e.flash(D(B)),
            e.sfx(`sndModuleLabLaunched`, 1, 1, !1, !1),
            e.stats.stats.nb_modules_win++)
          : (e.popup(
              t.x,
              t.y,
              `[d#${un}]${e.L(`MODULE_ARENA_LOSE`)}`,
              `[shake]`,
              0.7,
              2,
              -1,
              I.TextUp,
            ),
            e.cameraShake(20, !1),
            e.flash(D(un)),
            e.sfx(`sndWrong1`, 1, 1, !1, !1)),
        e.audio.stopTrack(`mscModuleArena`),
        e.later(2, `seconds`, () => {
          (pn(e), this.destroy());
        }));
    }
    onDestroy() {
      let e = this.g;
      for (let t of e.all(jn)) t.destroy();
      (this.fightWinner === 0 &&
        this.fightCards.forEach((t, n) => {
          let r = Zn(e, t.stats, 1 + n * 3, t.type);
          r.typeLock = !0;
        }),
        e.audio.stopTrack(`mscModuleArena`));
    }
    step() {
      this.handlerLink();
    }
    draw() {}
  },
  jn = class extends z {
    stats;
    team;
    type = A(6);
    isNew = !1;
    atk = 1;
    hp = 1;
    scale = 0.5;
    angleTo = 0;
    target = null;
    speed = 0;
    dir = 0;
    constructor(e, t, n, r, i) {
      (super(e, t, n),
        (this.stats = r),
        (this.team = i),
        (this.sprite = `sCardBase`),
        (this.visible = !1),
        (this.xs = this.ys = 1));
      let a = 5 + r.stars + r.price + this.type,
        o = [
          [0, 1],
          [0, 0, 1],
          [1, 1, 0],
          [1, 1, 1, 0],
        ][A(3)];
      for (let e = 0; e < a; e++)
        o[A(o.length - 1)] === 0 ? this.atk++ : this.hp++;
      e.later(
        0.1,
        `seconds`,
        () => {
          this.isNew && (this.hp = Math.max(this.hp, 3) * 3);
        },
        !1,
        this,
      );
    }
    attack() {
      let e = this.g;
      (e.sfx(`sndCardDraw3`, 1, 2, !1, !1),
        (this.scale = 1),
        e.later(
          0.3,
          `seconds`,
          () => {
            let t = this.target;
            !t ||
              t.dead ||
              ((this.dir = Math.atan2(t.y - this.y, t.x - this.x)),
              (this.speed = 20),
              (this.scale = 0.5),
              (this.angle += 40),
              e.sfx(`sndCardDraw1`, 1, 2, !1, !1));
          },
          !1,
          this,
        ),
        e.later(
          0.4,
          `seconds`,
          () => {
            let t = this.target;
            if (((this.speed = 0), !t || t.dead)) return;
            let n = ot(e.up(63)) ? 3 : 1,
              r = ot(e.up(63));
            if ((this.team === 1 && (n = 1), t.team === 1 && (r = !1), r))
              (e.popup(
                t.x,
                t.y,
                e.L(`MODULE_ARENA_MISS`),
                `[shake]`,
                0.5,
                1,
                -1,
                I.TextUp,
              ),
                (t.x += ot(50) ? 20 : -20),
                (t.angle += ot(50) ? 50 : -50),
                e.sfx(`sndWooshExit`, 1, 1, !0, !1));
            else {
              t.hp -= this.atk * n;
              let r = Math.atan2(this.y - t.y, this.x - t.x);
              ((t.x -= Math.cos(r) * 10),
                (t.y -= Math.sin(r) * 10),
                e.particle(`impactSmall`, t.x, t.y, 16777215, I.ParticlesUp),
                e.popup(
                  t.x,
                  t.y,
                  `-${this.atk * n}`,
                  `[shake]`,
                  n === 1 ? 0.5 : 0.8,
                  0.5,
                  -1,
                  I.TextUp,
                ),
                e.sfx(`sndHurt1`, 1, n === 1 ? 1 : 0.5, !0, !1));
            }
          },
          !1,
          this,
        ));
    }
    step() {
      let e = this.g;
      ((this.xs = N(this.xs, this.scale, 0.2)),
        (this.ys = this.xs),
        (this.angle = N(this.angle, this.angleTo, 0.2)),
        (this.x += Math.cos(this.dir) * this.speed),
        (this.y += Math.sin(this.dir) * this.speed),
        (this.x = N(this.x, this.xstart, 0.08)),
        (this.y = N(this.y, this.ystart, 0.08)),
        this.hp <= 0 &&
          (e.particle(`impactBig`, this.x, this.y, 16777215, I.ParticlesUp),
          e.cameraShake(10, !1),
          e.sfx(`sndExplosion1`, 1, 1, !0, !1),
          this.destroy()));
    }
    draw() {
      let e = this.g,
        t = e.r;
      if (
        (Hn(
          e,
          this.stats.ID,
          this.stats.stars,
          this.type,
          this.x,
          this.y,
          this.xs,
          this.ys,
          this.angle,
        ),
        t.circle(this.x - 24 * this.xs, this.y + 30 * this.ys, 5, D(6008319)),
        t.circle(this.x + 24 * this.xs, this.y + 30 * this.ys, 5, D(un)),
        this.isNew)
      ) {
        let n = Math.sin(Date.now() * 0.005) * 2,
          r = Math.sin(Date.now() * 0.004) * 15;
        (t.draw(
          `sModuleArenaCrown`,
          0,
          this.x,
          this.y - 25 + n,
          this.xs,
          this.ys,
          r,
          D(16224767),
          1,
          Me(this.type),
        ),
          k(
            t,
            this.x,
            this.y + 25,
            `[scale, .5][wave][fa_center][d#${B}]${e.L(`UI_NEW`)}`,
          ));
      }
    }
    drawGui() {
      let e = this.g.r;
      (k(
        e,
        this.x - 24 * this.xs,
        this.y + 30 * this.ys,
        `[scale, .35][c_black]${this.atk}`,
      ),
        k(
          e,
          this.x + 24 * this.xs,
          this.y + 30 * this.ys,
          `[scale, .35][c_black]${this.hp}`,
        ));
    }
  },
  Mn = class extends qt {
    canChoose = !1;
    canExpo = !1;
    expoCards = [];
    expoPriceInit = 30;
    expoPrice = 30;
    expoEntries = 1e3;
    expoReward = 3e4;
    expoRiskFactor = M(0.1, 0.6);
    expoRisk = 0;
    expoRiskPrice = 0;
    isWin = !1;
    constructor(e, t, n) {
      (super(e, t, n),
        this.link(`module`),
        e.later(
          1,
          `seconds`,
          () => {
            let t = hn(e, 5);
            (e.popup(
              t.x,
              t.y,
              e.L(`MODULE_MUSEUM_INTRO`),
              `[shake]`,
              0.7,
              2,
              -1,
              I.TextUp,
            ),
              e.cameraShake(20, !1),
              e.sfx(`sndExplosion2`, 1, 1, !0, !1));
          },
          !1,
          this,
        ),
        e.later(2, `seconds`, () => this.deal(), !1, this),
        e.audio.playTrack(`mscModuleMuseum`, 1, !0));
    }
    deal() {
      let e = this.g,
        t = _t(e.cards).filter((t) => t.type <= e.up(64)),
        n = [],
        r = Math.min(t.length, 18);
      for (let e = 0; e < r; e++) ((t = st(t)), n.push(t.shift()));
      let i = st(n),
        a = 0;
      for (let t = 0; t < 3; t++)
        for (let n = 0; n < 6 && !(a >= i.length); n++) {
          let r = i[a++],
            o = e.add(
              new Nn(e, 100 + n * 40, 70 + t * 40, e.cards[r.ID], r.type),
              I.UI,
            );
          e.later(
            0.1 + Math.random() * 0.5,
            `seconds`,
            () => {
              ((o.xs = 2),
                (o.visible = !0),
                e.sfx(`sndCardDraw1`, 1, 1, !0, !1));
            },
            !1,
            o,
          );
        }
      e.later(
        1,
        `seconds`,
        () => {
          this.canChoose = !0;
          for (let t of e.all(Nn)) ((t.flip = !1), (t.angle = 360));
        },
        !1,
        this,
      );
    }
    chosen() {
      let e = this.g;
      e.all(Nn).filter((e) => e.flip).length === 5 &&
        ((this.canChoose = !1),
        e.later(
          0.5,
          `seconds`,
          () => {
            for (let t of e.all(Nn)) t.flip || t.destroy();
            (e
              .all(Nn)
              .filter((e) => !e.dead)
              .slice(0, 5)
              .forEach((e, t) => {
                ((e.xx = 116 + t * 41),
                  (e.yy = 70),
                  (e.scale = 0.5),
                  this.expoCards.push({ stats: e.stats, type: e.type }),
                  (e.layer = I.UI));
              }),
              e.sfx(`sndWooshEnter`, 1, 1, !0, !1),
              (this.canExpo = !0));
            let t = e.add(new rn(e, 211, 145, 5, O.white, `module`));
            (t.linkNow(`module`),
              (t.func = () => {
                (this.priceDown(), this.recompute());
              }));
            let n = e.add(new rn(e, 287, 145, 0, O.white, `module`));
            (n.linkNow(`module`),
              (n.func = () => {
                (this.priceUp(), this.recompute());
              }));
            let r = e.add(new rn(e, 250, 166, 2, O.white, `module`));
            (r.linkNow(`module`), (r.func = () => this.expose()));
            let i = [1, 2, 3, 4],
              a = [1, 5, 10, 25, 50, 200, 500],
              o = 0;
            for (let e of this.expoCards) o += i[e.stats.stars - 1] * a[e.type];
            ((o /= 4e3),
              (this.expoEntries = 150 + 999850 * o ** 2),
              this.recompute());
          },
          !1,
          this,
        ));
    }
    recompute() {
      let e = this.expoPrice / this.expoPriceInit;
      ((this.expoRisk =
        100 * (1 - Math.exp(-this.expoRiskFactor * Math.log2(e)))),
        (this.expoReward = this.expoEntries * this.expoPrice),
        (this.expoRiskPrice = Math.max(
          this.expoReward / 10,
          this.expoReward * (this.expoRisk / 100),
        )),
        this.expoPrice === this.expoPriceInit &&
          (this.expoRiskPrice = Math.min(
            this.expoRiskPrice,
            this.g.stats.money - 3e3,
          )));
    }
    priceUp() {
      this.expoPrice >= 1e4
        ? (this.expoPrice += 5e3)
        : this.expoPrice >= 1e3
          ? (this.expoPrice += 500)
          : this.expoPrice >= 100
            ? (this.expoPrice += 50)
            : (this.expoPrice += 10);
    }
    priceDown() {
      this.expoPrice > 1e4
        ? (this.expoPrice -= 5e3)
        : this.expoPrice > 1e3
          ? (this.expoPrice -= 100)
          : this.expoPrice > 100
            ? (this.expoPrice -= 50)
            : (this.expoPrice = Math.max(10, this.expoPrice - 10));
    }
    expose() {
      let e = this.g,
        t = hn(e, 5);
      if (this.expoRiskPrice > e.stats.money) {
        (e.popup(
          t.x,
          t.y,
          e.L(`MODULE_MUSEUM_IMPOSSIBLE`),
          `[shake]`,
          0.7,
          2,
          -1,
          I.TextUp,
        ),
          e.sfx(`sndWrong1`, 1, 1, !1, !1));
        return;
      }
      ((this.canExpo = !1),
        gn(e),
        e.popup(
          t.x,
          t.y,
          e.L(`MODULE_MUSEUM_WAITING`),
          `[shake]`,
          0.7,
          2,
          -1,
          I.TextUp,
        ),
        e.sfx(`sndCardNotnew`, 1, 1, !0, !1),
        e.later(
          2,
          `seconds`,
          () => {
            let t = hn(e, 5),
              n = !ot(this.expoRisk);
            if ((e.cameraShake(20, !1), !n))
              (e.popup(
                t.x,
                t.y,
                `${e.L(`MODULE_MUSEUM_LOSE`)}\n-[d#${un}]${P(this.expoRiskPrice)}$`,
                `[shake]`,
                0.7,
                2,
                -1,
                I.TextUp,
              ),
                e.flash(D(un)),
                e.sfx(`sndWrong1`, 1, 1, !0, !1),
                e.moneyAdd(-this.expoRiskPrice, !0, `museum`),
                e.later(2, `seconds`, () => this.destroy(), !1, this));
            else {
              let n = Math.max(1, Math.round(this.expoEntries / 1e4)),
                r = Math.floor(this.expoReward / n),
                i = [0, 0, 0];
              for (let e = 0; e < n; e++) i[A(2)]++;
              (e.popup(
                t.x,
                t.y,
                e.L(`MODULE_MUSEUM_WIN`),
                `[shake]`,
                0.7,
                2,
                -1,
                I.TextUp,
              ),
                e.sfx(`sndModuleLabLaunched`, 1, 0.8, !1, !1),
                e.add(new Pn(e, 196, 160, i[0], r), I.UI),
                e.add(new Pn(e, 80, 130, i[1], r), I.UI),
                e.add(new Pn(e, 300, 130, i[2], r), I.UI),
                (this.isWin = !0),
                e.later(
                  2,
                  `seconds`,
                  () => {
                    e.count(Fn) === 0 && this.destroy();
                  },
                  !0,
                  this,
                ));
            }
          },
          !1,
          this,
        ));
    }
    onDestroy() {
      let e = this.g;
      for (let t of e.all(Nn)) t.destroy();
      for (let t of e.all(Pn)) t.destroy();
      (pn(e), e.audio.stopTrack(`mscModuleMuseum`));
    }
    step() {
      this.handlerLink();
    }
    draw() {
      if (!this.canExpo) return;
      let e = this.g,
        t = e.r,
        n = this.x,
        r = this.y + 58;
      (k(t, n - 30, r, `[scale, .5][fa_left]${e.L(`MODULE_MUSEUM_ENTRIES`)}`),
        k(
          t,
          n - 30,
          r + 14,
          `[scale, .5][fa_left]${e.L(`MODULE_MUSEUM_REWARD`)}`,
        ),
        k(
          t,
          n - 30,
          r + 28,
          `[scale, .5][fa_left][d#6008319]${e.L(`MODULE_MUSEUM_RISK`)}`,
        ),
        k(
          t,
          n - 30,
          r + 42,
          `[scale, .5][fa_left][d#6008319]${e.L(`MODULE_MUSEUM_RISK_PRICE`)}`,
        ),
        k(
          t,
          n + 35,
          r,
          `[scale, .5][fa_left][d#9240561]${P(this.expoEntries)}`,
        ),
        k(
          t,
          n + 35,
          r + 14,
          `[scale, .5][fa_left][d#9240561]${P(this.expoReward)}[d#${B}]$`,
        ),
        k(
          t,
          n + 35,
          r + 28,
          `[scale, .5][fa_left][d#${un}]${Math.round(this.expoRisk)}%`,
        ),
        k(
          t,
          n + 35,
          r + 42,
          `[scale, .5][fa_left][d#${un}]-${P(this.expoRiskPrice)}[d#${B}]$`,
        ),
        k(
          t,
          n + 150,
          r - 4,
          `[scale, .5]${e.L(`MODULE_MUSEUM_PRICE_SHORT`)}\n[d#9240561][scale, 1]${P(this.expoPrice)}[d#${B}]$`,
          { valign: `top`, lineHeight: 23 },
        ));
    }
  },
  Nn = class extends z {
    stats;
    type;
    flip = !0;
    scale = 0.5;
    xx;
    yy;
    constructor(e, t, n, r, i) {
      (super(e, t, n),
        (this.stats = r),
        (this.type = i),
        (this.sprite = `sCardBack`),
        (this.visible = !1),
        (this.xx = t),
        (this.yy = n),
        (this.xs = this.ys = 1));
    }
    mouse() {
      let e = this.g,
        t = e.all(Mn)[0];
      !this.visible ||
        !t ||
        !e.input.leftPressed ||
        !this.mouseHover() ||
        (!this.flip &&
          t.canChoose &&
          ((this.angle += 360),
          (this.scale = 0.75),
          (this.flip = !0),
          (this.layer = I.UI2),
          t.chosen(),
          e.cameraShake(5, !1),
          e.sfx(`sndCardFlip1`, 1, 2, !0, !1)));
    }
    step() {
      ((this.angle = N(this.angle, Math.sin(Date.now() * 0.0015) * 20, 0.2)),
        (this.xs = N(this.xs, this.scale, 0.2)),
        (this.ys = this.xs),
        (this.x = N(this.x, this.xx, 0.2)),
        (this.y = N(this.y, this.yy, 0.2)));
    }
    draw() {
      (this.flip || this.drawSelf(),
        Hn(
          this.g,
          this.stats.ID,
          this.stats.stars,
          this.type,
          this.x,
          this.y,
          this.xs,
          this.ys,
          this.angle,
        ));
    }
  },
  Pn = class extends z {
    nb;
    reward;
    constructor(e, t, n, r, i) {
      (super(e, t, n),
        (this.nb = r),
        (this.reward = i),
        (this.sprite = `sModuleMuseum`),
        (this.visible = !1),
        e.later(
          1 + Math.random() * 60,
          `frames`,
          () => {
            (e.sfx(`sndHurt1`, 1, 1, !1, !1),
              e.cameraShake(15),
              e.particle(`impactSmall`, this.x, this.y, 16777215, I.UI),
              (this.visible = !0),
              e.later(
                0.3,
                `seconds`,
                () => {
                  this.nb <= 0 ||
                    (this.nb--,
                    e.add(new Fn(e, this.x, this.y), I.UI),
                    e.popup(
                      this.x + M(-30, 30),
                      this.y + M(-30, 30),
                      `+${P(this.reward)}[d#${B}]$`,
                      `[shake]`,
                      0.5,
                      1,
                      -1,
                      I.TextUp,
                    ),
                    e.sfx(`sndMoney1`, 0.5, 1, !0, !1),
                    e.moneyAdd(this.reward, !0, `museum`));
                },
                !0,
                this,
              ));
          },
          !1,
          this,
        ));
    }
    step() {
      this.angle = Math.sin(Date.now() * 0.002) * 20;
    }
  },
  Fn = class extends z {
    xx;
    yy;
    stepN = 5;
    moving = !1;
    constructor(e, t, n) {
      (super(e, t, n),
        (this.sprite = `sModuleMuseum`),
        (this.frame = 1),
        (this.xx = t),
        (this.yy = n),
        (this.alarm[0] = 1),
        (this.blend = D([16777215, 9240561, 16755841, 16224767, B][A(4)])),
        e.later(
          0.2,
          `seconds`,
          () => {
            this.moving && (this.angle = ot(50) ? -20 : 20);
          },
          !0,
          this,
        ));
    }
    onAlarm(e) {
      if (e !== 0) return;
      let t = this.g;
      if (this.stepN > 0)
        ((this.xx = M(115, 280)),
          (this.yy = M(105, 130)),
          this.stepN--,
          (this.alarm[0] = M(30, 120)),
          t.sfx(
            [`sndModuleMuseum1`, `sndModuleMuseum2`, `sndModuleMuseum3`][A(2)],
            1,
            1,
            !0,
            !1,
          ));
      else {
        let e = t.all(Pn),
          n = e[A(e.length - 1)];
        n && ((this.xx = n.x), (this.yy = n.y));
      }
    }
    step() {
      let e = Math.hypot(this.xx - this.x, this.yy - this.y);
      ((this.moving = e > 1),
        this.moving &&
          ((this.x += (this.xx - this.x) / e),
          (this.y += (this.yy - this.y) / e)),
        (this.angle = N(this.angle, 0, 0.1)),
        this.stepN <= 0 &&
          this.g
            .all(Pn)
            .some((e) => Math.hypot(e.x - this.x, e.y - this.y) < 8) &&
          this.destroy());
    }
  },
  In = class extends qt {
    type;
    xx;
    yy;
    xMin = -1 / 0;
    xMax = 1 / 0;
    yMin = -1 / 0;
    yMax = 1 / 0;
    targets = () => [];
    constructor(e, t, n) {
      (super(e, 320 / 2, 180 / 2),
        (this.sprite = `sCursor`),
        (this.type = t),
        (this.targets = n),
        (this.xx = this.x),
        (this.yy = this.y),
        (this.alarm[0] = 60),
        (this.alarm[2] = 120),
        t === 1 &&
          ((this.xMin = 0),
          (this.xMax = 320),
          (this.yMin = 0),
          (this.yMax = 180)),
        (this.blend = D([B, 6008319, 9240561][t])),
        (this.layer = t === 1 ? I.InstancesTop : I.UI),
        this.link(``));
    }
    onAlarm(e) {
      let t = this.g;
      if (e === 0) {
        let e = 2 / t.up(53) / t.speedMod,
          n = this.targets().filter(
            (e) =>
              !e.dead &&
              e.x >= this.xMin &&
              e.x <= this.xMax &&
              e.y >= this.yMin &&
              e.y <= this.yMax,
          );
        if (n.length === 0) {
          ((this.xx += M(-10, 10)),
            (this.yy += M(-10, 10)),
            (this.alarm[0] = 15 + Math.random() * 30));
          return;
        }
        let r = n[A(n.length - 1)],
          i = t.r.sprite(r.sprite),
          a = ((i?.w ?? 20) * Math.abs(r.xs)) / 3,
          o = ((i?.h ?? 20) * Math.abs(r.ys)) / 3;
        ((this.xx = r.x + M(-a, a)),
          (this.yy = r.y + M(-o, o)),
          t.later(
            0.1 + Math.random() * e,
            `seconds`,
            () => {
              ((this.xs *= 3),
                (this.ys *= 3),
                (this.alarm[0] = 6 + 120 / t.up(53) / t.speedMod),
                t.stats.stats.nb_employee_clicks++,
                r.dead || r.userEvent0());
            },
            !1,
            this,
          ));
      } else if (e === 2) {
        let e = 50 * t.up(53);
        ((this.alarm[2] = 60),
          t.moneyAdd(-e, !1),
          (t.stats.stats.nb_employee_cost += e),
          (t.stats.money - e <= 0 || t.employeesSleep) &&
            (t.particle(`impactSmall`, this.x, this.y, this.blend, I.Particles),
            this.destroy()));
      }
    }
    step() {
      ((this.x = N(this.x, this.xx, 0.5)),
        (this.y = N(this.y, this.yy, 0.5)),
        (this.xs = N(this.xs, 1, 0.3)),
        (this.ys = N(this.ys, 1, 0.3)),
        this.type === 1 &&
          ((this.xx = Math.max(this.xMin, Math.min(this.xMax, this.xx))),
          (this.yy = Math.max(this.yMin, Math.min(this.yMax, this.yy)))));
    }
  };
function Ln(e) {
  return bn(e) || e.godpackCooldown > 0 || e.up(60) <= 0 ? !1 : ot(2);
}
function Rn(e) {
  ((e.godpackActive = !0), e.closeOnglets());
  for (let t of e.all(In)) t.destroy();
  for (let t of e.all(Gn)) t.destroy();
  for (let t of e.all(Yn)) t.destroy();
  let t = JSON.parse(JSON.stringify(e.boosters[1]));
  ((t.ID = 8),
    (t.proba = [5, 30, 35, 30]),
    (t.quantity = [4, 4]),
    (t.health = e.up(0) * 20));
  let n = Wn(e, t);
  ((n.xstart = n.x = 320 / 2),
    (n.ystart = n.y = 180 / 2),
    e.flash(16777215),
    e.sfx(`sndHurt1`, 1, 0.5, !1, !1),
    e.cameraShake(20, !1));
  let r = e.later(
    0.2,
    `seconds`,
    () => {
      zn(e) && e.cancel(r);
    },
    !0,
  );
}
function zn(e) {
  return e.count(Gn) > 0 || e.count(Yn) > 0
    ? !1
    : ((e.godpackActive = !1), (e.godpackCooldown = 36e3), !0);
}
function Bn(e) {
  if (
    e.stats.money < 1e3 ||
    e.employeesSleep ||
    e.godpackActive ||
    e.audio.isPlaying(`mscCollectionFull`)
  )
    return;
  let t = [0, 0, 0];
  for (let n of e.all(In)) t[n.type]++;
  for (let n = 0; n < 3; n++) {
    let r = e.up(40 + n);
    if (t[n] > r) {
      let t = e.all(In).filter((e) => e.type === n);
      t[A(t.length - 1)]?.destroy();
    } else t[n] < r && Vn(e, n);
  }
}
function Vn(e, t) {
  e.add(
    new In(
      e,
      t,
      {
        0: () => e.all(qr).filter((e) => e.stats.ID !== 6),
        1: () => [
          ...e.all(Gn).filter((e) => !e.isBlister),
          ...e.all(Yn),
          ...e.all($n),
        ],
        2: () => e.all(Yr).filter((e) => e.cards().length > 0),
      }[t],
    ),
  );
}
function Hn(e, t, n, r, i, a, o, s, c = 0, l = 16777215, u = 1) {
  let d = e.r,
    f = `sCardArt${t}`;
  if (r !== 6) {
    let e = Me(r);
    (d.draw(`sCardBackground`, 0, i, a, o, s, c, l, u, e),
      d.draw(f, 1, i, a, o, s, c, l, u),
      d.draw(f, 0, i, a, o, s, c, l, u),
      d.draw(`sCardTop`, 0, i, a, o, s, c, l, u, e),
      d.draw(`sCardBorder`, 0, i, a, o, s, c, l, u, e),
      d.draw(`sCardStars`, n - 1, i + 1, a + 1, o, s, c, O.black, 0.2 * u),
      d.draw(`sCardStars`, n - 1, i, a, o, s, c, l, u, e));
  } else {
    let e = Math.sin(Date.now() / 200);
    (d.draw(`sCardBackground`, 1, i, a, o, s, c, l, u, je.holo),
      d.draw(`sCardTop`, 1, i, a, o, s, c, l, u, je.gold),
      d.draw(
        f,
        0,
        i + 2 * o,
        a + 7 * s,
        o * 1.3 - e / 8,
        s * 1.3 + e / 8,
        20 * e,
        O.black,
        u / 2,
      ),
      d.draw(
        f,
        0,
        i,
        a + 5 * s,
        o * 1.3 - e / 8,
        s * 1.3 + e / 8,
        20 * e,
        l,
        u,
      ));
  }
}
function Un(e) {
  return e === 0 ? `normal` : `{type${e}}`;
}
function Wn(e, t, n = 0) {
  let r = 0,
    i = j(30, 290),
    a = j(40, 140),
    o = e.all(Gn),
    s = (e, t) =>
      o.some((n) => Math.abs(n.x - e) < 40 && Math.abs(n.y - t) < 40);
  for (; r < 10 && s(i, a);) (r++, (i = j(40, 280)), (a = j(40, 140)));
  let c = e.add(new Gn(e, i, a), I.Instances);
  return (
    (c.stats = JSON.parse(JSON.stringify(t))),
    (c.type = n),
    (c.stats.price *= 1 + n),
    e.cameraShake(10),
    e.sfx(`sndHurt1`, 1.3, 1, !0),
    !e.stats.tutorial_done &&
      (c.stats.quantity[0] !== 2 || c.stats.quantity[1] !== 2) &&
      (c.stats.quantity[0] = 3),
    c
  );
}
var Gn = class e extends z {
    stats;
    type = 0;
    health = 20;
    healthMax = 20;
    isBlister;
    blisterI = A(3);
    blisterProba = 1;
    angleBase = j(-50, 50);
    scaleBase = 0.8;
    nbHit = 0;
    constructor(t, n, r) {
      (super(t, n, r),
        (this.sprite = `sBooster0`),
        (this.isBlister = ot(t.up(32) * 10)),
        (this.alarm[0] = 300),
        (this.angle = this.angleBase),
        (this.xs = this.ys = this.scaleBase),
        t.later(
          10,
          `frames`,
          () => {
            ((this.health = this.stats.health), (this.healthMax = this.health));
          },
          !1,
          this,
        ));
      let i = t.count(e) + 1;
      t.later(
        0.3,
        `seconds`,
        () => {
          i > t.up(8) &&
            (this.destroy(),
            t.particle(`impactSmall`, this.x, this.y),
            t.popup(
              this.x,
              this.y,
              t.L(`UI_DESTROYED_BOOSTER`),
              `[d#6184703][shake]`,
              0.5,
              2,
            ),
            t.cameraShake(10),
            t.sfx(`sndWrong1`, 0.8, 1, !0));
        },
        !1,
        this,
      );
    }
    onAlarm(e) {
      if (e !== 0 || !this.isBlister) return;
      let t = this.g;
      ((this.alarm[0] = 60 * M(1, 5)),
        ot(this.blisterProba)
          ? ((this.xstart = 420),
            t.popup(
              this.x,
              this.y,
              `Blister sold !\n${P(this.stats.price)}$`,
              `[shake][d#6946705]`,
              0.5,
              3,
            ),
            t.moneyAdd(this.stats.price, !0, `blister`),
            t.sfx(`sndMoney1`, 1, 1, !0))
          : ((this.blisterProba *= 5 / t.up(33)),
            this.stats.price++,
            (this.stats.price *= 3),
            (this.xs *= 1.5),
            (this.ys *= 1.5),
            t.popup(
              this.x,
              this.y,
              `Value : ${P(this.stats.price)}$`,
              `[wave][d#6946705]`,
              0.5,
              this.alarm[0] / 60,
            ),
            t.sfx(`sndHover`, 1, 1.5, !0)));
    }
    hit() {
      let e = this.g;
      (this.isBlister &&
        ((this.isBlister = !1),
        e.particle(`blister`, this.x, this.y, 2105376),
        e.cameraShake(15),
        e.popup(
          this.x,
          this.y,
          `Blister
destroyed !`,
          `[shake][c_red]`,
          0.5,
          2,
        ),
        e.sfx(`sndMoney1`, 1, 1, !0)),
        (this.x += j(-5, 5)),
        (this.y += j(-5, 5)),
        (this.xs += M(-0.2, 0.2)),
        (this.ys += M(-0.2, 0.2)),
        (this.angle += j(-20, 20)),
        this.nbHit++,
        e.godpackActive &&
          this.nbHit % 5 == 0 &&
          (e.sfx(`sndExplosion1`, 1, 0.5 + this.nbHit / 20, !1, !1),
          e.cameraShake(20, !1)));
      let t = e.up(0);
      ((this.health -= t),
        e.particle(
          `impactSmall`,
          this.x + j(-30, 30),
          this.y + j(-30, 30),
          16777215,
          I.Particles,
        ),
        this.health > 0 &&
          e.popup(
            this.x + j(-30, 30),
            this.y + j(-30, 30),
            `-${t}`,
            `[shake]`,
            0.5,
            0.5,
          ),
        e.cameraShake(2),
        e.sfx(`sndClick1`, 0.5, 1, !0, !e.godpackActive),
        e.sfx(`sndBoosterHurt`, 0.6, 1, !0, !e.godpackActive));
    }
    step() {
      let e = this.g;
      if (!this.stats) {
        this.destroy();
        return;
      }
      let t = e.godpackActive ? 1 : Math.max(1, (e.up(11) * e.speedMod) / 2);
      if (
        ((this.x = N(this.x, this.xstart, 0.1)),
        (this.y = N(this.y, this.ystart, 0.1)),
        (this.angle = N(this.angle, this.angleBase, 0.1)),
        (this.xs = N(this.xs, this.scaleBase, 0.1)),
        (this.ys = N(this.ys, this.scaleBase, 0.1)),
        (this.sprite = `sBooster${Math.floor(this.stats.ID)}`),
        this.isBlister && this.stats.ID === 0 && (this.isBlister = !1),
        this.x > 380)
      ) {
        this.destroy();
        return;
      }
      if (this.health <= 0) {
        this.crack(t);
        return;
      }
      Zt(this, !0) && this.health > 0 && this.hit();
    }
    userEvent0() {
      this.health > 0 && this.hit();
    }
    crack(e) {
      let t = this.g,
        n = this.stats,
        r = j(n.quantity[0], n.quantity[1]);
      (ot(t.up(5)) &&
        ((r *= 3),
        t.stats.stats.nb_boosters_triple++,
        t.popup(
          this.x,
          this.y,
          t.L(`UI_TRIPLE`),
          `[shake][d#6008319]`,
          1,
          2 / t.up(11),
        ),
        t.cameraShake(50),
        t.sfx(`sndExplosion1`, 0.8, 0.5)),
        t.particle(`impactBig`, this.x, this.y),
        t.particle(`impactBig`, this.x, this.y));
      for (let e = 0; e < Math.min(r, 40); e++)
        t.particle(`impactCards`, this.x, this.y);
      t.cameraShake(50, !t.godpackActive);
      let i = [];
      for (let e = 0; e < r; e++) {
        let e = ht(t.cards, Tt(n.proba));
        e && i.push(e);
      }
      if (
        (r > t.stats.stats.nb_boosters_record &&
          (t.stats.stats.nb_boosters_record = r),
        i.forEach((n, i) => {
          if (t.count(Yn) < 300) {
            let a = 0;
            if (t.godpackActive)
              for (a = 6; a > 1 && t.cards[n.ID].quantity[a] < 0;) a--;
            let o = Zn(t, n, (60 + (r - i) * 3) / e, a);
            o.backImage = t.godpackActive ? 2 : 0;
          }
        }),
        t.godpackActive)
      ) {
        let e = st(gt(t.cards))[0];
        if (e) {
          let n = Zn(t, t.cards[e.ID], 60, e.type);
          ((n.typeLock = !0),
            (n.backImage = 3),
            t.stats.stats.nb_boosters_godpack++,
            t.flash(16777215));
        }
      }
      (t.sfx(`sndBoosterHurt2`, 1.4, 1, !0, !t.godpackActive),
        t.sfx(`sndExplosion1`, 0.6, 1, !1, !t.godpackActive),
        t.stats.stats.nb_boosters_cracked++,
        n.ID === 5 && (t.polarizedStreak = r === 0 ? t.polarizedStreak + 1 : 0),
        this.destroy());
    }
    draw() {
      let e = this.g,
        t = e.r;
      if (e.godpackActive) {
        let e = [
          [370, 210],
          [320 / 2 - 50, -30],
          [-60, 210],
          [350, 180 / 2 - 30],
        ];
        for (let n = 0; n < Math.min(4, Math.floor(this.nbHit / 5)); n++)
          t.line(this.x, this.y, e[n][0], e[n][1], M(2, 10), O.white, O.white);
      }
      let n = this.type === 0 ? je.plastic : Me(this.type);
      t.draw(
        this.sprite,
        0,
        this.x,
        this.y,
        this.xs,
        this.ys,
        this.angle,
        this.blend,
        this.alpha,
        n,
      );
      let r = ((this.angle + 55) * Math.PI) / 180,
        i = Math.cos(r) * 45 * this.xs,
        a = -Math.sin(r) * 45 * this.ys,
        o = 30 + 5 * Math.sin(Date.now() / 500);
      if (
        (this.healthMax === this.health && (o = 0),
        t.draw(
          `sBooster${this.stats.ID}Plastic`,
          0,
          this.x + i,
          this.y + a,
          this.xs,
          this.ys,
          this.angle - o,
          this.blend,
          this.alpha,
          n,
        ),
        this.isBlister)
      ) {
        let e = [je.normal, je.holo, je.gold, je.negative][this.blisterI];
        t.draw(
          `sBoosterBlister`,
          0,
          this.x,
          this.y,
          this.xs,
          this.ys,
          this.angle,
          2434341,
          0.1,
          e,
        );
      }
    }
  },
  Kn = 0,
  qn = 1,
  Jn = [35, 36, 37, 38, 48, 59],
  Yn = class e extends z {
    stats;
    type = 0;
    typeLock = !1;
    backImage = 0;
    sideFrom = qn;
    sideTo = qn;
    size = 0.6;
    isNew = !1;
    canSeal = !1;
    isSeal = !1;
    nbClones = 0;
    constructor(e, t, n, r) {
      (super(e, t, n),
        (this.stats = r),
        (this.sprite = `sCardBase`),
        (this.xs = this.ys = this.size * 5),
        (this.angle = M(-30, 30)),
        (this.y = this.ystart - 400));
    }
    mouse() {
      let e = this.g;
      e.input.leftPressed &&
        this.mouseHover() &&
        this.sideTo === Kn &&
        this.canSeal &&
        !this.isSeal &&
        this.isNew &&
        this.type > 0 &&
        e.up(Jn[this.type - 1]) > 0 &&
        ((this.xs *= 0.3),
        (this.ys *= 0.3),
        (this.angle -= 30),
        e.cameraShake(5),
        e.particle(`impactSmall`, this.x, this.y, 16711680),
        (this.isSeal = !0),
        (e.isFirstStamp = !1),
        Xn(e, this.stats, this.type),
        e.sfx(`sndCardStamp`, 1, 1, !0, !1),
        e.stats.stats.nb_cards_stamped++);
    }
    requestFlip() {
      let t = this.g,
        n = 0;
      for (let r of t.all(e)) (r.sideTo === Kn || r.alarm[3] > 0) && n++;
      this.sideTo === qn &&
        this.alarm[3] <= 0 &&
        n < t.up(9) &&
        (this.alarm[3] = 1 + Math.random() * 10);
    }
    onAlarm(e) {
      let t = this.g;
      e === 0
        ? (t.sfx(
            [`sndCardDraw1`, `sndCardDraw2`, `sndCardDraw3`][A(2)],
            1,
            1,
            !0,
          ),
          A(1) === 0 ? (this.ys *= 4) : (this.xs *= 4))
        : e === 3
          ? this.flipToFront()
          : e === 1
            ? this.reveal()
            : e === 2 && this.collect();
    }
    flipToFront() {
      let t = this.g,
        n = [280, 40, 220, 100];
      ((this.xstart = j(20, 300)), (this.ystart = 145), (this.size = 0.6));
      let r = t.all(e);
      for (let e of n)
        if (
          !r.some(
            (t) =>
              t !== this &&
              t.sideTo === Kn &&
              t.xstart === e &&
              t.ystart === 90,
          )
        ) {
          ((this.xstart = e), (this.ystart = 90), (this.size = 0.8));
          break;
        }
      ((this.sideTo = Kn),
        (this.layer = I.InstancesTop),
        t.sfx(`sndClick1`, 1, 1, !0));
    }
    mult() {
      return this.g.godpackActive ? 1 : this.g.up(11) * this.g.speedMod;
    }
    reveal() {
      let e = this.g,
        t = this.mult(),
        n = j(1, 100) <= e.up(22),
        r = j(1, e.up(23));
      (this.type === 0 &&
        !this.typeLock &&
        (this.type = mt(e.upgrades, e.rarityMod)),
        Tn(e, this.stats.ID, this.type) &&
          (this.type = lt(this.type - 1, 0, 6)));
      let i = lt(this.type / 1.5, 2, 5);
      if (
        ((this.canSeal = !0),
        (this.isNew = e.cards[this.stats.ID].quantity[this.type] === -1),
        (this.alarm[2] = 1),
        this.type > 0 &&
          (e.popup(
            this.x,
            this.y - 45,
            rr(e, Un(this.type)),
            ``,
            0.45,
            this.isNew ? i : 0.5 / t,
          ),
          (this.angle += 30),
          (this.alarm[2] = lt(60 / t, 1, 1 / 0)),
          e.sfx(`sndCardNotnew`, 1, 1 + this.type / 10)),
        !this.isNew &&
          n &&
          ((this.nbClones = r),
          (this.angle = 360),
          e.popup(this.x, this.y, `x${r + 1}`, `[shake][d#6946705]`, 1, 2 / t),
          (this.alarm[2] = lt(120 / t, 1, 1 / 0)),
          e.sfx(`sndCardNotnew`, 1, 2, !0)),
        this.isNew)
      ) {
        let t = 0;
        ((this.xs = this.ys = 2), (this.angle += 30));
        let n = e.price(this.stats.ID, this.type);
        (e.stats.card_record < n &&
          ((e.stats.card_record = n),
          e.popup(
            this.x,
            this.y,
            `${e.L(`UI_RECORD`)}\n${P(n)} $`,
            `[shake][rainbow]`,
            0.7,
            i,
          ),
          (i += 1),
          (t += 0.2),
          e.sfx(`sndCardRecord`, 1, 0.8, !1, !1)),
          (this.alarm[2] = 60 * i),
          e.popup(
            this.x,
            this.y - (this.type > 0 ? 60 : 50),
            e.L(`UI_NEW`),
            `[shake][d#6946705]`,
            0.7,
            i,
          ),
          e.popup(
            this.x,
            this.y + 40,
            e.L(this.stats.name),
            `[wave][fa_top]`,
            0.45,
            i,
            80,
          ),
          e.moneyAdd(n, !0, `new`),
          e.cameraShake(20 * this.stats.stars),
          e.flash(9568105),
          e.sfx(`sndExplosion1`, 1, 1, !0, !1),
          e.sfx(
            `sndCardNew${this.type}`,
            0.7,
            0.8 + 0.05 * this.stats.stars + t,
            !1,
            !1,
          ),
          e.later(1, `seconds`, () => {
            if (!e.options.voice) return;
            let t = `sndVoice${e.options.lang.toUpperCase()}${this.stats.ID}`;
            e.audio.has(t) && e.sfx(t, 1.8, 1, !1, !1);
          }));
      }
    }
    collect() {
      let e = this.g,
        t = wn(e, this.stats.ID, this.type);
      if (t && !this.isNew) {
        ((this.ystart = -50), (t.stock[this.type] += 1 + this.nbClones));
        return;
      }
      if (ot(e.up(31)) && !this.isNew) {
        (e.particle(`impactSmall`, this.x, this.y),
          e.moneyAdd(e.price(this.stats.ID, this.type)),
          e.add(
            new tr(e, this.x, this.y, this.stats.ID, this.type),
            I.InstancesTop,
          ),
          this.destroy());
        return;
      }
      let n = bt(e.cards, e.upgrades, this.stats.ID, this.type, this.isNew);
      if (n.collected) {
        (n.duplicate && e.stats.stats.nb_cards_duplicates++,
          this.isNew && !e.stats.UI_unlock[6] && (e.stats.UI_unlock[6] = !0));
        let t = e.all(tn).find((e) => e.ID === (this.isNew ? 2 : 1));
        t && ((t.xs = 4), (t.ys = 4), (t.angle += 30));
        for (let t = 0; t < this.nbClones; t++)
          bt(e.cards, e.upgrades, this.stats.ID, this.type, !1).duplicate &&
            e.stats.stats.nb_cards_duplicates++;
        (n.duplicate && yt(e.cards) >= e.up(6) - 2 && on(e),
          e.dupVersion++,
          (this.ystart = -50),
          e.sfx([`sndCardDraw1`, `sndCardDraw2`, `sndCardDraw3`][A(2)]),
          !(this.isNew && wt(e.cards, this.stats.ID)) &&
            t &&
            e.popup(
              t.x,
              t.y,
              `+1`,
              `[shake]`,
              0.5,
              this.isNew ? 3 : 0.5,
              -1,
              I.TextUp,
            ),
          (this.xs = 0.1));
      } else
        (this.destroy(),
          e.particle(`impactSmall`, this.x, this.y),
          e.popup(this.x, this.y - 15, e.L(`UI_DESTROYED`), `[shake]`, 0.5, 2),
          e.popup(
            this.x,
            this.y + 20,
            e.L(`UI_DESTROYED_DUPLICATE`),
            `[d#6184703][shake]`,
            0.5,
            2,
          ),
          e.cameraShake(8),
          e.sfx(`sndWrong1`, 0.8, 1, !0));
    }
    step() {
      let e = this.g,
        t = this.mult();
      if (
        (this.sideFrom === this.sideTo
          ? (this.xs = N(this.xs, this.size, 0.1 * t))
          : ((this.xs = N(this.xs, 0, 0.1 * t)),
            this.xs <= 0.03 &&
              ((this.sideFrom = this.sideTo),
              this.sideTo === Kn &&
                ((this.size *= 1.25),
                (this.alarm[1] = lt(48 / t, 1, 1 / 0)),
                e.sfx(`sndCardFlip1`, 0.6, 1.5)))),
        (this.ys = N(this.ys, this.size, 0.1 * t)),
        this.alarm[0] <= 0 &&
          ((this.x = N(this.x, this.xstart, 0.1 + t / 10)),
          (this.y = N(this.y, this.ystart, 0.1 + t / 10)),
          this.sideFrom === qn ||
            (this.angle =
              this.type === 0
                ? N(this.angle, 0, 0.2)
                : N(this.angle, 10 * Math.sin(Date.now() / 200), 0.2))),
        (this.blend =
          this.sideFrom === qn &&
          this.sideFrom === this.sideTo &&
          this.mouseHover()
            ? O.ltgray
            : O.white),
        this.sideTo === Kn && this.ystart < 0 && this.y < -20)
      ) {
        this.destroy();
        return;
      }
      Zt(this, !0) && this.requestFlip();
    }
    userEvent0() {
      this.requestFlip();
    }
    draw() {
      let e = this.g;
      if (this.sideFrom === Kn) {
        Hn(
          e,
          this.stats.ID,
          this.stats.stars,
          this.type,
          this.x,
          this.y,
          this.xs,
          this.ys,
          this.angle,
          this.blend,
        );
        for (let t = 1; t <= this.nbClones; t++)
          Hn(
            e,
            this.stats.ID,
            this.stats.stars,
            this.type,
            this.x,
            this.y - t * 5,
            this.xs,
            this.ys,
            this.angle,
            this.blend,
          );
        this.isSeal
          ? (e.r.draw(
              `sCardSeal`,
              0,
              this.x + 2,
              this.y + 2,
              this.xs,
              this.ys,
              this.angle,
              O.black,
              0.5,
            ),
            e.r.draw(
              `sCardSeal`,
              0,
              this.x,
              this.y,
              this.xs,
              this.ys,
              this.angle,
            ))
          : e.isFirstStamp &&
            this.isNew &&
            this.type > 0 &&
            e.up(Jn[this.type - 1]) > 0 &&
            e.r.draw(
              `sCardSeal`,
              0,
              this.x,
              this.y,
              this.xs,
              this.ys,
              this.angle,
              O.white,
              0.5 + Math.sin(Date.now() * 0.01) / 2,
            );
      } else
        e.r.draw(
          `sCardBack`,
          this.backImage,
          this.x,
          this.y,
          this.xs,
          this.ys,
          this.angle,
          this.blend,
          1,
        );
    }
  };
function Xn(e, t, n) {
  n === 1
    ? Qn(e, 0, Math.max(1, A(2 ** t.stars)))
    : n === 2
      ? Qn(e, 1, Math.max(1, A(t.stars)))
      : n === 3
        ? (e.speedMod = lt(e.speedMod + 1, 0.1, 2))
        : (n === 4 || n === 5) && e.stampShop?.(n);
}
function Zn(e, t, n, r = 0) {
  let i = e.add(new Yn(e, M(5, 315), M(45, 175), t), I.Instances);
  return ((i.type = r), (i.alarm[0] = n), i);
}
function Qn(e, t = 0, n = 1) {
  for (let r = 0; r < n; r++) {
    let n = e.add(new $n(e, M(5, 315), M(15, 175)), I.Instances);
    n.frame = t;
  }
}
var $n = class e extends z {
    taken = !1;
    constructor(t, n, r) {
      (super(t, n, r),
        (this.sprite = `sCoin`),
        (this.angle = A(360)),
        (this.y = this.ystart - 300),
        (this.alarm[0] =
          5 + 60 * Math.random() * Math.min(20, t.count(e) / 3)));
    }
    onAlarm(e) {
      e === 0 && this.g.sfx(`sndCoin`, 1, 1);
    }
    step() {
      (this.alarm[0] <= 0 && (this.y = N(this.y, this.ystart, 0.2)),
        !this.taken && Zt(this, !0) && this.userEvent0());
    }
    userEvent0() {
      if (!this.taken) {
        let e = this.g;
        ((this.taken = !0),
          e.cameraShake(1),
          (this.y += 15),
          e.later(1 + Math.random() * 10, `frames`, () => {
            (this.destroy(),
              e.moneyAdd([100, 1e3, 1e5, 1e6][this.frame] ?? 100, !0, `coins`));
          }),
          e.sfx(`sndCoin`, 1, 1.5),
          e.stats.stats.nb_coins++);
      }
    }
  },
  er = class extends z {
    aim = 0;
    constructor(e, t, n) {
      (super(e, t, n), (this.sprite = `sMagnet`), (this.alarm[0] = 60));
    }
    onAlarm(e) {
      let t = this.g;
      if (
        e !== 0 ||
        t.up(30) <= 0 ||
        ((this.alarm[0] = 60 / t.up(30)), t.godpackActive)
      )
        return;
      let n = t
        .all(Yn)
        .filter(
          (e) =>
            e.sideTo === qn &&
            e.alarm[0] <= 0 &&
            Math.hypot(e.x - this.x, e.y - this.y) > 20,
        )
        .sort(
          (e, t) =>
            Math.hypot(e.x - this.x, e.y - this.y) -
            Math.hypot(t.x - this.x, t.y - this.y),
        )[0];
      n &&
        ((this.aim =
          (Math.atan2(-(n.y - this.y), n.x - this.x) * 180) / Math.PI),
        t.particle(`magnet`, n.x, n.y, 16777215, I.InstancesTop),
        (n.xstart = this.x + M(-0.2, 0.2)),
        (n.ystart = this.y + M(-0.2, 0.2)),
        (this.xs = 2),
        (this.frame = 1),
        t.sfx(`sndWooshExit`, 0.5, 0.5));
    }
    step() {
      let e = this.g;
      ((this.angle = N(this.angle, this.aim, 0.1)),
        (this.xs = N(this.xs, 1, 0.3)),
        (this.ys = this.xs));
      let t = 60 / Math.max(1, e.up(30));
      (this.alarm[0] <= t / 2 && this.alarm[0] > 0 && (this.frame = 0),
        e.up(30) > 0 && this.alarm[0] <= 0 && (this.alarm[0] = 60 / e.up(30)));
    }
    draw() {
      this.g.up(30) > 0 && !this.g.godpackActive && this.drawSelf();
    }
  },
  tr = class extends z {
    id;
    type;
    dir = Math.random() * Math.PI * 2;
    speed = 4;
    vx;
    vy;
    hand;
    constructor(e, t, n, r, i) {
      (super(e, t, n),
        (this.id = r),
        (this.type = i),
        (this.sprite = `sCardBase`),
        (this.xs = this.ys = 0.1),
        (this.vx = Math.cos(this.dir) * this.speed),
        (this.vy = -Math.sin(this.dir) * this.speed),
        (this.hand = e.add(
          new nr(e, e.r.viewRight + 20, j(20, 160)),
          I.InstancesTop,
        )),
        (this.hand.card = this),
        e.particle(`impactSmall`, t, n),
        e.later(2, `seconds`, () => this.destroy(), !1, this));
    }
    step() {
      let e = this.hand.x - 50,
        t = this.hand.y,
        n = Math.atan2(t - this.y, e - this.x);
      ((this.vx += Math.cos(n) * 0.35),
        (this.vy += Math.sin(n) * 0.35),
        (this.vx *= 0.97),
        (this.vy *= 0.97),
        (this.x += this.vx),
        (this.y += this.vy),
        (this.angle = (Math.atan2(-this.vy, this.vx) * 180) / Math.PI + 90),
        (this.xs = N(this.xs, 0.6, 0.1)),
        (this.ys = this.xs),
        this.x > this.hand.x - 30 &&
          Math.abs(this.y - this.hand.y) < 30 &&
          (this.hand.grab(), this.destroy()));
    }
    draw() {
      let e = this.g;
      Hn(
        e,
        this.id,
        e.cards[this.id].stars,
        this.type,
        this.x,
        this.y,
        this.xs,
        this.ys,
        this.angle,
      );
    }
  },
  nr = class e extends z {
    xTo = 320;
    xMod = M(-5, 15);
    size;
    card = null;
    constructor(t, n, r) {
      (super(t, n, r),
        (this.xTo = t.r.viewRight),
        (this.sprite = `sHand`),
        (this.size = lt(1 / (Math.max(1, t.count(e)) / 50), 0.3, 1)),
        (this.blend = [16777215, 15859596, 8498943, 16735838, 16748791][A(4)]),
        t.later(10, `seconds`, () => this.destroy(), !1, this));
    }
    grab() {
      let e = this.g;
      ((this.frame = 1),
        (this.angle += 30),
        (this.x += 5),
        (this.xs *= 0.5),
        e.sfx(`sndCardDraw2`, 1, 1, !0),
        e.later(
          0.3 + Math.random(),
          `seconds`,
          () => {
            ((this.xTo += 80),
              e.particle(`impactSmall`, this.x - 20, this.y),
              e.sfx(`sndWooshExit`, 0.5, 1.5, !0));
          },
          !1,
          this,
        ),
        e.later(3, `seconds`, () => this.destroy(), !1, this));
    }
    step() {
      ((this.x = N(this.x, this.xTo + this.xMod, 0.2)),
        (this.angle = N(this.angle, 120, 0.2)),
        (this.xs = N(this.xs, this.size, 0.2)),
        (this.ys = this.xs));
    }
  };
function rr(e, t, n, r = 0) {
  if (t === `type0` || t === `{type0}`) return ``;
  let i = t;
  n !== void 0 && (i = i.split(`{value}`).join(n));
  let a = (e, t) => (i = i.split(e).join(t));
  return (
    a(`{shop}`, `[d#3249231][wave]${e.L(`FORMAT_SHOP`)}[/wave][c_black]`),
    a(`{star}`, `[rainbow][suistar][/rainbow][c_black]`),
    a(`{typevalue}`, `{type${r}}`),
    a(`{type1}`, `[c_ltgray][wheel]${e.L(`FORMAT_TYPE1`)}[/wheel][c_black]`),
    a(`{type2}`, `[d#5877678][wheel]${e.L(`FORMAT_TYPE2`)}[/wheel][c_black]`),
    a(`{type3}`, `[rainbow][wheel]${e.L(`FORMAT_TYPE3`)}[/wheel][/rainbow]`),
    a(
      `{type4}`,
      `[blink][wheel][d#16755841]${e.L(`FORMAT_TYPE4`)}[/wheel][/blink][c_black]`,
    ),
    a(
      `{type5}`,
      `[jitter][wheel][d#6184703]${e.L(`FORMAT_TYPE5`)}[/wheel][/jitter][c_black]`,
    ),
    a(
      `{type6}`,
      `[jitter][wheel][d#16224767]${e.L(`FORMAT_TYPE6`)}[/wheel][/jitter][c_black]`,
    ),
    a(`{boosters}`, `[d#3249231]${e.L(`FORMAT_BOOSTERS`)}[c_black]`),
    a(
      `{duplicates}`,
      `[d#5877678][wave]${e.L(`FORMAT_DUPLICATES`)}[/wave][c_black]`,
    ),
    a(`{blister}`, `[d#8539010]${e.L(`FORMAT_BLISTER`)}[c_black]`),
    a(`$`, `[d#5877678]$[c_black]`),
    a(
      `{roll}`,
      `[rainbow][wobble]${e.L(`UI_ROLL`)}[/wobble][/rainbow][c_black]`,
    ),
    a(`{godpack}`, `[d#16755841][wheel]${e.L(`UI_GODPACK`)}[/wheel][c_black]`),
    a(`{green}`, `[d#3249231]`),
    a(`{red}`, `[d#6184703]`),
    a(`{orange}`, `[d#6008319]`),
    a(`{blue}`, `[d#16755841]`),
    a(`{black}`, `[c_black]`),
    a(`{left_click}`, `[d#8212525]${e.L(`FORMAT_LEFTCLICK`)}[c_black]`),
    a(`{right_click}`, `[d#8212525]${e.L(`FORMAT_RIGHTCLICK`)}[c_black]`),
    i
  );
}
function ir() {
  if (typeof document > `u`) return !1;
  let e = document;
  return !!(document.fullscreenElement || e.webkitFullscreenElement);
}
function ar() {
  if (typeof document > `u`) return !1;
  let e = document.documentElement;
  return !!(e.requestFullscreen || e.webkitRequestFullscreen);
}
function or() {
  if (ir() || !ar()) return;
  let e = document.documentElement,
    t = () => {
      (navigator.keyboard?.lock?.([`Escape`]).catch(() => {}),
        screen.orientation?.lock?.(`landscape`).catch(() => {}));
    };
  try {
    e.requestFullscreen
      ? e
          .requestFullscreen({ navigationUI: `hide` })
          .then(t)
          .catch(() => {})
      : (e.webkitRequestFullscreen?.(), t());
  } catch {}
}
function sr() {
  if (!ir()) return;
  let e = document;
  (navigator.keyboard?.unlock?.(),
    document.exitFullscreen
      ? document.exitFullscreen().catch(() => {})
      : e.webkitExitFullscreen?.());
}
function cr(e) {
  e < 2 ? or() : sr();
}
var lr = 40,
  ur = 20,
  dr = 240,
  fr = 158;
function pr(e, t, n, r, i, a = `left`, o = `top`, s = `c_white`) {
  k(e.r, t, n, `[${s}][scale, ${i}]${r.replace(/\[/g, `(`)}`, {
    halign: a,
    valign: o,
  });
}
var mr = class {
    g;
    x;
    y;
    constructor(e, t, n) {
      ((this.g = e), (this.x = t), (this.y = n));
    }
    sync() {}
  },
  hr = class extends mr {
    key;
    max;
    onChange;
    value = 0;
    sliding = !1;
    constructor(e, t, n, r, i, a) {
      (super(e, t, n),
        (this.key = r),
        (this.max = i),
        (this.onChange = a),
        this.sync());
    }
    sync() {
      this.value = Number(this.g.options[this.key]);
    }
    hover() {
      let e = this.g.input;
      return (
        e.x >= this.x &&
        e.x < this.x + 40 &&
        e.y >= this.y - 7 &&
        e.y < this.y + 8
      );
    }
    step() {
      let e = this.g.input;
      if (
        ((this.value = lt(this.value, 0, this.max)),
        this.hover() && e.leftDown && (this.sliding = !0),
        this.sliding)
      ) {
        let t = lt(e.x, this.x, this.x + 40);
        ((this.value = N(0, this.max, (t - this.x) / 40)),
          e.leftDown ||
            ((this.sliding = !1),
            (this.g.options[this.key] = this.value),
            this.onChange?.(),
            this.g.saveOptions()));
      }
    }
    draw() {
      let e = this.g.r;
      (e.draw(`sGUISlidebar`, 1, this.x, this.y, this.value / this.max, 1),
        e.draw(`sGUISlidebar`, 0, this.x, this.y));
    }
  },
  gr = class extends mr {
    key;
    checked = !1;
    constructor(e, t, n, r) {
      (super(e, t, n), (this.key = r), this.sync());
    }
    sync() {
      this.checked = this.g.options[this.key] === !0;
    }
    step() {
      let e = this.g.input;
      e.leftPressed &&
        e.x >= this.x &&
        e.x < this.x + 20 &&
        e.y >= this.y &&
        e.y < this.y + 20 &&
        ((this.checked = !this.checked),
        (this.g.options[this.key] = this.checked),
        this.g.saveOptions());
    }
    draw() {
      this.g.r.draw(`sGUICheckbox`, +!!this.checked, this.x, this.y);
    }
  },
  _r = class extends mr {
    key;
    values;
    names;
    action;
    i = 0;
    constructor(e, t, n, r, i, a, o = () => {}) {
      (super(e, t, n),
        (this.key = r),
        (this.values = i),
        (this.names = a),
        (this.action = o),
        this.sync());
    }
    sync() {
      this.i = Math.max(0, this.values.indexOf(this.g.options[this.key]));
    }
    layout() {
      let e = this.names[this.i].slice(0, 10),
        t = Math.max(80, et(`[scale, 1]${e}`).w) * 0.5;
      return {
        show: e,
        left: this.x - t / 2 - 8,
        right: this.x + t / 2 + 8 + 2,
      };
    }
    set(e) {
      ((this.i = (this.i + e + this.values.length) % this.values.length),
        (this.g.options[this.key] = this.values[this.i]),
        this.action(),
        this.g.saveOptions());
    }
    step() {
      let e = this.g.input;
      if (!e.leftPressed) return;
      let { left: t, right: n } = this.layout();
      Math.hypot(e.x - t, e.y - this.y) <= 7
        ? this.set(-1)
        : Math.hypot(e.x - n, e.y - this.y) <= 7 && this.set(1);
    }
    draw() {
      let { show: e, left: t, right: n } = this.layout();
      (pr(this.g, this.x, this.y, e, 0.5, `center`, `middle`),
        this.g.r.draw(`sGUIArrows`, 0, t, this.y, -1, 1),
        this.g.r.draw(`sGUIArrows`, 0, n + 2, this.y, 1, 1));
    }
  },
  vr = class extends mr {
    name;
    color;
    confirmation;
    action;
    clicks = 0;
    confirm = !1;
    constructor(e, t, n, r, i, a, o) {
      (super(e, t, n),
        (this.name = r),
        (this.color = i),
        (this.confirmation = a),
        (this.action = o));
    }
    box() {
      let e = et(`[scale, .5]${this.name}`);
      return {
        x: this.x - 5 - e.w / 2,
        y: this.y - 5 - e.h / 2,
        w: 10 + e.w,
        h: 10 + e.h,
        sh: e.h,
      };
    }
    hover() {
      let e = this.box(),
        t = this.g.input;
      return t.x > e.x && t.x < e.x + e.w && t.y > e.y && t.y < e.y + e.h;
    }
    step() {
      this.hover() &&
        this.g.input.leftPressed &&
        (this.clicks++,
        !(
          this.confirmation &&
          ((this.confirm = !this.confirm),
          this.g.later(3, `seconds`, () => {
            ((this.clicks = 0), (this.confirm = !1));
          }),
          this.clicks < 2)
        ) && ((this.clicks = 0), this.action()));
    }
    draw() {
      let e = this.box();
      (this.g.r.drawStretched(
        `sGUIButton`,
        0,
        e.x,
        e.y,
        e.w,
        e.h,
        this.hover() ? O.dkgray : this.color,
        1,
      ),
        this.name
          .split(
            `
`,
          )
          .forEach(() => {}),
        pr(
          this.g,
          this.x,
          this.y,
          this.name,
          0.5,
          `center`,
          `middle`,
          `c_black`,
        ),
        this.confirm &&
          (() => {
            // Sits just above the button, clear of the checkboxes and labels above it
            let t = `[scale, .4]Sure ?`,
              n = et(t),
              r = Math.round(n.w + 12),
              i = 15,
              a = e.y - 2 - i / 2;
            Gr(
              this.g,
              Math.round(this.x - r / 2),
              Math.round(a - i / 2),
              r,
              i,
              12632256,
              4210752,
              this.x,
              a - 1,
              t,
              r,
            );
          })());
    }
  },
  yr = class extends z {
    controls = [];
    wasOpen = !1;
    constructor(e) {
      (super(e, 0, 0), (this.visible = !0));
      let t = (e) => lr + e,
        n = (e) => ur + e,
        r = () => {
          ((e.audio.sfxVolume = e.options.volume_effect / 10),
            (e.audio.musicVolume = e.options.volume_music / 10),
            e.audio.updateEmitter(e.audio.musicGain, e.audio.musicPitch));
        };
      this.controls = [
        new hr(e, t(62), n(16), `crt`, 2),
        new hr(e, t(186), n(20), `volume_music`, 10, r),
        new hr(e, t(186), n(41), `volume_effect`, 10, r),
        new gr(e, t(84), n(27), `camera_shake`),
        new gr(e, t(84), n(45), `moving_background`),
        new gr(e, t(84), n(63), `voice`),
        new gr(e, t(84), n(81), `flash`),
        new _r(
          e,
          t(184),
          n(62),
          `lang`,
          [`fr`, `en`, `tr`, `pl`],
          [`fr`, `en`, `tr`, `pl`],
          () => {
            e.lang = oe[e.options.lang] ?? oe.en;
          },
        ),
        new _r(
          e,
          t(184),
          n(84),
          `keyboard`,
          [`azerty`, `qwerty`],
          [`azerty`, `qwerty`],
        ),
        // The bulge slider sits where the old fullscreen selector was
        new hr(e, t(186), n(106), `bulge`, 10),
        new vr(e, t(117), n(141), `Done`, 16777215, !1, () => {
          e.optionsOpen = !1;
        }),
        new vr(
          e,
          t(42),
          n(141),
          `Quit game
(save)`,
          16777215,
          !0,
          () => {
            (e.save(),
              e.saveOptions(),
              (e.optionsOpen = !1),
              e.gotoRoom(`rmMenu`));
          },
        ),
        new vr(e, t(192), n(141), `Reset files`, 16743034, !0, () => {
          (e.resetSave(), window.location.reload());
        }),
      ];
    }
    step() {
      let e = this.g;
      if (
        (e.optionsOpen &&
          !this.wasOpen &&
          e.later(5, `frames`, () => this.controls.forEach((e) => e.sync())),
        (this.wasOpen = e.optionsOpen),
        e.optionsOpen)
      )
        for (let e of this.controls) e.step();
    }
    drawGui() {
      let e = this.g;
      if (e.optionsOpen) {
        e.r.drawStretched(`sUICadre`, 0, lr, ur, dr, fr, 5197647, 1);
        for (let [t, n, r] of [
          [147, 11, `Music`],
          [9, 9, `CRT`],
          [9, 28, `Shaking`],
          [9, 46, `Background`],
          [9, 64, `Voiceover`],
          [9, 82, `Flashes`],
          [136, 31, `Sounds`],
          [147, 97, `Bulge`],
        ])
          pr(e, lr + t, ur + n, r, 0.5);
        for (let e of this.controls) e.draw();
      }
    }
  },
  br = D(13739381);
function xr(e, t, n, r, i, a = 16777215) {
  let o = e.r,
    s = o.sprite(t);
  if (!s) return;
  let c = s.w,
    l = s.h,
    u = o.viewLeft,
    d = n - Math.ceil((n - u) / c) * c,
    f = i ? [] : [r];
  if (i) {
    let e = r - Math.ceil(r / l) * l;
    for (let t = e; t < 180; t += l) f.push(t);
  }
  for (let e of f)
    for (let n = d; n < o.viewRight; n += c) o.draw(t, 0, n, e, 1, 1, 0, a);
}
function Sr(e) {
  e.r.rect(e.r.viewLeft, 0, e.r.viewRight, 180, br);
}
function Cr(e, t) {
  if (t <= e[0][0]) return e[0][1];
  for (let n = 1; n < e.length; n++) {
    let [r, i] = e[n],
      [a, o] = e[n - 1];
    if (t <= r) return o + (i - o) * ((t - a) / (r - a || 1));
  }
  return e[e.length - 1][1];
}
var wr = class extends z {
    t = 0;
    step() {
      (this.t++, this.t > 1e3 && this.destroy());
    }
    draw() {
      let e = this.g.r,
        t = this.t,
        n = Cr(
          [
            [0, 1],
            [590.5, 1],
            [767, 0],
          ],
          t,
        );
      n > 0 && e.rect(e.viewLeft - 10, -10, e.viewRight + 10, 190, O.black, n);
      let r = Cr(
        [
          [0, 0],
          [94.26, 1],
          [183.94, 1],
          [252.98, 0],
        ],
        t,
      );
      r > 0 &&
        t <= 442 &&
        e.draw(`sMenuStudioLogo`, 0, 160, 90, 0.1, 0.1, 0, O.white, r);
      let i = Cr(
        [
          [0, 0],
          [254.55, 0],
          [353.21, 1],
          [454, 1],
          [539.61, 0],
        ],
        t,
      );
      i > 0 &&
        t <= 589 &&
        e.draw(`sMenuStudioDev`, 0, 160, 90, 0.1, 0.1, 0, O.white, i);
    }
  },
  Tr = class extends z {
    fadeIn;
    t = 0;
    constructor(e, t) {
      (super(e, 160, 90), (this.fadeIn = t));
    }
    step() {
      (this.t++, this.t > 1e3 && this.destroy());
    }
    draw() {
      let e = this.fadeIn
        ? Cr(
            [
              [0, 0],
              [100, 1],
            ],
            this.t,
          )
        : Cr(
            [
              [2, 1],
              [101, 0],
            ],
            this.t,
          );
      e > 0 &&
        this.g.r.rect(
          this.g.r.viewLeft - 10,
          -10,
          this.g.r.viewRight + 10,
          190,
          O.black,
          e,
        );
    }
  },
  Er = class extends z {
    bgSpeed = 0;
    bgCanSpeed = !1;
    bgY = 0;
    constructor(e) {
      (super(e, 0, 32),
        (this.visible = !1),
        e.later(10, `seconds`, () => (this.bgCanSpeed = !0), !1, this),
        e.later(
          12.7,
          `seconds`,
          () => {
            e.room === `rmMenuIntro` && e.gotoRoom(`rmMenu`);
          },
          !1,
          this,
        ),
        (e.titleStartedAt = performance.now()),
        Dr(e),
        (e.drawBackground = () => {
          (Sr(e), xr(e, `sBGMenuIntro_1`, 0, this.bgY, !0));
        }));
    }
    step() {
      (this.bgCanSpeed && (this.bgSpeed -= 0.1),
        (this.bgY += this.bgSpeed),
        this.g.input.keysPressed.has(`Enter`) && this.g.gotoRoom(`rmMenu`),
        this.g.audio.setTrackVolume(
          `mscTitle`,
          this.g.options.volume_music / 10,
        ));
    }
  };
function Dr(e) {
  if (!e.audio.ctx || e.audio.isPlaying(`mscTitle`)) return;
  let t = (performance.now() - e.titleStartedAt) / 1e3;
  (e.audio.playTrack(`mscTitle`, 1, !0, t),
    e.audio.setTrackVolume(`mscTitle`, e.options.volume_music / 10));
}
var Or = class extends z {
    bgLerp = 0;
    bgOff = 0;
    bgOffTo = 0;
    bpm = 150.2;
    beat = 0;
    bg = { b1: 300, b2: 300, b3: 300, b21: 0, x1: 0, x2: 0, x3: 0 };
    leaving = !1;
    constructor(e) {
      (super(e, 0, 0),
        (this.visible = !1),
        e.flash(16777215, I.UI),
        e.audio.play(`sndWooshEnter`, 1, 0.2),
        Dr(e),
        (e.drawBackground = () => {
          let t = this.bg;
          (Sr(e),
            xr(e, `sBGEnding_3`, t.x1, t.b1, !1),
            xr(e, `sBGEnding_1`, t.x2, t.b2, !1),
            xr(e, `sBGEnding_4`, t.x3, t.b3, !1),
            t.b21 > -180 && xr(e, `sBGMenuIntro_1`, 0, t.b21, !1));
        }));
    }
    step() {
      let e = this.g,
        t = this.bg;
      ((this.bgLerp = N(this.bgLerp, 1, 0.025)),
        (this.bgOff = N(this.bgOff, this.bgOffTo, 0.2)),
        (t.b1 = N(300, 27 + this.bgOff, this.bgLerp)),
        (t.b2 = N(300, 15 + this.bgOff, this.bgLerp)),
        (t.b3 = N(300, 39 + this.bgOff, this.bgLerp)),
        (t.x1 -= 0.5),
        --t.x2,
        (t.x3 -= 2),
        (t.b21 -= 10));
      let n = 60 / this.bpm;
      for (this.beat += 1 / 60; this.beat >= n;) {
        this.beat -= n;
        let t = e.all(kr)[0];
        (t &&
          t.alarm[0] <= 0 &&
          ((t.angleTo = t.angleTo < 0 ? 5 : -5), (t.xs += 0.02)),
          A(3) === 0 && e.add(new Ar(e, M(0, 320), 200), I.Instances));
      }
      this.leaving ||
        e.audio.setTrackVolume(`mscTitle`, e.options.volume_music / 10);
    }
    leave() {
      let e = this.g;
      ((this.leaving = !0),
        e.audio.stopTrack(`mscTitle`),
        e.add(new Tr(e, !0), I.UI),
        e.later(2, `seconds`, () => e.gotoRoom(`rmGame`)));
    }
  },
  kr = class extends z {
    angleTo = -1;
    hp = 20;
    hovered = !1;
    constructor(e) {
      (super(e, 160, 90),
        (this.sprite = `sLogo`),
        (this.xs = this.ys = 0.1),
        (this.ystart += 500),
        (this.alarm[0] = -1));
    }
    onAlarm(e) {
      e === 0 && (this.hp = 20);
    }
    mouse() {
      let e = this.g,
        t = this.mouseHover();
      if (
        (t !== this.hovered &&
          ((this.hovered = t), (this.blend = t ? O.dkgray : O.white)),
        !(!(e.input.leftPressed && t) || e.optionsOpen))
      )
        if (this.hp > 0) {
          (this.hp--,
            (this.angleTo = M(-30, 30)),
            (this.xs -= 0.05),
            e.cameraShake(20 - this.hp, !1));
          for (let t = 0; t < Math.min(5, 20 - this.hp); t++)
            e.particle(
              `impactSmall`,
              this.x + j(-50, 50),
              this.y + j(-50, 50),
              16777215,
              I.Particles,
            );
          (e.popup(
            this.x + j(-30, 30),
            this.y + j(-30, 30),
            `-1`,
            `[shake]`,
            0.5,
            0.5,
          ),
            e.sfx(`sndHurt1`, 1, 1, !0, !1),
            e.sfx(`sndExplosion1`, (20 - this.hp) / 20, 1, !0, !1),
            (this.alarm[0] = 300));
        } else {
          e.sfx(`sndExplosion1`, 1, 0.6, !1, !1);
          for (let t = 0; t < 20; t++)
            e.particle(`impactCards`, this.x, this.y, 16777215, I.Particles);
          (e.all(Or)[0]?.leave(),
            e.cameraShake(50),
            e.flash(16777215, I.Particles),
            this.destroy());
        }
    }
    step() {
      let e = performance.now(),
        t = Math.sin(e * 0.003) * 8;
      ((this.angle = N(this.angle, this.angleTo, 0.3)),
        (this.xs = N(this.xs, 0.15, 0.2)),
        (this.ys = this.xs),
        (this.y = this.ystart + t),
        (this.ystart = N(this.ystart, 90, 0.06)));
    }
  },
  Ar = class extends z {
    sinRand = A(300);
    vspeed = -0.5 - Math.random() * 2;
    cardId = A(30);
    type = A(3);
    constructor(e, t, n) {
      (super(e, t, n),
        (this.angle = A(360)),
        (this.sprite = `sCardBase`),
        (this.xs = this.ys = 0.5));
    }
    mouse() {
      let e = this.g;
      e.input.leftPressed &&
        this.mouseHover() &&
        !e.optionsOpen &&
        (e.particle(`impactSmall`, this.x, this.y, 16777215, I.UI),
        this.destroy(),
        e.cameraShake(10, !1),
        e.sfx(`sndHurt1`, 1, 1, !0, !1));
    }
    step() {
      ((this.xs = N(this.xs, 1, 0.2)),
        (this.ys = N(this.ys, 1, 0.2)),
        (this.angle += 2),
        (this.y += this.vspeed),
        this.y < -30 && this.destroy());
    }
    draw() {
      let e = this.g.cards[this.cardId];
      Hn(
        this.g,
        this.cardId,
        e ? e.stars : 1,
        this.type,
        this.x,
        this.y,
        0.5,
        0.5,
        this.angle,
      );
    }
  },
  jr = class extends z {
    isButton;
    hovered = !1;
    constructor(e, t, n, r) {
      (super(e, t, n),
        (this.isButton = r),
        (this.sprite = `sGUIMenu`),
        (this.y += 1e3));
    }
    clickable() {
      return this.isButton || this.g.input.touch;
    }
    mouse() {
      let e = this.g;
      if (e.input.keysPressed.has(`Escape`)) {
        let t = e.isOngletSelected();
        !this.isButton && t
          ? (e.closeOnglets(), e.cameraShake(10), (this.alarm[0] = 6))
          : this.alarm[0] <= 0 &&
            (e.optionsOpen = !this.isButton && !e.optionsOpen);
      }
      if (!this.isButton && !this.g.input.touch) {
        this.visible = !1;
        return;
      }
      ((this.visible = !0),
        this.isButton || ((this.xstart = 306), (this.ystart = 14)));
      let t = this.mouseHover();
      (t !== this.hovered &&
        ((this.hovered = t), (this.blend = t ? O.dkgray : O.white)),
        t &&
          e.input.leftPressed &&
          ((e.optionsOpen = !e.optionsOpen),
          (this.xs -= 0.2),
          (e.input.leftPressed = !1)));
    }
    step() {
      let e = performance.now(),
        t = Math.sin(e * 0.003) * 2,
        n = Math.sin(e * 0.002) * 10;
      ((this.angle = N(this.angle, n, 0.3)),
        (this.xs = N(this.xs, this.isButton ? 1 : 0.7, 0.2)),
        (this.ys = this.xs),
        (this.y = N(this.y, this.ystart + t, 0.1)),
        this.isButton || (this.x = this.xstart));
    }
  };
function Mr(e) {
  (e.add(new Er(e), I.UI), e.add(new wr(e, 160, 90), I.Sequence));
}
function Nr(e) {
  (e.add(new Or(e), I.UI),
    e.add(new kr(e), I.Logo),
    e.add(new jr(e, 291, 159, !0), I.Instances),
    e.add(new yr(e), I.UI));
}
function Pr(e) {
  (e.add(new jr(e, -20, -50, !1), I.UI), e.add(new yr(e), I.UI));
}
var Fr = [
    [1, 0.498, 0.2],
    [0.988, 1, 0.518],
    [0.604, 1, 0.569],
    [0.498, 0.675, 0.776],
    [0.537, 0.278, 0.506],
  ],
  Ir = (e) =>
    (Math.round(e[0] * 255) << 16) |
    (Math.round(e[1] * 255) << 8) |
    Math.round(e[2] * 255);
function Lr(e) {
  let t = Math.floor(e / 3600),
    n = Math.floor((e % 3600) / 60);
  return `${t}h${String(n).padStart(2, `0`)}`;
}
var Rr = class extends z {
    cursorSize = 1;
    cardId = 0;
    messages = [];
    creditI = 0;
    colorI = 0;
    tint = Ir(Fr[0]);
    fadeAlpha = 1;
    fadeColor = 16777215;
    fadeImage = !1;
    constructor(e) {
      (super(e, 0, -32),
        (this.alarm[0] = 180),
        (this.alarm[1] = 180),
        (this.messages = [...(e.Lany(`UI_CREDITS_MESSAGES`) ?? [])]));
      let t = e.Lany(`STATS`) ?? {};
      for (let [n, r] of Object.entries(t)) {
        let t = String(e.stats.stats[n] ?? 0);
        ((n === `game_duration` || n === `afk_duration`) && (t = Lr(Number(t))),
          (n === `nb_money_total` ||
            n === `nb_money_spent` ||
            n === `nb_employee_cost`) &&
            (t = `${P(Math.abs(Number(t)))}[d#6946705]$`),
          this.messages.push(`${r}\n${t}`));
      }
      ((this.messages = this.messages.map((t) =>
        rr(
          e,
          t.replace(
            /\n/g,
            `
[wave][d#9240561]`,
          ),
        ),
      )),
        e.sfx(`sndExplosion1`, 1, 0.5, !1, !1),
        e.audio.stopAll(),
        e.audio.playTrack(`mscEnding`, 1),
        (e.drawBackground = () => {
          let t = this.tint;
          (xr(e, `sBGEnding`, 0, 0, !0, t),
            xr(e, `sBGEnding_1`, 0, 0, !0, t),
            xr(e, `sBGEnding_2`, 0, 0, !0, t));
        }));
    }
    onAlarm(e) {
      let t = this.g;
      if (e === 0) {
        if (
          ((this.alarm[0] = 18), this.cardId++, this.cardId >= t.cards.length)
        )
          return;
        let e = A(2);
        e === 0
          ? t.add(new zr(t, -35, 135, this.cardId, 0, 1), I.Instances)
          : e === 1
            ? t.add(new zr(t, 344, 55, this.cardId, 1, 0.5), I.Bottom)
            : t.add(new zr(t, 344, 55, this.cardId, 2, 1), I.Instances);
      } else if (e === 1) {
        let e;
        do e = A(3);
        while (e === this.colorI);
        ((this.colorI = e),
          (this.tint = Ir(Fr[e])),
          this.creditI < this.messages.length - 1
            ? ((this.alarm[1] = 180),
              this.creditI++,
              t.sfx(`sndWooshEnter`, 1, 1, !0, !1))
            : (this.alarm[2] = 300));
      } else
        e === 2 &&
          ((this.fadeImage = !0),
          t.later(10, `seconds`, () => t.gotoRoom(`rmCredits`)));
    }
    mouse() {
      this.g.input.leftPressed && (this.cursorSize *= 2);
    }
    step() {
      ((this.cursorSize = N(this.cursorSize, 1, 0.2)),
        this.alarm[2] <= 0
          ? this.fadeAlpha > 0
            ? (this.fadeAlpha -= 0.003)
            : (this.fadeColor = 0)
          : (this.fadeAlpha += 0.004));
    }
    draw() {
      let e = this.g;
      (k(e.r, 320 / 2, 180 / 2, this.messages[this.creditI] ?? ``, {
        halign: `center`,
        valign: `middle`,
      }),
        e.r.draw(
          `sCursor`,
          0,
          e.input.x,
          e.input.y,
          this.cursorSize,
          this.cursorSize,
        ),
        this.fadeImage &&
          e.r.draw(
            `sFinalImage`,
            1 + Math.sin(performance.now() * 0.005),
            0,
            0,
            2,
            2,
          ));
    }
    drawGui() {
      let e = this.g.r;
      this.fadeAlpha > 0 &&
        e.rect(-10, -10, 330, 190, this.fadeColor, Math.min(1, this.fadeAlpha));
    }
  },
  zr = class extends z {
    id;
    mode;
    scale;
    sinRand = A(300);
    hspeed = 0;
    t = 0;
    constructor(e, t, n, r, i, a) {
      (super(e, t, n),
        (this.id = r),
        (this.mode = i),
        (this.scale = a),
        (this.sprite = `sCardArt${r}`),
        i === 0 &&
          ((this.hspeed = 1),
          e.later(
            0.3,
            `seconds`,
            () => {
              ((this.xs -= 0.3), (this.ys += 0.3));
            },
            !0,
            this,
          )),
        i === 2 && (this.hspeed = -1));
    }
    mouse() {
      let e = this.g;
      e.input.leftPressed &&
        this.mouseHover() &&
        (e.particle(`impactSmall`, this.x, this.y, 16777215, I.UI),
        this.destroy(),
        e.cameraShake(10, !1),
        e.sfx(`sndHurt1`, 1, 1, !0, !1));
    }
    step() {
      let e = performance.now(),
        t = Math.sin(this.sinRand + e * 0.01) * 15,
        n = Math.sin(this.sinRand + e * 0.005) * 12;
      if (
        ((this.xs = N(this.xs, this.scale, 0.2)),
        (this.ys = N(this.ys, this.scale, 0.2)),
        (this.x += this.hspeed),
        this.mode === 0)
      )
        ((this.angle = t), this.x > 350 && this.destroy());
      else if (this.mode === 1) {
        this.t += 2;
        let e = 344 - this.t,
          t = 55 - Math.sin(this.t / 60) * 30;
        ((this.angle = (Math.atan2(-(t - this.y), e - this.x) * 180) / Math.PI),
          (this.x = e),
          (this.y = t),
          (this.xs = -this.scale),
          this.x < -30 && this.destroy());
      } else
        ((this.y = N(this.y, this.ystart + n, 0.1)),
          this.angle++,
          this.x < -30 && this.destroy());
    }
  },
  Br = class extends z {
    textY = 210;
    messages = [
      `Thank you for playing :)`,
      ``,
      `[wave][d#6008319]Thanks to the translators`,
      `[scale, .5]Turkish
Mustafa 'Neekagami' Dinç`,
      ``,
      `[scale, .5]Polish
Jakub Brela
polishpatch.pl`,
      ``,
      ``,
      `[wave][d#6008319]This amazing free font`,
      `Cute Pixel`,
      `[scale, .75]by zK4rim`,
      ``,
      ``,
      `[wave][d#6008319]Playtesters`,
      ``,
      ...`Apty,artchuuur,bipeo_dev,bli._.blou,Decauville,decuv,Demurah,donroxas,ela_elo,Falcificateur,gegtropcool,girl_sweety,hug0g0,itsartstral,jimauve,Keraloon,Kiden17,Kouiik,Le_Pigeon_Baladeur,Limbes__,luucy_,Mouk,Ori,paranctiss,raphadekoko,redst0,richardwatterson__,souqhe,tselmek,valad0n`
        .split(`,`)
        .map((e) => `[scale, .5]${e}`),
      ``,
      ``,
      `[wave][d#6008319]Psychological support`,
      `Lucy`,
      ``,
      ``,
      `[d#16755841][wave](Press ENTER or ESCAPE)`,
    ];
    constructor(e) {
      (super(e, 0, 0),
        e.audio.stopAll(),
        e.audio.playTrack(`mscBoard3`, 1, !1, 0, 1.1));
      let t = D(5985334);
      e.drawBackground = () => e.r.rect(e.r.viewLeft, 0, e.r.viewRight, 180, t);
    }
    mouse() {
      let e = this.g.input.keysPressed;
      (e.has(`Enter`) ||
        e.has(`Escape`) ||
        (this.g.input.touch && this.g.input.leftPressed && this.textY < 0)) &&
        window.location.reload();
    }
    step() {
      this.textY > -(this.messages.length * 30 - 180 / 2) &&
        (this.textY -= 0.25);
    }
    draw() {
      this.messages.forEach((e, t) =>
        k(this.g.r, 320 / 2, this.textY + t * 30, `[scale, .75]${e}`, {
          halign: `center`,
          valign: `middle`,
        }),
      );
    }
  },
  Vr = class extends z {
    cooldown = 30;
    a = 0;
    constructor(e) {
      (super(e, 0, 0), (this.alarm[0] = this.cooldown));
    }
    onAlarm(e) {
      if (e !== 0 || this.cooldown <= 2) return;
      let t = this.g;
      ((this.alarm[0] = this.cooldown),
        this.cooldown--,
        (this.a += 0.04),
        t.particle(
          `impactBig`,
          5 + Math.random() * 310,
          15 + Math.random() * 160,
          16777215,
          I.UI,
        ),
        t.cameraShake(10, !1),
        t.sfx(`sndExplosion1`, 0.7, 1, !0, !1));
    }
    drawGui() {
      this.g.r.rect(-10, -10, 330, 190, O.white, Math.min(1, this.a));
    }
  };
function Hr(e) {
  (e.add(new Vr(e), I.UI),
    e.later(8, `seconds`, () => {
      (e.audio.stopAll(),
        (e.stats.finished = !0),
        e.save(),
        e.gotoRoom(`rmEnding`));
    }));
}
function Ur(e) {
  e.add(new Rr(e), I.UI);
}
function Wr(e) {
  e.add(new Br(e), I.Instances);
}
function Gr(e, t, n, r, i, a, o, s, c, l, u) {
  let d = e.r,
    f = r / 20,
    p = i / 20;
  (d.draw(`sUICadre`, 0, t + 2, n + 2, f, p, 0, O.black, 0.5),
    d.draw(`sUICadre`, 0, t, n, f, p, 0, o, 1),
    d.draw(`sUICadre`, 1, t, n, f, p, 0, a, 1),
    k(d, s, c, l, {
      halign: `center`,
      valign: `middle`,
      width: u ?? r * 0.9,
      lineHeight: 23,
    }));
}
function Kr(e) {
  return e.replace(/(\[[^\]]*\])|([^[]+)/g, (e, t) =>
    t ? e : e.toLowerCase(),
  );
}
var qr = class e extends qt {
  stats;
  type = 0;
  nbClicked = 0;
  isLock = !0;
  size = 0.5;
  nbPair = 1;
  infoLerp = 0;
  infoColor;
  sinStart;
  func = null;
  constructor(e, t, n, r, i, a = 0, o = 16777215) {
    (super(e, t, n),
      (this.stats = JSON.parse(JSON.stringify(e.boosters[r]))),
      (this.infoColor = i),
      (this.sinStart = a),
      (this.blendBase = o),
      (this.layer = I.Handler),
      (this.order = 1e3 + r),
      this.link(`shop`),
      (this.xs = this.ys = 0.5));
  }
  blendBase;
  price() {
    return Math.round(this.stats.price * this.nbPair);
  }
  buy() {
    let t = this.g;
    if (this.isLock || t.godpackActive) return;
    let n = this.price(),
      r = t.stats.money >= n || n === 0;
    if (this.alarm[0] <= 0) {
      if (!r) return;
      if (t.count(Gn) + 1 > t.up(8)) {
        (t.popup(
          320 / 2,
          180 / 2,
          t.L(`UI_DESTROYED_BOOSTER`),
          `[d#6184703][shake]`,
          0.5,
          1.5,
          -1,
          I.TextUp,
        ),
          t.cameraShake(10),
          t.sfx(`sndWrong1`, 0.8, 1, !0));
        return;
      }
      (t.moneyAdd(-n, !0, `shop`),
        (this.alarm[0] = Et(
          t.boosters[this.stats.ID].cooldown,
          t.upgrades,
          1,
        )));
      for (let e = 0; e < this.nbPair; e++) Wn(t, this.stats, this.type);
      ((this.nbPair = j(1, t.up(10))),
        (this.alarm[0] *= Math.max(1, this.nbPair / 2)),
        (this.type = 0),
        (this.stats = JSON.parse(JSON.stringify(t.boosters[this.stats.ID]))),
        this.func?.(),
        t.sfx(`sndClick1`, 1, 1, !0),
        t.sfx(`sndMoney1`),
        Ln(t) &&
          this.type !== 4 &&
          this.type !== 5 &&
          (Rn(t), (this.alarm[0] = 300)));
    } else if (
      ((this.alarm[0] -= 60),
      this.alarm[0] <= 0 && (this.alarm[0] = -1),
      t.sfx(`sndClick1`, 1, 1.5),
      this.nbClicked < 10 &&
        (t.popup(
          this.x + j(-15, 15),
          this.y + j(-15, 15),
          `-1`,
          `[shake]`,
          0.5,
          0.5,
          -1,
          I.TextUp,
        ),
        this.alarm[0] > 0))
    )
      for (let n of t.all(e)) n.nbClicked++;
    ((this.xs *= 1.3),
      (this.ys *= 1.3),
      (this.angle += 30),
      t.particle(`impactSmall`, this.x, this.y, 16777215, I.ParticlesUp));
  }
  step() {
    let e = this.g;
    if (
      (this.handlerLink(),
      (this.isLock = this.stats.ID > e.up(3) - 1),
      (this.y =
        this.ystart +
        (this.handler ? this.handler.y - this.hy : 0) +
        4 * Math.sin((this.sinStart + Date.now()) / 500)),
      (this.sprite = `sBooster${this.stats.ID}`),
      (this.frame = 1),
      (this.blend =
        this.alarm[0] <= 0 && !this.isLock ? this.blendBase : O.dkgray),
      Xt(this, this.size, 10 * Math.sin((this.sinStart + Date.now()) / 400)),
      !this.isLock && Zt(this) && this.buy(),
      this.type === 5 && Math.random() < 1 / 3)
    ) {
      let t = e.boosters[this.stats.ID];
      ((this.stats.proba = st(this.stats.proba)),
        (this.stats.price = j(t.price / 2, t.price * 2)),
        (this.stats.quantity[0] = j(t.quantity[0] / 2, t.quantity[0] * 3)),
        (this.stats.quantity[1] = j(t.quantity[1] / 2, t.quantity[1] * 3)));
    }
    e.speedMod > 1 && this.alarm[0] > 0 && (this.alarm[0] -= e.speedMod - 1);
  }
  userEvent0() {
    this.buy();
  }
  draw() {
    if (this.isLock) return;
    let e = this.g,
      t = e.r,
      n = this.price(),
      r = e.stats.money >= n || n <= 0;
    t.draw(
      this.sprite,
      this.frame,
      this.x + 2,
      this.y + 2,
      this.xs,
      this.ys,
      this.angle,
      O.black,
      0.5,
    );
    let i = this.mouseHover();
    (i && Qt(this, this.infoColor, 2),
      (this.infoLerp = N(this.infoLerp, +!!i, 0.5)));
    let a =
      this.type !== 0 && this.alarm[0] <= 0
        ? Me(this.type)
        : this.alarm[0] <= 0
          ? je.plastic
          : je.normal;
    for (let e = 0; e < this.nbPair; e++)
      t.draw(
        this.sprite,
        this.frame,
        this.x,
        this.y - e * 5,
        this.xs,
        this.ys,
        this.angle,
        this.blend,
        1,
        a,
      );
    let o = this.ystart + (this.handler ? this.handler.y - this.hy : 0) + 35;
    if (
      (k(t, this.x + 1, o + 1, `[scale, .5][wave][c_black][alpha, .5]${P(n)}$`),
      k(
        t,
        this.x,
        o,
        `[scale, .5][wave][${r ? `c_white` : `d#6184703`}]${P(n)}$`,
      ),
      this.alarm[0] > 0)
    ) {
      let e = 5 + Math.sin(Date.now() * 0.004) * 4,
        n = Math.sin(Date.now() * 0.003) * 10,
        r = Math.sin(Date.now() * 0.002) * 0.5;
      (k(t, this.x, this.y, `[scale, .5]${Math.floor(this.alarm[0] / 60)}`),
        this.nbClicked < 10 &&
          (t.draw(
            `sUIShopClick`,
            0,
            this.x,
            this.y + 10,
            1,
            1,
            0,
            O.white,
            0.5 + r,
          ),
          t.draw(
            `sUIShopClick`,
            1,
            this.x + e,
            this.y + 10 + e,
            1,
            1,
            n,
            O.white,
            0.5 + r,
          )));
    }
  }
  drawGui() {
    if (this.isLock || !this.mouseHover()) return;
    let e = this.g,
      t = 75 * this.infoLerp,
      n = this.stats,
      r = rr(e, e.L(n.description)),
      i = rr(
        e,
        `${e.L(`FORMAT_CARDS`)} : ${Math.floor(n.quantity[0])}-${Math.floor(n.quantity[1])}\n[rainbow][suistar][/rainbow][d#6008319] ${Jr(n.proba[0])}%\n[rainbow][suistar][suistar][/rainbow][c_ltgray] ${Jr(n.proba[1])}%\n[rainbow][suistar][suistar][suistar][/rainbow][d#5877678] ${Jr(n.proba[2])}%\n[rainbow][suistar][suistar][suistar][suistar][/rainbow][d#16224767] ${Jr(n.proba[3])}%`,
      ),
      a =
        this.type > 0
          ? rr(e, `{type${this.type}}`)
          : `${e.L(n.name).toLowerCase()}`;
    (Gr(
      e,
      210,
      t - 50,
      80,
      120,
      this.infoColor,
      4210752,
      250,
      t - 42,
      `[scale, .35]${a}`,
    ),
      Gr(
        e,
        215,
        t - 30,
        70,
        35,
        16777215,
        16777215,
        250,
        t - 15,
        `[scale, .32][c_black]${r}`,
      ),
      Gr(
        e,
        215,
        t + 10,
        70,
        55,
        16777215,
        16777215,
        220,
        t + 10,
        `[scale, .32][c_black][fa_left][fa_top]${i}`,
      ));
  }
};
function Jr(e) {
  return String(Math.round(e * 100) / 100);
}
var Yr = class extends qt {
    stars;
    sinStart;
    cache = { v: -1, cards: [] };
    constructor(e, t, n, r) {
      (super(e, t, n),
        (this.stars = r),
        (this.sprite = `sCardBase`),
        (this.layer = I.Handler),
        (this.order = 2e3 + r),
        (this.sinStart = t * 1e3),
        (this.xs = this.ys = 0.5),
        this.link(`duplicate`));
    }
    cards() {
      return (
        this.cache.v !== this.g.dupVersion &&
          (this.cache = {
            v: this.g.dupVersion,
            cards: vt(this.g.cards, this.stars),
          }),
        this.cache.cards
      );
    }
    sell() {
      let e = this.g,
        t = this.cards(),
        n = j(1, e.up(24));
      t.length > 0 &&
        (e.sfx(`sndClick1`, 1, 1, !0),
        e.sfx(`sndCoin`, 0.6, 0.6 + this.stars / 5));
      for (let t = 0; t < n; t++) {
        let t = this.cards();
        if (t.length === 0) break;
        let n = t[0];
        (e.moneyAdd(e.price(n.ID, n.type), !0, `duplicate`),
          e.cards[n.ID].quantity[n.type]--,
          e.dupVersion++,
          (this.xs = this.ys = 1.2),
          (this.angle = 30),
          e.cameraShake(2),
          e.count(tr) < 20 &&
            e.add(new tr(e, this.x, this.y, n.ID, n.type), I.TextUp));
      }
    }
    step() {
      (this.handlerLink(),
        (this.y =
          this.ystart +
          (this.handler ? this.handler.y - this.hy : 0) +
          4 * Math.sin((this.sinStart + Date.now()) / 500)),
        Xt(this, 0.5, 10),
        Zt(this) && this.sell());
    }
    userEvent0() {
      this.sell();
    }
    draw() {
      let e = this.g,
        t = this.cards();
      if (t.length === 0) return;
      let n = e.r,
        r = t[0],
        i = e.price(r.ID, r.type);
      (n.draw(
        this.sprite,
        0,
        this.x + 2,
        this.y + 2,
        this.xs,
        this.ys,
        this.angle,
        O.black,
        0.5,
      ),
        this.mouseHover() && Qt(this, O.white, 2));
      let a = Math.min(t.length - 1, 15),
        o = 0;
      for (let n = t.length - 1; n >= 0; n--) {
        let r = t[n];
        (n <= a &&
          Hn(
            e,
            r.ID,
            e.cards[r.ID].stars,
            r.type,
            this.x,
            this.y - (a - n) * 2,
            this.xs,
            this.ys,
            this.angle,
          ),
          (o += e.price(r.ID, r.type)));
      }
      let s = this.ystart + (this.handler ? this.handler.y - this.hy : 0);
      (k(
        n,
        this.x + 1,
        s + 38 + 1,
        `[scale, .5][c_black][alpha, .5]x${t.length}\n[scale, .5]${P(i)}$`,
      ),
        k(
          n,
          this.x,
          s + 38,
          `[scale, .5][c_white]x${t.length}\n[scale, .5]${P(i)}$`,
        ),
        k(n, this.x + 1, s + 61, `[scale, .5][c_black][alpha, .5]${P(o)}$`),
        k(n, this.x, s + 60, `[scale, .5][d#9240561]${P(o)}$`));
    }
  },
  Xr = class extends qt {
    shown = 0;
    constructor(e, t, n) {
      (super(e, t, n),
        (this.layer = I.Handler),
        (this.order = 2100),
        this.link(`duplicate`));
    }
    step() {
      (this.handlerLink(), (this.shown = N(this.shown, yt(this.g.cards), 0.1)));
    }
    draw() {
      let e = this.g,
        t = e.up(6);
      // 9-slice bar (rounded ends keep their shape) instead of a stretched sprite
      (e.r.draw(`sUIBar`, 0, this.x, this.y, 11, 1, 0, O.dkgray, 1),
        t > 0 &&
          this.shown > 0 &&
          e.r.draw(
            `sUIBar`,
            0,
            this.x,
            this.y,
            Math.min(1, this.shown / t) * 11,
            1,
            0,
            16740721,
            1,
          ),
        k(
          e.r,
          this.x + 110 / 2,
          this.y - 1,
          `[scale, .5]${Math.round(this.shown)}/${t}`,
        ));
    }
  },
  Zr = class extends qt {
    page = 0;
    sortType = `stars`;
    starsAsc = !0;
    qtyAsc = !0;
    constructor(e, t, n) {
      (super(e, t, n), (this.layer = I.UI), this.link(`collection`));
    }
    pages() {
      return Math.floor(this.g.cards.length / 12);
    }
    sorted() {
      let e = this.g.cards.slice(),
        t = (e) => e.quantity.filter((e) => e >= 0).length;
      return (
        this.sortType === `stars`
          ? e.sort(
              (e, t) =>
                (this.starsAsc ? e.stars - t.stars : t.stars - e.stars) ||
                e.ID - t.ID,
            )
          : e.sort(
              (e, n) =>
                (this.qtyAsc ? t(e) - t(n) : t(n) - t(e)) || e.ID - n.ID,
            ),
        e
      );
    }
    pageAdd(e) {
      (this.page + e >= 0 && this.page + e <= this.pages()
        ? (this.page += e)
        : (this.page = Math.sign(e) === -1 ? this.pages() : 0),
        this.refresh());
    }
    refresh() {
      let e = this.g;
      for (let t of e.all(Qr)) t.destroy();
      let t = this.page * 12,
        n = [60, 100, 140, 180, 220, 260, 60, 100, 140, 180, 220, 260],
        r = [260, 260, 260, 260, 260, 260, 310, 310, 310, 310, 310, 310],
        i = this.sorted(),
        a = this.handler;
      for (let o = 0; o < 12 && !(t + o >= i.length); o++) {
        let s = e.add(
          new Qr(e, n[o] + (a.x - a.roomX), r[o] + (a.y - a.roomY), i[t + o]),
          I.CardsTop,
        );
        ((s.xstart = n[o]),
          (s.ystart = r[o]),
          (s.hx = a.roomX),
          (s.hy = a.roomY));
      }
    }
    step() {
      this.handlerLink();
      let e = this.g.input.keysPressed;
      (e.has(`ArrowRight`) && this.pageAdd(1),
        e.has(`ArrowLeft`) && this.pageAdd(-1));
    }
    draw() {
      let e = this.g,
        t = Math.round(e.cards.length / 12);
      for (let n = 0; n < t; n++)
        e.r.circle(
          this.x + 145 - (t * 10) / 2 + n * 10,
          this.y + 30,
          2,
          n === this.page ? O.yellow : O.ltgray,
        );
    }
  },
  Qr = class extends qt {
    card;
    typesPossessed = 0;
    size = 0;
    sinStart;
    constructor(e, t, n, r) {
      (super(e, t, n),
        (this.card = r),
        (this.sprite = `sCardBase`),
        (this.xs = this.ys = 0),
        (this.sinStart = t * 8),
        (this.handler = e.all(Kt).find((e) => e.name === `collection`) ?? null),
        e.later(
          Math.max(1, t / 10),
          `frames`,
          () => {
            ((this.size = 0.6),
              (this.xs = this.ys = 2),
              e.sfx(
                [`sndCardDraw1`, `sndCardDraw2`, `sndCardDraw3`][j(0, 2)],
                0.4,
                1,
                !0,
                !1,
              ),
              (this.typesPossessed = r.quantity.filter((e) => e > -1).length));
          },
          !1,
          this,
        ));
    }
    sortKey() {
      return this.xs;
    }
    mouse() {
      let e = this.g;
      e.input.leftPressed &&
        this.mouseHover() &&
        this.typesPossessed > 0 &&
        this.xs <= 1 &&
        e.count(ei) === 0 &&
        e.add(new ei(e, 320 / 2, 180 / 2, this.card.ID), I.CardsTop);
    }
    step() {
      (this.handlerLink(),
        Xt(this, this.size, 10 * Math.sin((this.sinStart + Date.now()) / 500)),
        this.y > 240 && this.destroy());
    }
    draw() {
      let e = this.g,
        t = e.r;
      if (this.typesPossessed > 0) {
        let n = Math.floor((this.typesPossessed / 7) * 100),
          r = Math.min(255, Math.round((50 + n * 2) * (255 / 255))),
          i = (r << 16) | (r << 8) | r;
        if (
          (this.mouseHover() && (i = O.ltgray),
          t.draw(
            this.sprite,
            0,
            this.x + 2,
            this.y + 2,
            this.xs,
            this.ys,
            this.angle,
            O.black,
            0.5,
          ),
          Hn(
            e,
            this.card.ID,
            this.card.stars,
            0,
            this.x,
            this.y,
            this.xs,
            this.ys,
            this.angle,
            i,
          ),
          this.card.recent_unlock)
        ) {
          let n = Math.sin(Date.now() * 0.003) * 20;
          (t.draw(
            `sUIUnlock`,
            0,
            this.x + 1,
            this.y + 1,
            1,
            1,
            n,
            O.black,
            0.5,
          ),
            t.draw(`sUIUnlock`, 0, this.x, this.y, 1, 1, n, O.pink, 1),
            this.mouseHover() &&
              this.xs <= 1 &&
              ((this.card.recent_unlock = !1),
              e.sfx(`sndClick1`, 1, 1.5, !1, !1)));
        } else
          n < 100 &&
            (k(
              t,
              this.x + 1,
              this.y + 1,
              `[scale, .5][c_black][alpha, .7]${this.typesPossessed}/7`,
            ),
            k(t, this.x, this.y, `[scale, .5]${this.typesPossessed}/7`));
      } else
        (t.draw(
          `sCardLock`,
          0,
          this.x,
          this.y,
          this.xs,
          this.ys,
          this.angle,
          O.ltgray,
          0.2,
        ),
          t.draw(
            `sCardLock`,
            1,
            this.x,
            this.y,
            this.xs * 2,
            this.xs * 2,
            this.angle,
            O.ltgray,
            1,
          ));
    }
  },
  $r = class extends qt {
    possessed = 0;
    shown = 0;
    last = 0;
    total = 0;
    dy = 0;
    constructor(e, t, n) {
      (super(e, t, n),
        (this.layer = I.UI),
        this.link(`collection`),
        (this.total = St(e.cards)));
    }
    animate() {
      ((this.alarm[0] = 18),
        (this.possessed = 0),
        (this.shown = 0),
        (this.last = 0));
    }
    onAlarm(e) {
      e === 0 &&
        (this.g.later(
          0.5,
          `seconds`,
          () => {
            ((this.possessed = xt(this.g.cards)),
              (this.total = St(this.g.cards)));
          },
          !1,
          this,
        ),
        this.g.sfx(`sndWooshEnter`, 0.4, 0.9, !1, !1));
    }
    step() {
      (this.handlerLink(),
        (this.dy = N(this.dy, this.alarm[0] <= 0 ? 0 : 200, 0.9)),
        (this.shown = N(this.shown, this.possessed, 0.1)),
        this.last !== Math.floor(this.shown) &&
          ((this.last = Math.floor(this.shown)),
          this.g.sfx(`sndBarTick`, 0.5, 0.8 + this.shown / 1001, !1, !1)));
    }
    draw() {
      let e = this.g.r,
        t = this.y + this.dy;
      (e.draw(`sUIBar`, 0, this.x, t, 28, 1, 0, O.dkgray, 1),
        this.total > 0 &&
          this.shown > 0 &&
          e.draw(
            `sUIBar`,
            0,
            this.x,
            t,
            Math.min(1, this.shown / this.total) * 28,
            1,
            0,
            16740721,
            1,
          ),
        k(
          e,
          this.x + 140,
          t - 9.8,
          `[scale, .5]${Math.round(this.shown)}/${this.total}`,
          { valign: `top` },
        ));
    }
  },
  ei = class extends z {
    ID;
    type = 0;
    constructor(e, t, n, r) {
      (super(e, t, n),
        (this.ID = r),
        (this.sprite = `sCardBase`),
        (this.alarm[0] = 5),
        (this.y = 600));
    }
    sortKey() {
      return 100;
    }
    mouse() {
      let e = this.g;
      e.input.leftPressed &&
        (this.contains(e.input.x, e.input.y)
          ? this.next()
          : this.alarm[0] <= 0 && this.destroy());
    }
    next() {
      let e = this.g,
        t = e.cards[this.ID];
      ((this.angle = 720),
        (this.xs = 0.1),
        e.cameraShake(10),
        (this.y += 30),
        e.sfx(`sndWoosh1`, 1, 1, !0, !1),
        (this.type = this.type >= 6 ? 0 : this.type + 1),
        t.quantity[this.type] > -1
          ? e.sfx(`sndCardNew${this.type}`, 0.7, 0.8 + 0.1 * t.stars, !1, !1)
          : e.sfx(`sndWrong1`, 1, 1, !0, !0));
    }
    step() {
      ((this.x = N(this.x, this.xstart, 0.2)),
        this.alarm[0] <= 0 && (this.y = N(this.y, this.ystart, 0.2)),
        Xt(this, 1, 10 * Math.sin(Date.now() / 500)),
        this.g.input.keysPressed.has(`Escape`) && this.destroy());
    }
    draw() {
      let e = this.g,
        t = e.r,
        n = e.cards[this.ID],
        r = n.quantity[this.type] > -1;
      (t.rect(-10, -10, 330, 190, O.black, 0.6),
        k(
          t,
          320 / 2,
          25,
          `[wave][scale, .8][c_white]${e.L(n.name).toUpperCase()}`,
        ),
        k(
          t,
          320 / 2,
          40,
          `[scale, .6]${rr(e, this.type === 0 ? `normal` : `{type${this.type}}`)}`,
        ),
        k(t, 320 / 2, 160, `[wave][scale, .6]${e.L(n.description)}`, {
          width: 300,
        }),
        r
          ? (t.draw(
              this.sprite,
              0,
              this.x + 2,
              this.y + 2,
              this.xs,
              this.ys,
              this.angle,
              O.black,
              0.5,
            ),
            Hn(
              e,
              this.ID,
              n.stars,
              this.type,
              this.x,
              this.y,
              this.xs,
              this.ys,
              this.angle,
            ))
          : Hn(
              e,
              this.ID,
              n.stars,
              0,
              this.x,
              this.y,
              this.xs,
              this.ys,
              this.angle,
              O.dkgray,
            ));
    }
  },
  ti = class e extends qt {
    upgrade;
    isLock = !0;
    isComplete = !1;
    leftClicked = !1;
    pressAt = { x: 0, y: 0 };
    isDraw = !0;
    infoLerp = 0;
    func;
    constructor(e, t, n, r, i) {
      (super(e, t, n),
        (this.upgrade = e.upgrades[r]),
        (this.func = i),
        (this.sprite = `sUIUpgrade`),
        (this.layer = I.UI),
        this.link(`upgrades`));
    }
    upgradesOpen() {
      return this.g.all(tn).find((e) => e.ID === 3)?.isSelected ?? !1;
    }
    mouse() {
      let e = this.g.input;
      if (
        (e.leftPressed &&
          this.mouseHover() &&
          this.visible &&
          ((this.leftClicked = !0), (this.pressAt = { x: e.x, y: e.y })),
        e.leftReleased)
      ) {
        let t = Math.hypot(e.x - this.pressAt.x, e.y - this.pressAt.y);
        (this.leftClicked &&
          this.mouseHover() &&
          t < 6 &&
          !this.isComplete &&
          !this.isLock &&
          this.isDraw &&
          this.alarm[0] <= 0 &&
          this.buy(),
          (this.leftClicked = !1));
      }
    }
    buy() {
      let e = this.g,
        t = this.upgrade,
        n = t.prices[t.level];
      e.stats.money < n ||
        (e.moneyAdd(-n, !0, `upgrades`),
        t.level++,
        (this.xs *= 1.5),
        (this.angle += 30),
        e.cameraShake(5, !1),
        e.particle(
          `impactSmall`,
          e.input.x,
          e.input.y,
          16777215,
          I.ParticlesUp,
        ),
        ri(e, this),
        e.sfx(`sndClick1`, 1, 1, !0),
        e.sfx(`sndMoney1`, 1, 1, !1, !1),
        e.sfx(`sndUpgrade1`, 1, 0.5 + t.level / t.values.length, !1, !1),
        ft(e.upgrades));
    }
    step() {
      let e = this.g,
        t = this.handler;
      this.handlerLink();
      let n = this.upgrade;
      ((this.isComplete = dt(n)),
        (this.isLock = ut(e.upgrades, n.ID)),
        (this.visible = !this.isLock),
        Xt(this, 1, 0),
        (this.blend = this.isComplete
          ? O.green
          : n.prices[n.level] > e.stats.money
            ? O.redSoft
            : n.level > 0
              ? O.yellow
              : O.white),
        t && t.y > 180 / 2 && (this.alarm[0] = 30),
        (this.isDraw =
          !!t &&
          this.x >= t.x - 10 &&
          this.x <= t.x + 300 + 10 &&
          this.y >= t.y + 19 - 10 &&
          this.y <= t.y + t.h() + 10));
    }
    draw() {}
    drawNode() {
      let e = this.g.r,
        t = this.upgrade,
        n = t.level / t.values.length,
        r = t.level === 0 || this.isComplete ? 100 : n * 100;
      if (
        (e.circleProgress(
          this.x + 2,
          this.y + 2,
          12 * this.xs,
          2,
          r,
          O.black,
          !0,
          0.5,
        ),
        e.circleProgress(this.x, this.y, 12 * this.xs, 2, r, this.blend, !0, 1),
        !this.isLock)
      ) {
        let n = Math.sin(Date.now() / 300);
        t.ID !== 45 && t.ID !== 47
          ? e.draw(`sUIUpgradeIcons`, t.ID, this.x, this.y, this.xs, this.ys)
          : e.draw(
              `sUIUpgradeIcons`,
              t.ID,
              this.x,
              this.y,
              this.xs + n / 2,
              this.ys + n / 2,
              10 * n,
            );
      }
    }
    drawLines() {
      let t = this.g;
      for (let n of this.upgrade.dependencies) {
        let r = t.all(e).find((e) => e.upgrade.ID === n);
        r && t.r.line(this.x, this.y, r.x, r.y, 2, this.blend, r.blend);
      }
    }
    drawGui() {
      let e = this.g;
      if (
        !this.visible ||
        !this.isDraw ||
        !this.upgradesOpen() ||
        !this.mouseHover()
      ) {
        this.infoLerp = N(this.infoLerp, 0, 0.2);
        return;
      }
      let t = this.upgrade,
        n = F(e.upgrades, t.ID, t.level),
        r = F(e.upgrades, t.ID, t.level + 1),
        i =
          `[d#16755841]${ni(n)}` +
          (this.isComplete
            ? `[c_black]`
            : `[d#3249231] (+${ni(r - n)})[c_black]`),
        a = 0.32,
        o = ``;
      do
        ((o = `[scale, ${a.toFixed(2)}] ${Kr(rr(e, e.L(t.description), i, r))}`),
          (a -= 0.01));
      while (et(o, { width: 63 }).h >= 30 && a > 0.15);
      this.infoLerp = N(this.infoLerp, 1, 0.5);
      let s = 90 * this.infoLerp;
      (Gr(
        e,
        220,
        s - 50,
        80,
        60,
        12632256,
        4210752,
        260,
        s - 42,
        `[scale, .35]${Kr(rr(e, e.L(t.name)))}`,
      ),
        Gr(
          e,
          225,
          s - 30,
          70,
          35,
          16777215,
          16777215,
          260,
          s - 15,
          `[scale, .32][c_black]${o}`,
        ),
        this.isComplete ||
          Gr(
            e,
            220,
            s + 15,
            35,
            15,
            12632256,
            4210752,
            237,
            s + 19,
            `[scale, .38]${P(t.prices[t.level])}$`,
            60,
          ),
        Gr(
          e,
          265,
          s + 15,
          35,
          15,
          12632256,
          4210752,
          282,
          s + 19,
          `[scale, .4]${t.level}/${t.values.length}`,
          60,
        ));
    }
  };
function ni(e) {
  return isFinite(e) ? P(Math.round(e * 100) / 100) : `∞`;
}
function ri(e, t) {
  switch (t.func) {
    case `money1000`:
      e.stats.money_max = 1e3;
      break;
    case `money10000`:
      e.stats.money_max = 1e4;
      break;
    case `money1m`:
      e.stats.money_max = 1e6;
      break;
    case `moneyInf`:
      e.stats.money_max = 1 / 0;
      break;
    case `activate`:
      Ct(e.cards);
      break;
    case `activate2`:
      (Ct(e.cards), Ct(e.cards));
      break;
    case `godpack`:
      e.godpackCooldown = 300;
      break;
    case `magnet`:
      for (let t of e.all(er)) t.alarm[0] = 300;
      break;
    case `shopcard`:
      e.shopCardsRefresh();
      break;
    case `end`:
      e.stats.full_collection
        ? Hr(e)
        : (e.sfx(`sndWrong1`, 1, 1, !0, !1),
          e.popup(
            320 / 2,
            180 / 2,
            e.L(`UI_END_IMPOSSIBLE`),
            `[shake][d#6184703]`,
            0.5,
            3,
            -1,
            I.TextUp,
          ),
          (t.upgrade.level = 0),
          e.moneyAdd(t.upgrade.prices[0], !0, `upgrade`));
  }
}
// Header ends at +19; reserve 19 more pixels for the pulse/ring and shadow.
function ctpUpgradeTop(panelY) {
  return panelY + 38;
}
function ctpUpgradeDragY(delta, top, panelY, panelHeight) {
  return Math.max(ctpUpgradeTop(panelY) - top,
    Math.min(panelY + panelHeight - 20 - top, delta));
}
function ii(e, t) {
  let n = e.r;
  // The tree lives below the panel title
  n.setScissor({ x: t.x, y: t.y + 3, w: 300, h: t.h() - 3 });
  let r = e.all(ti);
  for (let e of r) e.isLock || e.drawLines();
  for (let e of r) e.visible && e.drawNode();
  n.setScissor(null);
}
var ai = class extends z {
  dragging = !1;
  lx = 0;
  ly = 0;
  step() {
    let e = this.g;
    if (!e.all(tn).find((e) => e.ID === 3)?.isSelected) {
      this.dragging = !1;
      return;
    }
    let t = e.input,
      n = e.all(Kt).find((e) => e.name === `upgrades`);
    if (
      (t.downStarted &&
        n &&
        n.pointIn(t.x, t.y) &&
        ((this.dragging = !0), (this.lx = t.x), (this.ly = t.y)),
      (t.leftReleased || !t.leftDown) && (this.dragging = !1),
      this.dragging)
    ) {
      let n = (t.x - this.lx) * 2,
        r = (t.y - this.ly) * 2,
        i = e.all(ti),
        a = Math.min(...i.map((e) => e.xstart)),
        o = Math.max(...i.map((e) => e.xstart)),
        s = Math.min(...i.map((e) => e.ystart)),
        c = Math.max(...i.map((e) => e.ystart)),
        l = lt(n, 40 - o, 290 - a),
        u = lt(r, 560 - c, 690 - s);
      for (let e of i) ((e.xstart += l), (e.ystart += u));
      ((this.lx = t.x), (this.ly = t.y));
    }
  }
};
function oi(e, t) {
  let n = e.all(qr).filter((e) => !e.isLock),
    r = [];
  for (let e of n) (r.push(e), e.stats.ID !== 3 && r.push(e));
  let i = r[Math.floor(Math.random() * r.length)];
  i &&
    (i.stats.ID !== 6 && (i.type = t),
    t === 4 && (i.stats.proba = i.stats.proba.slice().reverse()),
    (i.alarm[0] = 0));
}
var si = [
    [3, 150, 610, null],
    [4, 150, 650, null],
    [5, 190, 650, null],
    [6, 110, 610, null],
    [7, 30, 610, null],
    [0, 150, 570, null],
    [9, 150, 530, null],
    [8, 190, 530, null],
    [1, 30, 530, null],
    [10, 150, 690, null],
    [11, 110, 530, null],
    [12, 30, 650, null],
    [13, -10, 650, null],
    [14, -10, 610, null],
    [19, -10, 530, null],
    [20, -50, 530, null],
    [21, -90, 530, null],
    [15, 30, 570, null],
    [16, -10, 570, null],
    [17, -50, 570, null],
    [18, -90, 570, null],
    [22, 130, 490, null],
    [23, 130, 450, null],
    [24, 110, 650, null],
    [43, 390, 570, `money1m`],
    [26, 310, 610, `money10000`],
    [27, 230, 610, `money1000`],
    [28, 230, 530, null],
    [29, 210, 490, null],
    [30, 250, 490, `magnet`],
    [31, 110, 690, null],
    [34, 190, 690, `shopcard`],
    [35, 30, 490, null],
    [36, -10, 490, null],
    [37, -50, 490, null],
    [38, -90, 490, null],
    [39, 390, 650, null],
    [40, 350, 690, null],
    [41, 390, 690, null],
    [42, 430, 690, null],
    [25, 470, 570, `moneyInf`],
    [44, -130, 530, null],
    [45, -170, 530, null],
    [46, -130, 570, null],
    [47, -170, 570, null],
    [48, -130, 490, null],
    [49, 270, 650, `activate`],
    [50, 270, 690, `activate`],
    [51, 270, 730, `activate2`],
    [53, 390, 730, null],
    [54, 390, 530, null],
    [56, 370, 490, null],
    [57, 410, 490, null],
    [55, 330, 490, null],
    [58, 450, 490, null],
    [59, -170, 490, null],
    [60, 310, 570, `godpack`],
    [62, 370, 450, null],
    [63, 410, 450, null],
    [61, 330, 450, null],
    [64, 450, 450, null],
    [65, 230, 570, null],
    [66, 550, 570, `end`],
  ],
  ci = class extends z {
    constructor(e) {
      (super(e, -40, -20),
        (this.visible = !1),
        e.stats.tutorial_done
          ? (e.musicAlarm = 1)
          : (Ct(e.cards), (e.backgroundIndex = 5)),
        (this.alarm[0] = 60),
        (this.alarm[1] = 180),
        e.later(
          900,
          `seconds`,
          () => {
            e.stats.tutorial_done && this.saveWithPopup();
          },
          !0,
          this,
        ),
        e.later(5, `frames`, () => ui(e), !0, this));
    }
    saveWithPopup() {
      let e = this.g;
      (e.save(),
        e.stats.tutorial_done &&
          e.popup(
            25,
            160,
            e.L(`UI_SAVING`),
            `[fa_left][wave][d#16224767]`,
            0.5,
            3,
          ));
    }
    onAlarm(e) {
      (e === 0 && this.everySecond(), e === 1 && this.tutorial());
    }
    everySecond() {
      let e = this.g;
      if (
        ((this.alarm[0] = 60),
        e.stats.stats.game_duration++,
        e.lastCursor.x !== e.input.x || e.lastCursor.y !== e.input.y
          ? (e.lastCursor = { x: e.input.x, y: e.input.y })
          : e.stats.stats.afk_duration++,
        e.stats.tutorial_done)
      ) {
        for (let t of e.all(qr))
          if (t.stats.ID === 6 && t.alarm[0] <= 0 && !t.isLock) {
            let e = [10, 30, 40, 20];
            ((t.stats.price += 120),
              (t.stats.cooldown += 2),
              (t.stats.quantity[1] = Math.min(
                333,
                Math.max(1, t.stats.quantity[1] + 0.2),
              )));
            for (let n = 0; n < 4; n++)
              t.stats.proba[n] = N(t.stats.proba[n], e[n], 0.01);
          }
        if (
          (Bn(e),
          e.up(27) > 100 && ot(0.5) && Qn(e, 0, 1),
          !e.stats.full_collection)
        ) {
          let t = 1001 - xt(e.cards),
            n = (t, n, r) => {
              ((e.emitPitchTo = r), (e.lastRush = t), li(e, n));
            };
          t <= 0 && e.lastRush !== 4
            ? (n(4, 0, 0.95), (e.stats.full_collection = !0))
            : t <= 10 && e.lastRush < 3
              ? n(3, 10, 1.3)
              : t <= 50 && e.lastRush < 2
                ? n(2, 50, 1.2)
                : t <= 100 && e.lastRush < 1 && n(1, 100, 1.1);
        }
        if (ot(0.5)) for (let t of e.all(qr)) t.nbClicked = 0;
      }
    }
    tutorial() {
      let e = this.g;
      if (e.stats.tutorial_done) return;
      this.alarm[1] = 60;
      let t = e.stats.UI_unlock,
        n = (t) => {
          let n = e.all(tn).find((e) => e.ID === t);
          n && (n.visible = !0);
        },
        r = (t, n, r) => {
          (e.particle(`impactSmall`, t, 7, 16777215, I.ParticlesUp),
            e.cameraShake(5));
          let i =
            e.options.keyboard === `qwerty`
              ? `sUITutorialInput2`
              : `sUITutorialInput`;
          (e.popup(
            t,
            30,
            `${n}\n[scale, 1][${i}, ${r}]`,
            `[wave]`,
            0.5,
            4,
            -1,
            I.TextUp,
          ),
            e.sfx(`sndWrong1`, 1, 1.5));
        };
      if (t[5])
        t[6] && !t[3]
          ? e.later(0.5, `seconds`, () => {
              ((e.stats.UI_unlock[3] = !0),
                n(2),
                r(
                  169,
                  `${e.L(`FORMAT_COLLECTION`)} ${e.L(`UI_UNLOCKED_PRONOUN2`)} !`,
                  2,
                ));
            })
          : !t[4] && e.count(Yn) === 0 && e.count(Gn) === 0
            ? ((t[4] = !0),
              n(3),
              r(
                200,
                `${e.L(`FORMAT_UPGRADES`)} ${e.L(`UI_UNLOCKED_PRONOUN3`)} !`,
                3,
              ))
            : !t[1] &&
                e.upgrades[3].level > 0 &&
                e.count(Yn) === 0 &&
                e.count(Gn) === 0
              ? ((t[1] = !0),
                n(0),
                r(
                  110,
                  `${e.L(`FORMAT_SHOP`)} ${e.L(`UI_UNLOCKED_PRONOUN2`)} !`,
                  0,
                ))
              : !t[2] &&
                vt(e.cards).length > 0 &&
                ((t[2] = !0),
                (t[1] = !0),
                n(1),
                n(0),
                r(
                  140,
                  `${e.L(`FORMAT_DUPLICATES`)} ${e.L(`UI_UNLOCKED_PRONOUN4`)} !`,
                  1,
                ),
                e.later(0.5, `seconds`, () => {
                  ((e.stats.tutorial_done = !0),
                    e.cameraShake(200),
                    (e.backgroundIndex = 0),
                    e.popup(
                      320 / 2,
                      180 / 2,
                      `CRACK THE PACK !${
                        e.stats.legacy_mode
                          ? `
[scale, .8](again...)`
                          : ``
                      }`,
                      `[shake][rainbow]`,
                      1,
                      3,
                      -1,
                      I.TextUp,
                    ),
                    e.sfx(`sndExplosion1`, 1, 0.8),
                    e.flash(16777215),
                    Qn(
                      e,
                      1,
                      Math.min(1e3, Math.round(e.stats.money_legacy / 1e3)),
                    ),
                    e.audio.stopMusic(),
                    (e.musicAlarm = 1),
                    e.later(10, `seconds`, () => this.saveWithPopup()));
                }));
      else {
        t[5] = !0;
        let n = JSON.parse(JSON.stringify(e.boosters[0]));
        ((n.quantity = [2, 2]),
          (n.proba = [100, 0, 0, 0]),
          Wn(e, n),
          e.later(1, `seconds`, () => {
            ((e.stats.UI_unlock[0] = !0),
              e.particle(`impactSmall`, 72, 7, 16777215, I.ParticlesUp),
              e.cameraShake(5),
              e.sfx(`sndWrong1`, 1, 1.5),
              e.audio.playMusic(`mscTuto`, !0));
          }));
      }
    }
  };
function li(e, t) {
  (e.audio.playTrack(t <= 0 ? `mscCollectionFull` : `mscBoardRush`, 1),
    e.sfx(`sndExplosion2`, 1, 1, !1, !1));
  for (let t of e.all(tn)) t.isSelected = !1;
  (e.popup(
    320 / 2,
    180 / 2,
    `${t <= 0 ? `` : t} ${(t <= 0 ? e.L(`UI_COLLECTION_FULL`) : e.L(`FORMAT_CARDS`)).toUpperCase()}`,
    `[shake][d#6008319]`,
    1,
    5,
    -1,
    I.TextUp,
  ),
    e.cameraShake(50, !1),
    e.flash(13193295),
    (e.speedMod = 1),
    e.audio.stopMusic(),
    (e.musicAlarm = 60 * (t <= 0 ? 50 : 4.9)),
    (e.musicI = 1 + Math.floor(Math.random() * 5) - 1));
}
function ui(e) {
  let t = 0;
  for (let n of e.all(tn))
    if (n.isSelected) {
      t = n.ID + 1;
      break;
    }
  let n = Jt(e, `module`);
  if (n && n.x < 300) {
    let e = cn.indexOf(n.titleKey);
    e >= 0 && (t = 6 + e);
  }
  (e.godpackActive && (t = 10),
    e.audio.isPlaying(`mscCollectionFull`) && (t = 11),
    e.stats.tutorial_done &&
      e.backgroundIndex !== t &&
      (e.backgroundIndex = t));
}
function di(e) {
  (Gt(e), (e.drawBackground = () => e.drawBoard()), e.add(new ci(e), I.UI));
  let t = e.add(new Kt(e, `shop`, -160, 27, 9, 7.5, sn.shop));
  ((t.titleKey = `FORMAT_SHOP`),
    (t.funcDraw = () => {
      t.xs < 12 && e.up(34) > 0
        ? (t.xs = 12)
        : t.xs < 16 && e.up(54) > 0 && (t.xs = 16);
    }));
  let n = e.add(new Kt(e, `onglets`, 96, 2, 6, 0.5, sn.bar));
  n.funcDraw = () => (n.yy = e.stats.UI_unlock[6] ? 2 : -25);
  let r = e.add(new Kt(e, `duplicate`, -321, 27, 9, 7.5, sn.duplicate));
  r.titleKey = `FORMAT_DUPLICATES`;
  let i = e.add(new Kt(e, `money`, 44, 2, 2, 0.5, sn.bar));
  i.funcDraw = () => (i.yy = e.stats.UI_unlock[5] ? 2 : -15);
  let a = e.add(new Kt(e, `collection`, 10, 190, 15, 7.5, sn.collection));
  a.titleKey = `FORMAT_COLLECTION`;
  let o = e.add(new Kt(e, `upgrades`, 10, 540, 15, 7.5, sn.upgrades));
  ((o.titleKey = `FORMAT_UPGRADES`), (o.funcDraw = () => ii(e, o)));
  let s = e.add(new Kt(e, `module`, 345, 27, 13.3, 7.5, D(10724259)));
  ((s.titleShadowOffset = 5),
    (n.y = n.yy = e.stats.UI_unlock[6] ? 2 : -25),
    (i.y = i.yy = e.stats.UI_unlock[5] ? 2 : -15));
  let c = [
      [-130, 70, 0, 6946705, 0, 16777215],
      [-90, 70, 1, 6008319, 200, 16777215],
      [-50, 70, 2, 8539010, 200, 16777215],
      [-10, 70, 3, 16224767, 0, 16777215],
      [-130, 135, 4, 6184703, 0, 16777215],
      [-90, 135, 5, 0, 0, 16777215],
      [-50, 135, 6, 8212525, 0, 14540253],
      [-10, 135, 7, 3249231, 0, 16777215],
    ],
    l = (e) => ((e & 255) << 16) | (((e >> 8) & 255) << 8) | ((e >> 16) & 255);
  for (let [t, n, r, i, a, o] of c) {
    let s = e.add(new qr(e, t, n, r, l(i), a, o));
    r === 7 &&
      (s.func = () => {
        let t = e.boosters[7],
          n = 1.15;
        ((t.quantity[1] = Math.min(333, Math.max(1, t.quantity[1] * n))),
          (t.price = Math.min(1e9, Math.max(1, t.price * n * 1.5))),
          (t.cooldown *= n),
          (s.stats = JSON.parse(JSON.stringify(t))));
      });
  }
  ((e.stampShop = (t) => oi(e, t)),
    e.add(new Sn(e, 47, 70)),
    e.add(new Sn(e, 47, 135)),
    [
      [96, 70, 0],
      [136, 70, 1],
      [96, 134, 2],
      [136, 134, 3],
    ].forEach(([t, n, r]) => e.add(new xn(e, t, n, r))),
    (e.shopCardsRefresh = () => e.all(Sn).forEach((e) => (e.alarm[0] = 5))),
    [-290, -250, -210, -170].forEach((t, n) => e.add(new Yr(e, t, 100, n + 1))),
    e.add(new Xr(e, -284, 55)),
    e.add(new nn(e, 81, 6)));
  let u = [110, 140, 170, 200].map((t, n) => e.add(new tn(e, t, 8, n))),
    d = e.add(new Zr(e, 20, 200)),
    f = e.add(new $r(e, 20, 217));
  ((u[2].onToggle = () => {
    (e.later(0.6, `seconds`, () => {
      d.y < 180 && d.refresh();
    }),
      u[2].isSelected && f.animate());
  }),
    (e.isOngletSelected = () => u.some((e) => e.isSelected)),
    (e.closeOnglets = () => u.forEach((e) => (e.isSelected = !1))),
    (e.moduleOpen = () => s.xx < 300));
  let p = e.add(new rn(e, 296, 270, 0, 16772502, `collection`));
  p.func = () => d.pageAdd(1);
  let m = e.add(new rn(e, 24, 270, 0, 16772502, `collection`));
  ((m.angleTo = 180), (m.func = () => d.pageAdd(-1)));
  let h = e.add(new rn(e, 245, 200, 3, l(9568105), `collection`));
  h.name = e.L(`UI_BUTTON_SORT_STAR`);
  let g = e.add(new rn(e, 270, 200, 4, 11776947, `collection`));
  ((g.name = e.L(`UI_BUTTON_SORT_QUANTITY`)),
    (h.func = () => {
      ((g.blend = O.ltgray),
        d.sortType === `stars`
          ? (d.starsAsc = !d.starsAsc)
          : (d.sortType = `stars`),
        (h.blend = d.starsAsc ? O.green : O.orange),
        d.refresh());
    }),
    (g.func = () => {
      ((h.blend = O.ltgray),
        d.sortType === `quantity`
          ? (d.qtyAsc = !d.qtyAsc)
          : (d.sortType = `quantity`),
        (g.blend = d.qtyAsc ? O.green : O.orange),
        d.refresh());
    }));
  // The initial root (570) becomes 580 in panel space: center y=70 when open.
  for (let [t, n, r, i] of si) e.add(new ti(e, n, r + 10, t, i));
  (e.add(new ai(e, 0, 0), I.UI), (e.employeesSleep = !1));
  let _ = e.add(new rn(e, 22, 14, 7, D(6946705), ``)),
    v = () =>
      `[d#${e.employeesSleep ? 6008319 : 6946705}]${e.L(`UI_BUTTON_EMPLOYEE_SLEEP_${e.employeesSleep ? `YES` : `NO`}`)}`;
  ((_.name = e.L(`UI_BUTTON_EMPLOYEE_SLEEP_NO`)),
    (_.func = () => {
      ((e.employeesSleep = !e.employeesSleep),
        (_.blend = D(e.employeesSleep ? 6008319 : 6946705)),
        (_.frame = e.employeesSleep ? 6 : 7),
        (_.name = v()));
    }),
    (_.activate = !1),
    e.add(new er(e, 161, 90), I.InstancesTop),
    e.add(new an(e, 154, 4), I.InstancesTop));
}
var fi = `crack-the-pack-vault`,
  pi = `assets`,
  mi = `sprite_atlas`;
function hi() {
  return new Promise((e, t) => {
    let n = indexedDB.open(fi, 1);
    ((n.onupgradeneeded = () => {
      let e = n.result;
      e.objectStoreNames.contains(pi) || e.createObjectStore(pi);
    }),
      (n.onsuccess = () => e(n.result)),
      (n.onerror = () => t(n.error)));
  });
}
async function gi() {
  try {
    let e = await hi();
    return new Promise((t) => {
      let n = e.transaction(pi, `readonly`).objectStore(pi).get(mi);
      ((n.onsuccess = () => {
        t(n.result instanceof Blob ? n.result : null);
      }),
        (n.onerror = () => t(null)));
    });
  } catch {
    return null;
  }
}
async function _i(e) {
  let t = await hi();
  return new Promise((n, r) => {
    let i = t.transaction(pi, `readwrite`).objectStore(pi).put(e, mi);
    ((i.onsuccess = () => n()), (i.onerror = () => r(i.error)));
  });
}
var vi = o((e) => {
    var t = Symbol.for(`react.transitional.element`);
    function n(e, n, r) {
      var i = null;
      if (
        (r !== void 0 && (i = `` + r),
        n.key !== void 0 && (i = `` + n.key),
        `key` in n)
      )
        for (var a in ((r = {}), n)) a !== `key` && (r[a] = n[a]);
      else r = n;
      return (
        (n = r.ref),
        { $$typeof: t, type: e, key: i, ref: n === void 0 ? null : n, props: r }
      );
    }
    ((e.jsx = n), (e.jsxs = n));
  }),
  yi = o((e, t) => {
    t.exports = vi();
  })(),
  bi = {
    mask: `/ctp/game/fx/mask.png`,
    slot: `/ctp/game/fx/slot.png`,
    underwater: `/ctp/game/fx/underwater.png`,
    heathaze: `/ctp/game/fx/heathaze.png`,
  };
function xi({ atlasUrl: e }) {
  let t = (0, _.useRef)(null),
    [n, r] = (0, _.useState)(`loading`),
    [i, a] = (0, _.useState)(``);
  return (
    (0, _.useEffect)(() => {
      let n = t.current,
        i = 0,
        o = !1,
        s;
      try {
        s = new Ve(n);
      } catch (e) {
        (a(e instanceof Error ? e.message : String(e)), r(`error`));
        return;
      }
      let c = new Ft(s);
      window.__ctp = c;
      (c.load(),
        Gt(c),
        (c.roomBuilders = {
          rmMenuIntro: Mr,
          rmMenu: Nr,
          rmGame: (e) => {
            (di(e), Pr(e));
          },
          rmEnding: Ur,
          rmCredits: Wr,
        }),
        s.resize(),
        c.input.attach(n, s));
      let l = !0;
      ((c.input.onGesture = () => {
        (c.audio.unlock(),
          (c.room === `rmMenuIntro` || c.room === `rmMenu`) && Dr(c),
          l && ((l = !1), or()));
      }),
        (c.input.onFourFingerTap = () => {
          ir() || or();
        }));
      let u = 0,
        d = () => {
          (s.resize(), cancelAnimationFrame(u));
          let e = 0,
            t = () => {
              (s.resize(), ++e < 10 && (u = requestAnimationFrame(t)));
            };
          u = requestAnimationFrame(t);
        },
        f = new ResizeObserver(() => s.resize());
      (f.observe(n),
        window.addEventListener(`resize`, d),
        window.addEventListener(`orientationchange`, d),
        window.visualViewport?.addEventListener(`resize`, d),
        document.addEventListener(`fullscreenchange`, d));
      let p = () => {
        document.visibilityState === `hidden`
          ? (c.save(), c.audio.suspend())
          : c.audio.resume();
      };
      document.addEventListener(`visibilitychange`, p);
      let m = () => c.save();
      window.addEventListener(`pagehide`, m);
      let h = new URLSearchParams(location.search).has(`rawsprites`);
      return (
        (async () => {
          if (h) return s.loadSprites(`/ctp/game`, y, bi);
          let t = e;
          if (!t) {
            let e = await gi();
            e && (t = URL.createObjectURL(e));
          }
          if (!t)
            throw Error(
              `No sprite atlas found. Please launch from asset loader.`,
            );
          return s.loadAtlas(t, bi);
        })()
          .then(() => {
            if (o) return;
            (r(`running`), c.gotoRoom(`rmMenuIntro`), (c.started = !0));
            let e = performance.now(),
              t = 0,
              n = (r) => {
                if (o) return;
                ((t += Math.min(250, r - e)), (e = r));
                let a = 1e3 / 60,
                  s = 0;
                for (; t >= a && s < 5;) (c.step(), (t -= a), s++);
                (s >= 5 && (t = 0),
                  c.draw(r / 1e3),
                  (i = requestAnimationFrame(n)));
              };
            i = requestAnimationFrame(n);
          })
          .catch((e) => {
            (a(String(e)), r(`error`));
          }),
        () => {
          ((o = !0),
            cancelAnimationFrame(i),
            c.save(),
            c.audio.stopAll(),
            c.input.detach(),
            cancelAnimationFrame(u),
            f.disconnect(),
            window.removeEventListener(`resize`, d),
            window.removeEventListener(`orientationchange`, d),
            window.visualViewport?.removeEventListener(`resize`, d),
            document.removeEventListener(`fullscreenchange`, d),
            document.removeEventListener(`visibilitychange`, p),
            window.removeEventListener(`pagehide`, m));
        }
      );
    }, []),
    (0, yi.jsxs)(`div`, {
      className: `relative h-dvh w-full overflow-hidden bg-background select-none`,
      children: [
        (0, yi.jsx)(`canvas`, {
          ref: t,
          className: `absolute inset-0 h-full w-full touch-none`,
          style: {
            cursor: n === `running` ? `none` : `default`,
            imageRendering: `pixelated`,
          },
          "aria-label": `Crack the Pack`,
        }),
        n === `loading` &&
          (0, yi.jsx)(`div`, {
            className: `absolute inset-0 bg-black pointer-events-none`,
          }),
        n === `error` &&
          (0, yi.jsxs)(`div`, {
            className: `absolute inset-0 flex items-center justify-center p-6 text-center font-pixel text-lg text-destructive`,
            children: [`This device can't run the game: `, i],
          }),
        (0, yi.jsxs)(`div`, {
          className: `rotate-hint pointer-events-none absolute inset-0 hidden flex-col items-center justify-center gap-6 bg-background font-pixel text-foreground`,
          children: [
            (0, yi.jsx)(`div`, {
              className: `rotate-hint-phone`,
              "aria-hidden": !0,
            }),
            (0, yi.jsx)(`p`, {
              className: `px-8 text-center text-xl`,
              children: `Turn your phone sideways to play`,
            }),
          ],
        }),
      ],
    })
  );
}
function Si({ onVerified: e }) {
  let t = (0, _.useRef)(null),
    n = (0, _.useRef)(null),
    [r, i] = (0, _.useState)(`idle`),
    [a, o] = (0, _.useState)(``),
    [s, c] = (0, _.useState)(0),
    [l, u] = (0, _.useState)(``),
    d = (0, _.useRef)(r);
  d.current = r;
  let f = (0, _.useRef)(l);
  f.current = l;
  let p = (0, _.useRef)(s);
  p.current = s;
  let m = (0, _.useRef)(a);
  m.current = a;
  let h = (0, _.useRef)(null),
    g = (e, t = 0.8) => {
      try {
        let n = new Audio(`/ctp/game/audio/${e}.mp3`);
        ((n.volume = t), n.play().catch(() => {}));
      } catch {}
    },
    v = () => {
      if (!h.current) {
        let e = new Audio(`/ctp/game/audio/mscTitle.mp3`);
        ((e.loop = !0), (e.volume = 0.65), (h.current = e));
      }
      h.current.play().catch(() => {});
    },
    b = 0;
  return (
    (0, _.useEffect)(() => {
      let cv = t.current;
      if (!cv) return;
      v();
      // ---------- art: the loose sprite files that ship with the port ----------
      let img = (s) => {
          let i = new Image();
          return ((i.src = `/ctp/game/${s}.png`), i);
        },
        A = {
          board: img(`sprites/sBGBoard_0`),
          logo: img(`sprites/sLogo_0`),
          cadre: img(`sprites/sUICadre_0`),
          bar: img(`sprites/sUIBar_0`),
          cursor: img(`sprites/sCursor_0`),
          font: img(`fonts/fontBase`),
          mask: img(`fx/mask`),
          slot: img(`fx/slot`),
          water: img(`fx/underwater`),
        },
        ok = (i) => i.complete && i.naturalWidth > 0,
        tints = new Map(),
        // Multiply-tint an image like the game's sprite blend colour (cached per colour)
        tint = (i, c) => {
          if (!ok(i)) return null;
          let k = i.src + `|` + c,
            o = tints.get(k);
          if (o) return o;
          ((o = document.createElement(`canvas`)),
            (o.width = i.naturalWidth),
            (o.height = i.naturalHeight));
          let x = o.getContext(`2d`);
          return (
            x.drawImage(i, 0, 0),
            (x.globalCompositeOperation = `multiply`),
            (x.fillStyle = c),
            x.fillRect(0, 0, o.width, o.height),
            (x.globalCompositeOperation = `destination-in`),
            x.drawImage(i, 0, 0),
            tints.set(k, o),
            o
          );
        };
      // ---------- canvases ----------
      let board = document.createElement(`canvas`);
      board.height = 180;
      let bx = board.getContext(`2d`),
        gui = document.createElement(`canvas`),
        gx = gui.getContext(`2d`),
        W = 0,
        H = 0,
        S = 1,
        padX = 0,
        BW = 320,
        resize = () => {
          let e = Math.min(2, window.devicePixelRatio || 1),
            t = Math.max(1, Math.round(cv.clientWidth * e)),
            n = Math.max(1, Math.round(cv.clientHeight * e));
          (t === W && n === H) ||
            ((W = t),
            (H = n),
            (cv.width = W),
            (cv.height = H),
            (gui.width = W),
            (gui.height = H),
            (S = H / 180),
            (BW = Math.max(320, Math.ceil(W / S))),
            (padX = (W / S - 320) / 2),
            (board.width = BW));
        };
      resize();
      // ---------- room-space drawing helpers (room = 320x180, like the game) ----------
      let X = (e) => Math.round((e + padX) * S),
        Y = (e) => Math.round(e * S),
        // 9-slice with unscaled corners, exactly like the game's renderer (ns = [l, t, r, b])
        nine = (e, t, n, r, i, a) => {
          if (!e) return;
          let [o, s, c, l] = t,
            u = e.width,
            d = e.height,
            f = X(n),
            p = X(n + i),
            m = Y(r),
            h = Y(r + a),
            g = [f, f + Math.round(Math.min(o, i / 2) * S), p - Math.round(Math.min(c, i / 2) * S), p],
            _ = [m, m + Math.round(Math.min(s, a / 2) * S), h - Math.round(Math.min(l, a / 2) * S), h],
            v = [0, o, u - c, u],
            y = [0, s, d - l, d];
          for (let t = 0; t < 3; t++)
            for (let n = 0; n < 3; n++)
              g[n + 1] - g[n] > 0 &&
                _[t + 1] - _[t] > 0 &&
                gx.drawImage(e, v[n], y[t], v[n + 1] - v[n], y[t + 1] - y[t], g[n], _[t], g[n + 1] - g[n], _[t + 1] - _[t]);
        },
        // The game's top-bar box: sUICadre 9-slice, grey, 0.9 alpha, soft drop shadow
        panel = (e, t, n, r, i = `#707070`, a = 0.9) => {
          ((gx.globalAlpha = 0.5),
            nine(tint(A.cadre, `#000000`), [3, 3, 3, 3], e + 2, t + 2, n, r),
            (gx.globalAlpha = a),
            nine(tint(A.cadre, i), [3, 3, 3, 3], e, t, n, r),
            (gx.globalAlpha = 1));
        },
        bar = (e, t, n, r, i) => {
          (nine(tint(A.bar, `#404040`), [2, 2, 3, 2], e, t, n, 10),
            r > 0 && nine(tint(A.bar, i), [2, 2, 3, 2], e, t, Math.max(1, n * Math.min(1, r)), 10));
        },
        G = ve.font.glyphs,
        LH = ve.font.lineHeight,
        measure = (e, t) => {
          let n = 0;
          for (let r of e) n += ((G[r.charCodeAt(0)] || G[63])[4] || 0) * t;
          return n;
        },
        // Bitmap text with the game's own font; [wave] and the 1px shadow match the game's text
        text = (e, t, n, r, i = `#ffffff`, a = !1, o = `center`, s = 1) => {
          let c = tint(A.font, i),
            l = tint(A.font, `#000000`);
          if (!c || !l) return;
          let u = measure(e, r),
            d = o === `center` ? t - Math.trunc(u / 2) : o === `right` ? t - u : t,
            f = n - (LH * r) / 2,
            p = performance.now() * 0.06,
            m = 0;
          for (let t of e) {
            let n = t.charCodeAt(0),
              i = G[n] || G[63],
              o = y[n] || y[63];
            if (n !== 32 && o) {
              let e = a ? 1.5 * Math.sin(m + 0.05 * p) : 0,
                t = d + i[5] * r,
                c2 = X(t),
                u2 = Math.max(1, X(t + i[2] * r) - c2),
                h2 = Math.round(i[3] * r * S);
              (s > 0 &&
                ((gx.globalAlpha = 0.5 * s),
                gx.drawImage(l, o[0], o[1], i[2], i[3], X(t + 1), Y(f + e + 1), u2, h2)),
                (gx.globalAlpha = 1),
                gx.drawImage(c, o[0], o[1], i[2], i[3], c2, Y(f + e), u2, h2));
            }
            ((d += i[4] * r), m++);
          }
          gx.globalAlpha = 1;
        },
        wrap = (e, t, n) => {
          let r = [],
            i = ``;
          for (let a of e.split(` `)) {
            let e = i ? i + ` ` + a : a;
            measure(e, t) > n && i ? (r.push(i), (i = a)) : (i = e);
          }
          return (i && r.push(i), r.slice(0, 3));
        };
      // ---------- WebGL: the game's CRT shader on the board, then the GUI bent with the same warp ----------
      let gl =
          cv.getContext(`webgl2`, { alpha: !1, antialias: !1, premultipliedAlpha: !1 }) ||
          cv.getContext(`webgl`, { alpha: !1, antialias: !1, premultipliedAlpha: !1 }),
        crt = null,
        water = null,
        fbo = null,
        fboW = 0,
        warp = null,
        quad = null,
        tex = {},
        L = Be(1, 1);
      if (gl)
        try {
          let e = `attribute vec2 a_p; varying vec2 v_vTexcoord; varying vec4 v_vColour;
void main(){ v_vTexcoord = a_p; v_vColour = vec4(1.0); gl_Position = vec4(a_p.x*2.0-1.0, 1.0-a_p.y*2.0, 0.0, 1.0); }`,
            t = (t) => {
              let n = (e, t) => {
                  let n = gl.createShader(e);
                  if ((gl.shaderSource(n, t), gl.compileShader(n), !gl.getShaderParameter(n, gl.COMPILE_STATUS)))
                    throw Error(gl.getShaderInfoLog(n) || `shader`);
                  return n;
                },
                r = gl.createProgram();
              if (
                (gl.attachShader(r, n(gl.VERTEX_SHADER, e)),
                gl.attachShader(r, n(gl.FRAGMENT_SHADER, t)),
                gl.linkProgram(r),
                !gl.getProgramParameter(r, gl.LINK_STATUS))
              )
                throw Error(gl.getProgramInfoLog(r) || `link`);
              let i = {};
              return {
                p: r,
                a: gl.getAttribLocation(r, `a_p`),
                u: (e) => (e in i ? i[e] : (i[e] = gl.getUniformLocation(r, e))),
              };
            };
          // Same vertex layout, but no y-flip, for passes that render into a texture
          let ef = e.replace(`1.0-a_p.y*2.0`, `a_p.y*2.0-1.0`),
            tf = (n) => {
              let r = e;
              e = ef;
              try {
                return t(n);
              } finally {
                e = r;
              }
            };
          ((crt = t(ye + be)),
            (water = tf(ye + Te)),
            (warp = t(`precision mediump float;
varying vec2 v_vTexcoord; uniform sampler2D gm_BaseTexture; uniform float u_curvature; uniform vec2 u_output_size;
vec2 crt_warp(vec2 t){ vec2 c = t - 0.5; return c * ((1.0 + u_curvature * dot(c, c)) / (1.0 + u_curvature * 0.25)) + 0.5; }
void main(){
  vec2 uv = crt_warp(v_vTexcoord);
  vec2 px = min(uv, 1.0 - uv) * u_output_size;
  float edge = clamp(min(px.x, px.y) / 1.5 + 0.5, 0.0, 1.0);
  gl_FragColor = texture2D(gm_BaseTexture, clamp(uv, 0.0, 1.0)) * edge;
}`)),
            (quad = gl.createBuffer()),
            gl.bindBuffer(gl.ARRAY_BUFFER, quad),
            gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([0, 0, 1, 0, 0, 1, 0, 1, 1, 0, 1, 1]), gl.STATIC_DRAW));
          let n = (e, t) => {
            let n = gl.createTexture();
            return (
              gl.bindTexture(gl.TEXTURE_2D, n),
              gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, e),
              gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, e),
              gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, t),
              gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, t),
              gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([0, 0, 0, 255])),
              n
            );
          };
          ((tex.board = n(gl.NEAREST, gl.CLAMP_TO_EDGE)),
            (tex.app = n(gl.LINEAR, gl.CLAMP_TO_EDGE)),
            (tex.water = n(gl.LINEAR, gl.REPEAT)),
            (fbo = gl.createFramebuffer()),
            (tex.gui = n(gl.LINEAR, gl.CLAMP_TO_EDGE)),
            (tex.mask = n(gl.NEAREST, gl.REPEAT)),
            (tex.slot = n(gl.NEAREST, gl.REPEAT)),
            (tex.black = n(gl.NEAREST, gl.CLAMP_TO_EDGE)));
          let r = (e, t) => {
            let n = () => {
              (gl.bindTexture(gl.TEXTURE_2D, t),
                gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, !1),
                gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, e));
            };
            ok(e) ? n() : e.addEventListener(`load`, n, { once: !0 });
          };
          (r(A.mask, tex.mask), r(A.slot, tex.slot), r(A.water, tex.water));
        } catch (e) {
          (console.warn(`Launcher CRT init failed:`, e), (crt = null));
        }
      let pass = (e) => {
        (gl.bindBuffer(gl.ARRAY_BUFFER, quad),
          gl.enableVertexAttribArray(e.a),
          gl.vertexAttribPointer(e.a, 2, gl.FLOAT, !1, 0, 0),
          gl.drawArrays(gl.TRIANGLES, 0, 6));
      };
      // ---------- input (pointer goes through the same warp as the picture) ----------
      let mouse = { x: 160, y: 120, on: !1, touch: !1 },
        btn = { x: 105, y: 131, w: 110, h: 18 },
        hover = !1,
        press = !1,
        tap = { x: 160, y: 120, on: !1, upAt: -1e9 },
        lastTouch = -1e9,
        lastOpen = -1e9,
        // One picker per press: taps also fire emulated mouse events, which used to re-open it
        openPicker = () => {
          let e = performance.now();
          busy() || e - lastOpen < 1500 || ((lastOpen = e), n.current?.click());
        },
        fromTouch = () => performance.now() - lastTouch < 1e3,
        toRoom = (e, t) => {
          let n = cv.getBoundingClientRect(),
            r = ctpWarp((e - n.left) / n.width, (t - n.top) / n.height, crt ? L.curvature : 0);
          return { x: (r[0] * W) / S - padX, y: r[1] * 180 };
        },
        inBtn = (e) => e.x >= btn.x && e.x <= btn.x + btn.w && e.y >= btn.y && e.y <= btn.y + btn.h,
        busy = () => d.current === `loading` || d.current === `baking`,
        onMove = (e) => {
          if (fromTouch()) return;
          let t = toRoom(e.clientX, e.clientY);
          ((mouse.x = t.x), (mouse.y = t.y), (mouse.on = !0), (mouse.touch = !1));
          let n = hover;
          ((hover = inBtn(t) && !busy()), !n && hover && g(`sndCardFlip1`, 0.4));
        },
        onDown = (e) => {
          fromTouch() ||
            (v(), onMove(e), hover && ((press = !0), g(`sndCardStamp`, 0.6)));
        },
        onUp = () => {
          fromTouch() || (press && ((press = !1), openPicker()));
        },
        onTouchStart = (e) => {
          if (((lastTouch = performance.now()), v(), e.touches.length > 0)) {
            let t = toRoom(e.touches[0].clientX, e.touches[0].clientY);
            ((mouse.touch = !0),
              (mouse.on = !1),
              (tap.x = t.x),
              (tap.y = t.y),
              (tap.on = !0),
              inBtn(t) && !busy() && ((press = !0), (hover = !0), g(`sndCardStamp`, 0.6)));
          }
        },
        onTouchMove = (e) => {
          if (((lastTouch = performance.now()), e.touches.length > 0)) {
            let t = toRoom(e.touches[0].clientX, e.touches[0].clientY);
            ((tap.x = t.x), (tap.y = t.y));
          }
        },
        onTouchEnd = (e) => {
          ((lastTouch = performance.now()),
            e.touches.length === 0 && ((tap.on = !1), (tap.upAt = performance.now())));
          let t = press && inBtn(tap);
          ((press = !1), (hover = !1), t && openPicker());
        };
      (window.addEventListener(`mousemove`, onMove),
        window.addEventListener(`mousedown`, onDown),
        window.addEventListener(`mouseup`, onUp),
        cv.addEventListener(`touchstart`, onTouchStart, { passive: !0 }),
        cv.addEventListener(`touchmove`, onTouchMove, { passive: !0 }),
        cv.addEventListener(`touchend`, onTouchEnd, { passive: !0 }),
        cv.addEventListener(`touchcancel`, onTouchEnd, { passive: !0 }));
      // ---------- board scroll, same motion as the in-game board ----------
      let bgX = 0,
        bgY = 0,
        bgOffX = 0,
        bgOffY = 0,
        bgSide = 1,
        beat = 0,
        beatLen = 60 / 150.2,
        logoRot = -3.5,
        logoRotTo = -3.5,
        logoPulse = 1,
        acc = 0,
        last = performance.now(),
        raf = 0,
        frame = (e) => {
          resize();
          let t = Math.min(0.25, (e - last) / 1e3);
          for (last = e, acc += t, beat += t; acc >= 1 / 60; )
            ((acc -= 1 / 60),
              (bgX += (bgOffX - bgX) * 0.3),
              (bgY += (bgOffY - bgY) * 0.3),
              (bgOffX += 0.25),
              (bgOffY -= 0.25),
              (logoRot += (logoRotTo - logoRot) * 0.22),
              (logoPulse += (1 - logoPulse) * 0.18));
          for (; beat >= beatLen; )
            ((beat -= beatLen),
              (bgOffX += 5 * bgSide),
              (bgSide *= -1),
              (logoRotTo = logoRotTo < 0 ? 3.5 : -3.5),
              (logoPulse = 1.05));
          // board (room resolution, nearest pixels, tinted like the game)
          ((bx.fillStyle = `#000000`), bx.fillRect(0, 0, BW, 180));
          let n = tint(A.board, `#d3d3d3`);
          if (n) {
            let e = ((bgX % 50) + 50) % 50,
              t = ((bgY % 50) + 50) % 50,
              r = Math.floor(padX);
            for (let i = -50; i < 230; i += 50)
              for (let a = Math.floor(-r / 50) * 50 - 50; a < BW - r + 50; a += 50)
                bx.drawImage(n, Math.round(a + e + r), Math.round(i + t));
          }
          // GUI at screen resolution
          (gx.setTransform(1, 0, 0, 1, 0, 0), gx.clearRect(0, 0, W, H), (gx.imageSmoothingEnabled = !1));
          let r = e / 1e3;
          if (ok(A.logo)) {
            let e = 150 * logoPulse,
              t = (e * A.logo.naturalHeight) / A.logo.naturalWidth;
            (gx.save(),
              gx.translate(X(160), Y(46 + Math.sin(r * 2.8) * 1.5)),
              gx.rotate((logoRot * Math.PI) / 180),
              (gx.imageSmoothingEnabled = !0),
              (gx.imageSmoothingQuality = `high`),
              gx.drawImage(A.logo, (-e / 2) * S, (-t / 2) * S, e * S, t * S),
              gx.restore(),
              (gx.imageSmoothingEnabled = !1));
          }
          (panel(50, 91, 220, 80),
            text(`INSERT ASSETS`, 160, 102, 0.5, `#ffffff`, !0),
            text(`Select the original data.win`, 160, 114, 0.35, `#c0c0c0`),
            text(`to extract the game assets`, 160, 121, 0.35, `#c0c0c0`));
          let i = busy();
          if (i) {
            let e = p.current / 100;
            (bar(80, 140, 160, e, `#ff7171`),
              text(`${Math.round(p.current)}%`, 160, 145, 0.4, `#ffffff`),
              text(f.current || `Decompressing...`, 160, 160, 0.3, `#c0c0c0`));
          } else {
            let e = press ? 1 : 0;
            (panel(btn.x, btn.y + e, btn.w, btn.h, hover ? `#404040` : `#ffffff`, 1),
              text(`select data.win`, 160, btn.y + btn.h / 2 + e, 0.45, hover ? `#ffffff` : `#404040`, hover, `center`, hover ? 1 : 0),
              d.current === `error`
                ? wrap(`error: ${m.current}`, 0.3, 200).forEach((e, t, n) =>
                    text(e, 160, 160 + (t - (n.length - 1) / 2) * 6, 0.3, `#ff7171`),
                  )
                : text(`Assets are verified & saved offline on your device`, 160, 160, 0.28, `#c0c0c0`));
          }
          // Credit line, top-left of the visible screen; it shrinks to stay fully on
          // screen when the view is narrow (portrait), full size when there is room
          let creditTxt = `"By CreatriXstudioS, creator, repy."`,
            creditS = Math.min(0.28, (W / S - 28) / measure(creditTxt, 1));
          text(creditTxt, -padX + 14, 8, creditS, `#ffffff`, !0, `left`);
          // Cursor, same as the game's main menu: sCursor for the mouse; for touch a
          // pixel ring + dot that grow and fade out after the finger lifts (drawTouchCursor)
          let cur = (e, t, n, r) => {
            if (!ok(A.cursor) || n <= 0.05) return;
            let i = 20 * n;
            ((gx.globalAlpha = r),
              gx.drawImage(A.cursor, X(e - 9 * n), Y(t - 9 * n), Math.round(i * S), Math.round(i * S)),
              (gx.globalAlpha = 1));
          };
          if (mouse.on && !mouse.touch) cur(mouse.x, mouse.y, 1, 1);
          else if (mouse.touch) {
            let t = tap.on ? 0 : (e - tap.upAt) / 260;
            if (t < 1) {
              let n = 1 - (1 - t) * (1 - t),
                r = 1 - t,
                i = (6 + Math.sin(Date.now() / 400)) * (1 + 0.5 * n),
                a = Math.floor(tap.x),
                o = Math.floor(tap.y),
                s = Math.ceil(i) + 1;
              ((gx.globalAlpha = r), (gx.fillStyle = `#ffffff`));
              for (let e = -s; e <= s; e++)
                for (let t = -s; t <= s; t++)
                  Math.abs(Math.hypot(t, e) - i) < 0.5 &&
                    gx.fillRect(X(a + t), Y(o + e), X(a + t + 1) - X(a + t), Y(o + e + 1) - Y(o + e));
              ((gx.globalAlpha = 1), cur(tap.x, tap.y, 1 - n, r));
            }
          }
          if (gl && crt) {
            (gl.bindFramebuffer(gl.FRAMEBUFFER, null),
              gl.viewport(0, 0, W, H),
              gl.disable(gl.BLEND),
              gl.useProgram(crt.p),
              gl.activeTexture(gl.TEXTURE0),
              gl.bindTexture(gl.TEXTURE_2D, tex.board),
              gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, !1),
              gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, board));
            // In-game board wobble: the "underwater" layer filter, same uniforms as rmGame
            if (water && fbo) {
              (gl.bindTexture(gl.TEXTURE_2D, tex.app),
                fboW !== BW &&
                  ((fboW = BW),
                  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, BW, 180, 0, gl.RGBA, gl.UNSIGNED_BYTE, null)),
                gl.bindFramebuffer(gl.FRAMEBUFFER, fbo),
                gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex.app, 0),
                gl.viewport(0, 0, BW, 180),
                gl.useProgram(water.p),
                gl.activeTexture(gl.TEXTURE1),
                gl.bindTexture(gl.TEXTURE_2D, tex.water),
                gl.activeTexture(gl.TEXTURE0),
                gl.bindTexture(gl.TEXTURE_2D, tex.board));
              let e = water.u,
                t = r;
              (gl.uniform1i(e(`gm_BaseTexture`), 0),
                gl.uniform1i(e(`g_DistortTexture`), 1),
                gl.uniform2f(e(`gm_pSurfaceDimensions`), BW, 180),
                gl.uniform1f(e(`gm_pPreMultiplyAlpha`), 1),
                gl.uniform2f(e(`gm_pSurfaceTexelSize`), 1 / BW, 1 / 180),
                gl.uniform2f(e(`gm_pCamOffset`), 0, 0),
                gl.uniform2f(e(`g_DistortTextureTexelSize`), 1 / 256, 1 / 256),
                gl.uniform1f(e(`g_Distort1Speed`), (t * 0.004) % 1),
                gl.uniform1f(e(`g_Distort2Speed`), (t * 0.015) % 1),
                gl.uniform2f(e(`g_Distort1Scale`), 20, 2),
                gl.uniform2f(e(`g_Distort2Scale`), 100, 10),
                gl.uniform1f(e(`g_Distort1Amount`), 3),
                gl.uniform1f(e(`g_Distort2Amount`), 6),
                gl.uniform1f(e(`g_ChromaSpreadAmount`), 0),
                gl.uniform1f(e(`g_CamOffsetScale`), 1),
                gl.uniform4f(e(`g_GlintCol`), 0, 0, 0, 1),
                gl.uniform4f(e(`g_TintCol`), 1, 1, 1, 1),
                gl.uniform4f(e(`g_AddCol`), 0, 0, 0, 1),
                pass(water),
                gl.bindFramebuffer(gl.FRAMEBUFFER, null),
                gl.viewport(0, 0, W, H),
                gl.useProgram(crt.p),
                gl.activeTexture(gl.TEXTURE0),
                gl.bindTexture(gl.TEXTURE_2D, tex.app));
            }
            (gl.activeTexture(gl.TEXTURE1),
              gl.bindTexture(gl.TEXTURE_2D, tex.mask),
              gl.activeTexture(gl.TEXTURE2),
              gl.bindTexture(gl.TEXTURE_2D, tex.slot),
              gl.activeTexture(gl.TEXTURE3),
              gl.bindTexture(gl.TEXTURE_2D, tex.black));
            let e = (e, t) => gl.uniform1f(crt.u(e), t);
            (gl.uniform1i(crt.u(`gm_BaseTexture`), 0),
              gl.uniform1i(crt.u(`u_mask_sampler`), 1),
              gl.uniform1i(crt.u(`u_slot_sampler`), 2),
              gl.uniform1i(crt.u(`u_bloom_sampler`), 3),
              gl.uniform2f(crt.u(`u_content_size`), BW, 180),
              gl.uniform2f(crt.u(`u_output_size`), W, H),
              gl.uniform2f(crt.u(`u_output_offset`), 0, 0),
              e(`u_aspect_ratio`, BW / 180),
              e(`u_zoom`, 1),
              e(`u_curvature`, L.curvature),
              e(`u_do_int_scale`, 0),
              e(`u_image_softness`, L.softness),
              e(`u_do_tate`, 0),
              e(`u_min_sigma`, 0.225),
              e(`u_max_sigma`, 0.5),
              e(`u_line_brightness`, L.brightness),
              e(`u_mask_strength`, L.mask),
              e(`u_slot_strength`, 1),
              e(`u_mask_do_shadow`, 0),
              e(`u_mask_tex_width`, 4),
              e(`u_mask_scale`, 1),
              e(`u_mask_repeat_on_three`, 1),
              e(`u_do_mask_mirror`, 0),
              e(`u_mask_fade`, 1),
              e(`u_border_width`, 0),
              e(`u_border_brightness`, 0.2),
              e(`u_time`, r * 60),
              e(`u_bloom_strength`, 0),
              e(`u_deconvergence`, L.deconvergence),
              e(`u_gamma`, -1),
              e(`u_do_interlace`, 0),
              pass(crt),
              gl.enable(gl.BLEND),
              gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA),
              gl.useProgram(warp.p),
              gl.activeTexture(gl.TEXTURE0),
              gl.bindTexture(gl.TEXTURE_2D, tex.gui),
              gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, !0),
              gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, gui),
              gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, !1),
              gl.uniform1i(warp.u(`gm_BaseTexture`), 0),
              gl.uniform1f(warp.u(`u_curvature`), L.curvature),
              gl.uniform2f(warp.u(`u_output_size`), W, H),
              pass(warp));
          }
          raf = requestAnimationFrame(frame);
        };
      return (
        (raf = requestAnimationFrame(frame)),
        () => {
          (cancelAnimationFrame(raf),
            window.removeEventListener(`mousemove`, onMove),
            window.removeEventListener(`mousedown`, onDown),
            window.removeEventListener(`mouseup`, onUp),
            cv.removeEventListener(`touchstart`, onTouchStart),
            cv.removeEventListener(`touchmove`, onTouchMove),
            cv.removeEventListener(`touchend`, onTouchEnd),
            cv.removeEventListener(`touchcancel`, onTouchEnd),
            (h.current &&= (h.current.pause(), null)));
        }
      );
    }, []),
    (0, yi.jsxs)(`div`, {
      className: `h-screen w-screen bg-black overflow-hidden select-none m-0 p-0`,
      style: { cursor: `none` },
      children: [
        (0, yi.jsx)(`input`, {
          type: `file`,
          ref: n,
          onChange: async (t) => {
            console.log(
              `handleFileChange triggered, file:`,
              t.target.files?.[0]?.name,
            );
            let n = t.target.files?.[0];
            if (n) {
              (i(`loading`),
                o(``),
                c(10),
                u(`Reading data.win...`),
                g(`sndCardStamp`));
              try {
                let t = await n.arrayBuffer();
                if (t.byteLength < 16)
                  throw Error(
                    `File is too small to be a valid GameMaker data.win.`,
                  );
                let r = new Uint8Array(t, 0, 4);
                if (String.fromCharCode(...r) !== `FORM`)
                  throw Error(
                    `Invalid asset file. Must be a GameMaker data.win file (FORM header missing).`,
                  );
                (c(25), u(`Starting decompiler worker...`));
                let a = await new Promise((e, r) => {
                  let i;
                  try {
                    i = new Worker(`/ctp/assets/import.worker.js`, {
                      type: `module`,
                    });
                  } catch (e) {
                    r(
                      Error(
                        `Failed to initialize decompiler worker: ` + e.message,
                      ),
                    );
                    return;
                  }
                  ((i.onmessage = (t) => {
                    console.log(`Worker msg:`, t.data.type, t.data.p?.stage);
                    let n = t.data;
                    if (n.type === `progress`) {
                      let e = n.p;
                      if (e.stage === `sprites`) {
                        let t =
                          25 + Math.round((e.done / Math.max(1, e.total)) * 45);
                        (c(t),
                          u(
                            `Extracting sprite frames (${e.done}/${e.total})...`,
                          ),
                          e.done % 25 == 0 && g(`sndBarTick`, 0.3));
                      } else
                        e.stage === `textures` &&
                          (c(72), u(`Parsing texture regions...`));
                    } else
                      n.type === `result`
                        ? (i.terminate(),
                          console.log(
                            `Worker result res.ok:`,
                            n.res?.ok,
                            `files count:`,
                            n.res?.files?.length,
                          ),
                          n.res && n.res.ok && n.res.files
                            ? e(n.res.files)
                            : r(
                                Error(
                                  n.res?.identification?.reason ||
                                    `Validation failed for this data.win.`,
                                ),
                              ))
                        : n.type === `error` &&
                          (i.terminate(),
                          r(Error(n.message || `Decompiler error.`)));
                  }),
                    (i.onerror = (e) => {
                      (console.error(`Worker onerror:`, e),
                        i.terminate(),
                        r(Error(e.message || `Decompiler worker crashed.`)));
                    }),
                    i.postMessage(
                      { dataWin: t, fileName: n.name, extras: [] },
                      [t],
                    ));
                });
                (i(`baking`),
                  c(78),
                  console.log(`Stitching 2048x2048 sprite sheet...`),
                  u(`Stitching 2048x2048 sprite sheet...`),
                  g(`sndCardStamp`));
                let o = new Map();
                for (let e of a) o.set(e.path, e.data);
                let s = document.createElement(`canvas`);
                ((s.width = ve.w), (s.height = ve.h));
                let l = s.getContext(`2d`, { willReadFrequently: !1 }),
                  d = [];
                for (let [e, t] of Object.entries(ve.sprites))
                  for (let n = 0; n < t.f.length; n++) {
                    let [r, i] = t.f[n],
                      a = `assets/sprites/${e}_${n}.png`,
                      s = o.get(a);
                    s &&
                      d.push(
                        (async () => {
                          let e = new Blob([s], { type: `image/png` }),
                            n = await createImageBitmap(e);
                          (l.drawImage(
                            n,
                            r,
                            i,
                            t.tw || n.width,
                            t.th || n.height,
                          ),
                            n.close());
                        })(),
                      );
                  }
                (await Promise.all(d),
                  (l.fillStyle = `#ffffff`),
                  l.fillRect(ve.white[0], ve.white[1], 4, 4),
                  c(90),
                  u(`Stitching font glyphs & UI...`));
                let f =
                  o.get(`assets/textures/fonts/fontBase.png`) ||
                  o.get(`assets/fonts/fontBase.png`);
                if (f) {
                  let e = new Blob([f], { type: `image/png` }),
                    t = await createImageBitmap(e),
                    n = y;
                  for (let [e, r] of Object.entries(ve.font.glyphs)) {
                    let [i, a, o, s] = r,
                      c = n[e];
                    c &&
                      o > 0 &&
                      s > 0 &&
                      l.drawImage(t, c[0], c[1], o, s, i, a, o, s);
                  }
                }
                (c(96), u(`Saving atlas to offline vault...`));
                let p = await new Promise((e, t) => {
                  s.toBlob((n) => {
                    n ? e(n) : t(Error(`Failed to encode sprite atlas`));
                  }, `image/png`);
                });
                (console.log(`Saving atlas to vault...`),
                  await _i(p),
                  console.log(`Saved atlas to vault successfully!`),
                  c(100),
                  u(`Ready! Launching game...`),
                  g(`sndApplause`),
                  h.current && h.current.pause(),
                  setTimeout(() => {
                    let t = URL.createObjectURL(p);
                    (console.log(`Calling onVerified with url:`, t), e(t));
                  }, 500));
              } catch (e) {
                (console.error(`DECOMPILER ERROR:`, e),
                  i(`error`),
                  o(e.message || `Failed to decompile data.win.`),
                  g(`sndBoosterHurt`));
              }
            }
          },
          accept: `.win,*/*`,
          className: `hidden`,
        }),
        (0, yi.jsx)(`canvas`, {
          ref: t,
          className: `block w-full h-full touch-none`,
          style: { cursor: `none` },
          onClick: () => v(),
        }),
      ],
    })
  );
}
function Ci() {
  let [e, t] = (0, _.useState)(null),
    [n, r] = (0, _.useState)(!0);
  return (
    (0, _.useEffect)(() => {
      gi().then((e) => {
        (e && t(URL.createObjectURL(e)), r(!1));
      });
    }, []),
    n
      ? (0, yi.jsx)(`div`, {
          className: `h-screen w-screen bg-black m-0 p-0 overflow-hidden`,
        })
      : e
        ? (0, yi.jsx)(`div`, {
            className: `h-screen w-screen overflow-hidden bg-black m-0 p-0`,
            children: (0, yi.jsx)(xi, { atlasUrl: e }),
          })
        : (0, yi.jsx)(Si, { onVerified: (e) => t(e) })
  );
}
v.createRoot(document.getElementById(`root`)).render(
  (0, yi.jsx)(_.StrictMode, { children: (0, yi.jsx)(Ci, {}) }),
);
